
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ArrSourceKey",
    "ArrSourceSysKey",
    "TransferAmtType",
    "TransferAmt",
    "TransferUnits",
    "TransferPct",
    "SubAcctName",
    "AnnualIndex",
    "OLifEExtension",
    "id",
    "SubAcctID",
    "PaymentPartyID",
    "BankingInfoID",
    "DataRep",
    "HoldingID"
})
@Generated("jsonschema2pojo")
public class ArrSource {

    @JsonProperty("ArrSourceKey")
    private ArrSourceKey arrSourceKey;
    @JsonProperty("ArrSourceSysKey")
    private List<Object> arrSourceSysKey = new ArrayList<>();
    @JsonProperty("TransferAmtType")
    private TransferAmtType transferAmtType;
    @JsonProperty("TransferAmt")
    private Integer transferAmt;
    @JsonProperty("TransferUnits")
    private Integer transferUnits;
    @JsonProperty("TransferPct")
    private Integer transferPct;
    @JsonProperty("SubAcctName")
    private String subAcctName;
    @JsonProperty("AnnualIndex")
    private Integer annualIndex;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("SubAcctID")
    private String subAcctID;
    @JsonProperty("PaymentPartyID")
    private String paymentPartyID;
    @JsonProperty("BankingInfoID")
    private String bankingInfoID;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonProperty("HoldingID")
    private String holdingID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ArrSourceKey")
    public ArrSourceKey getArrSourceKey() {
        return arrSourceKey;
    }

    @JsonProperty("ArrSourceKey")
    public void setArrSourceKey(ArrSourceKey arrSourceKey) {
        this.arrSourceKey = arrSourceKey;
    }

    public ArrSource withArrSourceKey(ArrSourceKey arrSourceKey) {
        this.arrSourceKey = arrSourceKey;
        return this;
    }

    @JsonProperty("ArrSourceSysKey")
    public List<Object> getArrSourceSysKey() {
        return arrSourceSysKey;
    }

    @JsonProperty("ArrSourceSysKey")
    public void setArrSourceSysKey(List<Object> arrSourceSysKey) {
        this.arrSourceSysKey = arrSourceSysKey;
    }

    public ArrSource withArrSourceSysKey(List<Object> arrSourceSysKey) {
        this.arrSourceSysKey = arrSourceSysKey;
        return this;
    }

    @JsonProperty("TransferAmtType")
    public TransferAmtType getTransferAmtType() {
        return transferAmtType;
    }

    @JsonProperty("TransferAmtType")
    public void setTransferAmtType(TransferAmtType transferAmtType) {
        this.transferAmtType = transferAmtType;
    }

    public ArrSource withTransferAmtType(TransferAmtType transferAmtType) {
        this.transferAmtType = transferAmtType;
        return this;
    }

    @JsonProperty("TransferAmt")
    public Integer getTransferAmt() {
        return transferAmt;
    }

    @JsonProperty("TransferAmt")
    public void setTransferAmt(Integer transferAmt) {
        this.transferAmt = transferAmt;
    }

    public ArrSource withTransferAmt(Integer transferAmt) {
        this.transferAmt = transferAmt;
        return this;
    }

    @JsonProperty("TransferUnits")
    public Integer getTransferUnits() {
        return transferUnits;
    }

    @JsonProperty("TransferUnits")
    public void setTransferUnits(Integer transferUnits) {
        this.transferUnits = transferUnits;
    }

    public ArrSource withTransferUnits(Integer transferUnits) {
        this.transferUnits = transferUnits;
        return this;
    }

    @JsonProperty("TransferPct")
    public Integer getTransferPct() {
        return transferPct;
    }

    @JsonProperty("TransferPct")
    public void setTransferPct(Integer transferPct) {
        this.transferPct = transferPct;
    }

    public ArrSource withTransferPct(Integer transferPct) {
        this.transferPct = transferPct;
        return this;
    }

    @JsonProperty("SubAcctName")
    public String getSubAcctName() {
        return subAcctName;
    }

    @JsonProperty("SubAcctName")
    public void setSubAcctName(String subAcctName) {
        this.subAcctName = subAcctName;
    }

    public ArrSource withSubAcctName(String subAcctName) {
        this.subAcctName = subAcctName;
        return this;
    }

    @JsonProperty("AnnualIndex")
    public Integer getAnnualIndex() {
        return annualIndex;
    }

    @JsonProperty("AnnualIndex")
    public void setAnnualIndex(Integer annualIndex) {
        this.annualIndex = annualIndex;
    }

    public ArrSource withAnnualIndex(Integer annualIndex) {
        this.annualIndex = annualIndex;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public ArrSource withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public ArrSource withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("SubAcctID")
    public String getSubAcctID() {
        return subAcctID;
    }

    @JsonProperty("SubAcctID")
    public void setSubAcctID(String subAcctID) {
        this.subAcctID = subAcctID;
    }

    public ArrSource withSubAcctID(String subAcctID) {
        this.subAcctID = subAcctID;
        return this;
    }

    @JsonProperty("PaymentPartyID")
    public String getPaymentPartyID() {
        return paymentPartyID;
    }

    @JsonProperty("PaymentPartyID")
    public void setPaymentPartyID(String paymentPartyID) {
        this.paymentPartyID = paymentPartyID;
    }

    public ArrSource withPaymentPartyID(String paymentPartyID) {
        this.paymentPartyID = paymentPartyID;
        return this;
    }

    @JsonProperty("BankingInfoID")
    public String getBankingInfoID() {
        return bankingInfoID;
    }

    @JsonProperty("BankingInfoID")
    public void setBankingInfoID(String bankingInfoID) {
        this.bankingInfoID = bankingInfoID;
    }

    public ArrSource withBankingInfoID(String bankingInfoID) {
        this.bankingInfoID = bankingInfoID;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public ArrSource withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonProperty("HoldingID")
    public String getHoldingID() {
        return holdingID;
    }

    @JsonProperty("HoldingID")
    public void setHoldingID(String holdingID) {
        this.holdingID = holdingID;
    }

    public ArrSource withHoldingID(String holdingID) {
        this.holdingID = holdingID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ArrSource withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ArrSource.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("arrSourceKey");
        sb.append('=');
        sb.append(((this.arrSourceKey == null)?"<null>":this.arrSourceKey));
        sb.append(',');
        sb.append("arrSourceSysKey");
        sb.append('=');
        sb.append(((this.arrSourceSysKey == null)?"<null>":this.arrSourceSysKey));
        sb.append(',');
        sb.append("transferAmtType");
        sb.append('=');
        sb.append(((this.transferAmtType == null)?"<null>":this.transferAmtType));
        sb.append(',');
        sb.append("transferAmt");
        sb.append('=');
        sb.append(((this.transferAmt == null)?"<null>":this.transferAmt));
        sb.append(',');
        sb.append("transferUnits");
        sb.append('=');
        sb.append(((this.transferUnits == null)?"<null>":this.transferUnits));
        sb.append(',');
        sb.append("transferPct");
        sb.append('=');
        sb.append(((this.transferPct == null)?"<null>":this.transferPct));
        sb.append(',');
        sb.append("subAcctName");
        sb.append('=');
        sb.append(((this.subAcctName == null)?"<null>":this.subAcctName));
        sb.append(',');
        sb.append("annualIndex");
        sb.append('=');
        sb.append(((this.annualIndex == null)?"<null>":this.annualIndex));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("subAcctID");
        sb.append('=');
        sb.append(((this.subAcctID == null)?"<null>":this.subAcctID));
        sb.append(',');
        sb.append("paymentPartyID");
        sb.append('=');
        sb.append(((this.paymentPartyID == null)?"<null>":this.paymentPartyID));
        sb.append(',');
        sb.append("bankingInfoID");
        sb.append('=');
        sb.append(((this.bankingInfoID == null)?"<null>":this.bankingInfoID));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("holdingID");
        sb.append('=');
        sb.append(((this.holdingID == null)?"<null>":this.holdingID));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.transferUnits == null)? 0 :this.transferUnits.hashCode()));
        result = ((result* 31)+((this.holdingID == null)? 0 :this.holdingID.hashCode()));
        result = ((result* 31)+((this.arrSourceKey == null)? 0 :this.arrSourceKey.hashCode()));
        result = ((result* 31)+((this.subAcctName == null)? 0 :this.subAcctName.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.annualIndex == null)? 0 :this.annualIndex.hashCode()));
        result = ((result* 31)+((this.transferPct == null)? 0 :this.transferPct.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.arrSourceSysKey == null)? 0 :this.arrSourceSysKey.hashCode()));
        result = ((result* 31)+((this.transferAmtType == null)? 0 :this.transferAmtType.hashCode()));
        result = ((result* 31)+((this.subAcctID == null)? 0 :this.subAcctID.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.bankingInfoID == null)? 0 :this.bankingInfoID.hashCode()));
        result = ((result* 31)+((this.transferAmt == null)? 0 :this.transferAmt.hashCode()));
        result = ((result* 31)+((this.paymentPartyID == null)? 0 :this.paymentPartyID.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ArrSource) == false) {
            return false;
        }
        ArrSource rhs = ((ArrSource) other);
        return (((((((((((((((((this.transferUnits == rhs.transferUnits)||((this.transferUnits!= null)&&this.transferUnits.equals(rhs.transferUnits)))&&((this.holdingID == rhs.holdingID)||((this.holdingID!= null)&&this.holdingID.equals(rhs.holdingID))))&&((this.arrSourceKey == rhs.arrSourceKey)||((this.arrSourceKey!= null)&&this.arrSourceKey.equals(rhs.arrSourceKey))))&&((this.subAcctName == rhs.subAcctName)||((this.subAcctName!= null)&&this.subAcctName.equals(rhs.subAcctName))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.annualIndex == rhs.annualIndex)||((this.annualIndex!= null)&&this.annualIndex.equals(rhs.annualIndex))))&&((this.transferPct == rhs.transferPct)||((this.transferPct!= null)&&this.transferPct.equals(rhs.transferPct))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.arrSourceSysKey == rhs.arrSourceSysKey)||((this.arrSourceSysKey!= null)&&this.arrSourceSysKey.equals(rhs.arrSourceSysKey))))&&((this.transferAmtType == rhs.transferAmtType)||((this.transferAmtType!= null)&&this.transferAmtType.equals(rhs.transferAmtType))))&&((this.subAcctID == rhs.subAcctID)||((this.subAcctID!= null)&&this.subAcctID.equals(rhs.subAcctID))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.bankingInfoID == rhs.bankingInfoID)||((this.bankingInfoID!= null)&&this.bankingInfoID.equals(rhs.bankingInfoID))))&&((this.transferAmt == rhs.transferAmt)||((this.transferAmt!= null)&&this.transferAmt.equals(rhs.transferAmt))))&&((this.paymentPartyID == rhs.paymentPartyID)||((this.paymentPartyID!= null)&&this.paymentPartyID.equals(rhs.paymentPartyID))));
    }

}
