
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SeqNum",
    "PolicyActivity",
    "PolicyActivityDate",
    "OLifEExtension"
})
@Generated("jsonschema2pojo")
public class PolicyActivityList {

    @JsonProperty("SeqNum")
    private Integer seqNum;
    @JsonProperty("PolicyActivity")
    private PolicyActivity policyActivity;
    @JsonProperty("PolicyActivityDate")
    private String policyActivityDate;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("SeqNum")
    public Integer getSeqNum() {
        return seqNum;
    }

    @JsonProperty("SeqNum")
    public void setSeqNum(Integer seqNum) {
        this.seqNum = seqNum;
    }

    public PolicyActivityList withSeqNum(Integer seqNum) {
        this.seqNum = seqNum;
        return this;
    }

    @JsonProperty("PolicyActivity")
    public PolicyActivity getPolicyActivity() {
        return policyActivity;
    }

    @JsonProperty("PolicyActivity")
    public void setPolicyActivity(PolicyActivity policyActivity) {
        this.policyActivity = policyActivity;
    }

    public PolicyActivityList withPolicyActivity(PolicyActivity policyActivity) {
        this.policyActivity = policyActivity;
        return this;
    }

    @JsonProperty("PolicyActivityDate")
    public String getPolicyActivityDate() {
        return policyActivityDate;
    }

    @JsonProperty("PolicyActivityDate")
    public void setPolicyActivityDate(String policyActivityDate) {
        this.policyActivityDate = policyActivityDate;
    }

    public PolicyActivityList withPolicyActivityDate(String policyActivityDate) {
        this.policyActivityDate = policyActivityDate;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public PolicyActivityList withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PolicyActivityList withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(PolicyActivityList.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("seqNum");
        sb.append('=');
        sb.append(((this.seqNum == null)?"<null>":this.seqNum));
        sb.append(',');
        sb.append("policyActivity");
        sb.append('=');
        sb.append(((this.policyActivity == null)?"<null>":this.policyActivity));
        sb.append(',');
        sb.append("policyActivityDate");
        sb.append('=');
        sb.append(((this.policyActivityDate == null)?"<null>":this.policyActivityDate));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.policyActivityDate == null)? 0 :this.policyActivityDate.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.policyActivity == null)? 0 :this.policyActivity.hashCode()));
        result = ((result* 31)+((this.seqNum == null)? 0 :this.seqNum.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PolicyActivityList) == false) {
            return false;
        }
        PolicyActivityList rhs = ((PolicyActivityList) other);
        return ((((((this.policyActivityDate == rhs.policyActivityDate)||((this.policyActivityDate!= null)&&this.policyActivityDate.equals(rhs.policyActivityDate)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.policyActivity == rhs.policyActivity)||((this.policyActivity!= null)&&this.policyActivity.equals(rhs.policyActivity))))&&((this.seqNum == rhs.seqNum)||((this.seqNum!= null)&&this.seqNum.equals(rhs.seqNum))));
    }

}
