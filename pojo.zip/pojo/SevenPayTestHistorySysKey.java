
package haj.com.astute.json.to.pojo;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Value",
    "Persist",
    "SystemCode",
    "VendorCode"
})
@Generated("jsonschema2pojo")
public class SevenPayTestHistorySysKey {

    @JsonProperty("Value")
    private String value;
    @JsonProperty("Persist")
    private String persist;
    @JsonProperty("SystemCode")
    private String systemCode;
    @JsonProperty("VendorCode")
    private String vendorCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("Value")
    public String getValue() {
        return value;
    }

    @JsonProperty("Value")
    public void setValue(String value) {
        this.value = value;
    }

    public SevenPayTestHistorySysKey withValue(String value) {
        this.value = value;
        return this;
    }

    @JsonProperty("Persist")
    public String getPersist() {
        return persist;
    }

    @JsonProperty("Persist")
    public void setPersist(String persist) {
        this.persist = persist;
    }

    public SevenPayTestHistorySysKey withPersist(String persist) {
        this.persist = persist;
        return this;
    }

    @JsonProperty("SystemCode")
    public String getSystemCode() {
        return systemCode;
    }

    @JsonProperty("SystemCode")
    public void setSystemCode(String systemCode) {
        this.systemCode = systemCode;
    }

    public SevenPayTestHistorySysKey withSystemCode(String systemCode) {
        this.systemCode = systemCode;
        return this;
    }

    @JsonProperty("VendorCode")
    public String getVendorCode() {
        return vendorCode;
    }

    @JsonProperty("VendorCode")
    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    public SevenPayTestHistorySysKey withVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SevenPayTestHistorySysKey withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(SevenPayTestHistorySysKey.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("value");
        sb.append('=');
        sb.append(((this.value == null)?"<null>":this.value));
        sb.append(',');
        sb.append("persist");
        sb.append('=');
        sb.append(((this.persist == null)?"<null>":this.persist));
        sb.append(',');
        sb.append("systemCode");
        sb.append('=');
        sb.append(((this.systemCode == null)?"<null>":this.systemCode));
        sb.append(',');
        sb.append("vendorCode");
        sb.append('=');
        sb.append(((this.vendorCode == null)?"<null>":this.vendorCode));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.persist == null)? 0 :this.persist.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.value == null)? 0 :this.value.hashCode()));
        result = ((result* 31)+((this.systemCode == null)? 0 :this.systemCode.hashCode()));
        result = ((result* 31)+((this.vendorCode == null)? 0 :this.vendorCode.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SevenPayTestHistorySysKey) == false) {
            return false;
        }
        SevenPayTestHistorySysKey rhs = ((SevenPayTestHistorySysKey) other);
        return ((((((this.persist == rhs.persist)||((this.persist!= null)&&this.persist.equals(rhs.persist)))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.value == rhs.value)||((this.value!= null)&&this.value.equals(rhs.value))))&&((this.systemCode == rhs.systemCode)||((this.systemCode!= null)&&this.systemCode.equals(rhs.systemCode))))&&((this.vendorCode == rhs.vendorCode)||((this.vendorCode!= null)&&this.vendorCode.equals(rhs.vendorCode))));
    }

}
