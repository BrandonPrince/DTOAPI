
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ComplexContentDescriptorKey",
    "ComplexContentDescriptorSysKey",
    "ComplexContentCode",
    "ContentSubType",
    "ScalingFactor",
    "DataType",
    "ContentCodeType",
    "CurrencyTypeCode",
    "Mode",
    "Description",
    "Sequence",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class ComplexContentDescriptor {

    @JsonProperty("ComplexContentDescriptorKey")
    private ComplexContentDescriptorKey complexContentDescriptorKey;
    @JsonProperty("ComplexContentDescriptorSysKey")
    private List<Object> complexContentDescriptorSysKey = new ArrayList<>();
    @JsonProperty("ComplexContentCode")
    private String complexContentCode;
    @JsonProperty("ContentSubType")
    private ContentSubType contentSubType;
    @JsonProperty("ScalingFactor")
    private Integer scalingFactor;
    @JsonProperty("DataType")
    private DataType dataType;
    @JsonProperty("ContentCodeType")
    private ContentCodeType contentCodeType;
    @JsonProperty("CurrencyTypeCode")
    private CurrencyTypeCode currencyTypeCode;
    @JsonProperty("Mode")
    private Mode mode;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("Sequence")
    private Integer sequence;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ComplexContentDescriptorKey")
    public ComplexContentDescriptorKey getComplexContentDescriptorKey() {
        return complexContentDescriptorKey;
    }

    @JsonProperty("ComplexContentDescriptorKey")
    public void setComplexContentDescriptorKey(ComplexContentDescriptorKey complexContentDescriptorKey) {
        this.complexContentDescriptorKey = complexContentDescriptorKey;
    }

    public ComplexContentDescriptor withComplexContentDescriptorKey(ComplexContentDescriptorKey complexContentDescriptorKey) {
        this.complexContentDescriptorKey = complexContentDescriptorKey;
        return this;
    }

    @JsonProperty("ComplexContentDescriptorSysKey")
    public List<Object> getComplexContentDescriptorSysKey() {
        return complexContentDescriptorSysKey;
    }

    @JsonProperty("ComplexContentDescriptorSysKey")
    public void setComplexContentDescriptorSysKey(List<Object> complexContentDescriptorSysKey) {
        this.complexContentDescriptorSysKey = complexContentDescriptorSysKey;
    }

    public ComplexContentDescriptor withComplexContentDescriptorSysKey(List<Object> complexContentDescriptorSysKey) {
        this.complexContentDescriptorSysKey = complexContentDescriptorSysKey;
        return this;
    }

    @JsonProperty("ComplexContentCode")
    public String getComplexContentCode() {
        return complexContentCode;
    }

    @JsonProperty("ComplexContentCode")
    public void setComplexContentCode(String complexContentCode) {
        this.complexContentCode = complexContentCode;
    }

    public ComplexContentDescriptor withComplexContentCode(String complexContentCode) {
        this.complexContentCode = complexContentCode;
        return this;
    }

    @JsonProperty("ContentSubType")
    public ContentSubType getContentSubType() {
        return contentSubType;
    }

    @JsonProperty("ContentSubType")
    public void setContentSubType(ContentSubType contentSubType) {
        this.contentSubType = contentSubType;
    }

    public ComplexContentDescriptor withContentSubType(ContentSubType contentSubType) {
        this.contentSubType = contentSubType;
        return this;
    }

    @JsonProperty("ScalingFactor")
    public Integer getScalingFactor() {
        return scalingFactor;
    }

    @JsonProperty("ScalingFactor")
    public void setScalingFactor(Integer scalingFactor) {
        this.scalingFactor = scalingFactor;
    }

    public ComplexContentDescriptor withScalingFactor(Integer scalingFactor) {
        this.scalingFactor = scalingFactor;
        return this;
    }

    @JsonProperty("DataType")
    public DataType getDataType() {
        return dataType;
    }

    @JsonProperty("DataType")
    public void setDataType(DataType dataType) {
        this.dataType = dataType;
    }

    public ComplexContentDescriptor withDataType(DataType dataType) {
        this.dataType = dataType;
        return this;
    }

    @JsonProperty("ContentCodeType")
    public ContentCodeType getContentCodeType() {
        return contentCodeType;
    }

    @JsonProperty("ContentCodeType")
    public void setContentCodeType(ContentCodeType contentCodeType) {
        this.contentCodeType = contentCodeType;
    }

    public ComplexContentDescriptor withContentCodeType(ContentCodeType contentCodeType) {
        this.contentCodeType = contentCodeType;
        return this;
    }

    @JsonProperty("CurrencyTypeCode")
    public CurrencyTypeCode getCurrencyTypeCode() {
        return currencyTypeCode;
    }

    @JsonProperty("CurrencyTypeCode")
    public void setCurrencyTypeCode(CurrencyTypeCode currencyTypeCode) {
        this.currencyTypeCode = currencyTypeCode;
    }

    public ComplexContentDescriptor withCurrencyTypeCode(CurrencyTypeCode currencyTypeCode) {
        this.currencyTypeCode = currencyTypeCode;
        return this;
    }

    @JsonProperty("Mode")
    public Mode getMode() {
        return mode;
    }

    @JsonProperty("Mode")
    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public ComplexContentDescriptor withMode(Mode mode) {
        this.mode = mode;
        return this;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    public ComplexContentDescriptor withDescription(String description) {
        this.description = description;
        return this;
    }

    @JsonProperty("Sequence")
    public Integer getSequence() {
        return sequence;
    }

    @JsonProperty("Sequence")
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public ComplexContentDescriptor withSequence(Integer sequence) {
        this.sequence = sequence;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public ComplexContentDescriptor withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public ComplexContentDescriptor withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public ComplexContentDescriptor withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ComplexContentDescriptor withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ComplexContentDescriptor.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("complexContentDescriptorKey");
        sb.append('=');
        sb.append(((this.complexContentDescriptorKey == null)?"<null>":this.complexContentDescriptorKey));
        sb.append(',');
        sb.append("complexContentDescriptorSysKey");
        sb.append('=');
        sb.append(((this.complexContentDescriptorSysKey == null)?"<null>":this.complexContentDescriptorSysKey));
        sb.append(',');
        sb.append("complexContentCode");
        sb.append('=');
        sb.append(((this.complexContentCode == null)?"<null>":this.complexContentCode));
        sb.append(',');
        sb.append("contentSubType");
        sb.append('=');
        sb.append(((this.contentSubType == null)?"<null>":this.contentSubType));
        sb.append(',');
        sb.append("scalingFactor");
        sb.append('=');
        sb.append(((this.scalingFactor == null)?"<null>":this.scalingFactor));
        sb.append(',');
        sb.append("dataType");
        sb.append('=');
        sb.append(((this.dataType == null)?"<null>":this.dataType));
        sb.append(',');
        sb.append("contentCodeType");
        sb.append('=');
        sb.append(((this.contentCodeType == null)?"<null>":this.contentCodeType));
        sb.append(',');
        sb.append("currencyTypeCode");
        sb.append('=');
        sb.append(((this.currencyTypeCode == null)?"<null>":this.currencyTypeCode));
        sb.append(',');
        sb.append("mode");
        sb.append('=');
        sb.append(((this.mode == null)?"<null>":this.mode));
        sb.append(',');
        sb.append("description");
        sb.append('=');
        sb.append(((this.description == null)?"<null>":this.description));
        sb.append(',');
        sb.append("sequence");
        sb.append('=');
        sb.append(((this.sequence == null)?"<null>":this.sequence));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.complexContentDescriptorKey == null)? 0 :this.complexContentDescriptorKey.hashCode()));
        result = ((result* 31)+((this.dataType == null)? 0 :this.dataType.hashCode()));
        result = ((result* 31)+((this.scalingFactor == null)? 0 :this.scalingFactor.hashCode()));
        result = ((result* 31)+((this.description == null)? 0 :this.description.hashCode()));
        result = ((result* 31)+((this.contentSubType == null)? 0 :this.contentSubType.hashCode()));
        result = ((result* 31)+((this.mode == null)? 0 :this.mode.hashCode()));
        result = ((result* 31)+((this.sequence == null)? 0 :this.sequence.hashCode()));
        result = ((result* 31)+((this.currencyTypeCode == null)? 0 :this.currencyTypeCode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.complexContentCode == null)? 0 :this.complexContentCode.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.complexContentDescriptorSysKey == null)? 0 :this.complexContentDescriptorSysKey.hashCode()));
        result = ((result* 31)+((this.contentCodeType == null)? 0 :this.contentCodeType.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ComplexContentDescriptor) == false) {
            return false;
        }
        ComplexContentDescriptor rhs = ((ComplexContentDescriptor) other);
        return ((((((((((((((((this.complexContentDescriptorKey == rhs.complexContentDescriptorKey)||((this.complexContentDescriptorKey!= null)&&this.complexContentDescriptorKey.equals(rhs.complexContentDescriptorKey)))&&((this.dataType == rhs.dataType)||((this.dataType!= null)&&this.dataType.equals(rhs.dataType))))&&((this.scalingFactor == rhs.scalingFactor)||((this.scalingFactor!= null)&&this.scalingFactor.equals(rhs.scalingFactor))))&&((this.description == rhs.description)||((this.description!= null)&&this.description.equals(rhs.description))))&&((this.contentSubType == rhs.contentSubType)||((this.contentSubType!= null)&&this.contentSubType.equals(rhs.contentSubType))))&&((this.mode == rhs.mode)||((this.mode!= null)&&this.mode.equals(rhs.mode))))&&((this.sequence == rhs.sequence)||((this.sequence!= null)&&this.sequence.equals(rhs.sequence))))&&((this.currencyTypeCode == rhs.currencyTypeCode)||((this.currencyTypeCode!= null)&&this.currencyTypeCode.equals(rhs.currencyTypeCode))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.complexContentCode == rhs.complexContentCode)||((this.complexContentCode!= null)&&this.complexContentCode.equals(rhs.complexContentCode))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.complexContentDescriptorSysKey == rhs.complexContentDescriptorSysKey)||((this.complexContentDescriptorSysKey!= null)&&this.complexContentDescriptorSysKey.equals(rhs.complexContentDescriptorSysKey))))&&((this.contentCodeType == rhs.contentCodeType)||((this.contentCodeType!= null)&&this.contentCodeType.equals(rhs.contentCodeType))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
