
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "QualifiedPlanEntityExcludeKey",
    "QualifiedPlanEntityExcludeSysKey",
    "EntityType",
    "AccountDesignationCC",
    "QualifiedPlanOption",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class QualifiedPlanEntityExclude {

    @JsonProperty("QualifiedPlanEntityExcludeKey")
    private QualifiedPlanEntityExcludeKey qualifiedPlanEntityExcludeKey;
    @JsonProperty("QualifiedPlanEntityExcludeSysKey")
    private List<Object> qualifiedPlanEntityExcludeSysKey = new ArrayList<>();
    @JsonProperty("EntityType")
    private EntityType entityType;
    @JsonProperty("AccountDesignationCC")
    private AccountDesignationCC accountDesignationCC;
    @JsonProperty("QualifiedPlanOption")
    private List<Object> qualifiedPlanOption = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("QualifiedPlanEntityExcludeKey")
    public QualifiedPlanEntityExcludeKey getQualifiedPlanEntityExcludeKey() {
        return qualifiedPlanEntityExcludeKey;
    }

    @JsonProperty("QualifiedPlanEntityExcludeKey")
    public void setQualifiedPlanEntityExcludeKey(QualifiedPlanEntityExcludeKey qualifiedPlanEntityExcludeKey) {
        this.qualifiedPlanEntityExcludeKey = qualifiedPlanEntityExcludeKey;
    }

    public QualifiedPlanEntityExclude withQualifiedPlanEntityExcludeKey(QualifiedPlanEntityExcludeKey qualifiedPlanEntityExcludeKey) {
        this.qualifiedPlanEntityExcludeKey = qualifiedPlanEntityExcludeKey;
        return this;
    }

    @JsonProperty("QualifiedPlanEntityExcludeSysKey")
    public List<Object> getQualifiedPlanEntityExcludeSysKey() {
        return qualifiedPlanEntityExcludeSysKey;
    }

    @JsonProperty("QualifiedPlanEntityExcludeSysKey")
    public void setQualifiedPlanEntityExcludeSysKey(List<Object> qualifiedPlanEntityExcludeSysKey) {
        this.qualifiedPlanEntityExcludeSysKey = qualifiedPlanEntityExcludeSysKey;
    }

    public QualifiedPlanEntityExclude withQualifiedPlanEntityExcludeSysKey(List<Object> qualifiedPlanEntityExcludeSysKey) {
        this.qualifiedPlanEntityExcludeSysKey = qualifiedPlanEntityExcludeSysKey;
        return this;
    }

    @JsonProperty("EntityType")
    public EntityType getEntityType() {
        return entityType;
    }

    @JsonProperty("EntityType")
    public void setEntityType(EntityType entityType) {
        this.entityType = entityType;
    }

    public QualifiedPlanEntityExclude withEntityType(EntityType entityType) {
        this.entityType = entityType;
        return this;
    }

    @JsonProperty("AccountDesignationCC")
    public AccountDesignationCC getAccountDesignationCC() {
        return accountDesignationCC;
    }

    @JsonProperty("AccountDesignationCC")
    public void setAccountDesignationCC(AccountDesignationCC accountDesignationCC) {
        this.accountDesignationCC = accountDesignationCC;
    }

    public QualifiedPlanEntityExclude withAccountDesignationCC(AccountDesignationCC accountDesignationCC) {
        this.accountDesignationCC = accountDesignationCC;
        return this;
    }

    @JsonProperty("QualifiedPlanOption")
    public List<Object> getQualifiedPlanOption() {
        return qualifiedPlanOption;
    }

    @JsonProperty("QualifiedPlanOption")
    public void setQualifiedPlanOption(List<Object> qualifiedPlanOption) {
        this.qualifiedPlanOption = qualifiedPlanOption;
    }

    public QualifiedPlanEntityExclude withQualifiedPlanOption(List<Object> qualifiedPlanOption) {
        this.qualifiedPlanOption = qualifiedPlanOption;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public QualifiedPlanEntityExclude withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public QualifiedPlanEntityExclude withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public QualifiedPlanEntityExclude withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public QualifiedPlanEntityExclude withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(QualifiedPlanEntityExclude.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("qualifiedPlanEntityExcludeKey");
        sb.append('=');
        sb.append(((this.qualifiedPlanEntityExcludeKey == null)?"<null>":this.qualifiedPlanEntityExcludeKey));
        sb.append(',');
        sb.append("qualifiedPlanEntityExcludeSysKey");
        sb.append('=');
        sb.append(((this.qualifiedPlanEntityExcludeSysKey == null)?"<null>":this.qualifiedPlanEntityExcludeSysKey));
        sb.append(',');
        sb.append("entityType");
        sb.append('=');
        sb.append(((this.entityType == null)?"<null>":this.entityType));
        sb.append(',');
        sb.append("accountDesignationCC");
        sb.append('=');
        sb.append(((this.accountDesignationCC == null)?"<null>":this.accountDesignationCC));
        sb.append(',');
        sb.append("qualifiedPlanOption");
        sb.append('=');
        sb.append(((this.qualifiedPlanOption == null)?"<null>":this.qualifiedPlanOption));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.qualifiedPlanEntityExcludeKey == null)? 0 :this.qualifiedPlanEntityExcludeKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.qualifiedPlanOption == null)? 0 :this.qualifiedPlanOption.hashCode()));
        result = ((result* 31)+((this.entityType == null)? 0 :this.entityType.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.accountDesignationCC == null)? 0 :this.accountDesignationCC.hashCode()));
        result = ((result* 31)+((this.qualifiedPlanEntityExcludeSysKey == null)? 0 :this.qualifiedPlanEntityExcludeSysKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof QualifiedPlanEntityExclude) == false) {
            return false;
        }
        QualifiedPlanEntityExclude rhs = ((QualifiedPlanEntityExclude) other);
        return ((((((((((this.qualifiedPlanEntityExcludeKey == rhs.qualifiedPlanEntityExcludeKey)||((this.qualifiedPlanEntityExcludeKey!= null)&&this.qualifiedPlanEntityExcludeKey.equals(rhs.qualifiedPlanEntityExcludeKey)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.qualifiedPlanOption == rhs.qualifiedPlanOption)||((this.qualifiedPlanOption!= null)&&this.qualifiedPlanOption.equals(rhs.qualifiedPlanOption))))&&((this.entityType == rhs.entityType)||((this.entityType!= null)&&this.entityType.equals(rhs.entityType))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.accountDesignationCC == rhs.accountDesignationCC)||((this.accountDesignationCC!= null)&&this.accountDesignationCC.equals(rhs.accountDesignationCC))))&&((this.qualifiedPlanEntityExcludeSysKey == rhs.qualifiedPlanEntityExcludeSysKey)||((this.qualifiedPlanEntityExcludeSysKey!= null)&&this.qualifiedPlanEntityExcludeSysKey.equals(rhs.qualifiedPlanEntityExcludeSysKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
