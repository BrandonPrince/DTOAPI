
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "IdentificationKey",
    "IdentificationSysKey",
    "IdentificationNum",
    "IdentityVerificationType",
    "IdentificationExpDate",
    "PictureIDInd",
    "Jurisdiction",
    "Nation",
    "IdentificationIssueDate",
    "IssuingAgency",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class Identification {

    @JsonProperty("IdentificationKey")
    private IdentificationKey identificationKey;
    @JsonProperty("IdentificationSysKey")
    private List<Object> identificationSysKey = new ArrayList<>();
    @JsonProperty("IdentificationNum")
    private String identificationNum;
    @JsonProperty("IdentityVerificationType")
    private IdentityVerificationType identityVerificationType;
    @JsonProperty("IdentificationExpDate")
    private String identificationExpDate;
    @JsonProperty("PictureIDInd")
    private PictureIDInd pictureIDInd;
    @JsonProperty("Jurisdiction")
    private Jurisdiction jurisdiction;
    @JsonProperty("Nation")
    private Nation nation;
    @JsonProperty("IdentificationIssueDate")
    private String identificationIssueDate;
    @JsonProperty("IssuingAgency")
    private String issuingAgency;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("IdentificationKey")
    public IdentificationKey getIdentificationKey() {
        return identificationKey;
    }

    @JsonProperty("IdentificationKey")
    public void setIdentificationKey(IdentificationKey identificationKey) {
        this.identificationKey = identificationKey;
    }

    public Identification withIdentificationKey(IdentificationKey identificationKey) {
        this.identificationKey = identificationKey;
        return this;
    }

    @JsonProperty("IdentificationSysKey")
    public List<Object> getIdentificationSysKey() {
        return identificationSysKey;
    }

    @JsonProperty("IdentificationSysKey")
    public void setIdentificationSysKey(List<Object> identificationSysKey) {
        this.identificationSysKey = identificationSysKey;
    }

    public Identification withIdentificationSysKey(List<Object> identificationSysKey) {
        this.identificationSysKey = identificationSysKey;
        return this;
    }

    @JsonProperty("IdentificationNum")
    public String getIdentificationNum() {
        return identificationNum;
    }

    @JsonProperty("IdentificationNum")
    public void setIdentificationNum(String identificationNum) {
        this.identificationNum = identificationNum;
    }

    public Identification withIdentificationNum(String identificationNum) {
        this.identificationNum = identificationNum;
        return this;
    }

    @JsonProperty("IdentityVerificationType")
    public IdentityVerificationType getIdentityVerificationType() {
        return identityVerificationType;
    }

    @JsonProperty("IdentityVerificationType")
    public void setIdentityVerificationType(IdentityVerificationType identityVerificationType) {
        this.identityVerificationType = identityVerificationType;
    }

    public Identification withIdentityVerificationType(IdentityVerificationType identityVerificationType) {
        this.identityVerificationType = identityVerificationType;
        return this;
    }

    @JsonProperty("IdentificationExpDate")
    public String getIdentificationExpDate() {
        return identificationExpDate;
    }

    @JsonProperty("IdentificationExpDate")
    public void setIdentificationExpDate(String identificationExpDate) {
        this.identificationExpDate = identificationExpDate;
    }

    public Identification withIdentificationExpDate(String identificationExpDate) {
        this.identificationExpDate = identificationExpDate;
        return this;
    }

    @JsonProperty("PictureIDInd")
    public PictureIDInd getPictureIDInd() {
        return pictureIDInd;
    }

    @JsonProperty("PictureIDInd")
    public void setPictureIDInd(PictureIDInd pictureIDInd) {
        this.pictureIDInd = pictureIDInd;
    }

    public Identification withPictureIDInd(PictureIDInd pictureIDInd) {
        this.pictureIDInd = pictureIDInd;
        return this;
    }

    @JsonProperty("Jurisdiction")
    public Jurisdiction getJurisdiction() {
        return jurisdiction;
    }

    @JsonProperty("Jurisdiction")
    public void setJurisdiction(Jurisdiction jurisdiction) {
        this.jurisdiction = jurisdiction;
    }

    public Identification withJurisdiction(Jurisdiction jurisdiction) {
        this.jurisdiction = jurisdiction;
        return this;
    }

    @JsonProperty("Nation")
    public Nation getNation() {
        return nation;
    }

    @JsonProperty("Nation")
    public void setNation(Nation nation) {
        this.nation = nation;
    }

    public Identification withNation(Nation nation) {
        this.nation = nation;
        return this;
    }

    @JsonProperty("IdentificationIssueDate")
    public String getIdentificationIssueDate() {
        return identificationIssueDate;
    }

    @JsonProperty("IdentificationIssueDate")
    public void setIdentificationIssueDate(String identificationIssueDate) {
        this.identificationIssueDate = identificationIssueDate;
    }

    public Identification withIdentificationIssueDate(String identificationIssueDate) {
        this.identificationIssueDate = identificationIssueDate;
        return this;
    }

    @JsonProperty("IssuingAgency")
    public String getIssuingAgency() {
        return issuingAgency;
    }

    @JsonProperty("IssuingAgency")
    public void setIssuingAgency(String issuingAgency) {
        this.issuingAgency = issuingAgency;
    }

    public Identification withIssuingAgency(String issuingAgency) {
        this.issuingAgency = issuingAgency;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Identification withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Identification withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public Identification withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Identification withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Identification.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("identificationKey");
        sb.append('=');
        sb.append(((this.identificationKey == null)?"<null>":this.identificationKey));
        sb.append(',');
        sb.append("identificationSysKey");
        sb.append('=');
        sb.append(((this.identificationSysKey == null)?"<null>":this.identificationSysKey));
        sb.append(',');
        sb.append("identificationNum");
        sb.append('=');
        sb.append(((this.identificationNum == null)?"<null>":this.identificationNum));
        sb.append(',');
        sb.append("identityVerificationType");
        sb.append('=');
        sb.append(((this.identityVerificationType == null)?"<null>":this.identityVerificationType));
        sb.append(',');
        sb.append("identificationExpDate");
        sb.append('=');
        sb.append(((this.identificationExpDate == null)?"<null>":this.identificationExpDate));
        sb.append(',');
        sb.append("pictureIDInd");
        sb.append('=');
        sb.append(((this.pictureIDInd == null)?"<null>":this.pictureIDInd));
        sb.append(',');
        sb.append("jurisdiction");
        sb.append('=');
        sb.append(((this.jurisdiction == null)?"<null>":this.jurisdiction));
        sb.append(',');
        sb.append("nation");
        sb.append('=');
        sb.append(((this.nation == null)?"<null>":this.nation));
        sb.append(',');
        sb.append("identificationIssueDate");
        sb.append('=');
        sb.append(((this.identificationIssueDate == null)?"<null>":this.identificationIssueDate));
        sb.append(',');
        sb.append("issuingAgency");
        sb.append('=');
        sb.append(((this.issuingAgency == null)?"<null>":this.issuingAgency));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.nation == null)? 0 :this.nation.hashCode()));
        result = ((result* 31)+((this.identificationKey == null)? 0 :this.identificationKey.hashCode()));
        result = ((result* 31)+((this.jurisdiction == null)? 0 :this.jurisdiction.hashCode()));
        result = ((result* 31)+((this.issuingAgency == null)? 0 :this.issuingAgency.hashCode()));
        result = ((result* 31)+((this.identificationNum == null)? 0 :this.identificationNum.hashCode()));
        result = ((result* 31)+((this.identificationExpDate == null)? 0 :this.identificationExpDate.hashCode()));
        result = ((result* 31)+((this.identificationIssueDate == null)? 0 :this.identificationIssueDate.hashCode()));
        result = ((result* 31)+((this.identificationSysKey == null)? 0 :this.identificationSysKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.pictureIDInd == null)? 0 :this.pictureIDInd.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.identityVerificationType == null)? 0 :this.identityVerificationType.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Identification) == false) {
            return false;
        }
        Identification rhs = ((Identification) other);
        return (((((((((((((((this.nation == rhs.nation)||((this.nation!= null)&&this.nation.equals(rhs.nation)))&&((this.identificationKey == rhs.identificationKey)||((this.identificationKey!= null)&&this.identificationKey.equals(rhs.identificationKey))))&&((this.jurisdiction == rhs.jurisdiction)||((this.jurisdiction!= null)&&this.jurisdiction.equals(rhs.jurisdiction))))&&((this.issuingAgency == rhs.issuingAgency)||((this.issuingAgency!= null)&&this.issuingAgency.equals(rhs.issuingAgency))))&&((this.identificationNum == rhs.identificationNum)||((this.identificationNum!= null)&&this.identificationNum.equals(rhs.identificationNum))))&&((this.identificationExpDate == rhs.identificationExpDate)||((this.identificationExpDate!= null)&&this.identificationExpDate.equals(rhs.identificationExpDate))))&&((this.identificationIssueDate == rhs.identificationIssueDate)||((this.identificationIssueDate!= null)&&this.identificationIssueDate.equals(rhs.identificationIssueDate))))&&((this.identificationSysKey == rhs.identificationSysKey)||((this.identificationSysKey!= null)&&this.identificationSysKey.equals(rhs.identificationSysKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.pictureIDInd == rhs.pictureIDInd)||((this.pictureIDInd!= null)&&this.pictureIDInd.equals(rhs.pictureIDInd))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.identityVerificationType == rhs.identityVerificationType)||((this.identityVerificationType!= null)&&this.identityVerificationType.equals(rhs.identityVerificationType))));
    }

}
