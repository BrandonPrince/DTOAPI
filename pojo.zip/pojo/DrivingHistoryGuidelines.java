
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "DrivingHistoryGuidelinesKey",
    "DrivingHistoryGuidelinesSysKey",
    "GuidelineOperator",
    "DrivingHistoryGuideline",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class DrivingHistoryGuidelines {

    @JsonProperty("DrivingHistoryGuidelinesKey")
    private DrivingHistoryGuidelinesKey drivingHistoryGuidelinesKey;
    @JsonProperty("DrivingHistoryGuidelinesSysKey")
    private List<Object> drivingHistoryGuidelinesSysKey = new ArrayList<>();
    @JsonProperty("GuidelineOperator")
    private GuidelineOperator guidelineOperator;
    @JsonProperty("DrivingHistoryGuideline")
    private List<Object> drivingHistoryGuideline = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("DrivingHistoryGuidelinesKey")
    public DrivingHistoryGuidelinesKey getDrivingHistoryGuidelinesKey() {
        return drivingHistoryGuidelinesKey;
    }

    @JsonProperty("DrivingHistoryGuidelinesKey")
    public void setDrivingHistoryGuidelinesKey(DrivingHistoryGuidelinesKey drivingHistoryGuidelinesKey) {
        this.drivingHistoryGuidelinesKey = drivingHistoryGuidelinesKey;
    }

    public DrivingHistoryGuidelines withDrivingHistoryGuidelinesKey(DrivingHistoryGuidelinesKey drivingHistoryGuidelinesKey) {
        this.drivingHistoryGuidelinesKey = drivingHistoryGuidelinesKey;
        return this;
    }

    @JsonProperty("DrivingHistoryGuidelinesSysKey")
    public List<Object> getDrivingHistoryGuidelinesSysKey() {
        return drivingHistoryGuidelinesSysKey;
    }

    @JsonProperty("DrivingHistoryGuidelinesSysKey")
    public void setDrivingHistoryGuidelinesSysKey(List<Object> drivingHistoryGuidelinesSysKey) {
        this.drivingHistoryGuidelinesSysKey = drivingHistoryGuidelinesSysKey;
    }

    public DrivingHistoryGuidelines withDrivingHistoryGuidelinesSysKey(List<Object> drivingHistoryGuidelinesSysKey) {
        this.drivingHistoryGuidelinesSysKey = drivingHistoryGuidelinesSysKey;
        return this;
    }

    @JsonProperty("GuidelineOperator")
    public GuidelineOperator getGuidelineOperator() {
        return guidelineOperator;
    }

    @JsonProperty("GuidelineOperator")
    public void setGuidelineOperator(GuidelineOperator guidelineOperator) {
        this.guidelineOperator = guidelineOperator;
    }

    public DrivingHistoryGuidelines withGuidelineOperator(GuidelineOperator guidelineOperator) {
        this.guidelineOperator = guidelineOperator;
        return this;
    }

    @JsonProperty("DrivingHistoryGuideline")
    public List<Object> getDrivingHistoryGuideline() {
        return drivingHistoryGuideline;
    }

    @JsonProperty("DrivingHistoryGuideline")
    public void setDrivingHistoryGuideline(List<Object> drivingHistoryGuideline) {
        this.drivingHistoryGuideline = drivingHistoryGuideline;
    }

    public DrivingHistoryGuidelines withDrivingHistoryGuideline(List<Object> drivingHistoryGuideline) {
        this.drivingHistoryGuideline = drivingHistoryGuideline;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public DrivingHistoryGuidelines withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public DrivingHistoryGuidelines withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public DrivingHistoryGuidelines withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DrivingHistoryGuidelines withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(DrivingHistoryGuidelines.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("drivingHistoryGuidelinesKey");
        sb.append('=');
        sb.append(((this.drivingHistoryGuidelinesKey == null)?"<null>":this.drivingHistoryGuidelinesKey));
        sb.append(',');
        sb.append("drivingHistoryGuidelinesSysKey");
        sb.append('=');
        sb.append(((this.drivingHistoryGuidelinesSysKey == null)?"<null>":this.drivingHistoryGuidelinesSysKey));
        sb.append(',');
        sb.append("guidelineOperator");
        sb.append('=');
        sb.append(((this.guidelineOperator == null)?"<null>":this.guidelineOperator));
        sb.append(',');
        sb.append("drivingHistoryGuideline");
        sb.append('=');
        sb.append(((this.drivingHistoryGuideline == null)?"<null>":this.drivingHistoryGuideline));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.drivingHistoryGuidelinesKey == null)? 0 :this.drivingHistoryGuidelinesKey.hashCode()));
        result = ((result* 31)+((this.guidelineOperator == null)? 0 :this.guidelineOperator.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.drivingHistoryGuideline == null)? 0 :this.drivingHistoryGuideline.hashCode()));
        result = ((result* 31)+((this.drivingHistoryGuidelinesSysKey == null)? 0 :this.drivingHistoryGuidelinesSysKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DrivingHistoryGuidelines) == false) {
            return false;
        }
        DrivingHistoryGuidelines rhs = ((DrivingHistoryGuidelines) other);
        return (((((((((this.drivingHistoryGuidelinesKey == rhs.drivingHistoryGuidelinesKey)||((this.drivingHistoryGuidelinesKey!= null)&&this.drivingHistoryGuidelinesKey.equals(rhs.drivingHistoryGuidelinesKey)))&&((this.guidelineOperator == rhs.guidelineOperator)||((this.guidelineOperator!= null)&&this.guidelineOperator.equals(rhs.guidelineOperator))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.drivingHistoryGuideline == rhs.drivingHistoryGuideline)||((this.drivingHistoryGuideline!= null)&&this.drivingHistoryGuideline.equals(rhs.drivingHistoryGuideline))))&&((this.drivingHistoryGuidelinesSysKey == rhs.drivingHistoryGuidelinesSysKey)||((this.drivingHistoryGuidelinesSysKey!= null)&&this.drivingHistoryGuidelinesSysKey.equals(rhs.drivingHistoryGuidelinesSysKey))));
    }

}
