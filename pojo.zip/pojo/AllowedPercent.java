
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AllowedPercentKey",
    "AllowedPercentSysKey",
    "AllowedPayoutPct",
    "AllowedPctType",
    "DefaultInd",
    "Sequence",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AllowedPercent {

    @JsonProperty("AllowedPercentKey")
    private AllowedPercentKey allowedPercentKey;
    @JsonProperty("AllowedPercentSysKey")
    private List<Object> allowedPercentSysKey = new ArrayList<>();
    @JsonProperty("AllowedPayoutPct")
    private Integer allowedPayoutPct;
    @JsonProperty("AllowedPctType")
    private AllowedPctType allowedPctType;
    @JsonProperty("DefaultInd")
    private DefaultInd defaultInd;
    @JsonProperty("Sequence")
    private Integer sequence;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AllowedPercentKey")
    public AllowedPercentKey getAllowedPercentKey() {
        return allowedPercentKey;
    }

    @JsonProperty("AllowedPercentKey")
    public void setAllowedPercentKey(AllowedPercentKey allowedPercentKey) {
        this.allowedPercentKey = allowedPercentKey;
    }

    public AllowedPercent withAllowedPercentKey(AllowedPercentKey allowedPercentKey) {
        this.allowedPercentKey = allowedPercentKey;
        return this;
    }

    @JsonProperty("AllowedPercentSysKey")
    public List<Object> getAllowedPercentSysKey() {
        return allowedPercentSysKey;
    }

    @JsonProperty("AllowedPercentSysKey")
    public void setAllowedPercentSysKey(List<Object> allowedPercentSysKey) {
        this.allowedPercentSysKey = allowedPercentSysKey;
    }

    public AllowedPercent withAllowedPercentSysKey(List<Object> allowedPercentSysKey) {
        this.allowedPercentSysKey = allowedPercentSysKey;
        return this;
    }

    @JsonProperty("AllowedPayoutPct")
    public Integer getAllowedPayoutPct() {
        return allowedPayoutPct;
    }

    @JsonProperty("AllowedPayoutPct")
    public void setAllowedPayoutPct(Integer allowedPayoutPct) {
        this.allowedPayoutPct = allowedPayoutPct;
    }

    public AllowedPercent withAllowedPayoutPct(Integer allowedPayoutPct) {
        this.allowedPayoutPct = allowedPayoutPct;
        return this;
    }

    @JsonProperty("AllowedPctType")
    public AllowedPctType getAllowedPctType() {
        return allowedPctType;
    }

    @JsonProperty("AllowedPctType")
    public void setAllowedPctType(AllowedPctType allowedPctType) {
        this.allowedPctType = allowedPctType;
    }

    public AllowedPercent withAllowedPctType(AllowedPctType allowedPctType) {
        this.allowedPctType = allowedPctType;
        return this;
    }

    @JsonProperty("DefaultInd")
    public DefaultInd getDefaultInd() {
        return defaultInd;
    }

    @JsonProperty("DefaultInd")
    public void setDefaultInd(DefaultInd defaultInd) {
        this.defaultInd = defaultInd;
    }

    public AllowedPercent withDefaultInd(DefaultInd defaultInd) {
        this.defaultInd = defaultInd;
        return this;
    }

    @JsonProperty("Sequence")
    public Integer getSequence() {
        return sequence;
    }

    @JsonProperty("Sequence")
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public AllowedPercent withSequence(Integer sequence) {
        this.sequence = sequence;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AllowedPercent withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AllowedPercent withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AllowedPercent withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AllowedPercent withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AllowedPercent.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("allowedPercentKey");
        sb.append('=');
        sb.append(((this.allowedPercentKey == null)?"<null>":this.allowedPercentKey));
        sb.append(',');
        sb.append("allowedPercentSysKey");
        sb.append('=');
        sb.append(((this.allowedPercentSysKey == null)?"<null>":this.allowedPercentSysKey));
        sb.append(',');
        sb.append("allowedPayoutPct");
        sb.append('=');
        sb.append(((this.allowedPayoutPct == null)?"<null>":this.allowedPayoutPct));
        sb.append(',');
        sb.append("allowedPctType");
        sb.append('=');
        sb.append(((this.allowedPctType == null)?"<null>":this.allowedPctType));
        sb.append(',');
        sb.append("defaultInd");
        sb.append('=');
        sb.append(((this.defaultInd == null)?"<null>":this.defaultInd));
        sb.append(',');
        sb.append("sequence");
        sb.append('=');
        sb.append(((this.sequence == null)?"<null>":this.sequence));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.sequence == null)? 0 :this.sequence.hashCode()));
        result = ((result* 31)+((this.allowedPctType == null)? 0 :this.allowedPctType.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.allowedPercentKey == null)? 0 :this.allowedPercentKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.allowedPercentSysKey == null)? 0 :this.allowedPercentSysKey.hashCode()));
        result = ((result* 31)+((this.defaultInd == null)? 0 :this.defaultInd.hashCode()));
        result = ((result* 31)+((this.allowedPayoutPct == null)? 0 :this.allowedPayoutPct.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AllowedPercent) == false) {
            return false;
        }
        AllowedPercent rhs = ((AllowedPercent) other);
        return (((((((((((this.sequence == rhs.sequence)||((this.sequence!= null)&&this.sequence.equals(rhs.sequence)))&&((this.allowedPctType == rhs.allowedPctType)||((this.allowedPctType!= null)&&this.allowedPctType.equals(rhs.allowedPctType))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.allowedPercentKey == rhs.allowedPercentKey)||((this.allowedPercentKey!= null)&&this.allowedPercentKey.equals(rhs.allowedPercentKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.allowedPercentSysKey == rhs.allowedPercentSysKey)||((this.allowedPercentSysKey!= null)&&this.allowedPercentSysKey.equals(rhs.allowedPercentSysKey))))&&((this.defaultInd == rhs.defaultInd)||((this.defaultInd!= null)&&this.defaultInd.equals(rhs.defaultInd))))&&((this.allowedPayoutPct == rhs.allowedPayoutPct)||((this.allowedPayoutPct!= null)&&this.allowedPayoutPct.equals(rhs.allowedPayoutPct))));
    }

}
