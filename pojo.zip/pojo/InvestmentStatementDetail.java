
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "InvestmentStatementDetailKey",
    "InvestmentStatementDetailSysKey",
    "StartDate",
    "EndDate",
    "VolDedContribAmt",
    "VolNonDedContribAmt",
    "EEContribAmt",
    "TaxQualRolloverAmt",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class InvestmentStatementDetail {

    @JsonProperty("InvestmentStatementDetailKey")
    private InvestmentStatementDetailKey investmentStatementDetailKey;
    @JsonProperty("InvestmentStatementDetailSysKey")
    private List<Object> investmentStatementDetailSysKey = new ArrayList<>();
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("VolDedContribAmt")
    private Integer volDedContribAmt;
    @JsonProperty("VolNonDedContribAmt")
    private Integer volNonDedContribAmt;
    @JsonProperty("EEContribAmt")
    private Integer eEContribAmt;
    @JsonProperty("TaxQualRolloverAmt")
    private Integer taxQualRolloverAmt;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("InvestmentStatementDetailKey")
    public InvestmentStatementDetailKey getInvestmentStatementDetailKey() {
        return investmentStatementDetailKey;
    }

    @JsonProperty("InvestmentStatementDetailKey")
    public void setInvestmentStatementDetailKey(InvestmentStatementDetailKey investmentStatementDetailKey) {
        this.investmentStatementDetailKey = investmentStatementDetailKey;
    }

    public InvestmentStatementDetail withInvestmentStatementDetailKey(InvestmentStatementDetailKey investmentStatementDetailKey) {
        this.investmentStatementDetailKey = investmentStatementDetailKey;
        return this;
    }

    @JsonProperty("InvestmentStatementDetailSysKey")
    public List<Object> getInvestmentStatementDetailSysKey() {
        return investmentStatementDetailSysKey;
    }

    @JsonProperty("InvestmentStatementDetailSysKey")
    public void setInvestmentStatementDetailSysKey(List<Object> investmentStatementDetailSysKey) {
        this.investmentStatementDetailSysKey = investmentStatementDetailSysKey;
    }

    public InvestmentStatementDetail withInvestmentStatementDetailSysKey(List<Object> investmentStatementDetailSysKey) {
        this.investmentStatementDetailSysKey = investmentStatementDetailSysKey;
        return this;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public InvestmentStatementDetail withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public InvestmentStatementDetail withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("VolDedContribAmt")
    public Integer getVolDedContribAmt() {
        return volDedContribAmt;
    }

    @JsonProperty("VolDedContribAmt")
    public void setVolDedContribAmt(Integer volDedContribAmt) {
        this.volDedContribAmt = volDedContribAmt;
    }

    public InvestmentStatementDetail withVolDedContribAmt(Integer volDedContribAmt) {
        this.volDedContribAmt = volDedContribAmt;
        return this;
    }

    @JsonProperty("VolNonDedContribAmt")
    public Integer getVolNonDedContribAmt() {
        return volNonDedContribAmt;
    }

    @JsonProperty("VolNonDedContribAmt")
    public void setVolNonDedContribAmt(Integer volNonDedContribAmt) {
        this.volNonDedContribAmt = volNonDedContribAmt;
    }

    public InvestmentStatementDetail withVolNonDedContribAmt(Integer volNonDedContribAmt) {
        this.volNonDedContribAmt = volNonDedContribAmt;
        return this;
    }

    @JsonProperty("EEContribAmt")
    public Integer getEEContribAmt() {
        return eEContribAmt;
    }

    @JsonProperty("EEContribAmt")
    public void setEEContribAmt(Integer eEContribAmt) {
        this.eEContribAmt = eEContribAmt;
    }

    public InvestmentStatementDetail withEEContribAmt(Integer eEContribAmt) {
        this.eEContribAmt = eEContribAmt;
        return this;
    }

    @JsonProperty("TaxQualRolloverAmt")
    public Integer getTaxQualRolloverAmt() {
        return taxQualRolloverAmt;
    }

    @JsonProperty("TaxQualRolloverAmt")
    public void setTaxQualRolloverAmt(Integer taxQualRolloverAmt) {
        this.taxQualRolloverAmt = taxQualRolloverAmt;
    }

    public InvestmentStatementDetail withTaxQualRolloverAmt(Integer taxQualRolloverAmt) {
        this.taxQualRolloverAmt = taxQualRolloverAmt;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public InvestmentStatementDetail withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public InvestmentStatementDetail withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public InvestmentStatementDetail withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public InvestmentStatementDetail withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(InvestmentStatementDetail.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("investmentStatementDetailKey");
        sb.append('=');
        sb.append(((this.investmentStatementDetailKey == null)?"<null>":this.investmentStatementDetailKey));
        sb.append(',');
        sb.append("investmentStatementDetailSysKey");
        sb.append('=');
        sb.append(((this.investmentStatementDetailSysKey == null)?"<null>":this.investmentStatementDetailSysKey));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("volDedContribAmt");
        sb.append('=');
        sb.append(((this.volDedContribAmt == null)?"<null>":this.volDedContribAmt));
        sb.append(',');
        sb.append("volNonDedContribAmt");
        sb.append('=');
        sb.append(((this.volNonDedContribAmt == null)?"<null>":this.volNonDedContribAmt));
        sb.append(',');
        sb.append("eEContribAmt");
        sb.append('=');
        sb.append(((this.eEContribAmt == null)?"<null>":this.eEContribAmt));
        sb.append(',');
        sb.append("taxQualRolloverAmt");
        sb.append('=');
        sb.append(((this.taxQualRolloverAmt == null)?"<null>":this.taxQualRolloverAmt));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.investmentStatementDetailKey == null)? 0 :this.investmentStatementDetailKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.volNonDedContribAmt == null)? 0 :this.volNonDedContribAmt.hashCode()));
        result = ((result* 31)+((this.investmentStatementDetailSysKey == null)? 0 :this.investmentStatementDetailSysKey.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        result = ((result* 31)+((this.taxQualRolloverAmt == null)? 0 :this.taxQualRolloverAmt.hashCode()));
        result = ((result* 31)+((this.volDedContribAmt == null)? 0 :this.volDedContribAmt.hashCode()));
        result = ((result* 31)+((this.eEContribAmt == null)? 0 :this.eEContribAmt.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InvestmentStatementDetail) == false) {
            return false;
        }
        InvestmentStatementDetail rhs = ((InvestmentStatementDetail) other);
        return (((((((((((((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate)))&&((this.investmentStatementDetailKey == rhs.investmentStatementDetailKey)||((this.investmentStatementDetailKey!= null)&&this.investmentStatementDetailKey.equals(rhs.investmentStatementDetailKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.volNonDedContribAmt == rhs.volNonDedContribAmt)||((this.volNonDedContribAmt!= null)&&this.volNonDedContribAmt.equals(rhs.volNonDedContribAmt))))&&((this.investmentStatementDetailSysKey == rhs.investmentStatementDetailSysKey)||((this.investmentStatementDetailSysKey!= null)&&this.investmentStatementDetailSysKey.equals(rhs.investmentStatementDetailSysKey))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))))&&((this.taxQualRolloverAmt == rhs.taxQualRolloverAmt)||((this.taxQualRolloverAmt!= null)&&this.taxQualRolloverAmt.equals(rhs.taxQualRolloverAmt))))&&((this.volDedContribAmt == rhs.volDedContribAmt)||((this.volDedContribAmt!= null)&&this.volDedContribAmt.equals(rhs.volDedContribAmt))))&&((this.eEContribAmt == rhs.eEContribAmt)||((this.eEContribAmt!= null)&&this.eEContribAmt.equals(rhs.eEContribAmt))));
    }

}
