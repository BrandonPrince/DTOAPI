
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CommFormulaKey",
    "CommFormulaSysKey",
    "CommEvent",
    "CommissionType",
    "RelationRoleCode",
    "CarrierCommCode",
    "TableIdentity",
    "ProviderDomain",
    "PaymentRateCategory",
    "TableRef",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class CommFormula {

    @JsonProperty("CommFormulaKey")
    private CommFormulaKey commFormulaKey;
    @JsonProperty("CommFormulaSysKey")
    private List<Object> commFormulaSysKey = new ArrayList<>();
    @JsonProperty("CommEvent")
    private CommEvent commEvent;
    @JsonProperty("CommissionType")
    private CommissionType commissionType;
    @JsonProperty("RelationRoleCode")
    private RelationRoleCode relationRoleCode;
    @JsonProperty("CarrierCommCode")
    private String carrierCommCode;
    @JsonProperty("TableIdentity")
    private String tableIdentity;
    @JsonProperty("ProviderDomain")
    private String providerDomain;
    @JsonProperty("PaymentRateCategory")
    private PaymentRateCategory paymentRateCategory;
    @JsonProperty("TableRef")
    private List<Object> tableRef = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("CommFormulaKey")
    public CommFormulaKey getCommFormulaKey() {
        return commFormulaKey;
    }

    @JsonProperty("CommFormulaKey")
    public void setCommFormulaKey(CommFormulaKey commFormulaKey) {
        this.commFormulaKey = commFormulaKey;
    }

    public CommFormula withCommFormulaKey(CommFormulaKey commFormulaKey) {
        this.commFormulaKey = commFormulaKey;
        return this;
    }

    @JsonProperty("CommFormulaSysKey")
    public List<Object> getCommFormulaSysKey() {
        return commFormulaSysKey;
    }

    @JsonProperty("CommFormulaSysKey")
    public void setCommFormulaSysKey(List<Object> commFormulaSysKey) {
        this.commFormulaSysKey = commFormulaSysKey;
    }

    public CommFormula withCommFormulaSysKey(List<Object> commFormulaSysKey) {
        this.commFormulaSysKey = commFormulaSysKey;
        return this;
    }

    @JsonProperty("CommEvent")
    public CommEvent getCommEvent() {
        return commEvent;
    }

    @JsonProperty("CommEvent")
    public void setCommEvent(CommEvent commEvent) {
        this.commEvent = commEvent;
    }

    public CommFormula withCommEvent(CommEvent commEvent) {
        this.commEvent = commEvent;
        return this;
    }

    @JsonProperty("CommissionType")
    public CommissionType getCommissionType() {
        return commissionType;
    }

    @JsonProperty("CommissionType")
    public void setCommissionType(CommissionType commissionType) {
        this.commissionType = commissionType;
    }

    public CommFormula withCommissionType(CommissionType commissionType) {
        this.commissionType = commissionType;
        return this;
    }

    @JsonProperty("RelationRoleCode")
    public RelationRoleCode getRelationRoleCode() {
        return relationRoleCode;
    }

    @JsonProperty("RelationRoleCode")
    public void setRelationRoleCode(RelationRoleCode relationRoleCode) {
        this.relationRoleCode = relationRoleCode;
    }

    public CommFormula withRelationRoleCode(RelationRoleCode relationRoleCode) {
        this.relationRoleCode = relationRoleCode;
        return this;
    }

    @JsonProperty("CarrierCommCode")
    public String getCarrierCommCode() {
        return carrierCommCode;
    }

    @JsonProperty("CarrierCommCode")
    public void setCarrierCommCode(String carrierCommCode) {
        this.carrierCommCode = carrierCommCode;
    }

    public CommFormula withCarrierCommCode(String carrierCommCode) {
        this.carrierCommCode = carrierCommCode;
        return this;
    }

    @JsonProperty("TableIdentity")
    public String getTableIdentity() {
        return tableIdentity;
    }

    @JsonProperty("TableIdentity")
    public void setTableIdentity(String tableIdentity) {
        this.tableIdentity = tableIdentity;
    }

    public CommFormula withTableIdentity(String tableIdentity) {
        this.tableIdentity = tableIdentity;
        return this;
    }

    @JsonProperty("ProviderDomain")
    public String getProviderDomain() {
        return providerDomain;
    }

    @JsonProperty("ProviderDomain")
    public void setProviderDomain(String providerDomain) {
        this.providerDomain = providerDomain;
    }

    public CommFormula withProviderDomain(String providerDomain) {
        this.providerDomain = providerDomain;
        return this;
    }

    @JsonProperty("PaymentRateCategory")
    public PaymentRateCategory getPaymentRateCategory() {
        return paymentRateCategory;
    }

    @JsonProperty("PaymentRateCategory")
    public void setPaymentRateCategory(PaymentRateCategory paymentRateCategory) {
        this.paymentRateCategory = paymentRateCategory;
    }

    public CommFormula withPaymentRateCategory(PaymentRateCategory paymentRateCategory) {
        this.paymentRateCategory = paymentRateCategory;
        return this;
    }

    @JsonProperty("TableRef")
    public List<Object> getTableRef() {
        return tableRef;
    }

    @JsonProperty("TableRef")
    public void setTableRef(List<Object> tableRef) {
        this.tableRef = tableRef;
    }

    public CommFormula withTableRef(List<Object> tableRef) {
        this.tableRef = tableRef;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public CommFormula withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public CommFormula withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public CommFormula withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CommFormula withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(CommFormula.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("commFormulaKey");
        sb.append('=');
        sb.append(((this.commFormulaKey == null)?"<null>":this.commFormulaKey));
        sb.append(',');
        sb.append("commFormulaSysKey");
        sb.append('=');
        sb.append(((this.commFormulaSysKey == null)?"<null>":this.commFormulaSysKey));
        sb.append(',');
        sb.append("commEvent");
        sb.append('=');
        sb.append(((this.commEvent == null)?"<null>":this.commEvent));
        sb.append(',');
        sb.append("commissionType");
        sb.append('=');
        sb.append(((this.commissionType == null)?"<null>":this.commissionType));
        sb.append(',');
        sb.append("relationRoleCode");
        sb.append('=');
        sb.append(((this.relationRoleCode == null)?"<null>":this.relationRoleCode));
        sb.append(',');
        sb.append("carrierCommCode");
        sb.append('=');
        sb.append(((this.carrierCommCode == null)?"<null>":this.carrierCommCode));
        sb.append(',');
        sb.append("tableIdentity");
        sb.append('=');
        sb.append(((this.tableIdentity == null)?"<null>":this.tableIdentity));
        sb.append(',');
        sb.append("providerDomain");
        sb.append('=');
        sb.append(((this.providerDomain == null)?"<null>":this.providerDomain));
        sb.append(',');
        sb.append("paymentRateCategory");
        sb.append('=');
        sb.append(((this.paymentRateCategory == null)?"<null>":this.paymentRateCategory));
        sb.append(',');
        sb.append("tableRef");
        sb.append('=');
        sb.append(((this.tableRef == null)?"<null>":this.tableRef));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.paymentRateCategory == null)? 0 :this.paymentRateCategory.hashCode()));
        result = ((result* 31)+((this.tableRef == null)? 0 :this.tableRef.hashCode()));
        result = ((result* 31)+((this.relationRoleCode == null)? 0 :this.relationRoleCode.hashCode()));
        result = ((result* 31)+((this.commFormulaKey == null)? 0 :this.commFormulaKey.hashCode()));
        result = ((result* 31)+((this.commFormulaSysKey == null)? 0 :this.commFormulaSysKey.hashCode()));
        result = ((result* 31)+((this.commEvent == null)? 0 :this.commEvent.hashCode()));
        result = ((result* 31)+((this.carrierCommCode == null)? 0 :this.carrierCommCode.hashCode()));
        result = ((result* 31)+((this.commissionType == null)? 0 :this.commissionType.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.tableIdentity == null)? 0 :this.tableIdentity.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.providerDomain == null)? 0 :this.providerDomain.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CommFormula) == false) {
            return false;
        }
        CommFormula rhs = ((CommFormula) other);
        return (((((((((((((((this.paymentRateCategory == rhs.paymentRateCategory)||((this.paymentRateCategory!= null)&&this.paymentRateCategory.equals(rhs.paymentRateCategory)))&&((this.tableRef == rhs.tableRef)||((this.tableRef!= null)&&this.tableRef.equals(rhs.tableRef))))&&((this.relationRoleCode == rhs.relationRoleCode)||((this.relationRoleCode!= null)&&this.relationRoleCode.equals(rhs.relationRoleCode))))&&((this.commFormulaKey == rhs.commFormulaKey)||((this.commFormulaKey!= null)&&this.commFormulaKey.equals(rhs.commFormulaKey))))&&((this.commFormulaSysKey == rhs.commFormulaSysKey)||((this.commFormulaSysKey!= null)&&this.commFormulaSysKey.equals(rhs.commFormulaSysKey))))&&((this.commEvent == rhs.commEvent)||((this.commEvent!= null)&&this.commEvent.equals(rhs.commEvent))))&&((this.carrierCommCode == rhs.carrierCommCode)||((this.carrierCommCode!= null)&&this.carrierCommCode.equals(rhs.carrierCommCode))))&&((this.commissionType == rhs.commissionType)||((this.commissionType!= null)&&this.commissionType.equals(rhs.commissionType))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.tableIdentity == rhs.tableIdentity)||((this.tableIdentity!= null)&&this.tableIdentity.equals(rhs.tableIdentity))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.providerDomain == rhs.providerDomain)||((this.providerDomain!= null)&&this.providerDomain.equals(rhs.providerDomain))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
