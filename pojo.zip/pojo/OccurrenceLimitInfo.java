
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "OccurrenceLimitInfoKey",
    "OccurrenceLimitInfoSysKey",
    "OccurrenceTier",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class OccurrenceLimitInfo {

    @JsonProperty("OccurrenceLimitInfoKey")
    private OccurrenceLimitInfoKey occurrenceLimitInfoKey;
    @JsonProperty("OccurrenceLimitInfoSysKey")
    private List<Object> occurrenceLimitInfoSysKey = new ArrayList<>();
    @JsonProperty("OccurrenceTier")
    private List<Object> occurrenceTier = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("OccurrenceLimitInfoKey")
    public OccurrenceLimitInfoKey getOccurrenceLimitInfoKey() {
        return occurrenceLimitInfoKey;
    }

    @JsonProperty("OccurrenceLimitInfoKey")
    public void setOccurrenceLimitInfoKey(OccurrenceLimitInfoKey occurrenceLimitInfoKey) {
        this.occurrenceLimitInfoKey = occurrenceLimitInfoKey;
    }

    public OccurrenceLimitInfo withOccurrenceLimitInfoKey(OccurrenceLimitInfoKey occurrenceLimitInfoKey) {
        this.occurrenceLimitInfoKey = occurrenceLimitInfoKey;
        return this;
    }

    @JsonProperty("OccurrenceLimitInfoSysKey")
    public List<Object> getOccurrenceLimitInfoSysKey() {
        return occurrenceLimitInfoSysKey;
    }

    @JsonProperty("OccurrenceLimitInfoSysKey")
    public void setOccurrenceLimitInfoSysKey(List<Object> occurrenceLimitInfoSysKey) {
        this.occurrenceLimitInfoSysKey = occurrenceLimitInfoSysKey;
    }

    public OccurrenceLimitInfo withOccurrenceLimitInfoSysKey(List<Object> occurrenceLimitInfoSysKey) {
        this.occurrenceLimitInfoSysKey = occurrenceLimitInfoSysKey;
        return this;
    }

    @JsonProperty("OccurrenceTier")
    public List<Object> getOccurrenceTier() {
        return occurrenceTier;
    }

    @JsonProperty("OccurrenceTier")
    public void setOccurrenceTier(List<Object> occurrenceTier) {
        this.occurrenceTier = occurrenceTier;
    }

    public OccurrenceLimitInfo withOccurrenceTier(List<Object> occurrenceTier) {
        this.occurrenceTier = occurrenceTier;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public OccurrenceLimitInfo withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public OccurrenceLimitInfo withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public OccurrenceLimitInfo withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public OccurrenceLimitInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(OccurrenceLimitInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("occurrenceLimitInfoKey");
        sb.append('=');
        sb.append(((this.occurrenceLimitInfoKey == null)?"<null>":this.occurrenceLimitInfoKey));
        sb.append(',');
        sb.append("occurrenceLimitInfoSysKey");
        sb.append('=');
        sb.append(((this.occurrenceLimitInfoSysKey == null)?"<null>":this.occurrenceLimitInfoSysKey));
        sb.append(',');
        sb.append("occurrenceTier");
        sb.append('=');
        sb.append(((this.occurrenceTier == null)?"<null>":this.occurrenceTier));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.occurrenceLimitInfoKey == null)? 0 :this.occurrenceLimitInfoKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.occurrenceTier == null)? 0 :this.occurrenceTier.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.occurrenceLimitInfoSysKey == null)? 0 :this.occurrenceLimitInfoSysKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof OccurrenceLimitInfo) == false) {
            return false;
        }
        OccurrenceLimitInfo rhs = ((OccurrenceLimitInfo) other);
        return ((((((((this.occurrenceLimitInfoKey == rhs.occurrenceLimitInfoKey)||((this.occurrenceLimitInfoKey!= null)&&this.occurrenceLimitInfoKey.equals(rhs.occurrenceLimitInfoKey)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.occurrenceTier == rhs.occurrenceTier)||((this.occurrenceTier!= null)&&this.occurrenceTier.equals(rhs.occurrenceTier))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.occurrenceLimitInfoSysKey == rhs.occurrenceLimitInfoSysKey)||((this.occurrenceLimitInfoSysKey!= null)&&this.occurrenceLimitInfoSysKey.equals(rhs.occurrenceLimitInfoSysKey))));
    }

}
