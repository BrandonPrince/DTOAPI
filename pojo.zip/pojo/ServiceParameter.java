
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ServiceParameterKey",
    "ServiceParameterSysKey",
    "ServiceParameterType",
    "ServiceParameterInd",
    "ServiceParameterValue",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class ServiceParameter {

    @JsonProperty("ServiceParameterKey")
    private ServiceParameterKey serviceParameterKey;
    @JsonProperty("ServiceParameterSysKey")
    private List<Object> serviceParameterSysKey = new ArrayList<>();
    @JsonProperty("ServiceParameterType")
    private ServiceParameterType serviceParameterType;
    @JsonProperty("ServiceParameterInd")
    private ServiceParameterInd serviceParameterInd;
    @JsonProperty("ServiceParameterValue")
    private String serviceParameterValue;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ServiceParameterKey")
    public ServiceParameterKey getServiceParameterKey() {
        return serviceParameterKey;
    }

    @JsonProperty("ServiceParameterKey")
    public void setServiceParameterKey(ServiceParameterKey serviceParameterKey) {
        this.serviceParameterKey = serviceParameterKey;
    }

    public ServiceParameter withServiceParameterKey(ServiceParameterKey serviceParameterKey) {
        this.serviceParameterKey = serviceParameterKey;
        return this;
    }

    @JsonProperty("ServiceParameterSysKey")
    public List<Object> getServiceParameterSysKey() {
        return serviceParameterSysKey;
    }

    @JsonProperty("ServiceParameterSysKey")
    public void setServiceParameterSysKey(List<Object> serviceParameterSysKey) {
        this.serviceParameterSysKey = serviceParameterSysKey;
    }

    public ServiceParameter withServiceParameterSysKey(List<Object> serviceParameterSysKey) {
        this.serviceParameterSysKey = serviceParameterSysKey;
        return this;
    }

    @JsonProperty("ServiceParameterType")
    public ServiceParameterType getServiceParameterType() {
        return serviceParameterType;
    }

    @JsonProperty("ServiceParameterType")
    public void setServiceParameterType(ServiceParameterType serviceParameterType) {
        this.serviceParameterType = serviceParameterType;
    }

    public ServiceParameter withServiceParameterType(ServiceParameterType serviceParameterType) {
        this.serviceParameterType = serviceParameterType;
        return this;
    }

    @JsonProperty("ServiceParameterInd")
    public ServiceParameterInd getServiceParameterInd() {
        return serviceParameterInd;
    }

    @JsonProperty("ServiceParameterInd")
    public void setServiceParameterInd(ServiceParameterInd serviceParameterInd) {
        this.serviceParameterInd = serviceParameterInd;
    }

    public ServiceParameter withServiceParameterInd(ServiceParameterInd serviceParameterInd) {
        this.serviceParameterInd = serviceParameterInd;
        return this;
    }

    @JsonProperty("ServiceParameterValue")
    public String getServiceParameterValue() {
        return serviceParameterValue;
    }

    @JsonProperty("ServiceParameterValue")
    public void setServiceParameterValue(String serviceParameterValue) {
        this.serviceParameterValue = serviceParameterValue;
    }

    public ServiceParameter withServiceParameterValue(String serviceParameterValue) {
        this.serviceParameterValue = serviceParameterValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public ServiceParameter withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public ServiceParameter withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public ServiceParameter withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ServiceParameter withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ServiceParameter.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("serviceParameterKey");
        sb.append('=');
        sb.append(((this.serviceParameterKey == null)?"<null>":this.serviceParameterKey));
        sb.append(',');
        sb.append("serviceParameterSysKey");
        sb.append('=');
        sb.append(((this.serviceParameterSysKey == null)?"<null>":this.serviceParameterSysKey));
        sb.append(',');
        sb.append("serviceParameterType");
        sb.append('=');
        sb.append(((this.serviceParameterType == null)?"<null>":this.serviceParameterType));
        sb.append(',');
        sb.append("serviceParameterInd");
        sb.append('=');
        sb.append(((this.serviceParameterInd == null)?"<null>":this.serviceParameterInd));
        sb.append(',');
        sb.append("serviceParameterValue");
        sb.append('=');
        sb.append(((this.serviceParameterValue == null)?"<null>":this.serviceParameterValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.serviceParameterSysKey == null)? 0 :this.serviceParameterSysKey.hashCode()));
        result = ((result* 31)+((this.serviceParameterType == null)? 0 :this.serviceParameterType.hashCode()));
        result = ((result* 31)+((this.serviceParameterKey == null)? 0 :this.serviceParameterKey.hashCode()));
        result = ((result* 31)+((this.serviceParameterInd == null)? 0 :this.serviceParameterInd.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.serviceParameterValue == null)? 0 :this.serviceParameterValue.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ServiceParameter) == false) {
            return false;
        }
        ServiceParameter rhs = ((ServiceParameter) other);
        return ((((((((((this.serviceParameterSysKey == rhs.serviceParameterSysKey)||((this.serviceParameterSysKey!= null)&&this.serviceParameterSysKey.equals(rhs.serviceParameterSysKey)))&&((this.serviceParameterType == rhs.serviceParameterType)||((this.serviceParameterType!= null)&&this.serviceParameterType.equals(rhs.serviceParameterType))))&&((this.serviceParameterKey == rhs.serviceParameterKey)||((this.serviceParameterKey!= null)&&this.serviceParameterKey.equals(rhs.serviceParameterKey))))&&((this.serviceParameterInd == rhs.serviceParameterInd)||((this.serviceParameterInd!= null)&&this.serviceParameterInd.equals(rhs.serviceParameterInd))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.serviceParameterValue == rhs.serviceParameterValue)||((this.serviceParameterValue!= null)&&this.serviceParameterValue.equals(rhs.serviceParameterValue))));
    }

}
