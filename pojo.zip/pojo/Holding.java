
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "HoldingKey",
    "HoldingSysKey",
    "AccountDesignation",
    "HoldingTypeCode",
    "HoldingName",
    "HoldingStatus",
    "Purpose",
    "CurrencyTypeCode",
    "CarrierAdminSystem",
    "CarrierAdminSubSystem",
    "CostBasis",
    "ComponentOfPackage",
    "AssetValue",
    "LiabilityValue",
    "AsOfDate",
    "LastFinActivityDate",
    "LastFinActivityType",
    "LastNonFinActivityDate",
    "LastAnniversaryDate",
    "NextAnniversaryDate",
    "HoldingForm",
    "AssignmentCode",
    "QualifiedCode",
    "RestrictionCode",
    "DistributorClientAcctNum",
    "CommissionHoldInd",
    "MarketType",
    "ShareClass",
    "Policy",
    "Investment",
    "Attachment",
    "CompensationPayment",
    "Intent",
    "Arrangement",
    "Loan",
    "SystemMessage",
    "Banking",
    "Authorization",
    "HoldingXLat",
    "Fee",
    "RestrictionInfo",
    "PolicyValues",
    "SurrenderChargeSchedule",
    "Integrator",
    "KeyedValue",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class Holding {

    @JsonProperty("HoldingKey")
    private HoldingKey holdingKey;
    @JsonProperty("HoldingSysKey")
    private List<Object> holdingSysKey = new ArrayList<>();
    @JsonProperty("AccountDesignation")
    private AccountDesignation accountDesignation;
    @JsonProperty("HoldingTypeCode")
    private HoldingTypeCode holdingTypeCode;
    @JsonProperty("HoldingName")
    private String holdingName;
    @JsonProperty("HoldingStatus")
    private HoldingStatus holdingStatus;
    @JsonProperty("Purpose")
    private Purpose purpose;
    @JsonProperty("CurrencyTypeCode")
    private CurrencyTypeCode currencyTypeCode;
    @JsonProperty("CarrierAdminSystem")
    private String carrierAdminSystem;
    @JsonProperty("CarrierAdminSubSystem")
    private CarrierAdminSubSystem carrierAdminSubSystem;
    @JsonProperty("CostBasis")
    private Integer costBasis;
    @JsonProperty("ComponentOfPackage")
    private ComponentOfPackage componentOfPackage;
    @JsonProperty("AssetValue")
    private Integer assetValue;
    @JsonProperty("LiabilityValue")
    private Integer liabilityValue;
    @JsonProperty("AsOfDate")
    private String asOfDate;
    @JsonProperty("LastFinActivityDate")
    private String lastFinActivityDate;
    @JsonProperty("LastFinActivityType")
    private LastFinActivityType lastFinActivityType;
    @JsonProperty("LastNonFinActivityDate")
    private String lastNonFinActivityDate;
    @JsonProperty("LastAnniversaryDate")
    private String lastAnniversaryDate;
    @JsonProperty("NextAnniversaryDate")
    private String nextAnniversaryDate;
    @JsonProperty("HoldingForm")
    private HoldingForm holdingForm;
    @JsonProperty("AssignmentCode")
    private AssignmentCode assignmentCode;
    @JsonProperty("QualifiedCode")
    private QualifiedCode qualifiedCode;
    @JsonProperty("RestrictionCode")
    private RestrictionCode restrictionCode;
    @JsonProperty("DistributorClientAcctNum")
    private String distributorClientAcctNum;
    @JsonProperty("CommissionHoldInd")
    private CommissionHoldInd commissionHoldInd;
    @JsonProperty("MarketType")
    private MarketType marketType;
    @JsonProperty("ShareClass")
    private ShareClass shareClass;
    @JsonProperty("Policy")
    private Policy policy;
    @JsonProperty("Investment")
    private Investment investment;
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("CompensationPayment")
    private List<Object> compensationPayment = new ArrayList<>();
    @JsonProperty("Intent")
    private List<Object> intent = new ArrayList<>();
    @JsonProperty("Arrangement")
    private List<Object> arrangement = new ArrayList<>();
    @JsonProperty("Loan")
    private List<Object> loan = new ArrayList<>();
    @JsonProperty("SystemMessage")
    private List<Object> systemMessage = new ArrayList<>();
    @JsonProperty("Banking")
    private Banking banking;
    @JsonProperty("Authorization")
    private List<Object> authorization = new ArrayList<>();
    @JsonProperty("HoldingXLat")
    private List<Object> holdingXLat = new ArrayList<>();
    @JsonProperty("Fee")
    private List<Object> fee = new ArrayList<>();
    @JsonProperty("RestrictionInfo")
    private List<Object> restrictionInfo = new ArrayList<>();
    @JsonProperty("PolicyValues")
    private PolicyValues policyValues;
    @JsonProperty("SurrenderChargeSchedule")
    private List<Object> surrenderChargeSchedule = new ArrayList<>();
    @JsonProperty("Integrator")
    private List<Object> integrator = new ArrayList<>();
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("HoldingKey")
    public HoldingKey getHoldingKey() {
        return holdingKey;
    }

    @JsonProperty("HoldingKey")
    public void setHoldingKey(HoldingKey holdingKey) {
        this.holdingKey = holdingKey;
    }

    public Holding withHoldingKey(HoldingKey holdingKey) {
        this.holdingKey = holdingKey;
        return this;
    }

    @JsonProperty("HoldingSysKey")
    public List<Object> getHoldingSysKey() {
        return holdingSysKey;
    }

    @JsonProperty("HoldingSysKey")
    public void setHoldingSysKey(List<Object> holdingSysKey) {
        this.holdingSysKey = holdingSysKey;
    }

    public Holding withHoldingSysKey(List<Object> holdingSysKey) {
        this.holdingSysKey = holdingSysKey;
        return this;
    }

    @JsonProperty("AccountDesignation")
    public AccountDesignation getAccountDesignation() {
        return accountDesignation;
    }

    @JsonProperty("AccountDesignation")
    public void setAccountDesignation(AccountDesignation accountDesignation) {
        this.accountDesignation = accountDesignation;
    }

    public Holding withAccountDesignation(AccountDesignation accountDesignation) {
        this.accountDesignation = accountDesignation;
        return this;
    }

    @JsonProperty("HoldingTypeCode")
    public HoldingTypeCode getHoldingTypeCode() {
        return holdingTypeCode;
    }

    @JsonProperty("HoldingTypeCode")
    public void setHoldingTypeCode(HoldingTypeCode holdingTypeCode) {
        this.holdingTypeCode = holdingTypeCode;
    }

    public Holding withHoldingTypeCode(HoldingTypeCode holdingTypeCode) {
        this.holdingTypeCode = holdingTypeCode;
        return this;
    }

    @JsonProperty("HoldingName")
    public String getHoldingName() {
        return holdingName;
    }

    @JsonProperty("HoldingName")
    public void setHoldingName(String holdingName) {
        this.holdingName = holdingName;
    }

    public Holding withHoldingName(String holdingName) {
        this.holdingName = holdingName;
        return this;
    }

    @JsonProperty("HoldingStatus")
    public HoldingStatus getHoldingStatus() {
        return holdingStatus;
    }

    @JsonProperty("HoldingStatus")
    public void setHoldingStatus(HoldingStatus holdingStatus) {
        this.holdingStatus = holdingStatus;
    }

    public Holding withHoldingStatus(HoldingStatus holdingStatus) {
        this.holdingStatus = holdingStatus;
        return this;
    }

    @JsonProperty("Purpose")
    public Purpose getPurpose() {
        return purpose;
    }

    @JsonProperty("Purpose")
    public void setPurpose(Purpose purpose) {
        this.purpose = purpose;
    }

    public Holding withPurpose(Purpose purpose) {
        this.purpose = purpose;
        return this;
    }

    @JsonProperty("CurrencyTypeCode")
    public CurrencyTypeCode getCurrencyTypeCode() {
        return currencyTypeCode;
    }

    @JsonProperty("CurrencyTypeCode")
    public void setCurrencyTypeCode(CurrencyTypeCode currencyTypeCode) {
        this.currencyTypeCode = currencyTypeCode;
    }

    public Holding withCurrencyTypeCode(CurrencyTypeCode currencyTypeCode) {
        this.currencyTypeCode = currencyTypeCode;
        return this;
    }

    @JsonProperty("CarrierAdminSystem")
    public String getCarrierAdminSystem() {
        return carrierAdminSystem;
    }

    @JsonProperty("CarrierAdminSystem")
    public void setCarrierAdminSystem(String carrierAdminSystem) {
        this.carrierAdminSystem = carrierAdminSystem;
    }

    public Holding withCarrierAdminSystem(String carrierAdminSystem) {
        this.carrierAdminSystem = carrierAdminSystem;
        return this;
    }

    @JsonProperty("CarrierAdminSubSystem")
    public CarrierAdminSubSystem getCarrierAdminSubSystem() {
        return carrierAdminSubSystem;
    }

    @JsonProperty("CarrierAdminSubSystem")
    public void setCarrierAdminSubSystem(CarrierAdminSubSystem carrierAdminSubSystem) {
        this.carrierAdminSubSystem = carrierAdminSubSystem;
    }

    public Holding withCarrierAdminSubSystem(CarrierAdminSubSystem carrierAdminSubSystem) {
        this.carrierAdminSubSystem = carrierAdminSubSystem;
        return this;
    }

    @JsonProperty("CostBasis")
    public Integer getCostBasis() {
        return costBasis;
    }

    @JsonProperty("CostBasis")
    public void setCostBasis(Integer costBasis) {
        this.costBasis = costBasis;
    }

    public Holding withCostBasis(Integer costBasis) {
        this.costBasis = costBasis;
        return this;
    }

    @JsonProperty("ComponentOfPackage")
    public ComponentOfPackage getComponentOfPackage() {
        return componentOfPackage;
    }

    @JsonProperty("ComponentOfPackage")
    public void setComponentOfPackage(ComponentOfPackage componentOfPackage) {
        this.componentOfPackage = componentOfPackage;
    }

    public Holding withComponentOfPackage(ComponentOfPackage componentOfPackage) {
        this.componentOfPackage = componentOfPackage;
        return this;
    }

    @JsonProperty("AssetValue")
    public Integer getAssetValue() {
        return assetValue;
    }

    @JsonProperty("AssetValue")
    public void setAssetValue(Integer assetValue) {
        this.assetValue = assetValue;
    }

    public Holding withAssetValue(Integer assetValue) {
        this.assetValue = assetValue;
        return this;
    }

    @JsonProperty("LiabilityValue")
    public Integer getLiabilityValue() {
        return liabilityValue;
    }

    @JsonProperty("LiabilityValue")
    public void setLiabilityValue(Integer liabilityValue) {
        this.liabilityValue = liabilityValue;
    }

    public Holding withLiabilityValue(Integer liabilityValue) {
        this.liabilityValue = liabilityValue;
        return this;
    }

    @JsonProperty("AsOfDate")
    public String getAsOfDate() {
        return asOfDate;
    }

    @JsonProperty("AsOfDate")
    public void setAsOfDate(String asOfDate) {
        this.asOfDate = asOfDate;
    }

    public Holding withAsOfDate(String asOfDate) {
        this.asOfDate = asOfDate;
        return this;
    }

    @JsonProperty("LastFinActivityDate")
    public String getLastFinActivityDate() {
        return lastFinActivityDate;
    }

    @JsonProperty("LastFinActivityDate")
    public void setLastFinActivityDate(String lastFinActivityDate) {
        this.lastFinActivityDate = lastFinActivityDate;
    }

    public Holding withLastFinActivityDate(String lastFinActivityDate) {
        this.lastFinActivityDate = lastFinActivityDate;
        return this;
    }

    @JsonProperty("LastFinActivityType")
    public LastFinActivityType getLastFinActivityType() {
        return lastFinActivityType;
    }

    @JsonProperty("LastFinActivityType")
    public void setLastFinActivityType(LastFinActivityType lastFinActivityType) {
        this.lastFinActivityType = lastFinActivityType;
    }

    public Holding withLastFinActivityType(LastFinActivityType lastFinActivityType) {
        this.lastFinActivityType = lastFinActivityType;
        return this;
    }

    @JsonProperty("LastNonFinActivityDate")
    public String getLastNonFinActivityDate() {
        return lastNonFinActivityDate;
    }

    @JsonProperty("LastNonFinActivityDate")
    public void setLastNonFinActivityDate(String lastNonFinActivityDate) {
        this.lastNonFinActivityDate = lastNonFinActivityDate;
    }

    public Holding withLastNonFinActivityDate(String lastNonFinActivityDate) {
        this.lastNonFinActivityDate = lastNonFinActivityDate;
        return this;
    }

    @JsonProperty("LastAnniversaryDate")
    public String getLastAnniversaryDate() {
        return lastAnniversaryDate;
    }

    @JsonProperty("LastAnniversaryDate")
    public void setLastAnniversaryDate(String lastAnniversaryDate) {
        this.lastAnniversaryDate = lastAnniversaryDate;
    }

    public Holding withLastAnniversaryDate(String lastAnniversaryDate) {
        this.lastAnniversaryDate = lastAnniversaryDate;
        return this;
    }

    @JsonProperty("NextAnniversaryDate")
    public String getNextAnniversaryDate() {
        return nextAnniversaryDate;
    }

    @JsonProperty("NextAnniversaryDate")
    public void setNextAnniversaryDate(String nextAnniversaryDate) {
        this.nextAnniversaryDate = nextAnniversaryDate;
    }

    public Holding withNextAnniversaryDate(String nextAnniversaryDate) {
        this.nextAnniversaryDate = nextAnniversaryDate;
        return this;
    }

    @JsonProperty("HoldingForm")
    public HoldingForm getHoldingForm() {
        return holdingForm;
    }

    @JsonProperty("HoldingForm")
    public void setHoldingForm(HoldingForm holdingForm) {
        this.holdingForm = holdingForm;
    }

    public Holding withHoldingForm(HoldingForm holdingForm) {
        this.holdingForm = holdingForm;
        return this;
    }

    @JsonProperty("AssignmentCode")
    public AssignmentCode getAssignmentCode() {
        return assignmentCode;
    }

    @JsonProperty("AssignmentCode")
    public void setAssignmentCode(AssignmentCode assignmentCode) {
        this.assignmentCode = assignmentCode;
    }

    public Holding withAssignmentCode(AssignmentCode assignmentCode) {
        this.assignmentCode = assignmentCode;
        return this;
    }

    @JsonProperty("QualifiedCode")
    public QualifiedCode getQualifiedCode() {
        return qualifiedCode;
    }

    @JsonProperty("QualifiedCode")
    public void setQualifiedCode(QualifiedCode qualifiedCode) {
        this.qualifiedCode = qualifiedCode;
    }

    public Holding withQualifiedCode(QualifiedCode qualifiedCode) {
        this.qualifiedCode = qualifiedCode;
        return this;
    }

    @JsonProperty("RestrictionCode")
    public RestrictionCode getRestrictionCode() {
        return restrictionCode;
    }

    @JsonProperty("RestrictionCode")
    public void setRestrictionCode(RestrictionCode restrictionCode) {
        this.restrictionCode = restrictionCode;
    }

    public Holding withRestrictionCode(RestrictionCode restrictionCode) {
        this.restrictionCode = restrictionCode;
        return this;
    }

    @JsonProperty("DistributorClientAcctNum")
    public String getDistributorClientAcctNum() {
        return distributorClientAcctNum;
    }

    @JsonProperty("DistributorClientAcctNum")
    public void setDistributorClientAcctNum(String distributorClientAcctNum) {
        this.distributorClientAcctNum = distributorClientAcctNum;
    }

    public Holding withDistributorClientAcctNum(String distributorClientAcctNum) {
        this.distributorClientAcctNum = distributorClientAcctNum;
        return this;
    }

    @JsonProperty("CommissionHoldInd")
    public CommissionHoldInd getCommissionHoldInd() {
        return commissionHoldInd;
    }

    @JsonProperty("CommissionHoldInd")
    public void setCommissionHoldInd(CommissionHoldInd commissionHoldInd) {
        this.commissionHoldInd = commissionHoldInd;
    }

    public Holding withCommissionHoldInd(CommissionHoldInd commissionHoldInd) {
        this.commissionHoldInd = commissionHoldInd;
        return this;
    }

    @JsonProperty("MarketType")
    public MarketType getMarketType() {
        return marketType;
    }

    @JsonProperty("MarketType")
    public void setMarketType(MarketType marketType) {
        this.marketType = marketType;
    }

    public Holding withMarketType(MarketType marketType) {
        this.marketType = marketType;
        return this;
    }

    @JsonProperty("ShareClass")
    public ShareClass getShareClass() {
        return shareClass;
    }

    @JsonProperty("ShareClass")
    public void setShareClass(ShareClass shareClass) {
        this.shareClass = shareClass;
    }

    public Holding withShareClass(ShareClass shareClass) {
        this.shareClass = shareClass;
        return this;
    }

    @JsonProperty("Policy")
    public Policy getPolicy() {
        return policy;
    }

    @JsonProperty("Policy")
    public void setPolicy(Policy policy) {
        this.policy = policy;
    }

    public Holding withPolicy(Policy policy) {
        this.policy = policy;
        return this;
    }

    @JsonProperty("Investment")
    public Investment getInvestment() {
        return investment;
    }

    @JsonProperty("Investment")
    public void setInvestment(Investment investment) {
        this.investment = investment;
    }

    public Holding withInvestment(Investment investment) {
        this.investment = investment;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public Holding withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("CompensationPayment")
    public List<Object> getCompensationPayment() {
        return compensationPayment;
    }

    @JsonProperty("CompensationPayment")
    public void setCompensationPayment(List<Object> compensationPayment) {
        this.compensationPayment = compensationPayment;
    }

    public Holding withCompensationPayment(List<Object> compensationPayment) {
        this.compensationPayment = compensationPayment;
        return this;
    }

    @JsonProperty("Intent")
    public List<Object> getIntent() {
        return intent;
    }

    @JsonProperty("Intent")
    public void setIntent(List<Object> intent) {
        this.intent = intent;
    }

    public Holding withIntent(List<Object> intent) {
        this.intent = intent;
        return this;
    }

    @JsonProperty("Arrangement")
    public List<Object> getArrangement() {
        return arrangement;
    }

    @JsonProperty("Arrangement")
    public void setArrangement(List<Object> arrangement) {
        this.arrangement = arrangement;
    }

    public Holding withArrangement(List<Object> arrangement) {
        this.arrangement = arrangement;
        return this;
    }

    @JsonProperty("Loan")
    public List<Object> getLoan() {
        return loan;
    }

    @JsonProperty("Loan")
    public void setLoan(List<Object> loan) {
        this.loan = loan;
    }

    public Holding withLoan(List<Object> loan) {
        this.loan = loan;
        return this;
    }

    @JsonProperty("SystemMessage")
    public List<Object> getSystemMessage() {
        return systemMessage;
    }

    @JsonProperty("SystemMessage")
    public void setSystemMessage(List<Object> systemMessage) {
        this.systemMessage = systemMessage;
    }

    public Holding withSystemMessage(List<Object> systemMessage) {
        this.systemMessage = systemMessage;
        return this;
    }

    @JsonProperty("Banking")
    public Banking getBanking() {
        return banking;
    }

    @JsonProperty("Banking")
    public void setBanking(Banking banking) {
        this.banking = banking;
    }

    public Holding withBanking(Banking banking) {
        this.banking = banking;
        return this;
    }

    @JsonProperty("Authorization")
    public List<Object> getAuthorization() {
        return authorization;
    }

    @JsonProperty("Authorization")
    public void setAuthorization(List<Object> authorization) {
        this.authorization = authorization;
    }

    public Holding withAuthorization(List<Object> authorization) {
        this.authorization = authorization;
        return this;
    }

    @JsonProperty("HoldingXLat")
    public List<Object> getHoldingXLat() {
        return holdingXLat;
    }

    @JsonProperty("HoldingXLat")
    public void setHoldingXLat(List<Object> holdingXLat) {
        this.holdingXLat = holdingXLat;
    }

    public Holding withHoldingXLat(List<Object> holdingXLat) {
        this.holdingXLat = holdingXLat;
        return this;
    }

    @JsonProperty("Fee")
    public List<Object> getFee() {
        return fee;
    }

    @JsonProperty("Fee")
    public void setFee(List<Object> fee) {
        this.fee = fee;
    }

    public Holding withFee(List<Object> fee) {
        this.fee = fee;
        return this;
    }

    @JsonProperty("RestrictionInfo")
    public List<Object> getRestrictionInfo() {
        return restrictionInfo;
    }

    @JsonProperty("RestrictionInfo")
    public void setRestrictionInfo(List<Object> restrictionInfo) {
        this.restrictionInfo = restrictionInfo;
    }

    public Holding withRestrictionInfo(List<Object> restrictionInfo) {
        this.restrictionInfo = restrictionInfo;
        return this;
    }

    @JsonProperty("PolicyValues")
    public PolicyValues getPolicyValues() {
        return policyValues;
    }

    @JsonProperty("PolicyValues")
    public void setPolicyValues(PolicyValues policyValues) {
        this.policyValues = policyValues;
    }

    public Holding withPolicyValues(PolicyValues policyValues) {
        this.policyValues = policyValues;
        return this;
    }

    @JsonProperty("SurrenderChargeSchedule")
    public List<Object> getSurrenderChargeSchedule() {
        return surrenderChargeSchedule;
    }

    @JsonProperty("SurrenderChargeSchedule")
    public void setSurrenderChargeSchedule(List<Object> surrenderChargeSchedule) {
        this.surrenderChargeSchedule = surrenderChargeSchedule;
    }

    public Holding withSurrenderChargeSchedule(List<Object> surrenderChargeSchedule) {
        this.surrenderChargeSchedule = surrenderChargeSchedule;
        return this;
    }

    @JsonProperty("Integrator")
    public List<Object> getIntegrator() {
        return integrator;
    }

    @JsonProperty("Integrator")
    public void setIntegrator(List<Object> integrator) {
        this.integrator = integrator;
    }

    public Holding withIntegrator(List<Object> integrator) {
        this.integrator = integrator;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public Holding withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Holding withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Holding withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public Holding withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Holding withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Holding.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("holdingKey");
        sb.append('=');
        sb.append(((this.holdingKey == null)?"<null>":this.holdingKey));
        sb.append(',');
        sb.append("holdingSysKey");
        sb.append('=');
        sb.append(((this.holdingSysKey == null)?"<null>":this.holdingSysKey));
        sb.append(',');
        sb.append("accountDesignation");
        sb.append('=');
        sb.append(((this.accountDesignation == null)?"<null>":this.accountDesignation));
        sb.append(',');
        sb.append("holdingTypeCode");
        sb.append('=');
        sb.append(((this.holdingTypeCode == null)?"<null>":this.holdingTypeCode));
        sb.append(',');
        sb.append("holdingName");
        sb.append('=');
        sb.append(((this.holdingName == null)?"<null>":this.holdingName));
        sb.append(',');
        sb.append("holdingStatus");
        sb.append('=');
        sb.append(((this.holdingStatus == null)?"<null>":this.holdingStatus));
        sb.append(',');
        sb.append("purpose");
        sb.append('=');
        sb.append(((this.purpose == null)?"<null>":this.purpose));
        sb.append(',');
        sb.append("currencyTypeCode");
        sb.append('=');
        sb.append(((this.currencyTypeCode == null)?"<null>":this.currencyTypeCode));
        sb.append(',');
        sb.append("carrierAdminSystem");
        sb.append('=');
        sb.append(((this.carrierAdminSystem == null)?"<null>":this.carrierAdminSystem));
        sb.append(',');
        sb.append("carrierAdminSubSystem");
        sb.append('=');
        sb.append(((this.carrierAdminSubSystem == null)?"<null>":this.carrierAdminSubSystem));
        sb.append(',');
        sb.append("costBasis");
        sb.append('=');
        sb.append(((this.costBasis == null)?"<null>":this.costBasis));
        sb.append(',');
        sb.append("componentOfPackage");
        sb.append('=');
        sb.append(((this.componentOfPackage == null)?"<null>":this.componentOfPackage));
        sb.append(',');
        sb.append("assetValue");
        sb.append('=');
        sb.append(((this.assetValue == null)?"<null>":this.assetValue));
        sb.append(',');
        sb.append("liabilityValue");
        sb.append('=');
        sb.append(((this.liabilityValue == null)?"<null>":this.liabilityValue));
        sb.append(',');
        sb.append("asOfDate");
        sb.append('=');
        sb.append(((this.asOfDate == null)?"<null>":this.asOfDate));
        sb.append(',');
        sb.append("lastFinActivityDate");
        sb.append('=');
        sb.append(((this.lastFinActivityDate == null)?"<null>":this.lastFinActivityDate));
        sb.append(',');
        sb.append("lastFinActivityType");
        sb.append('=');
        sb.append(((this.lastFinActivityType == null)?"<null>":this.lastFinActivityType));
        sb.append(',');
        sb.append("lastNonFinActivityDate");
        sb.append('=');
        sb.append(((this.lastNonFinActivityDate == null)?"<null>":this.lastNonFinActivityDate));
        sb.append(',');
        sb.append("lastAnniversaryDate");
        sb.append('=');
        sb.append(((this.lastAnniversaryDate == null)?"<null>":this.lastAnniversaryDate));
        sb.append(',');
        sb.append("nextAnniversaryDate");
        sb.append('=');
        sb.append(((this.nextAnniversaryDate == null)?"<null>":this.nextAnniversaryDate));
        sb.append(',');
        sb.append("holdingForm");
        sb.append('=');
        sb.append(((this.holdingForm == null)?"<null>":this.holdingForm));
        sb.append(',');
        sb.append("assignmentCode");
        sb.append('=');
        sb.append(((this.assignmentCode == null)?"<null>":this.assignmentCode));
        sb.append(',');
        sb.append("qualifiedCode");
        sb.append('=');
        sb.append(((this.qualifiedCode == null)?"<null>":this.qualifiedCode));
        sb.append(',');
        sb.append("restrictionCode");
        sb.append('=');
        sb.append(((this.restrictionCode == null)?"<null>":this.restrictionCode));
        sb.append(',');
        sb.append("distributorClientAcctNum");
        sb.append('=');
        sb.append(((this.distributorClientAcctNum == null)?"<null>":this.distributorClientAcctNum));
        sb.append(',');
        sb.append("commissionHoldInd");
        sb.append('=');
        sb.append(((this.commissionHoldInd == null)?"<null>":this.commissionHoldInd));
        sb.append(',');
        sb.append("marketType");
        sb.append('=');
        sb.append(((this.marketType == null)?"<null>":this.marketType));
        sb.append(',');
        sb.append("shareClass");
        sb.append('=');
        sb.append(((this.shareClass == null)?"<null>":this.shareClass));
        sb.append(',');
        sb.append("policy");
        sb.append('=');
        sb.append(((this.policy == null)?"<null>":this.policy));
        sb.append(',');
        sb.append("investment");
        sb.append('=');
        sb.append(((this.investment == null)?"<null>":this.investment));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("compensationPayment");
        sb.append('=');
        sb.append(((this.compensationPayment == null)?"<null>":this.compensationPayment));
        sb.append(',');
        sb.append("intent");
        sb.append('=');
        sb.append(((this.intent == null)?"<null>":this.intent));
        sb.append(',');
        sb.append("arrangement");
        sb.append('=');
        sb.append(((this.arrangement == null)?"<null>":this.arrangement));
        sb.append(',');
        sb.append("loan");
        sb.append('=');
        sb.append(((this.loan == null)?"<null>":this.loan));
        sb.append(',');
        sb.append("systemMessage");
        sb.append('=');
        sb.append(((this.systemMessage == null)?"<null>":this.systemMessage));
        sb.append(',');
        sb.append("banking");
        sb.append('=');
        sb.append(((this.banking == null)?"<null>":this.banking));
        sb.append(',');
        sb.append("authorization");
        sb.append('=');
        sb.append(((this.authorization == null)?"<null>":this.authorization));
        sb.append(',');
        sb.append("holdingXLat");
        sb.append('=');
        sb.append(((this.holdingXLat == null)?"<null>":this.holdingXLat));
        sb.append(',');
        sb.append("fee");
        sb.append('=');
        sb.append(((this.fee == null)?"<null>":this.fee));
        sb.append(',');
        sb.append("restrictionInfo");
        sb.append('=');
        sb.append(((this.restrictionInfo == null)?"<null>":this.restrictionInfo));
        sb.append(',');
        sb.append("policyValues");
        sb.append('=');
        sb.append(((this.policyValues == null)?"<null>":this.policyValues));
        sb.append(',');
        sb.append("surrenderChargeSchedule");
        sb.append('=');
        sb.append(((this.surrenderChargeSchedule == null)?"<null>":this.surrenderChargeSchedule));
        sb.append(',');
        sb.append("integrator");
        sb.append('=');
        sb.append(((this.integrator == null)?"<null>":this.integrator));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.holdingStatus == null)? 0 :this.holdingStatus.hashCode()));
        result = ((result* 31)+((this.systemMessage == null)? 0 :this.systemMessage.hashCode()));
        result = ((result* 31)+((this.shareClass == null)? 0 :this.shareClass.hashCode()));
        result = ((result* 31)+((this.fee == null)? 0 :this.fee.hashCode()));
        result = ((result* 31)+((this.restrictionInfo == null)? 0 :this.restrictionInfo.hashCode()));
        result = ((result* 31)+((this.assetValue == null)? 0 :this.assetValue.hashCode()));
        result = ((result* 31)+((this.integrator == null)? 0 :this.integrator.hashCode()));
        result = ((result* 31)+((this.marketType == null)? 0 :this.marketType.hashCode()));
        result = ((result* 31)+((this.arrangement == null)? 0 :this.arrangement.hashCode()));
        result = ((result* 31)+((this.authorization == null)? 0 :this.authorization.hashCode()));
        result = ((result* 31)+((this.currencyTypeCode == null)? 0 :this.currencyTypeCode.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.holdingSysKey == null)? 0 :this.holdingSysKey.hashCode()));
        result = ((result* 31)+((this.compensationPayment == null)? 0 :this.compensationPayment.hashCode()));
        result = ((result* 31)+((this.lastNonFinActivityDate == null)? 0 :this.lastNonFinActivityDate.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.holdingForm == null)? 0 :this.holdingForm.hashCode()));
        result = ((result* 31)+((this.carrierAdminSystem == null)? 0 :this.carrierAdminSystem.hashCode()));
        result = ((result* 31)+((this.surrenderChargeSchedule == null)? 0 :this.surrenderChargeSchedule.hashCode()));
        result = ((result* 31)+((this.lastAnniversaryDate == null)? 0 :this.lastAnniversaryDate.hashCode()));
        result = ((result* 31)+((this.investment == null)? 0 :this.investment.hashCode()));
        result = ((result* 31)+((this.lastFinActivityType == null)? 0 :this.lastFinActivityType.hashCode()));
        result = ((result* 31)+((this.costBasis == null)? 0 :this.costBasis.hashCode()));
        result = ((result* 31)+((this.assignmentCode == null)? 0 :this.assignmentCode.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.asOfDate == null)? 0 :this.asOfDate.hashCode()));
        result = ((result* 31)+((this.lastFinActivityDate == null)? 0 :this.lastFinActivityDate.hashCode()));
        result = ((result* 31)+((this.loan == null)? 0 :this.loan.hashCode()));
        result = ((result* 31)+((this.purpose == null)? 0 :this.purpose.hashCode()));
        result = ((result* 31)+((this.distributorClientAcctNum == null)? 0 :this.distributorClientAcctNum.hashCode()));
        result = ((result* 31)+((this.holdingKey == null)? 0 :this.holdingKey.hashCode()));
        result = ((result* 31)+((this.holdingTypeCode == null)? 0 :this.holdingTypeCode.hashCode()));
        result = ((result* 31)+((this.componentOfPackage == null)? 0 :this.componentOfPackage.hashCode()));
        result = ((result* 31)+((this.banking == null)? 0 :this.banking.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.restrictionCode == null)? 0 :this.restrictionCode.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        result = ((result* 31)+((this.policyValues == null)? 0 :this.policyValues.hashCode()));
        result = ((result* 31)+((this.nextAnniversaryDate == null)? 0 :this.nextAnniversaryDate.hashCode()));
        result = ((result* 31)+((this.liabilityValue == null)? 0 :this.liabilityValue.hashCode()));
        result = ((result* 31)+((this.commissionHoldInd == null)? 0 :this.commissionHoldInd.hashCode()));
        result = ((result* 31)+((this.policy == null)? 0 :this.policy.hashCode()));
        result = ((result* 31)+((this.carrierAdminSubSystem == null)? 0 :this.carrierAdminSubSystem.hashCode()));
        result = ((result* 31)+((this.holdingName == null)? 0 :this.holdingName.hashCode()));
        result = ((result* 31)+((this.holdingXLat == null)? 0 :this.holdingXLat.hashCode()));
        result = ((result* 31)+((this.accountDesignation == null)? 0 :this.accountDesignation.hashCode()));
        result = ((result* 31)+((this.intent == null)? 0 :this.intent.hashCode()));
        result = ((result* 31)+((this.qualifiedCode == null)? 0 :this.qualifiedCode.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Holding) == false) {
            return false;
        }
        Holding rhs = ((Holding) other);
        return ((((((((((((((((((((((((((((((((((((((((((((((((((this.holdingStatus == rhs.holdingStatus)||((this.holdingStatus!= null)&&this.holdingStatus.equals(rhs.holdingStatus)))&&((this.systemMessage == rhs.systemMessage)||((this.systemMessage!= null)&&this.systemMessage.equals(rhs.systemMessage))))&&((this.shareClass == rhs.shareClass)||((this.shareClass!= null)&&this.shareClass.equals(rhs.shareClass))))&&((this.fee == rhs.fee)||((this.fee!= null)&&this.fee.equals(rhs.fee))))&&((this.restrictionInfo == rhs.restrictionInfo)||((this.restrictionInfo!= null)&&this.restrictionInfo.equals(rhs.restrictionInfo))))&&((this.assetValue == rhs.assetValue)||((this.assetValue!= null)&&this.assetValue.equals(rhs.assetValue))))&&((this.integrator == rhs.integrator)||((this.integrator!= null)&&this.integrator.equals(rhs.integrator))))&&((this.marketType == rhs.marketType)||((this.marketType!= null)&&this.marketType.equals(rhs.marketType))))&&((this.arrangement == rhs.arrangement)||((this.arrangement!= null)&&this.arrangement.equals(rhs.arrangement))))&&((this.authorization == rhs.authorization)||((this.authorization!= null)&&this.authorization.equals(rhs.authorization))))&&((this.currencyTypeCode == rhs.currencyTypeCode)||((this.currencyTypeCode!= null)&&this.currencyTypeCode.equals(rhs.currencyTypeCode))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.holdingSysKey == rhs.holdingSysKey)||((this.holdingSysKey!= null)&&this.holdingSysKey.equals(rhs.holdingSysKey))))&&((this.compensationPayment == rhs.compensationPayment)||((this.compensationPayment!= null)&&this.compensationPayment.equals(rhs.compensationPayment))))&&((this.lastNonFinActivityDate == rhs.lastNonFinActivityDate)||((this.lastNonFinActivityDate!= null)&&this.lastNonFinActivityDate.equals(rhs.lastNonFinActivityDate))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.holdingForm == rhs.holdingForm)||((this.holdingForm!= null)&&this.holdingForm.equals(rhs.holdingForm))))&&((this.carrierAdminSystem == rhs.carrierAdminSystem)||((this.carrierAdminSystem!= null)&&this.carrierAdminSystem.equals(rhs.carrierAdminSystem))))&&((this.surrenderChargeSchedule == rhs.surrenderChargeSchedule)||((this.surrenderChargeSchedule!= null)&&this.surrenderChargeSchedule.equals(rhs.surrenderChargeSchedule))))&&((this.lastAnniversaryDate == rhs.lastAnniversaryDate)||((this.lastAnniversaryDate!= null)&&this.lastAnniversaryDate.equals(rhs.lastAnniversaryDate))))&&((this.investment == rhs.investment)||((this.investment!= null)&&this.investment.equals(rhs.investment))))&&((this.lastFinActivityType == rhs.lastFinActivityType)||((this.lastFinActivityType!= null)&&this.lastFinActivityType.equals(rhs.lastFinActivityType))))&&((this.costBasis == rhs.costBasis)||((this.costBasis!= null)&&this.costBasis.equals(rhs.costBasis))))&&((this.assignmentCode == rhs.assignmentCode)||((this.assignmentCode!= null)&&this.assignmentCode.equals(rhs.assignmentCode))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.asOfDate == rhs.asOfDate)||((this.asOfDate!= null)&&this.asOfDate.equals(rhs.asOfDate))))&&((this.lastFinActivityDate == rhs.lastFinActivityDate)||((this.lastFinActivityDate!= null)&&this.lastFinActivityDate.equals(rhs.lastFinActivityDate))))&&((this.loan == rhs.loan)||((this.loan!= null)&&this.loan.equals(rhs.loan))))&&((this.purpose == rhs.purpose)||((this.purpose!= null)&&this.purpose.equals(rhs.purpose))))&&((this.distributorClientAcctNum == rhs.distributorClientAcctNum)||((this.distributorClientAcctNum!= null)&&this.distributorClientAcctNum.equals(rhs.distributorClientAcctNum))))&&((this.holdingKey == rhs.holdingKey)||((this.holdingKey!= null)&&this.holdingKey.equals(rhs.holdingKey))))&&((this.holdingTypeCode == rhs.holdingTypeCode)||((this.holdingTypeCode!= null)&&this.holdingTypeCode.equals(rhs.holdingTypeCode))))&&((this.componentOfPackage == rhs.componentOfPackage)||((this.componentOfPackage!= null)&&this.componentOfPackage.equals(rhs.componentOfPackage))))&&((this.banking == rhs.banking)||((this.banking!= null)&&this.banking.equals(rhs.banking))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.restrictionCode == rhs.restrictionCode)||((this.restrictionCode!= null)&&this.restrictionCode.equals(rhs.restrictionCode))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))))&&((this.policyValues == rhs.policyValues)||((this.policyValues!= null)&&this.policyValues.equals(rhs.policyValues))))&&((this.nextAnniversaryDate == rhs.nextAnniversaryDate)||((this.nextAnniversaryDate!= null)&&this.nextAnniversaryDate.equals(rhs.nextAnniversaryDate))))&&((this.liabilityValue == rhs.liabilityValue)||((this.liabilityValue!= null)&&this.liabilityValue.equals(rhs.liabilityValue))))&&((this.commissionHoldInd == rhs.commissionHoldInd)||((this.commissionHoldInd!= null)&&this.commissionHoldInd.equals(rhs.commissionHoldInd))))&&((this.policy == rhs.policy)||((this.policy!= null)&&this.policy.equals(rhs.policy))))&&((this.carrierAdminSubSystem == rhs.carrierAdminSubSystem)||((this.carrierAdminSubSystem!= null)&&this.carrierAdminSubSystem.equals(rhs.carrierAdminSubSystem))))&&((this.holdingName == rhs.holdingName)||((this.holdingName!= null)&&this.holdingName.equals(rhs.holdingName))))&&((this.holdingXLat == rhs.holdingXLat)||((this.holdingXLat!= null)&&this.holdingXLat.equals(rhs.holdingXLat))))&&((this.accountDesignation == rhs.accountDesignation)||((this.accountDesignation!= null)&&this.accountDesignation.equals(rhs.accountDesignation))))&&((this.intent == rhs.intent)||((this.intent!= null)&&this.intent.equals(rhs.intent))))&&((this.qualifiedCode == rhs.qualifiedCode)||((this.qualifiedCode!= null)&&this.qualifiedCode.equals(rhs.qualifiedCode))));
    }

}
