
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AllowedDistributionAgreementKey",
    "AllowedDistributionAgreementSysKey",
    "CarrierCode",
    "DistributionAgreementCode",
    "EffDate",
    "EndDate",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AllowedDistributionAgreement {

    @JsonProperty("AllowedDistributionAgreementKey")
    private AllowedDistributionAgreementKey allowedDistributionAgreementKey;
    @JsonProperty("AllowedDistributionAgreementSysKey")
    private List<Object> allowedDistributionAgreementSysKey = new ArrayList<>();
    @JsonProperty("CarrierCode")
    private String carrierCode;
    @JsonProperty("DistributionAgreementCode")
    private String distributionAgreementCode;
    @JsonProperty("EffDate")
    private String effDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AllowedDistributionAgreementKey")
    public AllowedDistributionAgreementKey getAllowedDistributionAgreementKey() {
        return allowedDistributionAgreementKey;
    }

    @JsonProperty("AllowedDistributionAgreementKey")
    public void setAllowedDistributionAgreementKey(AllowedDistributionAgreementKey allowedDistributionAgreementKey) {
        this.allowedDistributionAgreementKey = allowedDistributionAgreementKey;
    }

    public AllowedDistributionAgreement withAllowedDistributionAgreementKey(AllowedDistributionAgreementKey allowedDistributionAgreementKey) {
        this.allowedDistributionAgreementKey = allowedDistributionAgreementKey;
        return this;
    }

    @JsonProperty("AllowedDistributionAgreementSysKey")
    public List<Object> getAllowedDistributionAgreementSysKey() {
        return allowedDistributionAgreementSysKey;
    }

    @JsonProperty("AllowedDistributionAgreementSysKey")
    public void setAllowedDistributionAgreementSysKey(List<Object> allowedDistributionAgreementSysKey) {
        this.allowedDistributionAgreementSysKey = allowedDistributionAgreementSysKey;
    }

    public AllowedDistributionAgreement withAllowedDistributionAgreementSysKey(List<Object> allowedDistributionAgreementSysKey) {
        this.allowedDistributionAgreementSysKey = allowedDistributionAgreementSysKey;
        return this;
    }

    @JsonProperty("CarrierCode")
    public String getCarrierCode() {
        return carrierCode;
    }

    @JsonProperty("CarrierCode")
    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    public AllowedDistributionAgreement withCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
        return this;
    }

    @JsonProperty("DistributionAgreementCode")
    public String getDistributionAgreementCode() {
        return distributionAgreementCode;
    }

    @JsonProperty("DistributionAgreementCode")
    public void setDistributionAgreementCode(String distributionAgreementCode) {
        this.distributionAgreementCode = distributionAgreementCode;
    }

    public AllowedDistributionAgreement withDistributionAgreementCode(String distributionAgreementCode) {
        this.distributionAgreementCode = distributionAgreementCode;
        return this;
    }

    @JsonProperty("EffDate")
    public String getEffDate() {
        return effDate;
    }

    @JsonProperty("EffDate")
    public void setEffDate(String effDate) {
        this.effDate = effDate;
    }

    public AllowedDistributionAgreement withEffDate(String effDate) {
        this.effDate = effDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public AllowedDistributionAgreement withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AllowedDistributionAgreement withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AllowedDistributionAgreement withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AllowedDistributionAgreement withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AllowedDistributionAgreement withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AllowedDistributionAgreement.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("allowedDistributionAgreementKey");
        sb.append('=');
        sb.append(((this.allowedDistributionAgreementKey == null)?"<null>":this.allowedDistributionAgreementKey));
        sb.append(',');
        sb.append("allowedDistributionAgreementSysKey");
        sb.append('=');
        sb.append(((this.allowedDistributionAgreementSysKey == null)?"<null>":this.allowedDistributionAgreementSysKey));
        sb.append(',');
        sb.append("carrierCode");
        sb.append('=');
        sb.append(((this.carrierCode == null)?"<null>":this.carrierCode));
        sb.append(',');
        sb.append("distributionAgreementCode");
        sb.append('=');
        sb.append(((this.distributionAgreementCode == null)?"<null>":this.distributionAgreementCode));
        sb.append(',');
        sb.append("effDate");
        sb.append('=');
        sb.append(((this.effDate == null)?"<null>":this.effDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.allowedDistributionAgreementSysKey == null)? 0 :this.allowedDistributionAgreementSysKey.hashCode()));
        result = ((result* 31)+((this.effDate == null)? 0 :this.effDate.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.carrierCode == null)? 0 :this.carrierCode.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.allowedDistributionAgreementKey == null)? 0 :this.allowedDistributionAgreementKey.hashCode()));
        result = ((result* 31)+((this.distributionAgreementCode == null)? 0 :this.distributionAgreementCode.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AllowedDistributionAgreement) == false) {
            return false;
        }
        AllowedDistributionAgreement rhs = ((AllowedDistributionAgreement) other);
        return (((((((((((this.allowedDistributionAgreementSysKey == rhs.allowedDistributionAgreementSysKey)||((this.allowedDistributionAgreementSysKey!= null)&&this.allowedDistributionAgreementSysKey.equals(rhs.allowedDistributionAgreementSysKey)))&&((this.effDate == rhs.effDate)||((this.effDate!= null)&&this.effDate.equals(rhs.effDate))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.carrierCode == rhs.carrierCode)||((this.carrierCode!= null)&&this.carrierCode.equals(rhs.carrierCode))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.allowedDistributionAgreementKey == rhs.allowedDistributionAgreementKey)||((this.allowedDistributionAgreementKey!= null)&&this.allowedDistributionAgreementKey.equals(rhs.allowedDistributionAgreementKey))))&&((this.distributionAgreementCode == rhs.distributionAgreementCode)||((this.distributionAgreementCode!= null)&&this.distributionAgreementCode.equals(rhs.distributionAgreementCode))));
    }

}
