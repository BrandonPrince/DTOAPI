
package haj.com.astute.json.to.pojo;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CertificateRatingTypeCode",
    "CertificateRatingTypeDesc"
})
@Generated("jsonschema2pojo")
public class CertificateRatingType {

    @JsonProperty("CertificateRatingTypeCode")
    private CertificateRatingTypeCode certificateRatingTypeCode;
    @JsonProperty("CertificateRatingTypeDesc")
    private String certificateRatingTypeDesc;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("CertificateRatingTypeCode")
    public CertificateRatingTypeCode getCertificateRatingTypeCode() {
        return certificateRatingTypeCode;
    }

    @JsonProperty("CertificateRatingTypeCode")
    public void setCertificateRatingTypeCode(CertificateRatingTypeCode certificateRatingTypeCode) {
        this.certificateRatingTypeCode = certificateRatingTypeCode;
    }

    public CertificateRatingType withCertificateRatingTypeCode(CertificateRatingTypeCode certificateRatingTypeCode) {
        this.certificateRatingTypeCode = certificateRatingTypeCode;
        return this;
    }

    @JsonProperty("CertificateRatingTypeDesc")
    public String getCertificateRatingTypeDesc() {
        return certificateRatingTypeDesc;
    }

    @JsonProperty("CertificateRatingTypeDesc")
    public void setCertificateRatingTypeDesc(String certificateRatingTypeDesc) {
        this.certificateRatingTypeDesc = certificateRatingTypeDesc;
    }

    public CertificateRatingType withCertificateRatingTypeDesc(String certificateRatingTypeDesc) {
        this.certificateRatingTypeDesc = certificateRatingTypeDesc;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CertificateRatingType withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(CertificateRatingType.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("certificateRatingTypeCode");
        sb.append('=');
        sb.append(((this.certificateRatingTypeCode == null)?"<null>":this.certificateRatingTypeCode));
        sb.append(',');
        sb.append("certificateRatingTypeDesc");
        sb.append('=');
        sb.append(((this.certificateRatingTypeDesc == null)?"<null>":this.certificateRatingTypeDesc));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.certificateRatingTypeCode == null)? 0 :this.certificateRatingTypeCode.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.certificateRatingTypeDesc == null)? 0 :this.certificateRatingTypeDesc.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CertificateRatingType) == false) {
            return false;
        }
        CertificateRatingType rhs = ((CertificateRatingType) other);
        return ((((this.certificateRatingTypeCode == rhs.certificateRatingTypeCode)||((this.certificateRatingTypeCode!= null)&&this.certificateRatingTypeCode.equals(rhs.certificateRatingTypeCode)))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.certificateRatingTypeDesc == rhs.certificateRatingTypeDesc)||((this.certificateRatingTypeDesc!= null)&&this.certificateRatingTypeDesc.equals(rhs.certificateRatingTypeDesc))));
    }

}
