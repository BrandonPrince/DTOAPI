
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "FeatureOptRequisiteKey",
    "FeatureOptRequisiteSysKey",
    "FeatureCode",
    "ProductCode",
    "RequisiteLogic",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class FeatureOptRequisite {

    @JsonProperty("FeatureOptRequisiteKey")
    private FeatureOptRequisiteKey featureOptRequisiteKey;
    @JsonProperty("FeatureOptRequisiteSysKey")
    private List<Object> featureOptRequisiteSysKey = new ArrayList<>();
    @JsonProperty("FeatureCode")
    private String featureCode;
    @JsonProperty("ProductCode")
    private String productCode;
    @JsonProperty("RequisiteLogic")
    private RequisiteLogic requisiteLogic;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("FeatureOptRequisiteKey")
    public FeatureOptRequisiteKey getFeatureOptRequisiteKey() {
        return featureOptRequisiteKey;
    }

    @JsonProperty("FeatureOptRequisiteKey")
    public void setFeatureOptRequisiteKey(FeatureOptRequisiteKey featureOptRequisiteKey) {
        this.featureOptRequisiteKey = featureOptRequisiteKey;
    }

    public FeatureOptRequisite withFeatureOptRequisiteKey(FeatureOptRequisiteKey featureOptRequisiteKey) {
        this.featureOptRequisiteKey = featureOptRequisiteKey;
        return this;
    }

    @JsonProperty("FeatureOptRequisiteSysKey")
    public List<Object> getFeatureOptRequisiteSysKey() {
        return featureOptRequisiteSysKey;
    }

    @JsonProperty("FeatureOptRequisiteSysKey")
    public void setFeatureOptRequisiteSysKey(List<Object> featureOptRequisiteSysKey) {
        this.featureOptRequisiteSysKey = featureOptRequisiteSysKey;
    }

    public FeatureOptRequisite withFeatureOptRequisiteSysKey(List<Object> featureOptRequisiteSysKey) {
        this.featureOptRequisiteSysKey = featureOptRequisiteSysKey;
        return this;
    }

    @JsonProperty("FeatureCode")
    public String getFeatureCode() {
        return featureCode;
    }

    @JsonProperty("FeatureCode")
    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    public FeatureOptRequisite withFeatureCode(String featureCode) {
        this.featureCode = featureCode;
        return this;
    }

    @JsonProperty("ProductCode")
    public String getProductCode() {
        return productCode;
    }

    @JsonProperty("ProductCode")
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public FeatureOptRequisite withProductCode(String productCode) {
        this.productCode = productCode;
        return this;
    }

    @JsonProperty("RequisiteLogic")
    public RequisiteLogic getRequisiteLogic() {
        return requisiteLogic;
    }

    @JsonProperty("RequisiteLogic")
    public void setRequisiteLogic(RequisiteLogic requisiteLogic) {
        this.requisiteLogic = requisiteLogic;
    }

    public FeatureOptRequisite withRequisiteLogic(RequisiteLogic requisiteLogic) {
        this.requisiteLogic = requisiteLogic;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public FeatureOptRequisite withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public FeatureOptRequisite withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public FeatureOptRequisite withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public FeatureOptRequisite withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(FeatureOptRequisite.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("featureOptRequisiteKey");
        sb.append('=');
        sb.append(((this.featureOptRequisiteKey == null)?"<null>":this.featureOptRequisiteKey));
        sb.append(',');
        sb.append("featureOptRequisiteSysKey");
        sb.append('=');
        sb.append(((this.featureOptRequisiteSysKey == null)?"<null>":this.featureOptRequisiteSysKey));
        sb.append(',');
        sb.append("featureCode");
        sb.append('=');
        sb.append(((this.featureCode == null)?"<null>":this.featureCode));
        sb.append(',');
        sb.append("productCode");
        sb.append('=');
        sb.append(((this.productCode == null)?"<null>":this.productCode));
        sb.append(',');
        sb.append("requisiteLogic");
        sb.append('=');
        sb.append(((this.requisiteLogic == null)?"<null>":this.requisiteLogic));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.featureCode == null)? 0 :this.featureCode.hashCode()));
        result = ((result* 31)+((this.productCode == null)? 0 :this.productCode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.featureOptRequisiteSysKey == null)? 0 :this.featureOptRequisiteSysKey.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.requisiteLogic == null)? 0 :this.requisiteLogic.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.featureOptRequisiteKey == null)? 0 :this.featureOptRequisiteKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof FeatureOptRequisite) == false) {
            return false;
        }
        FeatureOptRequisite rhs = ((FeatureOptRequisite) other);
        return ((((((((((this.featureCode == rhs.featureCode)||((this.featureCode!= null)&&this.featureCode.equals(rhs.featureCode)))&&((this.productCode == rhs.productCode)||((this.productCode!= null)&&this.productCode.equals(rhs.productCode))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.featureOptRequisiteSysKey == rhs.featureOptRequisiteSysKey)||((this.featureOptRequisiteSysKey!= null)&&this.featureOptRequisiteSysKey.equals(rhs.featureOptRequisiteSysKey))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.requisiteLogic == rhs.requisiteLogic)||((this.requisiteLogic!= null)&&this.requisiteLogic.equals(rhs.requisiteLogic))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.featureOptRequisiteKey == rhs.featureOptRequisiteKey)||((this.featureOptRequisiteKey!= null)&&this.featureOptRequisiteKey.equals(rhs.featureOptRequisiteKey))));
    }

}
