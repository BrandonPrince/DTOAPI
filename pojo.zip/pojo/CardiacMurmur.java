
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CardiacMurmurKey",
    "CardiacMurmurSysKey",
    "ConditionInd",
    "TransmittedInd",
    "IntensityGradeTC",
    "LocationTC",
    "QualityTC",
    "TimingTC",
    "AfterExerciseDesc",
    "OLifEExtension",
    "id",
    "PartyID",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class CardiacMurmur {

    @JsonProperty("CardiacMurmurKey")
    private CardiacMurmurKey cardiacMurmurKey;
    @JsonProperty("CardiacMurmurSysKey")
    private List<Object> cardiacMurmurSysKey = new ArrayList<>();
    @JsonProperty("ConditionInd")
    private ConditionInd conditionInd;
    @JsonProperty("TransmittedInd")
    private TransmittedInd transmittedInd;
    @JsonProperty("IntensityGradeTC")
    private IntensityGradeTC intensityGradeTC;
    @JsonProperty("LocationTC")
    private LocationTC locationTC;
    @JsonProperty("QualityTC")
    private QualityTC qualityTC;
    @JsonProperty("TimingTC")
    private TimingTC timingTC;
    @JsonProperty("AfterExerciseDesc")
    private String afterExerciseDesc;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("PartyID")
    private String partyID;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("CardiacMurmurKey")
    public CardiacMurmurKey getCardiacMurmurKey() {
        return cardiacMurmurKey;
    }

    @JsonProperty("CardiacMurmurKey")
    public void setCardiacMurmurKey(CardiacMurmurKey cardiacMurmurKey) {
        this.cardiacMurmurKey = cardiacMurmurKey;
    }

    public CardiacMurmur withCardiacMurmurKey(CardiacMurmurKey cardiacMurmurKey) {
        this.cardiacMurmurKey = cardiacMurmurKey;
        return this;
    }

    @JsonProperty("CardiacMurmurSysKey")
    public List<Object> getCardiacMurmurSysKey() {
        return cardiacMurmurSysKey;
    }

    @JsonProperty("CardiacMurmurSysKey")
    public void setCardiacMurmurSysKey(List<Object> cardiacMurmurSysKey) {
        this.cardiacMurmurSysKey = cardiacMurmurSysKey;
    }

    public CardiacMurmur withCardiacMurmurSysKey(List<Object> cardiacMurmurSysKey) {
        this.cardiacMurmurSysKey = cardiacMurmurSysKey;
        return this;
    }

    @JsonProperty("ConditionInd")
    public ConditionInd getConditionInd() {
        return conditionInd;
    }

    @JsonProperty("ConditionInd")
    public void setConditionInd(ConditionInd conditionInd) {
        this.conditionInd = conditionInd;
    }

    public CardiacMurmur withConditionInd(ConditionInd conditionInd) {
        this.conditionInd = conditionInd;
        return this;
    }

    @JsonProperty("TransmittedInd")
    public TransmittedInd getTransmittedInd() {
        return transmittedInd;
    }

    @JsonProperty("TransmittedInd")
    public void setTransmittedInd(TransmittedInd transmittedInd) {
        this.transmittedInd = transmittedInd;
    }

    public CardiacMurmur withTransmittedInd(TransmittedInd transmittedInd) {
        this.transmittedInd = transmittedInd;
        return this;
    }

    @JsonProperty("IntensityGradeTC")
    public IntensityGradeTC getIntensityGradeTC() {
        return intensityGradeTC;
    }

    @JsonProperty("IntensityGradeTC")
    public void setIntensityGradeTC(IntensityGradeTC intensityGradeTC) {
        this.intensityGradeTC = intensityGradeTC;
    }

    public CardiacMurmur withIntensityGradeTC(IntensityGradeTC intensityGradeTC) {
        this.intensityGradeTC = intensityGradeTC;
        return this;
    }

    @JsonProperty("LocationTC")
    public LocationTC getLocationTC() {
        return locationTC;
    }

    @JsonProperty("LocationTC")
    public void setLocationTC(LocationTC locationTC) {
        this.locationTC = locationTC;
    }

    public CardiacMurmur withLocationTC(LocationTC locationTC) {
        this.locationTC = locationTC;
        return this;
    }

    @JsonProperty("QualityTC")
    public QualityTC getQualityTC() {
        return qualityTC;
    }

    @JsonProperty("QualityTC")
    public void setQualityTC(QualityTC qualityTC) {
        this.qualityTC = qualityTC;
    }

    public CardiacMurmur withQualityTC(QualityTC qualityTC) {
        this.qualityTC = qualityTC;
        return this;
    }

    @JsonProperty("TimingTC")
    public TimingTC getTimingTC() {
        return timingTC;
    }

    @JsonProperty("TimingTC")
    public void setTimingTC(TimingTC timingTC) {
        this.timingTC = timingTC;
    }

    public CardiacMurmur withTimingTC(TimingTC timingTC) {
        this.timingTC = timingTC;
        return this;
    }

    @JsonProperty("AfterExerciseDesc")
    public String getAfterExerciseDesc() {
        return afterExerciseDesc;
    }

    @JsonProperty("AfterExerciseDesc")
    public void setAfterExerciseDesc(String afterExerciseDesc) {
        this.afterExerciseDesc = afterExerciseDesc;
    }

    public CardiacMurmur withAfterExerciseDesc(String afterExerciseDesc) {
        this.afterExerciseDesc = afterExerciseDesc;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public CardiacMurmur withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public CardiacMurmur withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("PartyID")
    public String getPartyID() {
        return partyID;
    }

    @JsonProperty("PartyID")
    public void setPartyID(String partyID) {
        this.partyID = partyID;
    }

    public CardiacMurmur withPartyID(String partyID) {
        this.partyID = partyID;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public CardiacMurmur withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CardiacMurmur withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(CardiacMurmur.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("cardiacMurmurKey");
        sb.append('=');
        sb.append(((this.cardiacMurmurKey == null)?"<null>":this.cardiacMurmurKey));
        sb.append(',');
        sb.append("cardiacMurmurSysKey");
        sb.append('=');
        sb.append(((this.cardiacMurmurSysKey == null)?"<null>":this.cardiacMurmurSysKey));
        sb.append(',');
        sb.append("conditionInd");
        sb.append('=');
        sb.append(((this.conditionInd == null)?"<null>":this.conditionInd));
        sb.append(',');
        sb.append("transmittedInd");
        sb.append('=');
        sb.append(((this.transmittedInd == null)?"<null>":this.transmittedInd));
        sb.append(',');
        sb.append("intensityGradeTC");
        sb.append('=');
        sb.append(((this.intensityGradeTC == null)?"<null>":this.intensityGradeTC));
        sb.append(',');
        sb.append("locationTC");
        sb.append('=');
        sb.append(((this.locationTC == null)?"<null>":this.locationTC));
        sb.append(',');
        sb.append("qualityTC");
        sb.append('=');
        sb.append(((this.qualityTC == null)?"<null>":this.qualityTC));
        sb.append(',');
        sb.append("timingTC");
        sb.append('=');
        sb.append(((this.timingTC == null)?"<null>":this.timingTC));
        sb.append(',');
        sb.append("afterExerciseDesc");
        sb.append('=');
        sb.append(((this.afterExerciseDesc == null)?"<null>":this.afterExerciseDesc));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("partyID");
        sb.append('=');
        sb.append(((this.partyID == null)?"<null>":this.partyID));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.locationTC == null)? 0 :this.locationTC.hashCode()));
        result = ((result* 31)+((this.intensityGradeTC == null)? 0 :this.intensityGradeTC.hashCode()));
        result = ((result* 31)+((this.qualityTC == null)? 0 :this.qualityTC.hashCode()));
        result = ((result* 31)+((this.timingTC == null)? 0 :this.timingTC.hashCode()));
        result = ((result* 31)+((this.cardiacMurmurKey == null)? 0 :this.cardiacMurmurKey.hashCode()));
        result = ((result* 31)+((this.transmittedInd == null)? 0 :this.transmittedInd.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.conditionInd == null)? 0 :this.conditionInd.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.cardiacMurmurSysKey == null)? 0 :this.cardiacMurmurSysKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.afterExerciseDesc == null)? 0 :this.afterExerciseDesc.hashCode()));
        result = ((result* 31)+((this.partyID == null)? 0 :this.partyID.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CardiacMurmur) == false) {
            return false;
        }
        CardiacMurmur rhs = ((CardiacMurmur) other);
        return (((((((((((((((this.locationTC == rhs.locationTC)||((this.locationTC!= null)&&this.locationTC.equals(rhs.locationTC)))&&((this.intensityGradeTC == rhs.intensityGradeTC)||((this.intensityGradeTC!= null)&&this.intensityGradeTC.equals(rhs.intensityGradeTC))))&&((this.qualityTC == rhs.qualityTC)||((this.qualityTC!= null)&&this.qualityTC.equals(rhs.qualityTC))))&&((this.timingTC == rhs.timingTC)||((this.timingTC!= null)&&this.timingTC.equals(rhs.timingTC))))&&((this.cardiacMurmurKey == rhs.cardiacMurmurKey)||((this.cardiacMurmurKey!= null)&&this.cardiacMurmurKey.equals(rhs.cardiacMurmurKey))))&&((this.transmittedInd == rhs.transmittedInd)||((this.transmittedInd!= null)&&this.transmittedInd.equals(rhs.transmittedInd))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.conditionInd == rhs.conditionInd)||((this.conditionInd!= null)&&this.conditionInd.equals(rhs.conditionInd))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.cardiacMurmurSysKey == rhs.cardiacMurmurSysKey)||((this.cardiacMurmurSysKey!= null)&&this.cardiacMurmurSysKey.equals(rhs.cardiacMurmurSysKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.afterExerciseDesc == rhs.afterExerciseDesc)||((this.afterExerciseDesc!= null)&&this.afterExerciseDesc.equals(rhs.afterExerciseDesc))))&&((this.partyID == rhs.partyID)||((this.partyID!= null)&&this.partyID.equals(rhs.partyID))));
    }

}
