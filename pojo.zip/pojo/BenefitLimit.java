
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "BenefitLimitKey",
    "BenefitLimitSysKey",
    "MaxBenefitAmt",
    "PaymentMode",
    "MaxBenefitDuration",
    "MaxBenefitDurPeriod",
    "ClaimedAmt",
    "MinBenefitAmt",
    "LimitVariation",
    "KeyedValue",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class BenefitLimit {

    @JsonProperty("BenefitLimitKey")
    private BenefitLimitKey benefitLimitKey;
    @JsonProperty("BenefitLimitSysKey")
    private List<Object> benefitLimitSysKey = new ArrayList<>();
    @JsonProperty("MaxBenefitAmt")
    private Integer maxBenefitAmt;
    @JsonProperty("PaymentMode")
    private PaymentMode paymentMode;
    @JsonProperty("MaxBenefitDuration")
    private Integer maxBenefitDuration;
    @JsonProperty("MaxBenefitDurPeriod")
    private MaxBenefitDurPeriod maxBenefitDurPeriod;
    @JsonProperty("ClaimedAmt")
    private Integer claimedAmt;
    @JsonProperty("MinBenefitAmt")
    private Integer minBenefitAmt;
    @JsonProperty("LimitVariation")
    private List<Object> limitVariation = new ArrayList<>();
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("BenefitLimitKey")
    public BenefitLimitKey getBenefitLimitKey() {
        return benefitLimitKey;
    }

    @JsonProperty("BenefitLimitKey")
    public void setBenefitLimitKey(BenefitLimitKey benefitLimitKey) {
        this.benefitLimitKey = benefitLimitKey;
    }

    public BenefitLimit withBenefitLimitKey(BenefitLimitKey benefitLimitKey) {
        this.benefitLimitKey = benefitLimitKey;
        return this;
    }

    @JsonProperty("BenefitLimitSysKey")
    public List<Object> getBenefitLimitSysKey() {
        return benefitLimitSysKey;
    }

    @JsonProperty("BenefitLimitSysKey")
    public void setBenefitLimitSysKey(List<Object> benefitLimitSysKey) {
        this.benefitLimitSysKey = benefitLimitSysKey;
    }

    public BenefitLimit withBenefitLimitSysKey(List<Object> benefitLimitSysKey) {
        this.benefitLimitSysKey = benefitLimitSysKey;
        return this;
    }

    @JsonProperty("MaxBenefitAmt")
    public Integer getMaxBenefitAmt() {
        return maxBenefitAmt;
    }

    @JsonProperty("MaxBenefitAmt")
    public void setMaxBenefitAmt(Integer maxBenefitAmt) {
        this.maxBenefitAmt = maxBenefitAmt;
    }

    public BenefitLimit withMaxBenefitAmt(Integer maxBenefitAmt) {
        this.maxBenefitAmt = maxBenefitAmt;
        return this;
    }

    @JsonProperty("PaymentMode")
    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    @JsonProperty("PaymentMode")
    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public BenefitLimit withPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
        return this;
    }

    @JsonProperty("MaxBenefitDuration")
    public Integer getMaxBenefitDuration() {
        return maxBenefitDuration;
    }

    @JsonProperty("MaxBenefitDuration")
    public void setMaxBenefitDuration(Integer maxBenefitDuration) {
        this.maxBenefitDuration = maxBenefitDuration;
    }

    public BenefitLimit withMaxBenefitDuration(Integer maxBenefitDuration) {
        this.maxBenefitDuration = maxBenefitDuration;
        return this;
    }

    @JsonProperty("MaxBenefitDurPeriod")
    public MaxBenefitDurPeriod getMaxBenefitDurPeriod() {
        return maxBenefitDurPeriod;
    }

    @JsonProperty("MaxBenefitDurPeriod")
    public void setMaxBenefitDurPeriod(MaxBenefitDurPeriod maxBenefitDurPeriod) {
        this.maxBenefitDurPeriod = maxBenefitDurPeriod;
    }

    public BenefitLimit withMaxBenefitDurPeriod(MaxBenefitDurPeriod maxBenefitDurPeriod) {
        this.maxBenefitDurPeriod = maxBenefitDurPeriod;
        return this;
    }

    @JsonProperty("ClaimedAmt")
    public Integer getClaimedAmt() {
        return claimedAmt;
    }

    @JsonProperty("ClaimedAmt")
    public void setClaimedAmt(Integer claimedAmt) {
        this.claimedAmt = claimedAmt;
    }

    public BenefitLimit withClaimedAmt(Integer claimedAmt) {
        this.claimedAmt = claimedAmt;
        return this;
    }

    @JsonProperty("MinBenefitAmt")
    public Integer getMinBenefitAmt() {
        return minBenefitAmt;
    }

    @JsonProperty("MinBenefitAmt")
    public void setMinBenefitAmt(Integer minBenefitAmt) {
        this.minBenefitAmt = minBenefitAmt;
    }

    public BenefitLimit withMinBenefitAmt(Integer minBenefitAmt) {
        this.minBenefitAmt = minBenefitAmt;
        return this;
    }

    @JsonProperty("LimitVariation")
    public List<Object> getLimitVariation() {
        return limitVariation;
    }

    @JsonProperty("LimitVariation")
    public void setLimitVariation(List<Object> limitVariation) {
        this.limitVariation = limitVariation;
    }

    public BenefitLimit withLimitVariation(List<Object> limitVariation) {
        this.limitVariation = limitVariation;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public BenefitLimit withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public BenefitLimit withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public BenefitLimit withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public BenefitLimit withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public BenefitLimit withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(BenefitLimit.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("benefitLimitKey");
        sb.append('=');
        sb.append(((this.benefitLimitKey == null)?"<null>":this.benefitLimitKey));
        sb.append(',');
        sb.append("benefitLimitSysKey");
        sb.append('=');
        sb.append(((this.benefitLimitSysKey == null)?"<null>":this.benefitLimitSysKey));
        sb.append(',');
        sb.append("maxBenefitAmt");
        sb.append('=');
        sb.append(((this.maxBenefitAmt == null)?"<null>":this.maxBenefitAmt));
        sb.append(',');
        sb.append("paymentMode");
        sb.append('=');
        sb.append(((this.paymentMode == null)?"<null>":this.paymentMode));
        sb.append(',');
        sb.append("maxBenefitDuration");
        sb.append('=');
        sb.append(((this.maxBenefitDuration == null)?"<null>":this.maxBenefitDuration));
        sb.append(',');
        sb.append("maxBenefitDurPeriod");
        sb.append('=');
        sb.append(((this.maxBenefitDurPeriod == null)?"<null>":this.maxBenefitDurPeriod));
        sb.append(',');
        sb.append("claimedAmt");
        sb.append('=');
        sb.append(((this.claimedAmt == null)?"<null>":this.claimedAmt));
        sb.append(',');
        sb.append("minBenefitAmt");
        sb.append('=');
        sb.append(((this.minBenefitAmt == null)?"<null>":this.minBenefitAmt));
        sb.append(',');
        sb.append("limitVariation");
        sb.append('=');
        sb.append(((this.limitVariation == null)?"<null>":this.limitVariation));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.paymentMode == null)? 0 :this.paymentMode.hashCode()));
        result = ((result* 31)+((this.maxBenefitDuration == null)? 0 :this.maxBenefitDuration.hashCode()));
        result = ((result* 31)+((this.maxBenefitAmt == null)? 0 :this.maxBenefitAmt.hashCode()));
        result = ((result* 31)+((this.claimedAmt == null)? 0 :this.claimedAmt.hashCode()));
        result = ((result* 31)+((this.limitVariation == null)? 0 :this.limitVariation.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.maxBenefitDurPeriod == null)? 0 :this.maxBenefitDurPeriod.hashCode()));
        result = ((result* 31)+((this.benefitLimitKey == null)? 0 :this.benefitLimitKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.benefitLimitSysKey == null)? 0 :this.benefitLimitSysKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.minBenefitAmt == null)? 0 :this.minBenefitAmt.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BenefitLimit) == false) {
            return false;
        }
        BenefitLimit rhs = ((BenefitLimit) other);
        return (((((((((((((((this.paymentMode == rhs.paymentMode)||((this.paymentMode!= null)&&this.paymentMode.equals(rhs.paymentMode)))&&((this.maxBenefitDuration == rhs.maxBenefitDuration)||((this.maxBenefitDuration!= null)&&this.maxBenefitDuration.equals(rhs.maxBenefitDuration))))&&((this.maxBenefitAmt == rhs.maxBenefitAmt)||((this.maxBenefitAmt!= null)&&this.maxBenefitAmt.equals(rhs.maxBenefitAmt))))&&((this.claimedAmt == rhs.claimedAmt)||((this.claimedAmt!= null)&&this.claimedAmt.equals(rhs.claimedAmt))))&&((this.limitVariation == rhs.limitVariation)||((this.limitVariation!= null)&&this.limitVariation.equals(rhs.limitVariation))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.maxBenefitDurPeriod == rhs.maxBenefitDurPeriod)||((this.maxBenefitDurPeriod!= null)&&this.maxBenefitDurPeriod.equals(rhs.maxBenefitDurPeriod))))&&((this.benefitLimitKey == rhs.benefitLimitKey)||((this.benefitLimitKey!= null)&&this.benefitLimitKey.equals(rhs.benefitLimitKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.benefitLimitSysKey == rhs.benefitLimitSysKey)||((this.benefitLimitSysKey!= null)&&this.benefitLimitSysKey.equals(rhs.benefitLimitSysKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.minBenefitAmt == rhs.minBenefitAmt)||((this.minBenefitAmt!= null)&&this.minBenefitAmt.equals(rhs.minBenefitAmt))));
    }

}
