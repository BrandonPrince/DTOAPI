
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "RestrictionInfoKey",
    "RestrictionInfoSysKey",
    "RestrictionCode",
    "RestrictionReason",
    "RestrictionDetails",
    "StartDate",
    "EndDate",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class RestrictionInfo {

    @JsonProperty("RestrictionInfoKey")
    private RestrictionInfoKey restrictionInfoKey;
    @JsonProperty("RestrictionInfoSysKey")
    private List<Object> restrictionInfoSysKey = new ArrayList<>();
    @JsonProperty("RestrictionCode")
    private RestrictionCode restrictionCode;
    @JsonProperty("RestrictionReason")
    private RestrictionReason restrictionReason;
    @JsonProperty("RestrictionDetails")
    private String restrictionDetails;
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("RestrictionInfoKey")
    public RestrictionInfoKey getRestrictionInfoKey() {
        return restrictionInfoKey;
    }

    @JsonProperty("RestrictionInfoKey")
    public void setRestrictionInfoKey(RestrictionInfoKey restrictionInfoKey) {
        this.restrictionInfoKey = restrictionInfoKey;
    }

    public RestrictionInfo withRestrictionInfoKey(RestrictionInfoKey restrictionInfoKey) {
        this.restrictionInfoKey = restrictionInfoKey;
        return this;
    }

    @JsonProperty("RestrictionInfoSysKey")
    public List<Object> getRestrictionInfoSysKey() {
        return restrictionInfoSysKey;
    }

    @JsonProperty("RestrictionInfoSysKey")
    public void setRestrictionInfoSysKey(List<Object> restrictionInfoSysKey) {
        this.restrictionInfoSysKey = restrictionInfoSysKey;
    }

    public RestrictionInfo withRestrictionInfoSysKey(List<Object> restrictionInfoSysKey) {
        this.restrictionInfoSysKey = restrictionInfoSysKey;
        return this;
    }

    @JsonProperty("RestrictionCode")
    public RestrictionCode getRestrictionCode() {
        return restrictionCode;
    }

    @JsonProperty("RestrictionCode")
    public void setRestrictionCode(RestrictionCode restrictionCode) {
        this.restrictionCode = restrictionCode;
    }

    public RestrictionInfo withRestrictionCode(RestrictionCode restrictionCode) {
        this.restrictionCode = restrictionCode;
        return this;
    }

    @JsonProperty("RestrictionReason")
    public RestrictionReason getRestrictionReason() {
        return restrictionReason;
    }

    @JsonProperty("RestrictionReason")
    public void setRestrictionReason(RestrictionReason restrictionReason) {
        this.restrictionReason = restrictionReason;
    }

    public RestrictionInfo withRestrictionReason(RestrictionReason restrictionReason) {
        this.restrictionReason = restrictionReason;
        return this;
    }

    @JsonProperty("RestrictionDetails")
    public String getRestrictionDetails() {
        return restrictionDetails;
    }

    @JsonProperty("RestrictionDetails")
    public void setRestrictionDetails(String restrictionDetails) {
        this.restrictionDetails = restrictionDetails;
    }

    public RestrictionInfo withRestrictionDetails(String restrictionDetails) {
        this.restrictionDetails = restrictionDetails;
        return this;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public RestrictionInfo withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public RestrictionInfo withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public RestrictionInfo withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public RestrictionInfo withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public RestrictionInfo withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RestrictionInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(RestrictionInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("restrictionInfoKey");
        sb.append('=');
        sb.append(((this.restrictionInfoKey == null)?"<null>":this.restrictionInfoKey));
        sb.append(',');
        sb.append("restrictionInfoSysKey");
        sb.append('=');
        sb.append(((this.restrictionInfoSysKey == null)?"<null>":this.restrictionInfoSysKey));
        sb.append(',');
        sb.append("restrictionCode");
        sb.append('=');
        sb.append(((this.restrictionCode == null)?"<null>":this.restrictionCode));
        sb.append(',');
        sb.append("restrictionReason");
        sb.append('=');
        sb.append(((this.restrictionReason == null)?"<null>":this.restrictionReason));
        sb.append(',');
        sb.append("restrictionDetails");
        sb.append('=');
        sb.append(((this.restrictionDetails == null)?"<null>":this.restrictionDetails));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.restrictionInfoSysKey == null)? 0 :this.restrictionInfoSysKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.restrictionCode == null)? 0 :this.restrictionCode.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.restrictionDetails == null)? 0 :this.restrictionDetails.hashCode()));
        result = ((result* 31)+((this.restrictionInfoKey == null)? 0 :this.restrictionInfoKey.hashCode()));
        result = ((result* 31)+((this.restrictionReason == null)? 0 :this.restrictionReason.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RestrictionInfo) == false) {
            return false;
        }
        RestrictionInfo rhs = ((RestrictionInfo) other);
        return ((((((((((((this.restrictionInfoSysKey == rhs.restrictionInfoSysKey)||((this.restrictionInfoSysKey!= null)&&this.restrictionInfoSysKey.equals(rhs.restrictionInfoSysKey)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.restrictionCode == rhs.restrictionCode)||((this.restrictionCode!= null)&&this.restrictionCode.equals(rhs.restrictionCode))))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.restrictionDetails == rhs.restrictionDetails)||((this.restrictionDetails!= null)&&this.restrictionDetails.equals(rhs.restrictionDetails))))&&((this.restrictionInfoKey == rhs.restrictionInfoKey)||((this.restrictionInfoKey!= null)&&this.restrictionInfoKey.equals(rhs.restrictionInfoKey))))&&((this.restrictionReason == rhs.restrictionReason)||((this.restrictionReason!= null)&&this.restrictionReason.equals(rhs.restrictionReason))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))));
    }

}
