
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "RelatedParticipantProductInfoKey",
    "RelatedParticipantProductInfoSysKey",
    "ProductCode",
    "ObjectType",
    "ParticipantRoleCode",
    "MinNumRelatedRolePlayers",
    "MaxNumRelatedRolePlayers",
    "RelationshipInfo",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class RelatedParticipantProductInfo {

    @JsonProperty("RelatedParticipantProductInfoKey")
    private RelatedParticipantProductInfoKey relatedParticipantProductInfoKey;
    @JsonProperty("RelatedParticipantProductInfoSysKey")
    private List<Object> relatedParticipantProductInfoSysKey = new ArrayList<>();
    @JsonProperty("ProductCode")
    private String productCode;
    @JsonProperty("ObjectType")
    private ObjectType objectType;
    @JsonProperty("ParticipantRoleCode")
    private ParticipantRoleCode participantRoleCode;
    @JsonProperty("MinNumRelatedRolePlayers")
    private Integer minNumRelatedRolePlayers;
    @JsonProperty("MaxNumRelatedRolePlayers")
    private Integer maxNumRelatedRolePlayers;
    @JsonProperty("RelationshipInfo")
    private List<Object> relationshipInfo = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("RelatedParticipantProductInfoKey")
    public RelatedParticipantProductInfoKey getRelatedParticipantProductInfoKey() {
        return relatedParticipantProductInfoKey;
    }

    @JsonProperty("RelatedParticipantProductInfoKey")
    public void setRelatedParticipantProductInfoKey(RelatedParticipantProductInfoKey relatedParticipantProductInfoKey) {
        this.relatedParticipantProductInfoKey = relatedParticipantProductInfoKey;
    }

    public RelatedParticipantProductInfo withRelatedParticipantProductInfoKey(RelatedParticipantProductInfoKey relatedParticipantProductInfoKey) {
        this.relatedParticipantProductInfoKey = relatedParticipantProductInfoKey;
        return this;
    }

    @JsonProperty("RelatedParticipantProductInfoSysKey")
    public List<Object> getRelatedParticipantProductInfoSysKey() {
        return relatedParticipantProductInfoSysKey;
    }

    @JsonProperty("RelatedParticipantProductInfoSysKey")
    public void setRelatedParticipantProductInfoSysKey(List<Object> relatedParticipantProductInfoSysKey) {
        this.relatedParticipantProductInfoSysKey = relatedParticipantProductInfoSysKey;
    }

    public RelatedParticipantProductInfo withRelatedParticipantProductInfoSysKey(List<Object> relatedParticipantProductInfoSysKey) {
        this.relatedParticipantProductInfoSysKey = relatedParticipantProductInfoSysKey;
        return this;
    }

    @JsonProperty("ProductCode")
    public String getProductCode() {
        return productCode;
    }

    @JsonProperty("ProductCode")
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public RelatedParticipantProductInfo withProductCode(String productCode) {
        this.productCode = productCode;
        return this;
    }

    @JsonProperty("ObjectType")
    public ObjectType getObjectType() {
        return objectType;
    }

    @JsonProperty("ObjectType")
    public void setObjectType(ObjectType objectType) {
        this.objectType = objectType;
    }

    public RelatedParticipantProductInfo withObjectType(ObjectType objectType) {
        this.objectType = objectType;
        return this;
    }

    @JsonProperty("ParticipantRoleCode")
    public ParticipantRoleCode getParticipantRoleCode() {
        return participantRoleCode;
    }

    @JsonProperty("ParticipantRoleCode")
    public void setParticipantRoleCode(ParticipantRoleCode participantRoleCode) {
        this.participantRoleCode = participantRoleCode;
    }

    public RelatedParticipantProductInfo withParticipantRoleCode(ParticipantRoleCode participantRoleCode) {
        this.participantRoleCode = participantRoleCode;
        return this;
    }

    @JsonProperty("MinNumRelatedRolePlayers")
    public Integer getMinNumRelatedRolePlayers() {
        return minNumRelatedRolePlayers;
    }

    @JsonProperty("MinNumRelatedRolePlayers")
    public void setMinNumRelatedRolePlayers(Integer minNumRelatedRolePlayers) {
        this.minNumRelatedRolePlayers = minNumRelatedRolePlayers;
    }

    public RelatedParticipantProductInfo withMinNumRelatedRolePlayers(Integer minNumRelatedRolePlayers) {
        this.minNumRelatedRolePlayers = minNumRelatedRolePlayers;
        return this;
    }

    @JsonProperty("MaxNumRelatedRolePlayers")
    public Integer getMaxNumRelatedRolePlayers() {
        return maxNumRelatedRolePlayers;
    }

    @JsonProperty("MaxNumRelatedRolePlayers")
    public void setMaxNumRelatedRolePlayers(Integer maxNumRelatedRolePlayers) {
        this.maxNumRelatedRolePlayers = maxNumRelatedRolePlayers;
    }

    public RelatedParticipantProductInfo withMaxNumRelatedRolePlayers(Integer maxNumRelatedRolePlayers) {
        this.maxNumRelatedRolePlayers = maxNumRelatedRolePlayers;
        return this;
    }

    @JsonProperty("RelationshipInfo")
    public List<Object> getRelationshipInfo() {
        return relationshipInfo;
    }

    @JsonProperty("RelationshipInfo")
    public void setRelationshipInfo(List<Object> relationshipInfo) {
        this.relationshipInfo = relationshipInfo;
    }

    public RelatedParticipantProductInfo withRelationshipInfo(List<Object> relationshipInfo) {
        this.relationshipInfo = relationshipInfo;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public RelatedParticipantProductInfo withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public RelatedParticipantProductInfo withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public RelatedParticipantProductInfo withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RelatedParticipantProductInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(RelatedParticipantProductInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("relatedParticipantProductInfoKey");
        sb.append('=');
        sb.append(((this.relatedParticipantProductInfoKey == null)?"<null>":this.relatedParticipantProductInfoKey));
        sb.append(',');
        sb.append("relatedParticipantProductInfoSysKey");
        sb.append('=');
        sb.append(((this.relatedParticipantProductInfoSysKey == null)?"<null>":this.relatedParticipantProductInfoSysKey));
        sb.append(',');
        sb.append("productCode");
        sb.append('=');
        sb.append(((this.productCode == null)?"<null>":this.productCode));
        sb.append(',');
        sb.append("objectType");
        sb.append('=');
        sb.append(((this.objectType == null)?"<null>":this.objectType));
        sb.append(',');
        sb.append("participantRoleCode");
        sb.append('=');
        sb.append(((this.participantRoleCode == null)?"<null>":this.participantRoleCode));
        sb.append(',');
        sb.append("minNumRelatedRolePlayers");
        sb.append('=');
        sb.append(((this.minNumRelatedRolePlayers == null)?"<null>":this.minNumRelatedRolePlayers));
        sb.append(',');
        sb.append("maxNumRelatedRolePlayers");
        sb.append('=');
        sb.append(((this.maxNumRelatedRolePlayers == null)?"<null>":this.maxNumRelatedRolePlayers));
        sb.append(',');
        sb.append("relationshipInfo");
        sb.append('=');
        sb.append(((this.relationshipInfo == null)?"<null>":this.relationshipInfo));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.relatedParticipantProductInfoSysKey == null)? 0 :this.relatedParticipantProductInfoSysKey.hashCode()));
        result = ((result* 31)+((this.relatedParticipantProductInfoKey == null)? 0 :this.relatedParticipantProductInfoKey.hashCode()));
        result = ((result* 31)+((this.maxNumRelatedRolePlayers == null)? 0 :this.maxNumRelatedRolePlayers.hashCode()));
        result = ((result* 31)+((this.objectType == null)? 0 :this.objectType.hashCode()));
        result = ((result* 31)+((this.productCode == null)? 0 :this.productCode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.minNumRelatedRolePlayers == null)? 0 :this.minNumRelatedRolePlayers.hashCode()));
        result = ((result* 31)+((this.relationshipInfo == null)? 0 :this.relationshipInfo.hashCode()));
        result = ((result* 31)+((this.participantRoleCode == null)? 0 :this.participantRoleCode.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RelatedParticipantProductInfo) == false) {
            return false;
        }
        RelatedParticipantProductInfo rhs = ((RelatedParticipantProductInfo) other);
        return (((((((((((((this.relatedParticipantProductInfoSysKey == rhs.relatedParticipantProductInfoSysKey)||((this.relatedParticipantProductInfoSysKey!= null)&&this.relatedParticipantProductInfoSysKey.equals(rhs.relatedParticipantProductInfoSysKey)))&&((this.relatedParticipantProductInfoKey == rhs.relatedParticipantProductInfoKey)||((this.relatedParticipantProductInfoKey!= null)&&this.relatedParticipantProductInfoKey.equals(rhs.relatedParticipantProductInfoKey))))&&((this.maxNumRelatedRolePlayers == rhs.maxNumRelatedRolePlayers)||((this.maxNumRelatedRolePlayers!= null)&&this.maxNumRelatedRolePlayers.equals(rhs.maxNumRelatedRolePlayers))))&&((this.objectType == rhs.objectType)||((this.objectType!= null)&&this.objectType.equals(rhs.objectType))))&&((this.productCode == rhs.productCode)||((this.productCode!= null)&&this.productCode.equals(rhs.productCode))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.minNumRelatedRolePlayers == rhs.minNumRelatedRolePlayers)||((this.minNumRelatedRolePlayers!= null)&&this.minNumRelatedRolePlayers.equals(rhs.minNumRelatedRolePlayers))))&&((this.relationshipInfo == rhs.relationshipInfo)||((this.relationshipInfo!= null)&&this.relationshipInfo.equals(rhs.relationshipInfo))))&&((this.participantRoleCode == rhs.participantRoleCode)||((this.participantRoleCode!= null)&&this.participantRoleCode.equals(rhs.participantRoleCode))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
