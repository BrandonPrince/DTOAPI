
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AuditTransSummationKey",
    "AuditTransSummationSysKey",
    "AuditTotalType",
    "AuditTotal",
    "Name",
    "Description",
    "AuditTotalCode",
    "AuditElement",
    "AuditTransaction",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AuditTransSummation {

    @JsonProperty("AuditTransSummationKey")
    private AuditTransSummationKey auditTransSummationKey;
    @JsonProperty("AuditTransSummationSysKey")
    private List<Object> auditTransSummationSysKey = new ArrayList<>();
    @JsonProperty("AuditTotalType")
    private AuditTotalType auditTotalType;
    @JsonProperty("AuditTotal")
    private String auditTotal;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("AuditTotalCode")
    private String auditTotalCode;
    @JsonProperty("AuditElement")
    private List<Object> auditElement = new ArrayList<>();
    @JsonProperty("AuditTransaction")
    private List<Object> auditTransaction = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AuditTransSummationKey")
    public AuditTransSummationKey getAuditTransSummationKey() {
        return auditTransSummationKey;
    }

    @JsonProperty("AuditTransSummationKey")
    public void setAuditTransSummationKey(AuditTransSummationKey auditTransSummationKey) {
        this.auditTransSummationKey = auditTransSummationKey;
    }

    public AuditTransSummation withAuditTransSummationKey(AuditTransSummationKey auditTransSummationKey) {
        this.auditTransSummationKey = auditTransSummationKey;
        return this;
    }

    @JsonProperty("AuditTransSummationSysKey")
    public List<Object> getAuditTransSummationSysKey() {
        return auditTransSummationSysKey;
    }

    @JsonProperty("AuditTransSummationSysKey")
    public void setAuditTransSummationSysKey(List<Object> auditTransSummationSysKey) {
        this.auditTransSummationSysKey = auditTransSummationSysKey;
    }

    public AuditTransSummation withAuditTransSummationSysKey(List<Object> auditTransSummationSysKey) {
        this.auditTransSummationSysKey = auditTransSummationSysKey;
        return this;
    }

    @JsonProperty("AuditTotalType")
    public AuditTotalType getAuditTotalType() {
        return auditTotalType;
    }

    @JsonProperty("AuditTotalType")
    public void setAuditTotalType(AuditTotalType auditTotalType) {
        this.auditTotalType = auditTotalType;
    }

    public AuditTransSummation withAuditTotalType(AuditTotalType auditTotalType) {
        this.auditTotalType = auditTotalType;
        return this;
    }

    @JsonProperty("AuditTotal")
    public String getAuditTotal() {
        return auditTotal;
    }

    @JsonProperty("AuditTotal")
    public void setAuditTotal(String auditTotal) {
        this.auditTotal = auditTotal;
    }

    public AuditTransSummation withAuditTotal(String auditTotal) {
        this.auditTotal = auditTotal;
        return this;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    public AuditTransSummation withName(String name) {
        this.name = name;
        return this;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    public AuditTransSummation withDescription(String description) {
        this.description = description;
        return this;
    }

    @JsonProperty("AuditTotalCode")
    public String getAuditTotalCode() {
        return auditTotalCode;
    }

    @JsonProperty("AuditTotalCode")
    public void setAuditTotalCode(String auditTotalCode) {
        this.auditTotalCode = auditTotalCode;
    }

    public AuditTransSummation withAuditTotalCode(String auditTotalCode) {
        this.auditTotalCode = auditTotalCode;
        return this;
    }

    @JsonProperty("AuditElement")
    public List<Object> getAuditElement() {
        return auditElement;
    }

    @JsonProperty("AuditElement")
    public void setAuditElement(List<Object> auditElement) {
        this.auditElement = auditElement;
    }

    public AuditTransSummation withAuditElement(List<Object> auditElement) {
        this.auditElement = auditElement;
        return this;
    }

    @JsonProperty("AuditTransaction")
    public List<Object> getAuditTransaction() {
        return auditTransaction;
    }

    @JsonProperty("AuditTransaction")
    public void setAuditTransaction(List<Object> auditTransaction) {
        this.auditTransaction = auditTransaction;
    }

    public AuditTransSummation withAuditTransaction(List<Object> auditTransaction) {
        this.auditTransaction = auditTransaction;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AuditTransSummation withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AuditTransSummation withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AuditTransSummation withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AuditTransSummation withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AuditTransSummation.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("auditTransSummationKey");
        sb.append('=');
        sb.append(((this.auditTransSummationKey == null)?"<null>":this.auditTransSummationKey));
        sb.append(',');
        sb.append("auditTransSummationSysKey");
        sb.append('=');
        sb.append(((this.auditTransSummationSysKey == null)?"<null>":this.auditTransSummationSysKey));
        sb.append(',');
        sb.append("auditTotalType");
        sb.append('=');
        sb.append(((this.auditTotalType == null)?"<null>":this.auditTotalType));
        sb.append(',');
        sb.append("auditTotal");
        sb.append('=');
        sb.append(((this.auditTotal == null)?"<null>":this.auditTotal));
        sb.append(',');
        sb.append("name");
        sb.append('=');
        sb.append(((this.name == null)?"<null>":this.name));
        sb.append(',');
        sb.append("description");
        sb.append('=');
        sb.append(((this.description == null)?"<null>":this.description));
        sb.append(',');
        sb.append("auditTotalCode");
        sb.append('=');
        sb.append(((this.auditTotalCode == null)?"<null>":this.auditTotalCode));
        sb.append(',');
        sb.append("auditElement");
        sb.append('=');
        sb.append(((this.auditElement == null)?"<null>":this.auditElement));
        sb.append(',');
        sb.append("auditTransaction");
        sb.append('=');
        sb.append(((this.auditTransaction == null)?"<null>":this.auditTransaction));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.description == null)? 0 :this.description.hashCode()));
        result = ((result* 31)+((this.auditTotalType == null)? 0 :this.auditTotalType.hashCode()));
        result = ((result* 31)+((this.auditTotal == null)? 0 :this.auditTotal.hashCode()));
        result = ((result* 31)+((this.auditTotalCode == null)? 0 :this.auditTotalCode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.auditTransSummationKey == null)? 0 :this.auditTransSummationKey.hashCode()));
        result = ((result* 31)+((this.auditTransaction == null)? 0 :this.auditTransaction.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.auditTransSummationSysKey == null)? 0 :this.auditTransSummationSysKey.hashCode()));
        result = ((result* 31)+((this.name == null)? 0 :this.name.hashCode()));
        result = ((result* 31)+((this.auditElement == null)? 0 :this.auditElement.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AuditTransSummation) == false) {
            return false;
        }
        AuditTransSummation rhs = ((AuditTransSummation) other);
        return ((((((((((((((this.description == rhs.description)||((this.description!= null)&&this.description.equals(rhs.description)))&&((this.auditTotalType == rhs.auditTotalType)||((this.auditTotalType!= null)&&this.auditTotalType.equals(rhs.auditTotalType))))&&((this.auditTotal == rhs.auditTotal)||((this.auditTotal!= null)&&this.auditTotal.equals(rhs.auditTotal))))&&((this.auditTotalCode == rhs.auditTotalCode)||((this.auditTotalCode!= null)&&this.auditTotalCode.equals(rhs.auditTotalCode))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.auditTransSummationKey == rhs.auditTransSummationKey)||((this.auditTransSummationKey!= null)&&this.auditTransSummationKey.equals(rhs.auditTransSummationKey))))&&((this.auditTransaction == rhs.auditTransaction)||((this.auditTransaction!= null)&&this.auditTransaction.equals(rhs.auditTransaction))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.auditTransSummationSysKey == rhs.auditTransSummationSysKey)||((this.auditTransSummationSysKey!= null)&&this.auditTransSummationSysKey.equals(rhs.auditTransSummationSysKey))))&&((this.name == rhs.name)||((this.name!= null)&&this.name.equals(rhs.name))))&&((this.auditElement == rhs.auditElement)||((this.auditElement!= null)&&this.auditElement.equals(rhs.auditElement))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
