
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "UnderwritingClassGuidelineKey",
    "UnderwritingClassGuidelineSysKey",
    "UndClassGuidelineCode",
    "ClassName",
    "UnderwritingClass",
    "UnderwritingSubClass",
    "TobaccoPremiumBasis",
    "Sequence",
    "GuidelineFailInstructionType",
    "DrivingHistoryGuidelines",
    "BloodPressureGuidelines",
    "MedicalConditionGuidelines",
    "TobaccoUsageGuidelines",
    "SubstanceUsageGuidelines",
    "CholesterolGuidelines",
    "FamilyHistoryGuidelines",
    "ForeignTravelGuidelines",
    "AviationGuidelines",
    "OccupationGuidelines",
    "AvocationGuidelines",
    "ResidencyGuidelines",
    "MilitaryGuidelines",
    "Attachment",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class UnderwritingClassGuideline {

    @JsonProperty("UnderwritingClassGuidelineKey")
    private UnderwritingClassGuidelineKey underwritingClassGuidelineKey;
    @JsonProperty("UnderwritingClassGuidelineSysKey")
    private List<Object> underwritingClassGuidelineSysKey = new ArrayList<>();
    @JsonProperty("UndClassGuidelineCode")
    private String undClassGuidelineCode;
    @JsonProperty("ClassName")
    private String className;
    @JsonProperty("UnderwritingClass")
    private UnderwritingClass underwritingClass;
    @JsonProperty("UnderwritingSubClass")
    private UnderwritingSubClass underwritingSubClass;
    @JsonProperty("TobaccoPremiumBasis")
    private TobaccoPremiumBasis tobaccoPremiumBasis;
    @JsonProperty("Sequence")
    private Integer sequence;
    @JsonProperty("GuidelineFailInstructionType")
    private GuidelineFailInstructionType guidelineFailInstructionType;
    @JsonProperty("DrivingHistoryGuidelines")
    private DrivingHistoryGuidelines drivingHistoryGuidelines;
    @JsonProperty("BloodPressureGuidelines")
    private BloodPressureGuidelines bloodPressureGuidelines;
    @JsonProperty("MedicalConditionGuidelines")
    private MedicalConditionGuidelines medicalConditionGuidelines;
    @JsonProperty("TobaccoUsageGuidelines")
    private TobaccoUsageGuidelines tobaccoUsageGuidelines;
    @JsonProperty("SubstanceUsageGuidelines")
    private SubstanceUsageGuidelines substanceUsageGuidelines;
    @JsonProperty("CholesterolGuidelines")
    private CholesterolGuidelines cholesterolGuidelines;
    @JsonProperty("FamilyHistoryGuidelines")
    private FamilyHistoryGuidelines familyHistoryGuidelines;
    @JsonProperty("ForeignTravelGuidelines")
    private ForeignTravelGuidelines foreignTravelGuidelines;
    @JsonProperty("AviationGuidelines")
    private AviationGuidelines aviationGuidelines;
    @JsonProperty("OccupationGuidelines")
    private OccupationGuidelines occupationGuidelines;
    @JsonProperty("AvocationGuidelines")
    private AvocationGuidelines avocationGuidelines;
    @JsonProperty("ResidencyGuidelines")
    private ResidencyGuidelines residencyGuidelines;
    @JsonProperty("MilitaryGuidelines")
    private MilitaryGuidelines militaryGuidelines;
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("UnderwritingClassGuidelineKey")
    public UnderwritingClassGuidelineKey getUnderwritingClassGuidelineKey() {
        return underwritingClassGuidelineKey;
    }

    @JsonProperty("UnderwritingClassGuidelineKey")
    public void setUnderwritingClassGuidelineKey(UnderwritingClassGuidelineKey underwritingClassGuidelineKey) {
        this.underwritingClassGuidelineKey = underwritingClassGuidelineKey;
    }

    public UnderwritingClassGuideline withUnderwritingClassGuidelineKey(UnderwritingClassGuidelineKey underwritingClassGuidelineKey) {
        this.underwritingClassGuidelineKey = underwritingClassGuidelineKey;
        return this;
    }

    @JsonProperty("UnderwritingClassGuidelineSysKey")
    public List<Object> getUnderwritingClassGuidelineSysKey() {
        return underwritingClassGuidelineSysKey;
    }

    @JsonProperty("UnderwritingClassGuidelineSysKey")
    public void setUnderwritingClassGuidelineSysKey(List<Object> underwritingClassGuidelineSysKey) {
        this.underwritingClassGuidelineSysKey = underwritingClassGuidelineSysKey;
    }

    public UnderwritingClassGuideline withUnderwritingClassGuidelineSysKey(List<Object> underwritingClassGuidelineSysKey) {
        this.underwritingClassGuidelineSysKey = underwritingClassGuidelineSysKey;
        return this;
    }

    @JsonProperty("UndClassGuidelineCode")
    public String getUndClassGuidelineCode() {
        return undClassGuidelineCode;
    }

    @JsonProperty("UndClassGuidelineCode")
    public void setUndClassGuidelineCode(String undClassGuidelineCode) {
        this.undClassGuidelineCode = undClassGuidelineCode;
    }

    public UnderwritingClassGuideline withUndClassGuidelineCode(String undClassGuidelineCode) {
        this.undClassGuidelineCode = undClassGuidelineCode;
        return this;
    }

    @JsonProperty("ClassName")
    public String getClassName() {
        return className;
    }

    @JsonProperty("ClassName")
    public void setClassName(String className) {
        this.className = className;
    }

    public UnderwritingClassGuideline withClassName(String className) {
        this.className = className;
        return this;
    }

    @JsonProperty("UnderwritingClass")
    public UnderwritingClass getUnderwritingClass() {
        return underwritingClass;
    }

    @JsonProperty("UnderwritingClass")
    public void setUnderwritingClass(UnderwritingClass underwritingClass) {
        this.underwritingClass = underwritingClass;
    }

    public UnderwritingClassGuideline withUnderwritingClass(UnderwritingClass underwritingClass) {
        this.underwritingClass = underwritingClass;
        return this;
    }

    @JsonProperty("UnderwritingSubClass")
    public UnderwritingSubClass getUnderwritingSubClass() {
        return underwritingSubClass;
    }

    @JsonProperty("UnderwritingSubClass")
    public void setUnderwritingSubClass(UnderwritingSubClass underwritingSubClass) {
        this.underwritingSubClass = underwritingSubClass;
    }

    public UnderwritingClassGuideline withUnderwritingSubClass(UnderwritingSubClass underwritingSubClass) {
        this.underwritingSubClass = underwritingSubClass;
        return this;
    }

    @JsonProperty("TobaccoPremiumBasis")
    public TobaccoPremiumBasis getTobaccoPremiumBasis() {
        return tobaccoPremiumBasis;
    }

    @JsonProperty("TobaccoPremiumBasis")
    public void setTobaccoPremiumBasis(TobaccoPremiumBasis tobaccoPremiumBasis) {
        this.tobaccoPremiumBasis = tobaccoPremiumBasis;
    }

    public UnderwritingClassGuideline withTobaccoPremiumBasis(TobaccoPremiumBasis tobaccoPremiumBasis) {
        this.tobaccoPremiumBasis = tobaccoPremiumBasis;
        return this;
    }

    @JsonProperty("Sequence")
    public Integer getSequence() {
        return sequence;
    }

    @JsonProperty("Sequence")
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public UnderwritingClassGuideline withSequence(Integer sequence) {
        this.sequence = sequence;
        return this;
    }

    @JsonProperty("GuidelineFailInstructionType")
    public GuidelineFailInstructionType getGuidelineFailInstructionType() {
        return guidelineFailInstructionType;
    }

    @JsonProperty("GuidelineFailInstructionType")
    public void setGuidelineFailInstructionType(GuidelineFailInstructionType guidelineFailInstructionType) {
        this.guidelineFailInstructionType = guidelineFailInstructionType;
    }

    public UnderwritingClassGuideline withGuidelineFailInstructionType(GuidelineFailInstructionType guidelineFailInstructionType) {
        this.guidelineFailInstructionType = guidelineFailInstructionType;
        return this;
    }

    @JsonProperty("DrivingHistoryGuidelines")
    public DrivingHistoryGuidelines getDrivingHistoryGuidelines() {
        return drivingHistoryGuidelines;
    }

    @JsonProperty("DrivingHistoryGuidelines")
    public void setDrivingHistoryGuidelines(DrivingHistoryGuidelines drivingHistoryGuidelines) {
        this.drivingHistoryGuidelines = drivingHistoryGuidelines;
    }

    public UnderwritingClassGuideline withDrivingHistoryGuidelines(DrivingHistoryGuidelines drivingHistoryGuidelines) {
        this.drivingHistoryGuidelines = drivingHistoryGuidelines;
        return this;
    }

    @JsonProperty("BloodPressureGuidelines")
    public BloodPressureGuidelines getBloodPressureGuidelines() {
        return bloodPressureGuidelines;
    }

    @JsonProperty("BloodPressureGuidelines")
    public void setBloodPressureGuidelines(BloodPressureGuidelines bloodPressureGuidelines) {
        this.bloodPressureGuidelines = bloodPressureGuidelines;
    }

    public UnderwritingClassGuideline withBloodPressureGuidelines(BloodPressureGuidelines bloodPressureGuidelines) {
        this.bloodPressureGuidelines = bloodPressureGuidelines;
        return this;
    }

    @JsonProperty("MedicalConditionGuidelines")
    public MedicalConditionGuidelines getMedicalConditionGuidelines() {
        return medicalConditionGuidelines;
    }

    @JsonProperty("MedicalConditionGuidelines")
    public void setMedicalConditionGuidelines(MedicalConditionGuidelines medicalConditionGuidelines) {
        this.medicalConditionGuidelines = medicalConditionGuidelines;
    }

    public UnderwritingClassGuideline withMedicalConditionGuidelines(MedicalConditionGuidelines medicalConditionGuidelines) {
        this.medicalConditionGuidelines = medicalConditionGuidelines;
        return this;
    }

    @JsonProperty("TobaccoUsageGuidelines")
    public TobaccoUsageGuidelines getTobaccoUsageGuidelines() {
        return tobaccoUsageGuidelines;
    }

    @JsonProperty("TobaccoUsageGuidelines")
    public void setTobaccoUsageGuidelines(TobaccoUsageGuidelines tobaccoUsageGuidelines) {
        this.tobaccoUsageGuidelines = tobaccoUsageGuidelines;
    }

    public UnderwritingClassGuideline withTobaccoUsageGuidelines(TobaccoUsageGuidelines tobaccoUsageGuidelines) {
        this.tobaccoUsageGuidelines = tobaccoUsageGuidelines;
        return this;
    }

    @JsonProperty("SubstanceUsageGuidelines")
    public SubstanceUsageGuidelines getSubstanceUsageGuidelines() {
        return substanceUsageGuidelines;
    }

    @JsonProperty("SubstanceUsageGuidelines")
    public void setSubstanceUsageGuidelines(SubstanceUsageGuidelines substanceUsageGuidelines) {
        this.substanceUsageGuidelines = substanceUsageGuidelines;
    }

    public UnderwritingClassGuideline withSubstanceUsageGuidelines(SubstanceUsageGuidelines substanceUsageGuidelines) {
        this.substanceUsageGuidelines = substanceUsageGuidelines;
        return this;
    }

    @JsonProperty("CholesterolGuidelines")
    public CholesterolGuidelines getCholesterolGuidelines() {
        return cholesterolGuidelines;
    }

    @JsonProperty("CholesterolGuidelines")
    public void setCholesterolGuidelines(CholesterolGuidelines cholesterolGuidelines) {
        this.cholesterolGuidelines = cholesterolGuidelines;
    }

    public UnderwritingClassGuideline withCholesterolGuidelines(CholesterolGuidelines cholesterolGuidelines) {
        this.cholesterolGuidelines = cholesterolGuidelines;
        return this;
    }

    @JsonProperty("FamilyHistoryGuidelines")
    public FamilyHistoryGuidelines getFamilyHistoryGuidelines() {
        return familyHistoryGuidelines;
    }

    @JsonProperty("FamilyHistoryGuidelines")
    public void setFamilyHistoryGuidelines(FamilyHistoryGuidelines familyHistoryGuidelines) {
        this.familyHistoryGuidelines = familyHistoryGuidelines;
    }

    public UnderwritingClassGuideline withFamilyHistoryGuidelines(FamilyHistoryGuidelines familyHistoryGuidelines) {
        this.familyHistoryGuidelines = familyHistoryGuidelines;
        return this;
    }

    @JsonProperty("ForeignTravelGuidelines")
    public ForeignTravelGuidelines getForeignTravelGuidelines() {
        return foreignTravelGuidelines;
    }

    @JsonProperty("ForeignTravelGuidelines")
    public void setForeignTravelGuidelines(ForeignTravelGuidelines foreignTravelGuidelines) {
        this.foreignTravelGuidelines = foreignTravelGuidelines;
    }

    public UnderwritingClassGuideline withForeignTravelGuidelines(ForeignTravelGuidelines foreignTravelGuidelines) {
        this.foreignTravelGuidelines = foreignTravelGuidelines;
        return this;
    }

    @JsonProperty("AviationGuidelines")
    public AviationGuidelines getAviationGuidelines() {
        return aviationGuidelines;
    }

    @JsonProperty("AviationGuidelines")
    public void setAviationGuidelines(AviationGuidelines aviationGuidelines) {
        this.aviationGuidelines = aviationGuidelines;
    }

    public UnderwritingClassGuideline withAviationGuidelines(AviationGuidelines aviationGuidelines) {
        this.aviationGuidelines = aviationGuidelines;
        return this;
    }

    @JsonProperty("OccupationGuidelines")
    public OccupationGuidelines getOccupationGuidelines() {
        return occupationGuidelines;
    }

    @JsonProperty("OccupationGuidelines")
    public void setOccupationGuidelines(OccupationGuidelines occupationGuidelines) {
        this.occupationGuidelines = occupationGuidelines;
    }

    public UnderwritingClassGuideline withOccupationGuidelines(OccupationGuidelines occupationGuidelines) {
        this.occupationGuidelines = occupationGuidelines;
        return this;
    }

    @JsonProperty("AvocationGuidelines")
    public AvocationGuidelines getAvocationGuidelines() {
        return avocationGuidelines;
    }

    @JsonProperty("AvocationGuidelines")
    public void setAvocationGuidelines(AvocationGuidelines avocationGuidelines) {
        this.avocationGuidelines = avocationGuidelines;
    }

    public UnderwritingClassGuideline withAvocationGuidelines(AvocationGuidelines avocationGuidelines) {
        this.avocationGuidelines = avocationGuidelines;
        return this;
    }

    @JsonProperty("ResidencyGuidelines")
    public ResidencyGuidelines getResidencyGuidelines() {
        return residencyGuidelines;
    }

    @JsonProperty("ResidencyGuidelines")
    public void setResidencyGuidelines(ResidencyGuidelines residencyGuidelines) {
        this.residencyGuidelines = residencyGuidelines;
    }

    public UnderwritingClassGuideline withResidencyGuidelines(ResidencyGuidelines residencyGuidelines) {
        this.residencyGuidelines = residencyGuidelines;
        return this;
    }

    @JsonProperty("MilitaryGuidelines")
    public MilitaryGuidelines getMilitaryGuidelines() {
        return militaryGuidelines;
    }

    @JsonProperty("MilitaryGuidelines")
    public void setMilitaryGuidelines(MilitaryGuidelines militaryGuidelines) {
        this.militaryGuidelines = militaryGuidelines;
    }

    public UnderwritingClassGuideline withMilitaryGuidelines(MilitaryGuidelines militaryGuidelines) {
        this.militaryGuidelines = militaryGuidelines;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public UnderwritingClassGuideline withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public UnderwritingClassGuideline withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public UnderwritingClassGuideline withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public UnderwritingClassGuideline withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public UnderwritingClassGuideline withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(UnderwritingClassGuideline.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("underwritingClassGuidelineKey");
        sb.append('=');
        sb.append(((this.underwritingClassGuidelineKey == null)?"<null>":this.underwritingClassGuidelineKey));
        sb.append(',');
        sb.append("underwritingClassGuidelineSysKey");
        sb.append('=');
        sb.append(((this.underwritingClassGuidelineSysKey == null)?"<null>":this.underwritingClassGuidelineSysKey));
        sb.append(',');
        sb.append("undClassGuidelineCode");
        sb.append('=');
        sb.append(((this.undClassGuidelineCode == null)?"<null>":this.undClassGuidelineCode));
        sb.append(',');
        sb.append("className");
        sb.append('=');
        sb.append(((this.className == null)?"<null>":this.className));
        sb.append(',');
        sb.append("underwritingClass");
        sb.append('=');
        sb.append(((this.underwritingClass == null)?"<null>":this.underwritingClass));
        sb.append(',');
        sb.append("underwritingSubClass");
        sb.append('=');
        sb.append(((this.underwritingSubClass == null)?"<null>":this.underwritingSubClass));
        sb.append(',');
        sb.append("tobaccoPremiumBasis");
        sb.append('=');
        sb.append(((this.tobaccoPremiumBasis == null)?"<null>":this.tobaccoPremiumBasis));
        sb.append(',');
        sb.append("sequence");
        sb.append('=');
        sb.append(((this.sequence == null)?"<null>":this.sequence));
        sb.append(',');
        sb.append("guidelineFailInstructionType");
        sb.append('=');
        sb.append(((this.guidelineFailInstructionType == null)?"<null>":this.guidelineFailInstructionType));
        sb.append(',');
        sb.append("drivingHistoryGuidelines");
        sb.append('=');
        sb.append(((this.drivingHistoryGuidelines == null)?"<null>":this.drivingHistoryGuidelines));
        sb.append(',');
        sb.append("bloodPressureGuidelines");
        sb.append('=');
        sb.append(((this.bloodPressureGuidelines == null)?"<null>":this.bloodPressureGuidelines));
        sb.append(',');
        sb.append("medicalConditionGuidelines");
        sb.append('=');
        sb.append(((this.medicalConditionGuidelines == null)?"<null>":this.medicalConditionGuidelines));
        sb.append(',');
        sb.append("tobaccoUsageGuidelines");
        sb.append('=');
        sb.append(((this.tobaccoUsageGuidelines == null)?"<null>":this.tobaccoUsageGuidelines));
        sb.append(',');
        sb.append("substanceUsageGuidelines");
        sb.append('=');
        sb.append(((this.substanceUsageGuidelines == null)?"<null>":this.substanceUsageGuidelines));
        sb.append(',');
        sb.append("cholesterolGuidelines");
        sb.append('=');
        sb.append(((this.cholesterolGuidelines == null)?"<null>":this.cholesterolGuidelines));
        sb.append(',');
        sb.append("familyHistoryGuidelines");
        sb.append('=');
        sb.append(((this.familyHistoryGuidelines == null)?"<null>":this.familyHistoryGuidelines));
        sb.append(',');
        sb.append("foreignTravelGuidelines");
        sb.append('=');
        sb.append(((this.foreignTravelGuidelines == null)?"<null>":this.foreignTravelGuidelines));
        sb.append(',');
        sb.append("aviationGuidelines");
        sb.append('=');
        sb.append(((this.aviationGuidelines == null)?"<null>":this.aviationGuidelines));
        sb.append(',');
        sb.append("occupationGuidelines");
        sb.append('=');
        sb.append(((this.occupationGuidelines == null)?"<null>":this.occupationGuidelines));
        sb.append(',');
        sb.append("avocationGuidelines");
        sb.append('=');
        sb.append(((this.avocationGuidelines == null)?"<null>":this.avocationGuidelines));
        sb.append(',');
        sb.append("residencyGuidelines");
        sb.append('=');
        sb.append(((this.residencyGuidelines == null)?"<null>":this.residencyGuidelines));
        sb.append(',');
        sb.append("militaryGuidelines");
        sb.append('=');
        sb.append(((this.militaryGuidelines == null)?"<null>":this.militaryGuidelines));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.drivingHistoryGuidelines == null)? 0 :this.drivingHistoryGuidelines.hashCode()));
        result = ((result* 31)+((this.className == null)? 0 :this.className.hashCode()));
        result = ((result* 31)+((this.underwritingClass == null)? 0 :this.underwritingClass.hashCode()));
        result = ((result* 31)+((this.bloodPressureGuidelines == null)? 0 :this.bloodPressureGuidelines.hashCode()));
        result = ((result* 31)+((this.tobaccoPremiumBasis == null)? 0 :this.tobaccoPremiumBasis.hashCode()));
        result = ((result* 31)+((this.familyHistoryGuidelines == null)? 0 :this.familyHistoryGuidelines.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        result = ((result* 31)+((this.undClassGuidelineCode == null)? 0 :this.undClassGuidelineCode.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.avocationGuidelines == null)? 0 :this.avocationGuidelines.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.cholesterolGuidelines == null)? 0 :this.cholesterolGuidelines.hashCode()));
        result = ((result* 31)+((this.underwritingSubClass == null)? 0 :this.underwritingSubClass.hashCode()));
        result = ((result* 31)+((this.underwritingClassGuidelineKey == null)? 0 :this.underwritingClassGuidelineKey.hashCode()));
        result = ((result* 31)+((this.tobaccoUsageGuidelines == null)? 0 :this.tobaccoUsageGuidelines.hashCode()));
        result = ((result* 31)+((this.militaryGuidelines == null)? 0 :this.militaryGuidelines.hashCode()));
        result = ((result* 31)+((this.underwritingClassGuidelineSysKey == null)? 0 :this.underwritingClassGuidelineSysKey.hashCode()));
        result = ((result* 31)+((this.occupationGuidelines == null)? 0 :this.occupationGuidelines.hashCode()));
        result = ((result* 31)+((this.medicalConditionGuidelines == null)? 0 :this.medicalConditionGuidelines.hashCode()));
        result = ((result* 31)+((this.substanceUsageGuidelines == null)? 0 :this.substanceUsageGuidelines.hashCode()));
        result = ((result* 31)+((this.sequence == null)? 0 :this.sequence.hashCode()));
        result = ((result* 31)+((this.foreignTravelGuidelines == null)? 0 :this.foreignTravelGuidelines.hashCode()));
        result = ((result* 31)+((this.residencyGuidelines == null)? 0 :this.residencyGuidelines.hashCode()));
        result = ((result* 31)+((this.guidelineFailInstructionType == null)? 0 :this.guidelineFailInstructionType.hashCode()));
        result = ((result* 31)+((this.aviationGuidelines == null)? 0 :this.aviationGuidelines.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UnderwritingClassGuideline) == false) {
            return false;
        }
        UnderwritingClassGuideline rhs = ((UnderwritingClassGuideline) other);
        return ((((((((((((((((((((((((((((this.drivingHistoryGuidelines == rhs.drivingHistoryGuidelines)||((this.drivingHistoryGuidelines!= null)&&this.drivingHistoryGuidelines.equals(rhs.drivingHistoryGuidelines)))&&((this.className == rhs.className)||((this.className!= null)&&this.className.equals(rhs.className))))&&((this.underwritingClass == rhs.underwritingClass)||((this.underwritingClass!= null)&&this.underwritingClass.equals(rhs.underwritingClass))))&&((this.bloodPressureGuidelines == rhs.bloodPressureGuidelines)||((this.bloodPressureGuidelines!= null)&&this.bloodPressureGuidelines.equals(rhs.bloodPressureGuidelines))))&&((this.tobaccoPremiumBasis == rhs.tobaccoPremiumBasis)||((this.tobaccoPremiumBasis!= null)&&this.tobaccoPremiumBasis.equals(rhs.tobaccoPremiumBasis))))&&((this.familyHistoryGuidelines == rhs.familyHistoryGuidelines)||((this.familyHistoryGuidelines!= null)&&this.familyHistoryGuidelines.equals(rhs.familyHistoryGuidelines))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))))&&((this.undClassGuidelineCode == rhs.undClassGuidelineCode)||((this.undClassGuidelineCode!= null)&&this.undClassGuidelineCode.equals(rhs.undClassGuidelineCode))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.avocationGuidelines == rhs.avocationGuidelines)||((this.avocationGuidelines!= null)&&this.avocationGuidelines.equals(rhs.avocationGuidelines))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.cholesterolGuidelines == rhs.cholesterolGuidelines)||((this.cholesterolGuidelines!= null)&&this.cholesterolGuidelines.equals(rhs.cholesterolGuidelines))))&&((this.underwritingSubClass == rhs.underwritingSubClass)||((this.underwritingSubClass!= null)&&this.underwritingSubClass.equals(rhs.underwritingSubClass))))&&((this.underwritingClassGuidelineKey == rhs.underwritingClassGuidelineKey)||((this.underwritingClassGuidelineKey!= null)&&this.underwritingClassGuidelineKey.equals(rhs.underwritingClassGuidelineKey))))&&((this.tobaccoUsageGuidelines == rhs.tobaccoUsageGuidelines)||((this.tobaccoUsageGuidelines!= null)&&this.tobaccoUsageGuidelines.equals(rhs.tobaccoUsageGuidelines))))&&((this.militaryGuidelines == rhs.militaryGuidelines)||((this.militaryGuidelines!= null)&&this.militaryGuidelines.equals(rhs.militaryGuidelines))))&&((this.underwritingClassGuidelineSysKey == rhs.underwritingClassGuidelineSysKey)||((this.underwritingClassGuidelineSysKey!= null)&&this.underwritingClassGuidelineSysKey.equals(rhs.underwritingClassGuidelineSysKey))))&&((this.occupationGuidelines == rhs.occupationGuidelines)||((this.occupationGuidelines!= null)&&this.occupationGuidelines.equals(rhs.occupationGuidelines))))&&((this.medicalConditionGuidelines == rhs.medicalConditionGuidelines)||((this.medicalConditionGuidelines!= null)&&this.medicalConditionGuidelines.equals(rhs.medicalConditionGuidelines))))&&((this.substanceUsageGuidelines == rhs.substanceUsageGuidelines)||((this.substanceUsageGuidelines!= null)&&this.substanceUsageGuidelines.equals(rhs.substanceUsageGuidelines))))&&((this.sequence == rhs.sequence)||((this.sequence!= null)&&this.sequence.equals(rhs.sequence))))&&((this.foreignTravelGuidelines == rhs.foreignTravelGuidelines)||((this.foreignTravelGuidelines!= null)&&this.foreignTravelGuidelines.equals(rhs.foreignTravelGuidelines))))&&((this.residencyGuidelines == rhs.residencyGuidelines)||((this.residencyGuidelines!= null)&&this.residencyGuidelines.equals(rhs.residencyGuidelines))))&&((this.guidelineFailInstructionType == rhs.guidelineFailInstructionType)||((this.guidelineFailInstructionType!= null)&&this.guidelineFailInstructionType.equals(rhs.guidelineFailInstructionType))))&&((this.aviationGuidelines == rhs.aviationGuidelines)||((this.aviationGuidelines!= null)&&this.aviationGuidelines.equals(rhs.aviationGuidelines))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
