
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "MedicalCertRestrictionKey",
    "MedicalCertRestrictionSysKey",
    "MedCertRestrictionType",
    "MedCertRestrictionTypeDesc",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class MedicalCertRestriction {

    @JsonProperty("MedicalCertRestrictionKey")
    private MedicalCertRestrictionKey medicalCertRestrictionKey;
    @JsonProperty("MedicalCertRestrictionSysKey")
    private List<Object> medicalCertRestrictionSysKey = new ArrayList<>();
    @JsonProperty("MedCertRestrictionType")
    private MedCertRestrictionType medCertRestrictionType;
    @JsonProperty("MedCertRestrictionTypeDesc")
    private String medCertRestrictionTypeDesc;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("MedicalCertRestrictionKey")
    public MedicalCertRestrictionKey getMedicalCertRestrictionKey() {
        return medicalCertRestrictionKey;
    }

    @JsonProperty("MedicalCertRestrictionKey")
    public void setMedicalCertRestrictionKey(MedicalCertRestrictionKey medicalCertRestrictionKey) {
        this.medicalCertRestrictionKey = medicalCertRestrictionKey;
    }

    public MedicalCertRestriction withMedicalCertRestrictionKey(MedicalCertRestrictionKey medicalCertRestrictionKey) {
        this.medicalCertRestrictionKey = medicalCertRestrictionKey;
        return this;
    }

    @JsonProperty("MedicalCertRestrictionSysKey")
    public List<Object> getMedicalCertRestrictionSysKey() {
        return medicalCertRestrictionSysKey;
    }

    @JsonProperty("MedicalCertRestrictionSysKey")
    public void setMedicalCertRestrictionSysKey(List<Object> medicalCertRestrictionSysKey) {
        this.medicalCertRestrictionSysKey = medicalCertRestrictionSysKey;
    }

    public MedicalCertRestriction withMedicalCertRestrictionSysKey(List<Object> medicalCertRestrictionSysKey) {
        this.medicalCertRestrictionSysKey = medicalCertRestrictionSysKey;
        return this;
    }

    @JsonProperty("MedCertRestrictionType")
    public MedCertRestrictionType getMedCertRestrictionType() {
        return medCertRestrictionType;
    }

    @JsonProperty("MedCertRestrictionType")
    public void setMedCertRestrictionType(MedCertRestrictionType medCertRestrictionType) {
        this.medCertRestrictionType = medCertRestrictionType;
    }

    public MedicalCertRestriction withMedCertRestrictionType(MedCertRestrictionType medCertRestrictionType) {
        this.medCertRestrictionType = medCertRestrictionType;
        return this;
    }

    @JsonProperty("MedCertRestrictionTypeDesc")
    public String getMedCertRestrictionTypeDesc() {
        return medCertRestrictionTypeDesc;
    }

    @JsonProperty("MedCertRestrictionTypeDesc")
    public void setMedCertRestrictionTypeDesc(String medCertRestrictionTypeDesc) {
        this.medCertRestrictionTypeDesc = medCertRestrictionTypeDesc;
    }

    public MedicalCertRestriction withMedCertRestrictionTypeDesc(String medCertRestrictionTypeDesc) {
        this.medCertRestrictionTypeDesc = medCertRestrictionTypeDesc;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public MedicalCertRestriction withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public MedicalCertRestriction withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public MedicalCertRestriction withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MedicalCertRestriction withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(MedicalCertRestriction.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("medicalCertRestrictionKey");
        sb.append('=');
        sb.append(((this.medicalCertRestrictionKey == null)?"<null>":this.medicalCertRestrictionKey));
        sb.append(',');
        sb.append("medicalCertRestrictionSysKey");
        sb.append('=');
        sb.append(((this.medicalCertRestrictionSysKey == null)?"<null>":this.medicalCertRestrictionSysKey));
        sb.append(',');
        sb.append("medCertRestrictionType");
        sb.append('=');
        sb.append(((this.medCertRestrictionType == null)?"<null>":this.medCertRestrictionType));
        sb.append(',');
        sb.append("medCertRestrictionTypeDesc");
        sb.append('=');
        sb.append(((this.medCertRestrictionTypeDesc == null)?"<null>":this.medCertRestrictionTypeDesc));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.medicalCertRestrictionKey == null)? 0 :this.medicalCertRestrictionKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.medCertRestrictionTypeDesc == null)? 0 :this.medCertRestrictionTypeDesc.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.medicalCertRestrictionSysKey == null)? 0 :this.medicalCertRestrictionSysKey.hashCode()));
        result = ((result* 31)+((this.medCertRestrictionType == null)? 0 :this.medCertRestrictionType.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MedicalCertRestriction) == false) {
            return false;
        }
        MedicalCertRestriction rhs = ((MedicalCertRestriction) other);
        return (((((((((this.medicalCertRestrictionKey == rhs.medicalCertRestrictionKey)||((this.medicalCertRestrictionKey!= null)&&this.medicalCertRestrictionKey.equals(rhs.medicalCertRestrictionKey)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.medCertRestrictionTypeDesc == rhs.medCertRestrictionTypeDesc)||((this.medCertRestrictionTypeDesc!= null)&&this.medCertRestrictionTypeDesc.equals(rhs.medCertRestrictionTypeDesc))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.medicalCertRestrictionSysKey == rhs.medicalCertRestrictionSysKey)||((this.medicalCertRestrictionSysKey!= null)&&this.medicalCertRestrictionSysKey.equals(rhs.medicalCertRestrictionSysKey))))&&((this.medCertRestrictionType == rhs.medCertRestrictionType)||((this.medCertRestrictionType!= null)&&this.medCertRestrictionType.equals(rhs.medCertRestrictionType))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
