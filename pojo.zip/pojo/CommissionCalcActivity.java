
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CommissionCalcActivityKey",
    "CommissionCalcActivitySysKey",
    "CommissionCalcDetail",
    "CommissionDetail",
    "CompanyProducerID",
    "CommissionBasisAmt",
    "RelationRoleCode",
    "CommissionLink",
    "OLifEExtension",
    "id",
    "CompanyProducerIDREF",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class CommissionCalcActivity {

    @JsonProperty("CommissionCalcActivityKey")
    private CommissionCalcActivityKey commissionCalcActivityKey;
    @JsonProperty("CommissionCalcActivitySysKey")
    private List<Object> commissionCalcActivitySysKey = new ArrayList<>();
    @JsonProperty("CommissionCalcDetail")
    private CommissionCalcDetail commissionCalcDetail;
    @JsonProperty("CommissionDetail")
    private List<Object> commissionDetail = new ArrayList<>();
    @JsonProperty("CompanyProducerID")
    private String companyProducerID;
    @JsonProperty("CommissionBasisAmt")
    private Integer commissionBasisAmt;
    @JsonProperty("RelationRoleCode")
    private RelationRoleCode relationRoleCode;
    @JsonProperty("CommissionLink")
    private String commissionLink;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("CompanyProducerIDREF")
    private String companyProducerIDREF;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("CommissionCalcActivityKey")
    public CommissionCalcActivityKey getCommissionCalcActivityKey() {
        return commissionCalcActivityKey;
    }

    @JsonProperty("CommissionCalcActivityKey")
    public void setCommissionCalcActivityKey(CommissionCalcActivityKey commissionCalcActivityKey) {
        this.commissionCalcActivityKey = commissionCalcActivityKey;
    }

    public CommissionCalcActivity withCommissionCalcActivityKey(CommissionCalcActivityKey commissionCalcActivityKey) {
        this.commissionCalcActivityKey = commissionCalcActivityKey;
        return this;
    }

    @JsonProperty("CommissionCalcActivitySysKey")
    public List<Object> getCommissionCalcActivitySysKey() {
        return commissionCalcActivitySysKey;
    }

    @JsonProperty("CommissionCalcActivitySysKey")
    public void setCommissionCalcActivitySysKey(List<Object> commissionCalcActivitySysKey) {
        this.commissionCalcActivitySysKey = commissionCalcActivitySysKey;
    }

    public CommissionCalcActivity withCommissionCalcActivitySysKey(List<Object> commissionCalcActivitySysKey) {
        this.commissionCalcActivitySysKey = commissionCalcActivitySysKey;
        return this;
    }

    @JsonProperty("CommissionCalcDetail")
    public CommissionCalcDetail getCommissionCalcDetail() {
        return commissionCalcDetail;
    }

    @JsonProperty("CommissionCalcDetail")
    public void setCommissionCalcDetail(CommissionCalcDetail commissionCalcDetail) {
        this.commissionCalcDetail = commissionCalcDetail;
    }

    public CommissionCalcActivity withCommissionCalcDetail(CommissionCalcDetail commissionCalcDetail) {
        this.commissionCalcDetail = commissionCalcDetail;
        return this;
    }

    @JsonProperty("CommissionDetail")
    public List<Object> getCommissionDetail() {
        return commissionDetail;
    }

    @JsonProperty("CommissionDetail")
    public void setCommissionDetail(List<Object> commissionDetail) {
        this.commissionDetail = commissionDetail;
    }

    public CommissionCalcActivity withCommissionDetail(List<Object> commissionDetail) {
        this.commissionDetail = commissionDetail;
        return this;
    }

    @JsonProperty("CompanyProducerID")
    public String getCompanyProducerID() {
        return companyProducerID;
    }

    @JsonProperty("CompanyProducerID")
    public void setCompanyProducerID(String companyProducerID) {
        this.companyProducerID = companyProducerID;
    }

    public CommissionCalcActivity withCompanyProducerID(String companyProducerID) {
        this.companyProducerID = companyProducerID;
        return this;
    }

    @JsonProperty("CommissionBasisAmt")
    public Integer getCommissionBasisAmt() {
        return commissionBasisAmt;
    }

    @JsonProperty("CommissionBasisAmt")
    public void setCommissionBasisAmt(Integer commissionBasisAmt) {
        this.commissionBasisAmt = commissionBasisAmt;
    }

    public CommissionCalcActivity withCommissionBasisAmt(Integer commissionBasisAmt) {
        this.commissionBasisAmt = commissionBasisAmt;
        return this;
    }

    @JsonProperty("RelationRoleCode")
    public RelationRoleCode getRelationRoleCode() {
        return relationRoleCode;
    }

    @JsonProperty("RelationRoleCode")
    public void setRelationRoleCode(RelationRoleCode relationRoleCode) {
        this.relationRoleCode = relationRoleCode;
    }

    public CommissionCalcActivity withRelationRoleCode(RelationRoleCode relationRoleCode) {
        this.relationRoleCode = relationRoleCode;
        return this;
    }

    @JsonProperty("CommissionLink")
    public String getCommissionLink() {
        return commissionLink;
    }

    @JsonProperty("CommissionLink")
    public void setCommissionLink(String commissionLink) {
        this.commissionLink = commissionLink;
    }

    public CommissionCalcActivity withCommissionLink(String commissionLink) {
        this.commissionLink = commissionLink;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public CommissionCalcActivity withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public CommissionCalcActivity withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("CompanyProducerIDREF")
    public String getCompanyProducerIDREF() {
        return companyProducerIDREF;
    }

    @JsonProperty("CompanyProducerIDREF")
    public void setCompanyProducerIDREF(String companyProducerIDREF) {
        this.companyProducerIDREF = companyProducerIDREF;
    }

    public CommissionCalcActivity withCompanyProducerIDREF(String companyProducerIDREF) {
        this.companyProducerIDREF = companyProducerIDREF;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public CommissionCalcActivity withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CommissionCalcActivity withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(CommissionCalcActivity.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("commissionCalcActivityKey");
        sb.append('=');
        sb.append(((this.commissionCalcActivityKey == null)?"<null>":this.commissionCalcActivityKey));
        sb.append(',');
        sb.append("commissionCalcActivitySysKey");
        sb.append('=');
        sb.append(((this.commissionCalcActivitySysKey == null)?"<null>":this.commissionCalcActivitySysKey));
        sb.append(',');
        sb.append("commissionCalcDetail");
        sb.append('=');
        sb.append(((this.commissionCalcDetail == null)?"<null>":this.commissionCalcDetail));
        sb.append(',');
        sb.append("commissionDetail");
        sb.append('=');
        sb.append(((this.commissionDetail == null)?"<null>":this.commissionDetail));
        sb.append(',');
        sb.append("companyProducerID");
        sb.append('=');
        sb.append(((this.companyProducerID == null)?"<null>":this.companyProducerID));
        sb.append(',');
        sb.append("commissionBasisAmt");
        sb.append('=');
        sb.append(((this.commissionBasisAmt == null)?"<null>":this.commissionBasisAmt));
        sb.append(',');
        sb.append("relationRoleCode");
        sb.append('=');
        sb.append(((this.relationRoleCode == null)?"<null>":this.relationRoleCode));
        sb.append(',');
        sb.append("commissionLink");
        sb.append('=');
        sb.append(((this.commissionLink == null)?"<null>":this.commissionLink));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("companyProducerIDREF");
        sb.append('=');
        sb.append(((this.companyProducerIDREF == null)?"<null>":this.companyProducerIDREF));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.commissionLink == null)? 0 :this.commissionLink.hashCode()));
        result = ((result* 31)+((this.companyProducerIDREF == null)? 0 :this.companyProducerIDREF.hashCode()));
        result = ((result* 31)+((this.commissionCalcDetail == null)? 0 :this.commissionCalcDetail.hashCode()));
        result = ((result* 31)+((this.relationRoleCode == null)? 0 :this.relationRoleCode.hashCode()));
        result = ((result* 31)+((this.commissionCalcActivityKey == null)? 0 :this.commissionCalcActivityKey.hashCode()));
        result = ((result* 31)+((this.commissionCalcActivitySysKey == null)? 0 :this.commissionCalcActivitySysKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.companyProducerID == null)? 0 :this.companyProducerID.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.commissionDetail == null)? 0 :this.commissionDetail.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.commissionBasisAmt == null)? 0 :this.commissionBasisAmt.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CommissionCalcActivity) == false) {
            return false;
        }
        CommissionCalcActivity rhs = ((CommissionCalcActivity) other);
        return ((((((((((((((this.commissionLink == rhs.commissionLink)||((this.commissionLink!= null)&&this.commissionLink.equals(rhs.commissionLink)))&&((this.companyProducerIDREF == rhs.companyProducerIDREF)||((this.companyProducerIDREF!= null)&&this.companyProducerIDREF.equals(rhs.companyProducerIDREF))))&&((this.commissionCalcDetail == rhs.commissionCalcDetail)||((this.commissionCalcDetail!= null)&&this.commissionCalcDetail.equals(rhs.commissionCalcDetail))))&&((this.relationRoleCode == rhs.relationRoleCode)||((this.relationRoleCode!= null)&&this.relationRoleCode.equals(rhs.relationRoleCode))))&&((this.commissionCalcActivityKey == rhs.commissionCalcActivityKey)||((this.commissionCalcActivityKey!= null)&&this.commissionCalcActivityKey.equals(rhs.commissionCalcActivityKey))))&&((this.commissionCalcActivitySysKey == rhs.commissionCalcActivitySysKey)||((this.commissionCalcActivitySysKey!= null)&&this.commissionCalcActivitySysKey.equals(rhs.commissionCalcActivitySysKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.companyProducerID == rhs.companyProducerID)||((this.companyProducerID!= null)&&this.companyProducerID.equals(rhs.companyProducerID))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.commissionDetail == rhs.commissionDetail)||((this.commissionDetail!= null)&&this.commissionDetail.equals(rhs.commissionDetail))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.commissionBasisAmt == rhs.commissionBasisAmt)||((this.commissionBasisAmt!= null)&&this.commissionBasisAmt.equals(rhs.commissionBasisAmt))));
    }

}
