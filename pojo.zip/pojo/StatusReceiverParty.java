
package haj.com.astute.json.to.pojo;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "StatusReceiverPartyID"
})
@Generated("jsonschema2pojo")
public class StatusReceiverParty {

    @JsonProperty("StatusReceiverPartyID")
    private String statusReceiverPartyID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("StatusReceiverPartyID")
    public String getStatusReceiverPartyID() {
        return statusReceiverPartyID;
    }

    @JsonProperty("StatusReceiverPartyID")
    public void setStatusReceiverPartyID(String statusReceiverPartyID) {
        this.statusReceiverPartyID = statusReceiverPartyID;
    }

    public StatusReceiverParty withStatusReceiverPartyID(String statusReceiverPartyID) {
        this.statusReceiverPartyID = statusReceiverPartyID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public StatusReceiverParty withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(StatusReceiverParty.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("statusReceiverPartyID");
        sb.append('=');
        sb.append(((this.statusReceiverPartyID == null)?"<null>":this.statusReceiverPartyID));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.statusReceiverPartyID == null)? 0 :this.statusReceiverPartyID.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof StatusReceiverParty) == false) {
            return false;
        }
        StatusReceiverParty rhs = ((StatusReceiverParty) other);
        return (((this.statusReceiverPartyID == rhs.statusReceiverPartyID)||((this.statusReceiverPartyID!= null)&&this.statusReceiverPartyID.equals(rhs.statusReceiverPartyID)))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
