
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CodeListKey",
    "CodeListSysKey",
    "CodeListType",
    "CodeListCode",
    "CodeListVersion",
    "KeyCodeType",
    "ProviderDomain",
    "VersionDate",
    "Name",
    "Description",
    "CodeDefinition",
    "OLifEExtension",
    "id",
    "DataRep",
    "OwnerPartyID"
})
@Generated("jsonschema2pojo")
public class CodeList {

    @JsonProperty("CodeListKey")
    private CodeListKey codeListKey;
    @JsonProperty("CodeListSysKey")
    private List<Object> codeListSysKey = new ArrayList<>();
    @JsonProperty("CodeListType")
    private CodeListType codeListType;
    @JsonProperty("CodeListCode")
    private String codeListCode;
    @JsonProperty("CodeListVersion")
    private String codeListVersion;
    @JsonProperty("KeyCodeType")
    private KeyCodeType keyCodeType;
    @JsonProperty("ProviderDomain")
    private String providerDomain;
    @JsonProperty("VersionDate")
    private String versionDate;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("CodeDefinition")
    private List<Object> codeDefinition = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonProperty("OwnerPartyID")
    private String ownerPartyID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("CodeListKey")
    public CodeListKey getCodeListKey() {
        return codeListKey;
    }

    @JsonProperty("CodeListKey")
    public void setCodeListKey(CodeListKey codeListKey) {
        this.codeListKey = codeListKey;
    }

    public CodeList withCodeListKey(CodeListKey codeListKey) {
        this.codeListKey = codeListKey;
        return this;
    }

    @JsonProperty("CodeListSysKey")
    public List<Object> getCodeListSysKey() {
        return codeListSysKey;
    }

    @JsonProperty("CodeListSysKey")
    public void setCodeListSysKey(List<Object> codeListSysKey) {
        this.codeListSysKey = codeListSysKey;
    }

    public CodeList withCodeListSysKey(List<Object> codeListSysKey) {
        this.codeListSysKey = codeListSysKey;
        return this;
    }

    @JsonProperty("CodeListType")
    public CodeListType getCodeListType() {
        return codeListType;
    }

    @JsonProperty("CodeListType")
    public void setCodeListType(CodeListType codeListType) {
        this.codeListType = codeListType;
    }

    public CodeList withCodeListType(CodeListType codeListType) {
        this.codeListType = codeListType;
        return this;
    }

    @JsonProperty("CodeListCode")
    public String getCodeListCode() {
        return codeListCode;
    }

    @JsonProperty("CodeListCode")
    public void setCodeListCode(String codeListCode) {
        this.codeListCode = codeListCode;
    }

    public CodeList withCodeListCode(String codeListCode) {
        this.codeListCode = codeListCode;
        return this;
    }

    @JsonProperty("CodeListVersion")
    public String getCodeListVersion() {
        return codeListVersion;
    }

    @JsonProperty("CodeListVersion")
    public void setCodeListVersion(String codeListVersion) {
        this.codeListVersion = codeListVersion;
    }

    public CodeList withCodeListVersion(String codeListVersion) {
        this.codeListVersion = codeListVersion;
        return this;
    }

    @JsonProperty("KeyCodeType")
    public KeyCodeType getKeyCodeType() {
        return keyCodeType;
    }

    @JsonProperty("KeyCodeType")
    public void setKeyCodeType(KeyCodeType keyCodeType) {
        this.keyCodeType = keyCodeType;
    }

    public CodeList withKeyCodeType(KeyCodeType keyCodeType) {
        this.keyCodeType = keyCodeType;
        return this;
    }

    @JsonProperty("ProviderDomain")
    public String getProviderDomain() {
        return providerDomain;
    }

    @JsonProperty("ProviderDomain")
    public void setProviderDomain(String providerDomain) {
        this.providerDomain = providerDomain;
    }

    public CodeList withProviderDomain(String providerDomain) {
        this.providerDomain = providerDomain;
        return this;
    }

    @JsonProperty("VersionDate")
    public String getVersionDate() {
        return versionDate;
    }

    @JsonProperty("VersionDate")
    public void setVersionDate(String versionDate) {
        this.versionDate = versionDate;
    }

    public CodeList withVersionDate(String versionDate) {
        this.versionDate = versionDate;
        return this;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    public CodeList withName(String name) {
        this.name = name;
        return this;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    public CodeList withDescription(String description) {
        this.description = description;
        return this;
    }

    @JsonProperty("CodeDefinition")
    public List<Object> getCodeDefinition() {
        return codeDefinition;
    }

    @JsonProperty("CodeDefinition")
    public void setCodeDefinition(List<Object> codeDefinition) {
        this.codeDefinition = codeDefinition;
    }

    public CodeList withCodeDefinition(List<Object> codeDefinition) {
        this.codeDefinition = codeDefinition;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public CodeList withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public CodeList withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public CodeList withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonProperty("OwnerPartyID")
    public String getOwnerPartyID() {
        return ownerPartyID;
    }

    @JsonProperty("OwnerPartyID")
    public void setOwnerPartyID(String ownerPartyID) {
        this.ownerPartyID = ownerPartyID;
    }

    public CodeList withOwnerPartyID(String ownerPartyID) {
        this.ownerPartyID = ownerPartyID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CodeList withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(CodeList.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("codeListKey");
        sb.append('=');
        sb.append(((this.codeListKey == null)?"<null>":this.codeListKey));
        sb.append(',');
        sb.append("codeListSysKey");
        sb.append('=');
        sb.append(((this.codeListSysKey == null)?"<null>":this.codeListSysKey));
        sb.append(',');
        sb.append("codeListType");
        sb.append('=');
        sb.append(((this.codeListType == null)?"<null>":this.codeListType));
        sb.append(',');
        sb.append("codeListCode");
        sb.append('=');
        sb.append(((this.codeListCode == null)?"<null>":this.codeListCode));
        sb.append(',');
        sb.append("codeListVersion");
        sb.append('=');
        sb.append(((this.codeListVersion == null)?"<null>":this.codeListVersion));
        sb.append(',');
        sb.append("keyCodeType");
        sb.append('=');
        sb.append(((this.keyCodeType == null)?"<null>":this.keyCodeType));
        sb.append(',');
        sb.append("providerDomain");
        sb.append('=');
        sb.append(((this.providerDomain == null)?"<null>":this.providerDomain));
        sb.append(',');
        sb.append("versionDate");
        sb.append('=');
        sb.append(((this.versionDate == null)?"<null>":this.versionDate));
        sb.append(',');
        sb.append("name");
        sb.append('=');
        sb.append(((this.name == null)?"<null>":this.name));
        sb.append(',');
        sb.append("description");
        sb.append('=');
        sb.append(((this.description == null)?"<null>":this.description));
        sb.append(',');
        sb.append("codeDefinition");
        sb.append('=');
        sb.append(((this.codeDefinition == null)?"<null>":this.codeDefinition));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("ownerPartyID");
        sb.append('=');
        sb.append(((this.ownerPartyID == null)?"<null>":this.ownerPartyID));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.keyCodeType == null)? 0 :this.keyCodeType.hashCode()));
        result = ((result* 31)+((this.description == null)? 0 :this.description.hashCode()));
        result = ((result* 31)+((this.codeListCode == null)? 0 :this.codeListCode.hashCode()));
        result = ((result* 31)+((this.codeListVersion == null)? 0 :this.codeListVersion.hashCode()));
        result = ((result* 31)+((this.versionDate == null)? 0 :this.versionDate.hashCode()));
        result = ((result* 31)+((this.codeDefinition == null)? 0 :this.codeDefinition.hashCode()));
        result = ((result* 31)+((this.codeListSysKey == null)? 0 :this.codeListSysKey.hashCode()));
        result = ((result* 31)+((this.ownerPartyID == null)? 0 :this.ownerPartyID.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.providerDomain == null)? 0 :this.providerDomain.hashCode()));
        result = ((result* 31)+((this.codeListKey == null)? 0 :this.codeListKey.hashCode()));
        result = ((result* 31)+((this.name == null)? 0 :this.name.hashCode()));
        result = ((result* 31)+((this.codeListType == null)? 0 :this.codeListType.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CodeList) == false) {
            return false;
        }
        CodeList rhs = ((CodeList) other);
        return (((((((((((((((((this.keyCodeType == rhs.keyCodeType)||((this.keyCodeType!= null)&&this.keyCodeType.equals(rhs.keyCodeType)))&&((this.description == rhs.description)||((this.description!= null)&&this.description.equals(rhs.description))))&&((this.codeListCode == rhs.codeListCode)||((this.codeListCode!= null)&&this.codeListCode.equals(rhs.codeListCode))))&&((this.codeListVersion == rhs.codeListVersion)||((this.codeListVersion!= null)&&this.codeListVersion.equals(rhs.codeListVersion))))&&((this.versionDate == rhs.versionDate)||((this.versionDate!= null)&&this.versionDate.equals(rhs.versionDate))))&&((this.codeDefinition == rhs.codeDefinition)||((this.codeDefinition!= null)&&this.codeDefinition.equals(rhs.codeDefinition))))&&((this.codeListSysKey == rhs.codeListSysKey)||((this.codeListSysKey!= null)&&this.codeListSysKey.equals(rhs.codeListSysKey))))&&((this.ownerPartyID == rhs.ownerPartyID)||((this.ownerPartyID!= null)&&this.ownerPartyID.equals(rhs.ownerPartyID))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.providerDomain == rhs.providerDomain)||((this.providerDomain!= null)&&this.providerDomain.equals(rhs.providerDomain))))&&((this.codeListKey == rhs.codeListKey)||((this.codeListKey!= null)&&this.codeListKey.equals(rhs.codeListKey))))&&((this.name == rhs.name)||((this.name!= null)&&this.name.equals(rhs.name))))&&((this.codeListType == rhs.codeListType)||((this.codeListType!= null)&&this.codeListType.equals(rhs.codeListType))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
