
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ClientKey",
    "ClientSysKey",
    "ClientTypeCode",
    "ClientStatus",
    "NumRelations",
    "LeadSource",
    "EstTaxBracket",
    "PrefLanguage",
    "AlternateLanguage",
    "AlternateLanguageProficiency",
    "InvestorType",
    "GovtSocialInsEligibilityInd",
    "ShareInfoWithTradePartnerInd",
    "BrokerDealerInd",
    "DirectorInd",
    "EstIncomeAmt",
    "PrimaryInvObjective",
    "InvHorizonPeriod",
    "InvHorizonRangeMin",
    "InvHorizonRangeMax",
    "PrivacyAffiliateCode",
    "PrivacyThirdPartyCode",
    "LeadType",
    "ClientRegion",
    "ClientSubRegion",
    "ExpenseNeed",
    "KeyedValue",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class Client {

    @JsonProperty("ClientKey")
    private ClientKey clientKey;
    @JsonProperty("ClientSysKey")
    private List<Object> clientSysKey = new ArrayList<>();
    @JsonProperty("ClientTypeCode")
    private ClientTypeCode clientTypeCode;
    @JsonProperty("ClientStatus")
    private ClientStatus clientStatus;
    @JsonProperty("NumRelations")
    private Integer numRelations;
    @JsonProperty("LeadSource")
    private String leadSource;
    @JsonProperty("EstTaxBracket")
    private Integer estTaxBracket;
    @JsonProperty("PrefLanguage")
    private PrefLanguage prefLanguage;
    @JsonProperty("AlternateLanguage")
    private AlternateLanguage alternateLanguage;
    @JsonProperty("AlternateLanguageProficiency")
    private AlternateLanguageProficiency alternateLanguageProficiency;
    @JsonProperty("InvestorType")
    private Integer investorType;
    @JsonProperty("GovtSocialInsEligibilityInd")
    private GovtSocialInsEligibilityInd govtSocialInsEligibilityInd;
    @JsonProperty("ShareInfoWithTradePartnerInd")
    private ShareInfoWithTradePartnerInd shareInfoWithTradePartnerInd;
    @JsonProperty("BrokerDealerInd")
    private BrokerDealerInd brokerDealerInd;
    @JsonProperty("DirectorInd")
    private DirectorInd directorInd;
    @JsonProperty("EstIncomeAmt")
    private Integer estIncomeAmt;
    @JsonProperty("PrimaryInvObjective")
    private PrimaryInvObjective primaryInvObjective;
    @JsonProperty("InvHorizonPeriod")
    private InvHorizonPeriod invHorizonPeriod;
    @JsonProperty("InvHorizonRangeMin")
    private Integer invHorizonRangeMin;
    @JsonProperty("InvHorizonRangeMax")
    private Integer invHorizonRangeMax;
    @JsonProperty("PrivacyAffiliateCode")
    private PrivacyAffiliateCode privacyAffiliateCode;
    @JsonProperty("PrivacyThirdPartyCode")
    private PrivacyThirdPartyCode privacyThirdPartyCode;
    @JsonProperty("LeadType")
    private LeadType leadType;
    @JsonProperty("ClientRegion")
    private String clientRegion;
    @JsonProperty("ClientSubRegion")
    private String clientSubRegion;
    @JsonProperty("ExpenseNeed")
    private List<Object> expenseNeed = new ArrayList<>();
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ClientKey")
    public ClientKey getClientKey() {
        return clientKey;
    }

    @JsonProperty("ClientKey")
    public void setClientKey(ClientKey clientKey) {
        this.clientKey = clientKey;
    }

    public Client withClientKey(ClientKey clientKey) {
        this.clientKey = clientKey;
        return this;
    }

    @JsonProperty("ClientSysKey")
    public List<Object> getClientSysKey() {
        return clientSysKey;
    }

    @JsonProperty("ClientSysKey")
    public void setClientSysKey(List<Object> clientSysKey) {
        this.clientSysKey = clientSysKey;
    }

    public Client withClientSysKey(List<Object> clientSysKey) {
        this.clientSysKey = clientSysKey;
        return this;
    }

    @JsonProperty("ClientTypeCode")
    public ClientTypeCode getClientTypeCode() {
        return clientTypeCode;
    }

    @JsonProperty("ClientTypeCode")
    public void setClientTypeCode(ClientTypeCode clientTypeCode) {
        this.clientTypeCode = clientTypeCode;
    }

    public Client withClientTypeCode(ClientTypeCode clientTypeCode) {
        this.clientTypeCode = clientTypeCode;
        return this;
    }

    @JsonProperty("ClientStatus")
    public ClientStatus getClientStatus() {
        return clientStatus;
    }

    @JsonProperty("ClientStatus")
    public void setClientStatus(ClientStatus clientStatus) {
        this.clientStatus = clientStatus;
    }

    public Client withClientStatus(ClientStatus clientStatus) {
        this.clientStatus = clientStatus;
        return this;
    }

    @JsonProperty("NumRelations")
    public Integer getNumRelations() {
        return numRelations;
    }

    @JsonProperty("NumRelations")
    public void setNumRelations(Integer numRelations) {
        this.numRelations = numRelations;
    }

    public Client withNumRelations(Integer numRelations) {
        this.numRelations = numRelations;
        return this;
    }

    @JsonProperty("LeadSource")
    public String getLeadSource() {
        return leadSource;
    }

    @JsonProperty("LeadSource")
    public void setLeadSource(String leadSource) {
        this.leadSource = leadSource;
    }

    public Client withLeadSource(String leadSource) {
        this.leadSource = leadSource;
        return this;
    }

    @JsonProperty("EstTaxBracket")
    public Integer getEstTaxBracket() {
        return estTaxBracket;
    }

    @JsonProperty("EstTaxBracket")
    public void setEstTaxBracket(Integer estTaxBracket) {
        this.estTaxBracket = estTaxBracket;
    }

    public Client withEstTaxBracket(Integer estTaxBracket) {
        this.estTaxBracket = estTaxBracket;
        return this;
    }

    @JsonProperty("PrefLanguage")
    public PrefLanguage getPrefLanguage() {
        return prefLanguage;
    }

    @JsonProperty("PrefLanguage")
    public void setPrefLanguage(PrefLanguage prefLanguage) {
        this.prefLanguage = prefLanguage;
    }

    public Client withPrefLanguage(PrefLanguage prefLanguage) {
        this.prefLanguage = prefLanguage;
        return this;
    }

    @JsonProperty("AlternateLanguage")
    public AlternateLanguage getAlternateLanguage() {
        return alternateLanguage;
    }

    @JsonProperty("AlternateLanguage")
    public void setAlternateLanguage(AlternateLanguage alternateLanguage) {
        this.alternateLanguage = alternateLanguage;
    }

    public Client withAlternateLanguage(AlternateLanguage alternateLanguage) {
        this.alternateLanguage = alternateLanguage;
        return this;
    }

    @JsonProperty("AlternateLanguageProficiency")
    public AlternateLanguageProficiency getAlternateLanguageProficiency() {
        return alternateLanguageProficiency;
    }

    @JsonProperty("AlternateLanguageProficiency")
    public void setAlternateLanguageProficiency(AlternateLanguageProficiency alternateLanguageProficiency) {
        this.alternateLanguageProficiency = alternateLanguageProficiency;
    }

    public Client withAlternateLanguageProficiency(AlternateLanguageProficiency alternateLanguageProficiency) {
        this.alternateLanguageProficiency = alternateLanguageProficiency;
        return this;
    }

    @JsonProperty("InvestorType")
    public Integer getInvestorType() {
        return investorType;
    }

    @JsonProperty("InvestorType")
    public void setInvestorType(Integer investorType) {
        this.investorType = investorType;
    }

    public Client withInvestorType(Integer investorType) {
        this.investorType = investorType;
        return this;
    }

    @JsonProperty("GovtSocialInsEligibilityInd")
    public GovtSocialInsEligibilityInd getGovtSocialInsEligibilityInd() {
        return govtSocialInsEligibilityInd;
    }

    @JsonProperty("GovtSocialInsEligibilityInd")
    public void setGovtSocialInsEligibilityInd(GovtSocialInsEligibilityInd govtSocialInsEligibilityInd) {
        this.govtSocialInsEligibilityInd = govtSocialInsEligibilityInd;
    }

    public Client withGovtSocialInsEligibilityInd(GovtSocialInsEligibilityInd govtSocialInsEligibilityInd) {
        this.govtSocialInsEligibilityInd = govtSocialInsEligibilityInd;
        return this;
    }

    @JsonProperty("ShareInfoWithTradePartnerInd")
    public ShareInfoWithTradePartnerInd getShareInfoWithTradePartnerInd() {
        return shareInfoWithTradePartnerInd;
    }

    @JsonProperty("ShareInfoWithTradePartnerInd")
    public void setShareInfoWithTradePartnerInd(ShareInfoWithTradePartnerInd shareInfoWithTradePartnerInd) {
        this.shareInfoWithTradePartnerInd = shareInfoWithTradePartnerInd;
    }

    public Client withShareInfoWithTradePartnerInd(ShareInfoWithTradePartnerInd shareInfoWithTradePartnerInd) {
        this.shareInfoWithTradePartnerInd = shareInfoWithTradePartnerInd;
        return this;
    }

    @JsonProperty("BrokerDealerInd")
    public BrokerDealerInd getBrokerDealerInd() {
        return brokerDealerInd;
    }

    @JsonProperty("BrokerDealerInd")
    public void setBrokerDealerInd(BrokerDealerInd brokerDealerInd) {
        this.brokerDealerInd = brokerDealerInd;
    }

    public Client withBrokerDealerInd(BrokerDealerInd brokerDealerInd) {
        this.brokerDealerInd = brokerDealerInd;
        return this;
    }

    @JsonProperty("DirectorInd")
    public DirectorInd getDirectorInd() {
        return directorInd;
    }

    @JsonProperty("DirectorInd")
    public void setDirectorInd(DirectorInd directorInd) {
        this.directorInd = directorInd;
    }

    public Client withDirectorInd(DirectorInd directorInd) {
        this.directorInd = directorInd;
        return this;
    }

    @JsonProperty("EstIncomeAmt")
    public Integer getEstIncomeAmt() {
        return estIncomeAmt;
    }

    @JsonProperty("EstIncomeAmt")
    public void setEstIncomeAmt(Integer estIncomeAmt) {
        this.estIncomeAmt = estIncomeAmt;
    }

    public Client withEstIncomeAmt(Integer estIncomeAmt) {
        this.estIncomeAmt = estIncomeAmt;
        return this;
    }

    @JsonProperty("PrimaryInvObjective")
    public PrimaryInvObjective getPrimaryInvObjective() {
        return primaryInvObjective;
    }

    @JsonProperty("PrimaryInvObjective")
    public void setPrimaryInvObjective(PrimaryInvObjective primaryInvObjective) {
        this.primaryInvObjective = primaryInvObjective;
    }

    public Client withPrimaryInvObjective(PrimaryInvObjective primaryInvObjective) {
        this.primaryInvObjective = primaryInvObjective;
        return this;
    }

    @JsonProperty("InvHorizonPeriod")
    public InvHorizonPeriod getInvHorizonPeriod() {
        return invHorizonPeriod;
    }

    @JsonProperty("InvHorizonPeriod")
    public void setInvHorizonPeriod(InvHorizonPeriod invHorizonPeriod) {
        this.invHorizonPeriod = invHorizonPeriod;
    }

    public Client withInvHorizonPeriod(InvHorizonPeriod invHorizonPeriod) {
        this.invHorizonPeriod = invHorizonPeriod;
        return this;
    }

    @JsonProperty("InvHorizonRangeMin")
    public Integer getInvHorizonRangeMin() {
        return invHorizonRangeMin;
    }

    @JsonProperty("InvHorizonRangeMin")
    public void setInvHorizonRangeMin(Integer invHorizonRangeMin) {
        this.invHorizonRangeMin = invHorizonRangeMin;
    }

    public Client withInvHorizonRangeMin(Integer invHorizonRangeMin) {
        this.invHorizonRangeMin = invHorizonRangeMin;
        return this;
    }

    @JsonProperty("InvHorizonRangeMax")
    public Integer getInvHorizonRangeMax() {
        return invHorizonRangeMax;
    }

    @JsonProperty("InvHorizonRangeMax")
    public void setInvHorizonRangeMax(Integer invHorizonRangeMax) {
        this.invHorizonRangeMax = invHorizonRangeMax;
    }

    public Client withInvHorizonRangeMax(Integer invHorizonRangeMax) {
        this.invHorizonRangeMax = invHorizonRangeMax;
        return this;
    }

    @JsonProperty("PrivacyAffiliateCode")
    public PrivacyAffiliateCode getPrivacyAffiliateCode() {
        return privacyAffiliateCode;
    }

    @JsonProperty("PrivacyAffiliateCode")
    public void setPrivacyAffiliateCode(PrivacyAffiliateCode privacyAffiliateCode) {
        this.privacyAffiliateCode = privacyAffiliateCode;
    }

    public Client withPrivacyAffiliateCode(PrivacyAffiliateCode privacyAffiliateCode) {
        this.privacyAffiliateCode = privacyAffiliateCode;
        return this;
    }

    @JsonProperty("PrivacyThirdPartyCode")
    public PrivacyThirdPartyCode getPrivacyThirdPartyCode() {
        return privacyThirdPartyCode;
    }

    @JsonProperty("PrivacyThirdPartyCode")
    public void setPrivacyThirdPartyCode(PrivacyThirdPartyCode privacyThirdPartyCode) {
        this.privacyThirdPartyCode = privacyThirdPartyCode;
    }

    public Client withPrivacyThirdPartyCode(PrivacyThirdPartyCode privacyThirdPartyCode) {
        this.privacyThirdPartyCode = privacyThirdPartyCode;
        return this;
    }

    @JsonProperty("LeadType")
    public LeadType getLeadType() {
        return leadType;
    }

    @JsonProperty("LeadType")
    public void setLeadType(LeadType leadType) {
        this.leadType = leadType;
    }

    public Client withLeadType(LeadType leadType) {
        this.leadType = leadType;
        return this;
    }

    @JsonProperty("ClientRegion")
    public String getClientRegion() {
        return clientRegion;
    }

    @JsonProperty("ClientRegion")
    public void setClientRegion(String clientRegion) {
        this.clientRegion = clientRegion;
    }

    public Client withClientRegion(String clientRegion) {
        this.clientRegion = clientRegion;
        return this;
    }

    @JsonProperty("ClientSubRegion")
    public String getClientSubRegion() {
        return clientSubRegion;
    }

    @JsonProperty("ClientSubRegion")
    public void setClientSubRegion(String clientSubRegion) {
        this.clientSubRegion = clientSubRegion;
    }

    public Client withClientSubRegion(String clientSubRegion) {
        this.clientSubRegion = clientSubRegion;
        return this;
    }

    @JsonProperty("ExpenseNeed")
    public List<Object> getExpenseNeed() {
        return expenseNeed;
    }

    @JsonProperty("ExpenseNeed")
    public void setExpenseNeed(List<Object> expenseNeed) {
        this.expenseNeed = expenseNeed;
    }

    public Client withExpenseNeed(List<Object> expenseNeed) {
        this.expenseNeed = expenseNeed;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public Client withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Client withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Client withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public Client withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Client withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Client.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("clientKey");
        sb.append('=');
        sb.append(((this.clientKey == null)?"<null>":this.clientKey));
        sb.append(',');
        sb.append("clientSysKey");
        sb.append('=');
        sb.append(((this.clientSysKey == null)?"<null>":this.clientSysKey));
        sb.append(',');
        sb.append("clientTypeCode");
        sb.append('=');
        sb.append(((this.clientTypeCode == null)?"<null>":this.clientTypeCode));
        sb.append(',');
        sb.append("clientStatus");
        sb.append('=');
        sb.append(((this.clientStatus == null)?"<null>":this.clientStatus));
        sb.append(',');
        sb.append("numRelations");
        sb.append('=');
        sb.append(((this.numRelations == null)?"<null>":this.numRelations));
        sb.append(',');
        sb.append("leadSource");
        sb.append('=');
        sb.append(((this.leadSource == null)?"<null>":this.leadSource));
        sb.append(',');
        sb.append("estTaxBracket");
        sb.append('=');
        sb.append(((this.estTaxBracket == null)?"<null>":this.estTaxBracket));
        sb.append(',');
        sb.append("prefLanguage");
        sb.append('=');
        sb.append(((this.prefLanguage == null)?"<null>":this.prefLanguage));
        sb.append(',');
        sb.append("alternateLanguage");
        sb.append('=');
        sb.append(((this.alternateLanguage == null)?"<null>":this.alternateLanguage));
        sb.append(',');
        sb.append("alternateLanguageProficiency");
        sb.append('=');
        sb.append(((this.alternateLanguageProficiency == null)?"<null>":this.alternateLanguageProficiency));
        sb.append(',');
        sb.append("investorType");
        sb.append('=');
        sb.append(((this.investorType == null)?"<null>":this.investorType));
        sb.append(',');
        sb.append("govtSocialInsEligibilityInd");
        sb.append('=');
        sb.append(((this.govtSocialInsEligibilityInd == null)?"<null>":this.govtSocialInsEligibilityInd));
        sb.append(',');
        sb.append("shareInfoWithTradePartnerInd");
        sb.append('=');
        sb.append(((this.shareInfoWithTradePartnerInd == null)?"<null>":this.shareInfoWithTradePartnerInd));
        sb.append(',');
        sb.append("brokerDealerInd");
        sb.append('=');
        sb.append(((this.brokerDealerInd == null)?"<null>":this.brokerDealerInd));
        sb.append(',');
        sb.append("directorInd");
        sb.append('=');
        sb.append(((this.directorInd == null)?"<null>":this.directorInd));
        sb.append(',');
        sb.append("estIncomeAmt");
        sb.append('=');
        sb.append(((this.estIncomeAmt == null)?"<null>":this.estIncomeAmt));
        sb.append(',');
        sb.append("primaryInvObjective");
        sb.append('=');
        sb.append(((this.primaryInvObjective == null)?"<null>":this.primaryInvObjective));
        sb.append(',');
        sb.append("invHorizonPeriod");
        sb.append('=');
        sb.append(((this.invHorizonPeriod == null)?"<null>":this.invHorizonPeriod));
        sb.append(',');
        sb.append("invHorizonRangeMin");
        sb.append('=');
        sb.append(((this.invHorizonRangeMin == null)?"<null>":this.invHorizonRangeMin));
        sb.append(',');
        sb.append("invHorizonRangeMax");
        sb.append('=');
        sb.append(((this.invHorizonRangeMax == null)?"<null>":this.invHorizonRangeMax));
        sb.append(',');
        sb.append("privacyAffiliateCode");
        sb.append('=');
        sb.append(((this.privacyAffiliateCode == null)?"<null>":this.privacyAffiliateCode));
        sb.append(',');
        sb.append("privacyThirdPartyCode");
        sb.append('=');
        sb.append(((this.privacyThirdPartyCode == null)?"<null>":this.privacyThirdPartyCode));
        sb.append(',');
        sb.append("leadType");
        sb.append('=');
        sb.append(((this.leadType == null)?"<null>":this.leadType));
        sb.append(',');
        sb.append("clientRegion");
        sb.append('=');
        sb.append(((this.clientRegion == null)?"<null>":this.clientRegion));
        sb.append(',');
        sb.append("clientSubRegion");
        sb.append('=');
        sb.append(((this.clientSubRegion == null)?"<null>":this.clientSubRegion));
        sb.append(',');
        sb.append("expenseNeed");
        sb.append('=');
        sb.append(((this.expenseNeed == null)?"<null>":this.expenseNeed));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.privacyThirdPartyCode == null)? 0 :this.privacyThirdPartyCode.hashCode()));
        result = ((result* 31)+((this.expenseNeed == null)? 0 :this.expenseNeed.hashCode()));
        result = ((result* 31)+((this.clientTypeCode == null)? 0 :this.clientTypeCode.hashCode()));
        result = ((result* 31)+((this.clientStatus == null)? 0 :this.clientStatus.hashCode()));
        result = ((result* 31)+((this.numRelations == null)? 0 :this.numRelations.hashCode()));
        result = ((result* 31)+((this.shareInfoWithTradePartnerInd == null)? 0 :this.shareInfoWithTradePartnerInd.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.invHorizonRangeMin == null)? 0 :this.invHorizonRangeMin.hashCode()));
        result = ((result* 31)+((this.clientRegion == null)? 0 :this.clientRegion.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.privacyAffiliateCode == null)? 0 :this.privacyAffiliateCode.hashCode()));
        result = ((result* 31)+((this.clientKey == null)? 0 :this.clientKey.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.govtSocialInsEligibilityInd == null)? 0 :this.govtSocialInsEligibilityInd.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.clientSysKey == null)? 0 :this.clientSysKey.hashCode()));
        result = ((result* 31)+((this.prefLanguage == null)? 0 :this.prefLanguage.hashCode()));
        result = ((result* 31)+((this.directorInd == null)? 0 :this.directorInd.hashCode()));
        result = ((result* 31)+((this.primaryInvObjective == null)? 0 :this.primaryInvObjective.hashCode()));
        result = ((result* 31)+((this.leadSource == null)? 0 :this.leadSource.hashCode()));
        result = ((result* 31)+((this.invHorizonPeriod == null)? 0 :this.invHorizonPeriod.hashCode()));
        result = ((result* 31)+((this.alternateLanguage == null)? 0 :this.alternateLanguage.hashCode()));
        result = ((result* 31)+((this.alternateLanguageProficiency == null)? 0 :this.alternateLanguageProficiency.hashCode()));
        result = ((result* 31)+((this.leadType == null)? 0 :this.leadType.hashCode()));
        result = ((result* 31)+((this.estIncomeAmt == null)? 0 :this.estIncomeAmt.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.brokerDealerInd == null)? 0 :this.brokerDealerInd.hashCode()));
        result = ((result* 31)+((this.clientSubRegion == null)? 0 :this.clientSubRegion.hashCode()));
        result = ((result* 31)+((this.estTaxBracket == null)? 0 :this.estTaxBracket.hashCode()));
        result = ((result* 31)+((this.investorType == null)? 0 :this.investorType.hashCode()));
        result = ((result* 31)+((this.invHorizonRangeMax == null)? 0 :this.invHorizonRangeMax.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Client) == false) {
            return false;
        }
        Client rhs = ((Client) other);
        return ((((((((((((((((((((((((((((((((this.privacyThirdPartyCode == rhs.privacyThirdPartyCode)||((this.privacyThirdPartyCode!= null)&&this.privacyThirdPartyCode.equals(rhs.privacyThirdPartyCode)))&&((this.expenseNeed == rhs.expenseNeed)||((this.expenseNeed!= null)&&this.expenseNeed.equals(rhs.expenseNeed))))&&((this.clientTypeCode == rhs.clientTypeCode)||((this.clientTypeCode!= null)&&this.clientTypeCode.equals(rhs.clientTypeCode))))&&((this.clientStatus == rhs.clientStatus)||((this.clientStatus!= null)&&this.clientStatus.equals(rhs.clientStatus))))&&((this.numRelations == rhs.numRelations)||((this.numRelations!= null)&&this.numRelations.equals(rhs.numRelations))))&&((this.shareInfoWithTradePartnerInd == rhs.shareInfoWithTradePartnerInd)||((this.shareInfoWithTradePartnerInd!= null)&&this.shareInfoWithTradePartnerInd.equals(rhs.shareInfoWithTradePartnerInd))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.invHorizonRangeMin == rhs.invHorizonRangeMin)||((this.invHorizonRangeMin!= null)&&this.invHorizonRangeMin.equals(rhs.invHorizonRangeMin))))&&((this.clientRegion == rhs.clientRegion)||((this.clientRegion!= null)&&this.clientRegion.equals(rhs.clientRegion))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.privacyAffiliateCode == rhs.privacyAffiliateCode)||((this.privacyAffiliateCode!= null)&&this.privacyAffiliateCode.equals(rhs.privacyAffiliateCode))))&&((this.clientKey == rhs.clientKey)||((this.clientKey!= null)&&this.clientKey.equals(rhs.clientKey))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.govtSocialInsEligibilityInd == rhs.govtSocialInsEligibilityInd)||((this.govtSocialInsEligibilityInd!= null)&&this.govtSocialInsEligibilityInd.equals(rhs.govtSocialInsEligibilityInd))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.clientSysKey == rhs.clientSysKey)||((this.clientSysKey!= null)&&this.clientSysKey.equals(rhs.clientSysKey))))&&((this.prefLanguage == rhs.prefLanguage)||((this.prefLanguage!= null)&&this.prefLanguage.equals(rhs.prefLanguage))))&&((this.directorInd == rhs.directorInd)||((this.directorInd!= null)&&this.directorInd.equals(rhs.directorInd))))&&((this.primaryInvObjective == rhs.primaryInvObjective)||((this.primaryInvObjective!= null)&&this.primaryInvObjective.equals(rhs.primaryInvObjective))))&&((this.leadSource == rhs.leadSource)||((this.leadSource!= null)&&this.leadSource.equals(rhs.leadSource))))&&((this.invHorizonPeriod == rhs.invHorizonPeriod)||((this.invHorizonPeriod!= null)&&this.invHorizonPeriod.equals(rhs.invHorizonPeriod))))&&((this.alternateLanguage == rhs.alternateLanguage)||((this.alternateLanguage!= null)&&this.alternateLanguage.equals(rhs.alternateLanguage))))&&((this.alternateLanguageProficiency == rhs.alternateLanguageProficiency)||((this.alternateLanguageProficiency!= null)&&this.alternateLanguageProficiency.equals(rhs.alternateLanguageProficiency))))&&((this.leadType == rhs.leadType)||((this.leadType!= null)&&this.leadType.equals(rhs.leadType))))&&((this.estIncomeAmt == rhs.estIncomeAmt)||((this.estIncomeAmt!= null)&&this.estIncomeAmt.equals(rhs.estIncomeAmt))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.brokerDealerInd == rhs.brokerDealerInd)||((this.brokerDealerInd!= null)&&this.brokerDealerInd.equals(rhs.brokerDealerInd))))&&((this.clientSubRegion == rhs.clientSubRegion)||((this.clientSubRegion!= null)&&this.clientSubRegion.equals(rhs.clientSubRegion))))&&((this.estTaxBracket == rhs.estTaxBracket)||((this.estTaxBracket!= null)&&this.estTaxBracket.equals(rhs.estTaxBracket))))&&((this.investorType == rhs.investorType)||((this.investorType!= null)&&this.investorType.equals(rhs.investorType))))&&((this.invHorizonRangeMax == rhs.invHorizonRangeMax)||((this.invHorizonRangeMax!= null)&&this.invHorizonRangeMax.equals(rhs.invHorizonRangeMax))));
    }

}
