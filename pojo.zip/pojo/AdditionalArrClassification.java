
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AdditionalArrClassificationKey",
    "AdditionalArrClassificationSysKey",
    "ArrType",
    "ArrSubType",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AdditionalArrClassification {

    @JsonProperty("AdditionalArrClassificationKey")
    private AdditionalArrClassificationKey additionalArrClassificationKey;
    @JsonProperty("AdditionalArrClassificationSysKey")
    private List<Object> additionalArrClassificationSysKey = new ArrayList<>();
    @JsonProperty("ArrType")
    private ArrType arrType;
    @JsonProperty("ArrSubType")
    private ArrSubType arrSubType;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AdditionalArrClassificationKey")
    public AdditionalArrClassificationKey getAdditionalArrClassificationKey() {
        return additionalArrClassificationKey;
    }

    @JsonProperty("AdditionalArrClassificationKey")
    public void setAdditionalArrClassificationKey(AdditionalArrClassificationKey additionalArrClassificationKey) {
        this.additionalArrClassificationKey = additionalArrClassificationKey;
    }

    public AdditionalArrClassification withAdditionalArrClassificationKey(AdditionalArrClassificationKey additionalArrClassificationKey) {
        this.additionalArrClassificationKey = additionalArrClassificationKey;
        return this;
    }

    @JsonProperty("AdditionalArrClassificationSysKey")
    public List<Object> getAdditionalArrClassificationSysKey() {
        return additionalArrClassificationSysKey;
    }

    @JsonProperty("AdditionalArrClassificationSysKey")
    public void setAdditionalArrClassificationSysKey(List<Object> additionalArrClassificationSysKey) {
        this.additionalArrClassificationSysKey = additionalArrClassificationSysKey;
    }

    public AdditionalArrClassification withAdditionalArrClassificationSysKey(List<Object> additionalArrClassificationSysKey) {
        this.additionalArrClassificationSysKey = additionalArrClassificationSysKey;
        return this;
    }

    @JsonProperty("ArrType")
    public ArrType getArrType() {
        return arrType;
    }

    @JsonProperty("ArrType")
    public void setArrType(ArrType arrType) {
        this.arrType = arrType;
    }

    public AdditionalArrClassification withArrType(ArrType arrType) {
        this.arrType = arrType;
        return this;
    }

    @JsonProperty("ArrSubType")
    public ArrSubType getArrSubType() {
        return arrSubType;
    }

    @JsonProperty("ArrSubType")
    public void setArrSubType(ArrSubType arrSubType) {
        this.arrSubType = arrSubType;
    }

    public AdditionalArrClassification withArrSubType(ArrSubType arrSubType) {
        this.arrSubType = arrSubType;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AdditionalArrClassification withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AdditionalArrClassification withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AdditionalArrClassification withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AdditionalArrClassification withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AdditionalArrClassification.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("additionalArrClassificationKey");
        sb.append('=');
        sb.append(((this.additionalArrClassificationKey == null)?"<null>":this.additionalArrClassificationKey));
        sb.append(',');
        sb.append("additionalArrClassificationSysKey");
        sb.append('=');
        sb.append(((this.additionalArrClassificationSysKey == null)?"<null>":this.additionalArrClassificationSysKey));
        sb.append(',');
        sb.append("arrType");
        sb.append('=');
        sb.append(((this.arrType == null)?"<null>":this.arrType));
        sb.append(',');
        sb.append("arrSubType");
        sb.append('=');
        sb.append(((this.arrSubType == null)?"<null>":this.arrSubType));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.arrSubType == null)? 0 :this.arrSubType.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.arrType == null)? 0 :this.arrType.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.additionalArrClassificationSysKey == null)? 0 :this.additionalArrClassificationSysKey.hashCode()));
        result = ((result* 31)+((this.additionalArrClassificationKey == null)? 0 :this.additionalArrClassificationKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AdditionalArrClassification) == false) {
            return false;
        }
        AdditionalArrClassification rhs = ((AdditionalArrClassification) other);
        return (((((((((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension)))&&((this.arrSubType == rhs.arrSubType)||((this.arrSubType!= null)&&this.arrSubType.equals(rhs.arrSubType))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.arrType == rhs.arrType)||((this.arrType!= null)&&this.arrType.equals(rhs.arrType))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.additionalArrClassificationSysKey == rhs.additionalArrClassificationSysKey)||((this.additionalArrClassificationSysKey!= null)&&this.additionalArrClassificationSysKey.equals(rhs.additionalArrClassificationSysKey))))&&((this.additionalArrClassificationKey == rhs.additionalArrClassificationKey)||((this.additionalArrClassificationKey!= null)&&this.additionalArrClassificationKey.equals(rhs.additionalArrClassificationKey))));
    }

}
