
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Content",
    "VendorCode",
    "ExtensionCode"
})
@Generated("jsonschema2pojo")
public class Extension {

    @JsonProperty("Content")
    private List<String> content = new ArrayList<>();
    @JsonProperty("VendorCode")
    private String vendorCode;
    @JsonProperty("ExtensionCode")
    private String extensionCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("Content")
    public List<String> getContent() {
        return content;
    }

    @JsonProperty("Content")
    public void setContent(List<String> content) {
        this.content = content;
    }

    public Extension withContent(List<String> content) {
        this.content = content;
        return this;
    }

    @JsonProperty("VendorCode")
    public String getVendorCode() {
        return vendorCode;
    }

    @JsonProperty("VendorCode")
    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    public Extension withVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
        return this;
    }

    @JsonProperty("ExtensionCode")
    public String getExtensionCode() {
        return extensionCode;
    }

    @JsonProperty("ExtensionCode")
    public void setExtensionCode(String extensionCode) {
        this.extensionCode = extensionCode;
    }

    public Extension withExtensionCode(String extensionCode) {
        this.extensionCode = extensionCode;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Extension withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Extension.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("content");
        sb.append('=');
        sb.append(((this.content == null)?"<null>":this.content));
        sb.append(',');
        sb.append("vendorCode");
        sb.append('=');
        sb.append(((this.vendorCode == null)?"<null>":this.vendorCode));
        sb.append(',');
        sb.append("extensionCode");
        sb.append('=');
        sb.append(((this.extensionCode == null)?"<null>":this.extensionCode));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.extensionCode == null)? 0 :this.extensionCode.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.content == null)? 0 :this.content.hashCode()));
        result = ((result* 31)+((this.vendorCode == null)? 0 :this.vendorCode.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Extension) == false) {
            return false;
        }
        Extension rhs = ((Extension) other);
        return (((((this.extensionCode == rhs.extensionCode)||((this.extensionCode!= null)&&this.extensionCode.equals(rhs.extensionCode)))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.content == rhs.content)||((this.content!= null)&&this.content.equals(rhs.content))))&&((this.vendorCode == rhs.vendorCode)||((this.vendorCode!= null)&&this.vendorCode.equals(rhs.vendorCode))));
    }

}
