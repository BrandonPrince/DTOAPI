
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "LimitVariationKey",
    "LimitVariationSysKey",
    "BenefitChangeTrigger",
    "BenefitChangeType",
    "BenefitChangeAge",
    "BenefitChangePct",
    "BenefitChangeDate",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class LimitVariation {

    @JsonProperty("LimitVariationKey")
    private LimitVariationKey limitVariationKey;
    @JsonProperty("LimitVariationSysKey")
    private List<Object> limitVariationSysKey = new ArrayList<>();
    @JsonProperty("BenefitChangeTrigger")
    private BenefitChangeTrigger benefitChangeTrigger;
    @JsonProperty("BenefitChangeType")
    private BenefitChangeType benefitChangeType;
    @JsonProperty("BenefitChangeAge")
    private Integer benefitChangeAge;
    @JsonProperty("BenefitChangePct")
    private Integer benefitChangePct;
    @JsonProperty("BenefitChangeDate")
    private String benefitChangeDate;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("LimitVariationKey")
    public LimitVariationKey getLimitVariationKey() {
        return limitVariationKey;
    }

    @JsonProperty("LimitVariationKey")
    public void setLimitVariationKey(LimitVariationKey limitVariationKey) {
        this.limitVariationKey = limitVariationKey;
    }

    public LimitVariation withLimitVariationKey(LimitVariationKey limitVariationKey) {
        this.limitVariationKey = limitVariationKey;
        return this;
    }

    @JsonProperty("LimitVariationSysKey")
    public List<Object> getLimitVariationSysKey() {
        return limitVariationSysKey;
    }

    @JsonProperty("LimitVariationSysKey")
    public void setLimitVariationSysKey(List<Object> limitVariationSysKey) {
        this.limitVariationSysKey = limitVariationSysKey;
    }

    public LimitVariation withLimitVariationSysKey(List<Object> limitVariationSysKey) {
        this.limitVariationSysKey = limitVariationSysKey;
        return this;
    }

    @JsonProperty("BenefitChangeTrigger")
    public BenefitChangeTrigger getBenefitChangeTrigger() {
        return benefitChangeTrigger;
    }

    @JsonProperty("BenefitChangeTrigger")
    public void setBenefitChangeTrigger(BenefitChangeTrigger benefitChangeTrigger) {
        this.benefitChangeTrigger = benefitChangeTrigger;
    }

    public LimitVariation withBenefitChangeTrigger(BenefitChangeTrigger benefitChangeTrigger) {
        this.benefitChangeTrigger = benefitChangeTrigger;
        return this;
    }

    @JsonProperty("BenefitChangeType")
    public BenefitChangeType getBenefitChangeType() {
        return benefitChangeType;
    }

    @JsonProperty("BenefitChangeType")
    public void setBenefitChangeType(BenefitChangeType benefitChangeType) {
        this.benefitChangeType = benefitChangeType;
    }

    public LimitVariation withBenefitChangeType(BenefitChangeType benefitChangeType) {
        this.benefitChangeType = benefitChangeType;
        return this;
    }

    @JsonProperty("BenefitChangeAge")
    public Integer getBenefitChangeAge() {
        return benefitChangeAge;
    }

    @JsonProperty("BenefitChangeAge")
    public void setBenefitChangeAge(Integer benefitChangeAge) {
        this.benefitChangeAge = benefitChangeAge;
    }

    public LimitVariation withBenefitChangeAge(Integer benefitChangeAge) {
        this.benefitChangeAge = benefitChangeAge;
        return this;
    }

    @JsonProperty("BenefitChangePct")
    public Integer getBenefitChangePct() {
        return benefitChangePct;
    }

    @JsonProperty("BenefitChangePct")
    public void setBenefitChangePct(Integer benefitChangePct) {
        this.benefitChangePct = benefitChangePct;
    }

    public LimitVariation withBenefitChangePct(Integer benefitChangePct) {
        this.benefitChangePct = benefitChangePct;
        return this;
    }

    @JsonProperty("BenefitChangeDate")
    public String getBenefitChangeDate() {
        return benefitChangeDate;
    }

    @JsonProperty("BenefitChangeDate")
    public void setBenefitChangeDate(String benefitChangeDate) {
        this.benefitChangeDate = benefitChangeDate;
    }

    public LimitVariation withBenefitChangeDate(String benefitChangeDate) {
        this.benefitChangeDate = benefitChangeDate;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public LimitVariation withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public LimitVariation withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public LimitVariation withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public LimitVariation withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(LimitVariation.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("limitVariationKey");
        sb.append('=');
        sb.append(((this.limitVariationKey == null)?"<null>":this.limitVariationKey));
        sb.append(',');
        sb.append("limitVariationSysKey");
        sb.append('=');
        sb.append(((this.limitVariationSysKey == null)?"<null>":this.limitVariationSysKey));
        sb.append(',');
        sb.append("benefitChangeTrigger");
        sb.append('=');
        sb.append(((this.benefitChangeTrigger == null)?"<null>":this.benefitChangeTrigger));
        sb.append(',');
        sb.append("benefitChangeType");
        sb.append('=');
        sb.append(((this.benefitChangeType == null)?"<null>":this.benefitChangeType));
        sb.append(',');
        sb.append("benefitChangeAge");
        sb.append('=');
        sb.append(((this.benefitChangeAge == null)?"<null>":this.benefitChangeAge));
        sb.append(',');
        sb.append("benefitChangePct");
        sb.append('=');
        sb.append(((this.benefitChangePct == null)?"<null>":this.benefitChangePct));
        sb.append(',');
        sb.append("benefitChangeDate");
        sb.append('=');
        sb.append(((this.benefitChangeDate == null)?"<null>":this.benefitChangeDate));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.benefitChangeDate == null)? 0 :this.benefitChangeDate.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.benefitChangeTrigger == null)? 0 :this.benefitChangeTrigger.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.benefitChangeAge == null)? 0 :this.benefitChangeAge.hashCode()));
        result = ((result* 31)+((this.limitVariationSysKey == null)? 0 :this.limitVariationSysKey.hashCode()));
        result = ((result* 31)+((this.limitVariationKey == null)? 0 :this.limitVariationKey.hashCode()));
        result = ((result* 31)+((this.benefitChangePct == null)? 0 :this.benefitChangePct.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.benefitChangeType == null)? 0 :this.benefitChangeType.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof LimitVariation) == false) {
            return false;
        }
        LimitVariation rhs = ((LimitVariation) other);
        return ((((((((((((this.benefitChangeDate == rhs.benefitChangeDate)||((this.benefitChangeDate!= null)&&this.benefitChangeDate.equals(rhs.benefitChangeDate)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.benefitChangeTrigger == rhs.benefitChangeTrigger)||((this.benefitChangeTrigger!= null)&&this.benefitChangeTrigger.equals(rhs.benefitChangeTrigger))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.benefitChangeAge == rhs.benefitChangeAge)||((this.benefitChangeAge!= null)&&this.benefitChangeAge.equals(rhs.benefitChangeAge))))&&((this.limitVariationSysKey == rhs.limitVariationSysKey)||((this.limitVariationSysKey!= null)&&this.limitVariationSysKey.equals(rhs.limitVariationSysKey))))&&((this.limitVariationKey == rhs.limitVariationKey)||((this.limitVariationKey!= null)&&this.limitVariationKey.equals(rhs.limitVariationKey))))&&((this.benefitChangePct == rhs.benefitChangePct)||((this.benefitChangePct!= null)&&this.benefitChangePct.equals(rhs.benefitChangePct))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.benefitChangeType == rhs.benefitChangeType)||((this.benefitChangeType!= null)&&this.benefitChangeType.equals(rhs.benefitChangeType))));
    }

}
