
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "VectorType",
    "VectorBaseDate",
    "VectorEndDate",
    "VectorMode",
    "InitialValue",
    "V",
    "TimingOption",
    "Continuous",
    "OLifEExtension",
    "RelatedObjectID"
})
@Generated("jsonschema2pojo")
public class Vector {

    @JsonProperty("VectorType")
    private VectorType vectorType;
    @JsonProperty("VectorBaseDate")
    private String vectorBaseDate;
    @JsonProperty("VectorEndDate")
    private String vectorEndDate;
    @JsonProperty("VectorMode")
    private VectorMode vectorMode;
    @JsonProperty("InitialValue")
    private Integer initialValue;
    @JsonProperty("V")
    private List<Object> v = new ArrayList<>();
    @JsonProperty("TimingOption")
    private TimingOption timingOption;
    @JsonProperty("Continuous")
    private Continuous continuous;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("RelatedObjectID")
    private String relatedObjectID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("VectorType")
    public VectorType getVectorType() {
        return vectorType;
    }

    @JsonProperty("VectorType")
    public void setVectorType(VectorType vectorType) {
        this.vectorType = vectorType;
    }

    public Vector withVectorType(VectorType vectorType) {
        this.vectorType = vectorType;
        return this;
    }

    @JsonProperty("VectorBaseDate")
    public String getVectorBaseDate() {
        return vectorBaseDate;
    }

    @JsonProperty("VectorBaseDate")
    public void setVectorBaseDate(String vectorBaseDate) {
        this.vectorBaseDate = vectorBaseDate;
    }

    public Vector withVectorBaseDate(String vectorBaseDate) {
        this.vectorBaseDate = vectorBaseDate;
        return this;
    }

    @JsonProperty("VectorEndDate")
    public String getVectorEndDate() {
        return vectorEndDate;
    }

    @JsonProperty("VectorEndDate")
    public void setVectorEndDate(String vectorEndDate) {
        this.vectorEndDate = vectorEndDate;
    }

    public Vector withVectorEndDate(String vectorEndDate) {
        this.vectorEndDate = vectorEndDate;
        return this;
    }

    @JsonProperty("VectorMode")
    public VectorMode getVectorMode() {
        return vectorMode;
    }

    @JsonProperty("VectorMode")
    public void setVectorMode(VectorMode vectorMode) {
        this.vectorMode = vectorMode;
    }

    public Vector withVectorMode(VectorMode vectorMode) {
        this.vectorMode = vectorMode;
        return this;
    }

    @JsonProperty("InitialValue")
    public Integer getInitialValue() {
        return initialValue;
    }

    @JsonProperty("InitialValue")
    public void setInitialValue(Integer initialValue) {
        this.initialValue = initialValue;
    }

    public Vector withInitialValue(Integer initialValue) {
        this.initialValue = initialValue;
        return this;
    }

    @JsonProperty("V")
    public List<Object> getV() {
        return v;
    }

    @JsonProperty("V")
    public void setV(List<Object> v) {
        this.v = v;
    }

    public Vector withV(List<Object> v) {
        this.v = v;
        return this;
    }

    @JsonProperty("TimingOption")
    public TimingOption getTimingOption() {
        return timingOption;
    }

    @JsonProperty("TimingOption")
    public void setTimingOption(TimingOption timingOption) {
        this.timingOption = timingOption;
    }

    public Vector withTimingOption(TimingOption timingOption) {
        this.timingOption = timingOption;
        return this;
    }

    @JsonProperty("Continuous")
    public Continuous getContinuous() {
        return continuous;
    }

    @JsonProperty("Continuous")
    public void setContinuous(Continuous continuous) {
        this.continuous = continuous;
    }

    public Vector withContinuous(Continuous continuous) {
        this.continuous = continuous;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Vector withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("RelatedObjectID")
    public String getRelatedObjectID() {
        return relatedObjectID;
    }

    @JsonProperty("RelatedObjectID")
    public void setRelatedObjectID(String relatedObjectID) {
        this.relatedObjectID = relatedObjectID;
    }

    public Vector withRelatedObjectID(String relatedObjectID) {
        this.relatedObjectID = relatedObjectID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Vector withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Vector.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("vectorType");
        sb.append('=');
        sb.append(((this.vectorType == null)?"<null>":this.vectorType));
        sb.append(',');
        sb.append("vectorBaseDate");
        sb.append('=');
        sb.append(((this.vectorBaseDate == null)?"<null>":this.vectorBaseDate));
        sb.append(',');
        sb.append("vectorEndDate");
        sb.append('=');
        sb.append(((this.vectorEndDate == null)?"<null>":this.vectorEndDate));
        sb.append(',');
        sb.append("vectorMode");
        sb.append('=');
        sb.append(((this.vectorMode == null)?"<null>":this.vectorMode));
        sb.append(',');
        sb.append("initialValue");
        sb.append('=');
        sb.append(((this.initialValue == null)?"<null>":this.initialValue));
        sb.append(',');
        sb.append("v");
        sb.append('=');
        sb.append(((this.v == null)?"<null>":this.v));
        sb.append(',');
        sb.append("timingOption");
        sb.append('=');
        sb.append(((this.timingOption == null)?"<null>":this.timingOption));
        sb.append(',');
        sb.append("continuous");
        sb.append('=');
        sb.append(((this.continuous == null)?"<null>":this.continuous));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("relatedObjectID");
        sb.append('=');
        sb.append(((this.relatedObjectID == null)?"<null>":this.relatedObjectID));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.vectorMode == null)? 0 :this.vectorMode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.vectorType == null)? 0 :this.vectorType.hashCode()));
        result = ((result* 31)+((this.relatedObjectID == null)? 0 :this.relatedObjectID.hashCode()));
        result = ((result* 31)+((this.v == null)? 0 :this.v.hashCode()));
        result = ((result* 31)+((this.continuous == null)? 0 :this.continuous.hashCode()));
        result = ((result* 31)+((this.vectorBaseDate == null)? 0 :this.vectorBaseDate.hashCode()));
        result = ((result* 31)+((this.timingOption == null)? 0 :this.timingOption.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.vectorEndDate == null)? 0 :this.vectorEndDate.hashCode()));
        result = ((result* 31)+((this.initialValue == null)? 0 :this.initialValue.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Vector) == false) {
            return false;
        }
        Vector rhs = ((Vector) other);
        return ((((((((((((this.vectorMode == rhs.vectorMode)||((this.vectorMode!= null)&&this.vectorMode.equals(rhs.vectorMode)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.vectorType == rhs.vectorType)||((this.vectorType!= null)&&this.vectorType.equals(rhs.vectorType))))&&((this.relatedObjectID == rhs.relatedObjectID)||((this.relatedObjectID!= null)&&this.relatedObjectID.equals(rhs.relatedObjectID))))&&((this.v == rhs.v)||((this.v!= null)&&this.v.equals(rhs.v))))&&((this.continuous == rhs.continuous)||((this.continuous!= null)&&this.continuous.equals(rhs.continuous))))&&((this.vectorBaseDate == rhs.vectorBaseDate)||((this.vectorBaseDate!= null)&&this.vectorBaseDate.equals(rhs.vectorBaseDate))))&&((this.timingOption == rhs.timingOption)||((this.timingOption!= null)&&this.timingOption.equals(rhs.timingOption))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.vectorEndDate == rhs.vectorEndDate)||((this.vectorEndDate!= null)&&this.vectorEndDate.equals(rhs.vectorEndDate))))&&((this.initialValue == rhs.initialValue)||((this.initialValue!= null)&&this.initialValue.equals(rhs.initialValue))));
    }

}
