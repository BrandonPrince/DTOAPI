
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "LoanIntMethod"
})
@Generated("jsonschema2pojo")
public class LoanIntMethodCC {

    @JsonProperty("LoanIntMethod")
    private List<LoanIntMethod> loanIntMethod = new ArrayList<>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("LoanIntMethod")
    public List<LoanIntMethod> getLoanIntMethod() {
        return loanIntMethod;
    }

    @JsonProperty("LoanIntMethod")
    public void setLoanIntMethod(List<LoanIntMethod> loanIntMethod) {
        this.loanIntMethod = loanIntMethod;
    }

    public LoanIntMethodCC withLoanIntMethod(List<LoanIntMethod> loanIntMethod) {
        this.loanIntMethod = loanIntMethod;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public LoanIntMethodCC withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(LoanIntMethodCC.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("loanIntMethod");
        sb.append('=');
        sb.append(((this.loanIntMethod == null)?"<null>":this.loanIntMethod));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.loanIntMethod == null)? 0 :this.loanIntMethod.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof LoanIntMethodCC) == false) {
            return false;
        }
        LoanIntMethodCC rhs = ((LoanIntMethodCC) other);
        return (((this.loanIntMethod == rhs.loanIntMethod)||((this.loanIntMethod!= null)&&this.loanIntMethod.equals(rhs.loanIntMethod)))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
