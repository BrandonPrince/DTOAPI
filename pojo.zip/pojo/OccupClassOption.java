
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "OccupClassOptionKey",
    "OccupClassOptionSysKey",
    "OccupClass",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class OccupClassOption {

    @JsonProperty("OccupClassOptionKey")
    private OccupClassOptionKey occupClassOptionKey;
    @JsonProperty("OccupClassOptionSysKey")
    private List<Object> occupClassOptionSysKey = new ArrayList<>();
    @JsonProperty("OccupClass")
    private OccupClass occupClass;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("OccupClassOptionKey")
    public OccupClassOptionKey getOccupClassOptionKey() {
        return occupClassOptionKey;
    }

    @JsonProperty("OccupClassOptionKey")
    public void setOccupClassOptionKey(OccupClassOptionKey occupClassOptionKey) {
        this.occupClassOptionKey = occupClassOptionKey;
    }

    public OccupClassOption withOccupClassOptionKey(OccupClassOptionKey occupClassOptionKey) {
        this.occupClassOptionKey = occupClassOptionKey;
        return this;
    }

    @JsonProperty("OccupClassOptionSysKey")
    public List<Object> getOccupClassOptionSysKey() {
        return occupClassOptionSysKey;
    }

    @JsonProperty("OccupClassOptionSysKey")
    public void setOccupClassOptionSysKey(List<Object> occupClassOptionSysKey) {
        this.occupClassOptionSysKey = occupClassOptionSysKey;
    }

    public OccupClassOption withOccupClassOptionSysKey(List<Object> occupClassOptionSysKey) {
        this.occupClassOptionSysKey = occupClassOptionSysKey;
        return this;
    }

    @JsonProperty("OccupClass")
    public OccupClass getOccupClass() {
        return occupClass;
    }

    @JsonProperty("OccupClass")
    public void setOccupClass(OccupClass occupClass) {
        this.occupClass = occupClass;
    }

    public OccupClassOption withOccupClass(OccupClass occupClass) {
        this.occupClass = occupClass;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public OccupClassOption withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public OccupClassOption withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public OccupClassOption withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public OccupClassOption withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(OccupClassOption.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("occupClassOptionKey");
        sb.append('=');
        sb.append(((this.occupClassOptionKey == null)?"<null>":this.occupClassOptionKey));
        sb.append(',');
        sb.append("occupClassOptionSysKey");
        sb.append('=');
        sb.append(((this.occupClassOptionSysKey == null)?"<null>":this.occupClassOptionSysKey));
        sb.append(',');
        sb.append("occupClass");
        sb.append('=');
        sb.append(((this.occupClass == null)?"<null>":this.occupClass));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.occupClass == null)? 0 :this.occupClass.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.occupClassOptionSysKey == null)? 0 :this.occupClassOptionSysKey.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.occupClassOptionKey == null)? 0 :this.occupClassOptionKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof OccupClassOption) == false) {
            return false;
        }
        OccupClassOption rhs = ((OccupClassOption) other);
        return ((((((((this.occupClass == rhs.occupClass)||((this.occupClass!= null)&&this.occupClass.equals(rhs.occupClass)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.occupClassOptionSysKey == rhs.occupClassOptionSysKey)||((this.occupClassOptionSysKey!= null)&&this.occupClassOptionSysKey.equals(rhs.occupClassOptionSysKey))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.occupClassOptionKey == rhs.occupClassOptionKey)||((this.occupClassOptionKey!= null)&&this.occupClassOptionKey.equals(rhs.occupClassOptionKey))));
    }

}
