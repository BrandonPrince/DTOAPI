
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "FeatureRequisiteKey",
    "FeatureRequisiteSysKey",
    "FeatureCode",
    "ProductCode",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class FeatureRequisite {

    @JsonProperty("FeatureRequisiteKey")
    private FeatureRequisiteKey featureRequisiteKey;
    @JsonProperty("FeatureRequisiteSysKey")
    private List<Object> featureRequisiteSysKey = new ArrayList<>();
    @JsonProperty("FeatureCode")
    private String featureCode;
    @JsonProperty("ProductCode")
    private String productCode;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("FeatureRequisiteKey")
    public FeatureRequisiteKey getFeatureRequisiteKey() {
        return featureRequisiteKey;
    }

    @JsonProperty("FeatureRequisiteKey")
    public void setFeatureRequisiteKey(FeatureRequisiteKey featureRequisiteKey) {
        this.featureRequisiteKey = featureRequisiteKey;
    }

    public FeatureRequisite withFeatureRequisiteKey(FeatureRequisiteKey featureRequisiteKey) {
        this.featureRequisiteKey = featureRequisiteKey;
        return this;
    }

    @JsonProperty("FeatureRequisiteSysKey")
    public List<Object> getFeatureRequisiteSysKey() {
        return featureRequisiteSysKey;
    }

    @JsonProperty("FeatureRequisiteSysKey")
    public void setFeatureRequisiteSysKey(List<Object> featureRequisiteSysKey) {
        this.featureRequisiteSysKey = featureRequisiteSysKey;
    }

    public FeatureRequisite withFeatureRequisiteSysKey(List<Object> featureRequisiteSysKey) {
        this.featureRequisiteSysKey = featureRequisiteSysKey;
        return this;
    }

    @JsonProperty("FeatureCode")
    public String getFeatureCode() {
        return featureCode;
    }

    @JsonProperty("FeatureCode")
    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    public FeatureRequisite withFeatureCode(String featureCode) {
        this.featureCode = featureCode;
        return this;
    }

    @JsonProperty("ProductCode")
    public String getProductCode() {
        return productCode;
    }

    @JsonProperty("ProductCode")
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public FeatureRequisite withProductCode(String productCode) {
        this.productCode = productCode;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public FeatureRequisite withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public FeatureRequisite withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public FeatureRequisite withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public FeatureRequisite withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(FeatureRequisite.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("featureRequisiteKey");
        sb.append('=');
        sb.append(((this.featureRequisiteKey == null)?"<null>":this.featureRequisiteKey));
        sb.append(',');
        sb.append("featureRequisiteSysKey");
        sb.append('=');
        sb.append(((this.featureRequisiteSysKey == null)?"<null>":this.featureRequisiteSysKey));
        sb.append(',');
        sb.append("featureCode");
        sb.append('=');
        sb.append(((this.featureCode == null)?"<null>":this.featureCode));
        sb.append(',');
        sb.append("productCode");
        sb.append('=');
        sb.append(((this.productCode == null)?"<null>":this.productCode));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.featureRequisiteKey == null)? 0 :this.featureRequisiteKey.hashCode()));
        result = ((result* 31)+((this.featureCode == null)? 0 :this.featureCode.hashCode()));
        result = ((result* 31)+((this.productCode == null)? 0 :this.productCode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.featureRequisiteSysKey == null)? 0 :this.featureRequisiteSysKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof FeatureRequisite) == false) {
            return false;
        }
        FeatureRequisite rhs = ((FeatureRequisite) other);
        return (((((((((this.featureRequisiteKey == rhs.featureRequisiteKey)||((this.featureRequisiteKey!= null)&&this.featureRequisiteKey.equals(rhs.featureRequisiteKey)))&&((this.featureCode == rhs.featureCode)||((this.featureCode!= null)&&this.featureCode.equals(rhs.featureCode))))&&((this.productCode == rhs.productCode)||((this.productCode!= null)&&this.productCode.equals(rhs.productCode))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.featureRequisiteSysKey == rhs.featureRequisiteSysKey)||((this.featureRequisiteSysKey!= null)&&this.featureRequisiteSysKey.equals(rhs.featureRequisiteSysKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
