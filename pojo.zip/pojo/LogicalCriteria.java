
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "LogicalCriteriaKey",
    "LogicalCriteriaSysKey",
    "Operation",
    "EnumeratedStringValue",
    "EnumeratedTypeCodeValue",
    "EnumeratedValue",
    "KeyDef",
    "AxisDef",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class LogicalCriteria {

    @JsonProperty("LogicalCriteriaKey")
    private LogicalCriteriaKey logicalCriteriaKey;
    @JsonProperty("LogicalCriteriaSysKey")
    private List<Object> logicalCriteriaSysKey = new ArrayList<>();
    @JsonProperty("Operation")
    private Operation operation;
    @JsonProperty("EnumeratedStringValue")
    private String enumeratedStringValue;
    @JsonProperty("EnumeratedTypeCodeValue")
    private EnumeratedTypeCodeValue enumeratedTypeCodeValue;
    @JsonProperty("EnumeratedValue")
    private EnumeratedValue enumeratedValue;
    @JsonProperty("KeyDef")
    private KeyDef keyDef;
    @JsonProperty("AxisDef")
    private List<Object> axisDef = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("LogicalCriteriaKey")
    public LogicalCriteriaKey getLogicalCriteriaKey() {
        return logicalCriteriaKey;
    }

    @JsonProperty("LogicalCriteriaKey")
    public void setLogicalCriteriaKey(LogicalCriteriaKey logicalCriteriaKey) {
        this.logicalCriteriaKey = logicalCriteriaKey;
    }

    public LogicalCriteria withLogicalCriteriaKey(LogicalCriteriaKey logicalCriteriaKey) {
        this.logicalCriteriaKey = logicalCriteriaKey;
        return this;
    }

    @JsonProperty("LogicalCriteriaSysKey")
    public List<Object> getLogicalCriteriaSysKey() {
        return logicalCriteriaSysKey;
    }

    @JsonProperty("LogicalCriteriaSysKey")
    public void setLogicalCriteriaSysKey(List<Object> logicalCriteriaSysKey) {
        this.logicalCriteriaSysKey = logicalCriteriaSysKey;
    }

    public LogicalCriteria withLogicalCriteriaSysKey(List<Object> logicalCriteriaSysKey) {
        this.logicalCriteriaSysKey = logicalCriteriaSysKey;
        return this;
    }

    @JsonProperty("Operation")
    public Operation getOperation() {
        return operation;
    }

    @JsonProperty("Operation")
    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public LogicalCriteria withOperation(Operation operation) {
        this.operation = operation;
        return this;
    }

    @JsonProperty("EnumeratedStringValue")
    public String getEnumeratedStringValue() {
        return enumeratedStringValue;
    }

    @JsonProperty("EnumeratedStringValue")
    public void setEnumeratedStringValue(String enumeratedStringValue) {
        this.enumeratedStringValue = enumeratedStringValue;
    }

    public LogicalCriteria withEnumeratedStringValue(String enumeratedStringValue) {
        this.enumeratedStringValue = enumeratedStringValue;
        return this;
    }

    @JsonProperty("EnumeratedTypeCodeValue")
    public EnumeratedTypeCodeValue getEnumeratedTypeCodeValue() {
        return enumeratedTypeCodeValue;
    }

    @JsonProperty("EnumeratedTypeCodeValue")
    public void setEnumeratedTypeCodeValue(EnumeratedTypeCodeValue enumeratedTypeCodeValue) {
        this.enumeratedTypeCodeValue = enumeratedTypeCodeValue;
    }

    public LogicalCriteria withEnumeratedTypeCodeValue(EnumeratedTypeCodeValue enumeratedTypeCodeValue) {
        this.enumeratedTypeCodeValue = enumeratedTypeCodeValue;
        return this;
    }

    @JsonProperty("EnumeratedValue")
    public EnumeratedValue getEnumeratedValue() {
        return enumeratedValue;
    }

    @JsonProperty("EnumeratedValue")
    public void setEnumeratedValue(EnumeratedValue enumeratedValue) {
        this.enumeratedValue = enumeratedValue;
    }

    public LogicalCriteria withEnumeratedValue(EnumeratedValue enumeratedValue) {
        this.enumeratedValue = enumeratedValue;
        return this;
    }

    @JsonProperty("KeyDef")
    public KeyDef getKeyDef() {
        return keyDef;
    }

    @JsonProperty("KeyDef")
    public void setKeyDef(KeyDef keyDef) {
        this.keyDef = keyDef;
    }

    public LogicalCriteria withKeyDef(KeyDef keyDef) {
        this.keyDef = keyDef;
        return this;
    }

    @JsonProperty("AxisDef")
    public List<Object> getAxisDef() {
        return axisDef;
    }

    @JsonProperty("AxisDef")
    public void setAxisDef(List<Object> axisDef) {
        this.axisDef = axisDef;
    }

    public LogicalCriteria withAxisDef(List<Object> axisDef) {
        this.axisDef = axisDef;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public LogicalCriteria withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public LogicalCriteria withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public LogicalCriteria withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public LogicalCriteria withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(LogicalCriteria.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("logicalCriteriaKey");
        sb.append('=');
        sb.append(((this.logicalCriteriaKey == null)?"<null>":this.logicalCriteriaKey));
        sb.append(',');
        sb.append("logicalCriteriaSysKey");
        sb.append('=');
        sb.append(((this.logicalCriteriaSysKey == null)?"<null>":this.logicalCriteriaSysKey));
        sb.append(',');
        sb.append("operation");
        sb.append('=');
        sb.append(((this.operation == null)?"<null>":this.operation));
        sb.append(',');
        sb.append("enumeratedStringValue");
        sb.append('=');
        sb.append(((this.enumeratedStringValue == null)?"<null>":this.enumeratedStringValue));
        sb.append(',');
        sb.append("enumeratedTypeCodeValue");
        sb.append('=');
        sb.append(((this.enumeratedTypeCodeValue == null)?"<null>":this.enumeratedTypeCodeValue));
        sb.append(',');
        sb.append("enumeratedValue");
        sb.append('=');
        sb.append(((this.enumeratedValue == null)?"<null>":this.enumeratedValue));
        sb.append(',');
        sb.append("keyDef");
        sb.append('=');
        sb.append(((this.keyDef == null)?"<null>":this.keyDef));
        sb.append(',');
        sb.append("axisDef");
        sb.append('=');
        sb.append(((this.axisDef == null)?"<null>":this.axisDef));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.enumeratedTypeCodeValue == null)? 0 :this.enumeratedTypeCodeValue.hashCode()));
        result = ((result* 31)+((this.enumeratedStringValue == null)? 0 :this.enumeratedStringValue.hashCode()));
        result = ((result* 31)+((this.logicalCriteriaKey == null)? 0 :this.logicalCriteriaKey.hashCode()));
        result = ((result* 31)+((this.logicalCriteriaSysKey == null)? 0 :this.logicalCriteriaSysKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.enumeratedValue == null)? 0 :this.enumeratedValue.hashCode()));
        result = ((result* 31)+((this.axisDef == null)? 0 :this.axisDef.hashCode()));
        result = ((result* 31)+((this.keyDef == null)? 0 :this.keyDef.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.operation == null)? 0 :this.operation.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof LogicalCriteria) == false) {
            return false;
        }
        LogicalCriteria rhs = ((LogicalCriteria) other);
        return (((((((((((((this.enumeratedTypeCodeValue == rhs.enumeratedTypeCodeValue)||((this.enumeratedTypeCodeValue!= null)&&this.enumeratedTypeCodeValue.equals(rhs.enumeratedTypeCodeValue)))&&((this.enumeratedStringValue == rhs.enumeratedStringValue)||((this.enumeratedStringValue!= null)&&this.enumeratedStringValue.equals(rhs.enumeratedStringValue))))&&((this.logicalCriteriaKey == rhs.logicalCriteriaKey)||((this.logicalCriteriaKey!= null)&&this.logicalCriteriaKey.equals(rhs.logicalCriteriaKey))))&&((this.logicalCriteriaSysKey == rhs.logicalCriteriaSysKey)||((this.logicalCriteriaSysKey!= null)&&this.logicalCriteriaSysKey.equals(rhs.logicalCriteriaSysKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.enumeratedValue == rhs.enumeratedValue)||((this.enumeratedValue!= null)&&this.enumeratedValue.equals(rhs.enumeratedValue))))&&((this.axisDef == rhs.axisDef)||((this.axisDef!= null)&&this.axisDef.equals(rhs.axisDef))))&&((this.keyDef == rhs.keyDef)||((this.keyDef!= null)&&this.keyDef.equals(rhs.keyDef))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.operation == rhs.operation)||((this.operation!= null)&&this.operation.equals(rhs.operation))));
    }

}
