
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "LifeUSAProductKey",
    "LifeUSAProductSysKey",
    "MECIssueType",
    "IRSPremCalcMethod",
    "DefLifeInsMethodCC",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class LifeUSAProduct {

    @JsonProperty("LifeUSAProductKey")
    private LifeUSAProductKey lifeUSAProductKey;
    @JsonProperty("LifeUSAProductSysKey")
    private List<Object> lifeUSAProductSysKey = new ArrayList<>();
    @JsonProperty("MECIssueType")
    private MECIssueType mECIssueType;
    @JsonProperty("IRSPremCalcMethod")
    private List<Object> iRSPremCalcMethod = new ArrayList<>();
    @JsonProperty("DefLifeInsMethodCC")
    private DefLifeInsMethodCC defLifeInsMethodCC;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("LifeUSAProductKey")
    public LifeUSAProductKey getLifeUSAProductKey() {
        return lifeUSAProductKey;
    }

    @JsonProperty("LifeUSAProductKey")
    public void setLifeUSAProductKey(LifeUSAProductKey lifeUSAProductKey) {
        this.lifeUSAProductKey = lifeUSAProductKey;
    }

    public LifeUSAProduct withLifeUSAProductKey(LifeUSAProductKey lifeUSAProductKey) {
        this.lifeUSAProductKey = lifeUSAProductKey;
        return this;
    }

    @JsonProperty("LifeUSAProductSysKey")
    public List<Object> getLifeUSAProductSysKey() {
        return lifeUSAProductSysKey;
    }

    @JsonProperty("LifeUSAProductSysKey")
    public void setLifeUSAProductSysKey(List<Object> lifeUSAProductSysKey) {
        this.lifeUSAProductSysKey = lifeUSAProductSysKey;
    }

    public LifeUSAProduct withLifeUSAProductSysKey(List<Object> lifeUSAProductSysKey) {
        this.lifeUSAProductSysKey = lifeUSAProductSysKey;
        return this;
    }

    @JsonProperty("MECIssueType")
    public MECIssueType getMECIssueType() {
        return mECIssueType;
    }

    @JsonProperty("MECIssueType")
    public void setMECIssueType(MECIssueType mECIssueType) {
        this.mECIssueType = mECIssueType;
    }

    public LifeUSAProduct withMECIssueType(MECIssueType mECIssueType) {
        this.mECIssueType = mECIssueType;
        return this;
    }

    @JsonProperty("IRSPremCalcMethod")
    public List<Object> getIRSPremCalcMethod() {
        return iRSPremCalcMethod;
    }

    @JsonProperty("IRSPremCalcMethod")
    public void setIRSPremCalcMethod(List<Object> iRSPremCalcMethod) {
        this.iRSPremCalcMethod = iRSPremCalcMethod;
    }

    public LifeUSAProduct withIRSPremCalcMethod(List<Object> iRSPremCalcMethod) {
        this.iRSPremCalcMethod = iRSPremCalcMethod;
        return this;
    }

    @JsonProperty("DefLifeInsMethodCC")
    public DefLifeInsMethodCC getDefLifeInsMethodCC() {
        return defLifeInsMethodCC;
    }

    @JsonProperty("DefLifeInsMethodCC")
    public void setDefLifeInsMethodCC(DefLifeInsMethodCC defLifeInsMethodCC) {
        this.defLifeInsMethodCC = defLifeInsMethodCC;
    }

    public LifeUSAProduct withDefLifeInsMethodCC(DefLifeInsMethodCC defLifeInsMethodCC) {
        this.defLifeInsMethodCC = defLifeInsMethodCC;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public LifeUSAProduct withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public LifeUSAProduct withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public LifeUSAProduct withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public LifeUSAProduct withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(LifeUSAProduct.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("lifeUSAProductKey");
        sb.append('=');
        sb.append(((this.lifeUSAProductKey == null)?"<null>":this.lifeUSAProductKey));
        sb.append(',');
        sb.append("lifeUSAProductSysKey");
        sb.append('=');
        sb.append(((this.lifeUSAProductSysKey == null)?"<null>":this.lifeUSAProductSysKey));
        sb.append(',');
        sb.append("mECIssueType");
        sb.append('=');
        sb.append(((this.mECIssueType == null)?"<null>":this.mECIssueType));
        sb.append(',');
        sb.append("iRSPremCalcMethod");
        sb.append('=');
        sb.append(((this.iRSPremCalcMethod == null)?"<null>":this.iRSPremCalcMethod));
        sb.append(',');
        sb.append("defLifeInsMethodCC");
        sb.append('=');
        sb.append(((this.defLifeInsMethodCC == null)?"<null>":this.defLifeInsMethodCC));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.lifeUSAProductKey == null)? 0 :this.lifeUSAProductKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.defLifeInsMethodCC == null)? 0 :this.defLifeInsMethodCC.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.iRSPremCalcMethod == null)? 0 :this.iRSPremCalcMethod.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.mECIssueType == null)? 0 :this.mECIssueType.hashCode()));
        result = ((result* 31)+((this.lifeUSAProductSysKey == null)? 0 :this.lifeUSAProductSysKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof LifeUSAProduct) == false) {
            return false;
        }
        LifeUSAProduct rhs = ((LifeUSAProduct) other);
        return ((((((((((this.lifeUSAProductKey == rhs.lifeUSAProductKey)||((this.lifeUSAProductKey!= null)&&this.lifeUSAProductKey.equals(rhs.lifeUSAProductKey)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.defLifeInsMethodCC == rhs.defLifeInsMethodCC)||((this.defLifeInsMethodCC!= null)&&this.defLifeInsMethodCC.equals(rhs.defLifeInsMethodCC))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.iRSPremCalcMethod == rhs.iRSPremCalcMethod)||((this.iRSPremCalcMethod!= null)&&this.iRSPremCalcMethod.equals(rhs.iRSPremCalcMethod))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.mECIssueType == rhs.mECIssueType)||((this.mECIssueType!= null)&&this.mECIssueType.equals(rhs.mECIssueType))))&&((this.lifeUSAProductSysKey == rhs.lifeUSAProductSysKey)||((this.lifeUSAProductSysKey!= null)&&this.lifeUSAProductSysKey.equals(rhs.lifeUSAProductSysKey))));
    }

}
