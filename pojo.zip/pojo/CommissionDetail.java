
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CommissionDetailKey",
    "CommissionDetailSysKey",
    "CarrierCode",
    "CommissionType",
    "CommissionTransactionType",
    "TransactionDate",
    "CommissionRate",
    "SplitPercent",
    "PaymentBasisAmt",
    "OriginatingBasisAmt",
    "OriginatingBasisType",
    "PaymentBasisReason",
    "PaymentRateCategory",
    "Description",
    "CommissionSchedule",
    "PaidAmt",
    "EarnedAmt",
    "PolNumber",
    "ProductCode",
    "EffDate",
    "CommissionEarnedDate",
    "PaidToDate",
    "CoverageAmt",
    "WritingProducerID",
    "PaidProducerID",
    "DebtRecaptureProducerID",
    "ActualObjectType",
    "ActualProductCode",
    "ActualEffDate",
    "ActualPlanName",
    "TaxableInd",
    "CommissionEvent",
    "PaymentMode",
    "ChargeBackRate",
    "ClientName",
    "AdvancedInd",
    "SettlementAmt",
    "SettlementDate",
    "FundCarrierCode",
    "FundProductCode",
    "TrailFrequency",
    "PayType",
    "PolicyStatus",
    "OwnerName",
    "CusipNum",
    "CovNumber",
    "CarrierAdminSystem",
    "CommissionStatus",
    "SponsoringPlanName",
    "SponsoringPlanCode",
    "SponsorName",
    "OLifEExtension",
    "id",
    "HoldingID",
    "WritingProducerPartyID",
    "PaidProducerPartyID",
    "DataRep",
    "ActualObjectID",
    "CoverageID",
    "OwnerPartyID",
    "PaidProducerAgreementID",
    "WritingProducerAgreementID",
    "SettlementVendorID"
})
@Generated("jsonschema2pojo")
public class CommissionDetail {

    @JsonProperty("CommissionDetailKey")
    private CommissionDetailKey commissionDetailKey;
    @JsonProperty("CommissionDetailSysKey")
    private List<Object> commissionDetailSysKey = new ArrayList<>();
    @JsonProperty("CarrierCode")
    private String carrierCode;
    @JsonProperty("CommissionType")
    private CommissionType commissionType;
    @JsonProperty("CommissionTransactionType")
    private CommissionTransactionType commissionTransactionType;
    @JsonProperty("TransactionDate")
    private String transactionDate;
    @JsonProperty("CommissionRate")
    private Integer commissionRate;
    @JsonProperty("SplitPercent")
    private Integer splitPercent;
    @JsonProperty("PaymentBasisAmt")
    private Integer paymentBasisAmt;
    @JsonProperty("OriginatingBasisAmt")
    private Integer originatingBasisAmt;
    @JsonProperty("OriginatingBasisType")
    private OriginatingBasisType originatingBasisType;
    @JsonProperty("PaymentBasisReason")
    private PaymentBasisReason paymentBasisReason;
    @JsonProperty("PaymentRateCategory")
    private PaymentRateCategory paymentRateCategory;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("CommissionSchedule")
    private String commissionSchedule;
    @JsonProperty("PaidAmt")
    private Integer paidAmt;
    @JsonProperty("EarnedAmt")
    private Integer earnedAmt;
    @JsonProperty("PolNumber")
    private String polNumber;
    @JsonProperty("ProductCode")
    private String productCode;
    @JsonProperty("EffDate")
    private String effDate;
    @JsonProperty("CommissionEarnedDate")
    private String commissionEarnedDate;
    @JsonProperty("PaidToDate")
    private String paidToDate;
    @JsonProperty("CoverageAmt")
    private Integer coverageAmt;
    @JsonProperty("WritingProducerID")
    private String writingProducerID;
    @JsonProperty("PaidProducerID")
    private String paidProducerID;
    @JsonProperty("DebtRecaptureProducerID")
    private String debtRecaptureProducerID;
    @JsonProperty("ActualObjectType")
    private ActualObjectType actualObjectType;
    @JsonProperty("ActualProductCode")
    private String actualProductCode;
    @JsonProperty("ActualEffDate")
    private String actualEffDate;
    @JsonProperty("ActualPlanName")
    private String actualPlanName;
    @JsonProperty("TaxableInd")
    private TaxableInd taxableInd;
    @JsonProperty("CommissionEvent")
    private CommissionEvent commissionEvent;
    @JsonProperty("PaymentMode")
    private PaymentMode paymentMode;
    @JsonProperty("ChargeBackRate")
    private Integer chargeBackRate;
    @JsonProperty("ClientName")
    private String clientName;
    @JsonProperty("AdvancedInd")
    private AdvancedInd advancedInd;
    @JsonProperty("SettlementAmt")
    private Integer settlementAmt;
    @JsonProperty("SettlementDate")
    private String settlementDate;
    @JsonProperty("FundCarrierCode")
    private String fundCarrierCode;
    @JsonProperty("FundProductCode")
    private String fundProductCode;
    @JsonProperty("TrailFrequency")
    private TrailFrequency trailFrequency;
    @JsonProperty("PayType")
    private PayType payType;
    @JsonProperty("PolicyStatus")
    private PolicyStatus policyStatus;
    @JsonProperty("OwnerName")
    private String ownerName;
    @JsonProperty("CusipNum")
    private String cusipNum;
    @JsonProperty("CovNumber")
    private String covNumber;
    @JsonProperty("CarrierAdminSystem")
    private String carrierAdminSystem;
    @JsonProperty("CommissionStatus")
    private CommissionStatus commissionStatus;
    @JsonProperty("SponsoringPlanName")
    private String sponsoringPlanName;
    @JsonProperty("SponsoringPlanCode")
    private String sponsoringPlanCode;
    @JsonProperty("SponsorName")
    private String sponsorName;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("HoldingID")
    private String holdingID;
    @JsonProperty("WritingProducerPartyID")
    private String writingProducerPartyID;
    @JsonProperty("PaidProducerPartyID")
    private String paidProducerPartyID;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonProperty("ActualObjectID")
    private String actualObjectID;
    @JsonProperty("CoverageID")
    private String coverageID;
    @JsonProperty("OwnerPartyID")
    private String ownerPartyID;
    @JsonProperty("PaidProducerAgreementID")
    private String paidProducerAgreementID;
    @JsonProperty("WritingProducerAgreementID")
    private String writingProducerAgreementID;
    @JsonProperty("SettlementVendorID")
    private String settlementVendorID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("CommissionDetailKey")
    public CommissionDetailKey getCommissionDetailKey() {
        return commissionDetailKey;
    }

    @JsonProperty("CommissionDetailKey")
    public void setCommissionDetailKey(CommissionDetailKey commissionDetailKey) {
        this.commissionDetailKey = commissionDetailKey;
    }

    public CommissionDetail withCommissionDetailKey(CommissionDetailKey commissionDetailKey) {
        this.commissionDetailKey = commissionDetailKey;
        return this;
    }

    @JsonProperty("CommissionDetailSysKey")
    public List<Object> getCommissionDetailSysKey() {
        return commissionDetailSysKey;
    }

    @JsonProperty("CommissionDetailSysKey")
    public void setCommissionDetailSysKey(List<Object> commissionDetailSysKey) {
        this.commissionDetailSysKey = commissionDetailSysKey;
    }

    public CommissionDetail withCommissionDetailSysKey(List<Object> commissionDetailSysKey) {
        this.commissionDetailSysKey = commissionDetailSysKey;
        return this;
    }

    @JsonProperty("CarrierCode")
    public String getCarrierCode() {
        return carrierCode;
    }

    @JsonProperty("CarrierCode")
    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    public CommissionDetail withCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
        return this;
    }

    @JsonProperty("CommissionType")
    public CommissionType getCommissionType() {
        return commissionType;
    }

    @JsonProperty("CommissionType")
    public void setCommissionType(CommissionType commissionType) {
        this.commissionType = commissionType;
    }

    public CommissionDetail withCommissionType(CommissionType commissionType) {
        this.commissionType = commissionType;
        return this;
    }

    @JsonProperty("CommissionTransactionType")
    public CommissionTransactionType getCommissionTransactionType() {
        return commissionTransactionType;
    }

    @JsonProperty("CommissionTransactionType")
    public void setCommissionTransactionType(CommissionTransactionType commissionTransactionType) {
        this.commissionTransactionType = commissionTransactionType;
    }

    public CommissionDetail withCommissionTransactionType(CommissionTransactionType commissionTransactionType) {
        this.commissionTransactionType = commissionTransactionType;
        return this;
    }

    @JsonProperty("TransactionDate")
    public String getTransactionDate() {
        return transactionDate;
    }

    @JsonProperty("TransactionDate")
    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public CommissionDetail withTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
        return this;
    }

    @JsonProperty("CommissionRate")
    public Integer getCommissionRate() {
        return commissionRate;
    }

    @JsonProperty("CommissionRate")
    public void setCommissionRate(Integer commissionRate) {
        this.commissionRate = commissionRate;
    }

    public CommissionDetail withCommissionRate(Integer commissionRate) {
        this.commissionRate = commissionRate;
        return this;
    }

    @JsonProperty("SplitPercent")
    public Integer getSplitPercent() {
        return splitPercent;
    }

    @JsonProperty("SplitPercent")
    public void setSplitPercent(Integer splitPercent) {
        this.splitPercent = splitPercent;
    }

    public CommissionDetail withSplitPercent(Integer splitPercent) {
        this.splitPercent = splitPercent;
        return this;
    }

    @JsonProperty("PaymentBasisAmt")
    public Integer getPaymentBasisAmt() {
        return paymentBasisAmt;
    }

    @JsonProperty("PaymentBasisAmt")
    public void setPaymentBasisAmt(Integer paymentBasisAmt) {
        this.paymentBasisAmt = paymentBasisAmt;
    }

    public CommissionDetail withPaymentBasisAmt(Integer paymentBasisAmt) {
        this.paymentBasisAmt = paymentBasisAmt;
        return this;
    }

    @JsonProperty("OriginatingBasisAmt")
    public Integer getOriginatingBasisAmt() {
        return originatingBasisAmt;
    }

    @JsonProperty("OriginatingBasisAmt")
    public void setOriginatingBasisAmt(Integer originatingBasisAmt) {
        this.originatingBasisAmt = originatingBasisAmt;
    }

    public CommissionDetail withOriginatingBasisAmt(Integer originatingBasisAmt) {
        this.originatingBasisAmt = originatingBasisAmt;
        return this;
    }

    @JsonProperty("OriginatingBasisType")
    public OriginatingBasisType getOriginatingBasisType() {
        return originatingBasisType;
    }

    @JsonProperty("OriginatingBasisType")
    public void setOriginatingBasisType(OriginatingBasisType originatingBasisType) {
        this.originatingBasisType = originatingBasisType;
    }

    public CommissionDetail withOriginatingBasisType(OriginatingBasisType originatingBasisType) {
        this.originatingBasisType = originatingBasisType;
        return this;
    }

    @JsonProperty("PaymentBasisReason")
    public PaymentBasisReason getPaymentBasisReason() {
        return paymentBasisReason;
    }

    @JsonProperty("PaymentBasisReason")
    public void setPaymentBasisReason(PaymentBasisReason paymentBasisReason) {
        this.paymentBasisReason = paymentBasisReason;
    }

    public CommissionDetail withPaymentBasisReason(PaymentBasisReason paymentBasisReason) {
        this.paymentBasisReason = paymentBasisReason;
        return this;
    }

    @JsonProperty("PaymentRateCategory")
    public PaymentRateCategory getPaymentRateCategory() {
        return paymentRateCategory;
    }

    @JsonProperty("PaymentRateCategory")
    public void setPaymentRateCategory(PaymentRateCategory paymentRateCategory) {
        this.paymentRateCategory = paymentRateCategory;
    }

    public CommissionDetail withPaymentRateCategory(PaymentRateCategory paymentRateCategory) {
        this.paymentRateCategory = paymentRateCategory;
        return this;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    public CommissionDetail withDescription(String description) {
        this.description = description;
        return this;
    }

    @JsonProperty("CommissionSchedule")
    public String getCommissionSchedule() {
        return commissionSchedule;
    }

    @JsonProperty("CommissionSchedule")
    public void setCommissionSchedule(String commissionSchedule) {
        this.commissionSchedule = commissionSchedule;
    }

    public CommissionDetail withCommissionSchedule(String commissionSchedule) {
        this.commissionSchedule = commissionSchedule;
        return this;
    }

    @JsonProperty("PaidAmt")
    public Integer getPaidAmt() {
        return paidAmt;
    }

    @JsonProperty("PaidAmt")
    public void setPaidAmt(Integer paidAmt) {
        this.paidAmt = paidAmt;
    }

    public CommissionDetail withPaidAmt(Integer paidAmt) {
        this.paidAmt = paidAmt;
        return this;
    }

    @JsonProperty("EarnedAmt")
    public Integer getEarnedAmt() {
        return earnedAmt;
    }

    @JsonProperty("EarnedAmt")
    public void setEarnedAmt(Integer earnedAmt) {
        this.earnedAmt = earnedAmt;
    }

    public CommissionDetail withEarnedAmt(Integer earnedAmt) {
        this.earnedAmt = earnedAmt;
        return this;
    }

    @JsonProperty("PolNumber")
    public String getPolNumber() {
        return polNumber;
    }

    @JsonProperty("PolNumber")
    public void setPolNumber(String polNumber) {
        this.polNumber = polNumber;
    }

    public CommissionDetail withPolNumber(String polNumber) {
        this.polNumber = polNumber;
        return this;
    }

    @JsonProperty("ProductCode")
    public String getProductCode() {
        return productCode;
    }

    @JsonProperty("ProductCode")
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public CommissionDetail withProductCode(String productCode) {
        this.productCode = productCode;
        return this;
    }

    @JsonProperty("EffDate")
    public String getEffDate() {
        return effDate;
    }

    @JsonProperty("EffDate")
    public void setEffDate(String effDate) {
        this.effDate = effDate;
    }

    public CommissionDetail withEffDate(String effDate) {
        this.effDate = effDate;
        return this;
    }

    @JsonProperty("CommissionEarnedDate")
    public String getCommissionEarnedDate() {
        return commissionEarnedDate;
    }

    @JsonProperty("CommissionEarnedDate")
    public void setCommissionEarnedDate(String commissionEarnedDate) {
        this.commissionEarnedDate = commissionEarnedDate;
    }

    public CommissionDetail withCommissionEarnedDate(String commissionEarnedDate) {
        this.commissionEarnedDate = commissionEarnedDate;
        return this;
    }

    @JsonProperty("PaidToDate")
    public String getPaidToDate() {
        return paidToDate;
    }

    @JsonProperty("PaidToDate")
    public void setPaidToDate(String paidToDate) {
        this.paidToDate = paidToDate;
    }

    public CommissionDetail withPaidToDate(String paidToDate) {
        this.paidToDate = paidToDate;
        return this;
    }

    @JsonProperty("CoverageAmt")
    public Integer getCoverageAmt() {
        return coverageAmt;
    }

    @JsonProperty("CoverageAmt")
    public void setCoverageAmt(Integer coverageAmt) {
        this.coverageAmt = coverageAmt;
    }

    public CommissionDetail withCoverageAmt(Integer coverageAmt) {
        this.coverageAmt = coverageAmt;
        return this;
    }

    @JsonProperty("WritingProducerID")
    public String getWritingProducerID() {
        return writingProducerID;
    }

    @JsonProperty("WritingProducerID")
    public void setWritingProducerID(String writingProducerID) {
        this.writingProducerID = writingProducerID;
    }

    public CommissionDetail withWritingProducerID(String writingProducerID) {
        this.writingProducerID = writingProducerID;
        return this;
    }

    @JsonProperty("PaidProducerID")
    public String getPaidProducerID() {
        return paidProducerID;
    }

    @JsonProperty("PaidProducerID")
    public void setPaidProducerID(String paidProducerID) {
        this.paidProducerID = paidProducerID;
    }

    public CommissionDetail withPaidProducerID(String paidProducerID) {
        this.paidProducerID = paidProducerID;
        return this;
    }

    @JsonProperty("DebtRecaptureProducerID")
    public String getDebtRecaptureProducerID() {
        return debtRecaptureProducerID;
    }

    @JsonProperty("DebtRecaptureProducerID")
    public void setDebtRecaptureProducerID(String debtRecaptureProducerID) {
        this.debtRecaptureProducerID = debtRecaptureProducerID;
    }

    public CommissionDetail withDebtRecaptureProducerID(String debtRecaptureProducerID) {
        this.debtRecaptureProducerID = debtRecaptureProducerID;
        return this;
    }

    @JsonProperty("ActualObjectType")
    public ActualObjectType getActualObjectType() {
        return actualObjectType;
    }

    @JsonProperty("ActualObjectType")
    public void setActualObjectType(ActualObjectType actualObjectType) {
        this.actualObjectType = actualObjectType;
    }

    public CommissionDetail withActualObjectType(ActualObjectType actualObjectType) {
        this.actualObjectType = actualObjectType;
        return this;
    }

    @JsonProperty("ActualProductCode")
    public String getActualProductCode() {
        return actualProductCode;
    }

    @JsonProperty("ActualProductCode")
    public void setActualProductCode(String actualProductCode) {
        this.actualProductCode = actualProductCode;
    }

    public CommissionDetail withActualProductCode(String actualProductCode) {
        this.actualProductCode = actualProductCode;
        return this;
    }

    @JsonProperty("ActualEffDate")
    public String getActualEffDate() {
        return actualEffDate;
    }

    @JsonProperty("ActualEffDate")
    public void setActualEffDate(String actualEffDate) {
        this.actualEffDate = actualEffDate;
    }

    public CommissionDetail withActualEffDate(String actualEffDate) {
        this.actualEffDate = actualEffDate;
        return this;
    }

    @JsonProperty("ActualPlanName")
    public String getActualPlanName() {
        return actualPlanName;
    }

    @JsonProperty("ActualPlanName")
    public void setActualPlanName(String actualPlanName) {
        this.actualPlanName = actualPlanName;
    }

    public CommissionDetail withActualPlanName(String actualPlanName) {
        this.actualPlanName = actualPlanName;
        return this;
    }

    @JsonProperty("TaxableInd")
    public TaxableInd getTaxableInd() {
        return taxableInd;
    }

    @JsonProperty("TaxableInd")
    public void setTaxableInd(TaxableInd taxableInd) {
        this.taxableInd = taxableInd;
    }

    public CommissionDetail withTaxableInd(TaxableInd taxableInd) {
        this.taxableInd = taxableInd;
        return this;
    }

    @JsonProperty("CommissionEvent")
    public CommissionEvent getCommissionEvent() {
        return commissionEvent;
    }

    @JsonProperty("CommissionEvent")
    public void setCommissionEvent(CommissionEvent commissionEvent) {
        this.commissionEvent = commissionEvent;
    }

    public CommissionDetail withCommissionEvent(CommissionEvent commissionEvent) {
        this.commissionEvent = commissionEvent;
        return this;
    }

    @JsonProperty("PaymentMode")
    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    @JsonProperty("PaymentMode")
    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public CommissionDetail withPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
        return this;
    }

    @JsonProperty("ChargeBackRate")
    public Integer getChargeBackRate() {
        return chargeBackRate;
    }

    @JsonProperty("ChargeBackRate")
    public void setChargeBackRate(Integer chargeBackRate) {
        this.chargeBackRate = chargeBackRate;
    }

    public CommissionDetail withChargeBackRate(Integer chargeBackRate) {
        this.chargeBackRate = chargeBackRate;
        return this;
    }

    @JsonProperty("ClientName")
    public String getClientName() {
        return clientName;
    }

    @JsonProperty("ClientName")
    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public CommissionDetail withClientName(String clientName) {
        this.clientName = clientName;
        return this;
    }

    @JsonProperty("AdvancedInd")
    public AdvancedInd getAdvancedInd() {
        return advancedInd;
    }

    @JsonProperty("AdvancedInd")
    public void setAdvancedInd(AdvancedInd advancedInd) {
        this.advancedInd = advancedInd;
    }

    public CommissionDetail withAdvancedInd(AdvancedInd advancedInd) {
        this.advancedInd = advancedInd;
        return this;
    }

    @JsonProperty("SettlementAmt")
    public Integer getSettlementAmt() {
        return settlementAmt;
    }

    @JsonProperty("SettlementAmt")
    public void setSettlementAmt(Integer settlementAmt) {
        this.settlementAmt = settlementAmt;
    }

    public CommissionDetail withSettlementAmt(Integer settlementAmt) {
        this.settlementAmt = settlementAmt;
        return this;
    }

    @JsonProperty("SettlementDate")
    public String getSettlementDate() {
        return settlementDate;
    }

    @JsonProperty("SettlementDate")
    public void setSettlementDate(String settlementDate) {
        this.settlementDate = settlementDate;
    }

    public CommissionDetail withSettlementDate(String settlementDate) {
        this.settlementDate = settlementDate;
        return this;
    }

    @JsonProperty("FundCarrierCode")
    public String getFundCarrierCode() {
        return fundCarrierCode;
    }

    @JsonProperty("FundCarrierCode")
    public void setFundCarrierCode(String fundCarrierCode) {
        this.fundCarrierCode = fundCarrierCode;
    }

    public CommissionDetail withFundCarrierCode(String fundCarrierCode) {
        this.fundCarrierCode = fundCarrierCode;
        return this;
    }

    @JsonProperty("FundProductCode")
    public String getFundProductCode() {
        return fundProductCode;
    }

    @JsonProperty("FundProductCode")
    public void setFundProductCode(String fundProductCode) {
        this.fundProductCode = fundProductCode;
    }

    public CommissionDetail withFundProductCode(String fundProductCode) {
        this.fundProductCode = fundProductCode;
        return this;
    }

    @JsonProperty("TrailFrequency")
    public TrailFrequency getTrailFrequency() {
        return trailFrequency;
    }

    @JsonProperty("TrailFrequency")
    public void setTrailFrequency(TrailFrequency trailFrequency) {
        this.trailFrequency = trailFrequency;
    }

    public CommissionDetail withTrailFrequency(TrailFrequency trailFrequency) {
        this.trailFrequency = trailFrequency;
        return this;
    }

    @JsonProperty("PayType")
    public PayType getPayType() {
        return payType;
    }

    @JsonProperty("PayType")
    public void setPayType(PayType payType) {
        this.payType = payType;
    }

    public CommissionDetail withPayType(PayType payType) {
        this.payType = payType;
        return this;
    }

    @JsonProperty("PolicyStatus")
    public PolicyStatus getPolicyStatus() {
        return policyStatus;
    }

    @JsonProperty("PolicyStatus")
    public void setPolicyStatus(PolicyStatus policyStatus) {
        this.policyStatus = policyStatus;
    }

    public CommissionDetail withPolicyStatus(PolicyStatus policyStatus) {
        this.policyStatus = policyStatus;
        return this;
    }

    @JsonProperty("OwnerName")
    public String getOwnerName() {
        return ownerName;
    }

    @JsonProperty("OwnerName")
    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public CommissionDetail withOwnerName(String ownerName) {
        this.ownerName = ownerName;
        return this;
    }

    @JsonProperty("CusipNum")
    public String getCusipNum() {
        return cusipNum;
    }

    @JsonProperty("CusipNum")
    public void setCusipNum(String cusipNum) {
        this.cusipNum = cusipNum;
    }

    public CommissionDetail withCusipNum(String cusipNum) {
        this.cusipNum = cusipNum;
        return this;
    }

    @JsonProperty("CovNumber")
    public String getCovNumber() {
        return covNumber;
    }

    @JsonProperty("CovNumber")
    public void setCovNumber(String covNumber) {
        this.covNumber = covNumber;
    }

    public CommissionDetail withCovNumber(String covNumber) {
        this.covNumber = covNumber;
        return this;
    }

    @JsonProperty("CarrierAdminSystem")
    public String getCarrierAdminSystem() {
        return carrierAdminSystem;
    }

    @JsonProperty("CarrierAdminSystem")
    public void setCarrierAdminSystem(String carrierAdminSystem) {
        this.carrierAdminSystem = carrierAdminSystem;
    }

    public CommissionDetail withCarrierAdminSystem(String carrierAdminSystem) {
        this.carrierAdminSystem = carrierAdminSystem;
        return this;
    }

    @JsonProperty("CommissionStatus")
    public CommissionStatus getCommissionStatus() {
        return commissionStatus;
    }

    @JsonProperty("CommissionStatus")
    public void setCommissionStatus(CommissionStatus commissionStatus) {
        this.commissionStatus = commissionStatus;
    }

    public CommissionDetail withCommissionStatus(CommissionStatus commissionStatus) {
        this.commissionStatus = commissionStatus;
        return this;
    }

    @JsonProperty("SponsoringPlanName")
    public String getSponsoringPlanName() {
        return sponsoringPlanName;
    }

    @JsonProperty("SponsoringPlanName")
    public void setSponsoringPlanName(String sponsoringPlanName) {
        this.sponsoringPlanName = sponsoringPlanName;
    }

    public CommissionDetail withSponsoringPlanName(String sponsoringPlanName) {
        this.sponsoringPlanName = sponsoringPlanName;
        return this;
    }

    @JsonProperty("SponsoringPlanCode")
    public String getSponsoringPlanCode() {
        return sponsoringPlanCode;
    }

    @JsonProperty("SponsoringPlanCode")
    public void setSponsoringPlanCode(String sponsoringPlanCode) {
        this.sponsoringPlanCode = sponsoringPlanCode;
    }

    public CommissionDetail withSponsoringPlanCode(String sponsoringPlanCode) {
        this.sponsoringPlanCode = sponsoringPlanCode;
        return this;
    }

    @JsonProperty("SponsorName")
    public String getSponsorName() {
        return sponsorName;
    }

    @JsonProperty("SponsorName")
    public void setSponsorName(String sponsorName) {
        this.sponsorName = sponsorName;
    }

    public CommissionDetail withSponsorName(String sponsorName) {
        this.sponsorName = sponsorName;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public CommissionDetail withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public CommissionDetail withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("HoldingID")
    public String getHoldingID() {
        return holdingID;
    }

    @JsonProperty("HoldingID")
    public void setHoldingID(String holdingID) {
        this.holdingID = holdingID;
    }

    public CommissionDetail withHoldingID(String holdingID) {
        this.holdingID = holdingID;
        return this;
    }

    @JsonProperty("WritingProducerPartyID")
    public String getWritingProducerPartyID() {
        return writingProducerPartyID;
    }

    @JsonProperty("WritingProducerPartyID")
    public void setWritingProducerPartyID(String writingProducerPartyID) {
        this.writingProducerPartyID = writingProducerPartyID;
    }

    public CommissionDetail withWritingProducerPartyID(String writingProducerPartyID) {
        this.writingProducerPartyID = writingProducerPartyID;
        return this;
    }

    @JsonProperty("PaidProducerPartyID")
    public String getPaidProducerPartyID() {
        return paidProducerPartyID;
    }

    @JsonProperty("PaidProducerPartyID")
    public void setPaidProducerPartyID(String paidProducerPartyID) {
        this.paidProducerPartyID = paidProducerPartyID;
    }

    public CommissionDetail withPaidProducerPartyID(String paidProducerPartyID) {
        this.paidProducerPartyID = paidProducerPartyID;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public CommissionDetail withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonProperty("ActualObjectID")
    public String getActualObjectID() {
        return actualObjectID;
    }

    @JsonProperty("ActualObjectID")
    public void setActualObjectID(String actualObjectID) {
        this.actualObjectID = actualObjectID;
    }

    public CommissionDetail withActualObjectID(String actualObjectID) {
        this.actualObjectID = actualObjectID;
        return this;
    }

    @JsonProperty("CoverageID")
    public String getCoverageID() {
        return coverageID;
    }

    @JsonProperty("CoverageID")
    public void setCoverageID(String coverageID) {
        this.coverageID = coverageID;
    }

    public CommissionDetail withCoverageID(String coverageID) {
        this.coverageID = coverageID;
        return this;
    }

    @JsonProperty("OwnerPartyID")
    public String getOwnerPartyID() {
        return ownerPartyID;
    }

    @JsonProperty("OwnerPartyID")
    public void setOwnerPartyID(String ownerPartyID) {
        this.ownerPartyID = ownerPartyID;
    }

    public CommissionDetail withOwnerPartyID(String ownerPartyID) {
        this.ownerPartyID = ownerPartyID;
        return this;
    }

    @JsonProperty("PaidProducerAgreementID")
    public String getPaidProducerAgreementID() {
        return paidProducerAgreementID;
    }

    @JsonProperty("PaidProducerAgreementID")
    public void setPaidProducerAgreementID(String paidProducerAgreementID) {
        this.paidProducerAgreementID = paidProducerAgreementID;
    }

    public CommissionDetail withPaidProducerAgreementID(String paidProducerAgreementID) {
        this.paidProducerAgreementID = paidProducerAgreementID;
        return this;
    }

    @JsonProperty("WritingProducerAgreementID")
    public String getWritingProducerAgreementID() {
        return writingProducerAgreementID;
    }

    @JsonProperty("WritingProducerAgreementID")
    public void setWritingProducerAgreementID(String writingProducerAgreementID) {
        this.writingProducerAgreementID = writingProducerAgreementID;
    }

    public CommissionDetail withWritingProducerAgreementID(String writingProducerAgreementID) {
        this.writingProducerAgreementID = writingProducerAgreementID;
        return this;
    }

    @JsonProperty("SettlementVendorID")
    public String getSettlementVendorID() {
        return settlementVendorID;
    }

    @JsonProperty("SettlementVendorID")
    public void setSettlementVendorID(String settlementVendorID) {
        this.settlementVendorID = settlementVendorID;
    }

    public CommissionDetail withSettlementVendorID(String settlementVendorID) {
        this.settlementVendorID = settlementVendorID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CommissionDetail withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(CommissionDetail.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("commissionDetailKey");
        sb.append('=');
        sb.append(((this.commissionDetailKey == null)?"<null>":this.commissionDetailKey));
        sb.append(',');
        sb.append("commissionDetailSysKey");
        sb.append('=');
        sb.append(((this.commissionDetailSysKey == null)?"<null>":this.commissionDetailSysKey));
        sb.append(',');
        sb.append("carrierCode");
        sb.append('=');
        sb.append(((this.carrierCode == null)?"<null>":this.carrierCode));
        sb.append(',');
        sb.append("commissionType");
        sb.append('=');
        sb.append(((this.commissionType == null)?"<null>":this.commissionType));
        sb.append(',');
        sb.append("commissionTransactionType");
        sb.append('=');
        sb.append(((this.commissionTransactionType == null)?"<null>":this.commissionTransactionType));
        sb.append(',');
        sb.append("transactionDate");
        sb.append('=');
        sb.append(((this.transactionDate == null)?"<null>":this.transactionDate));
        sb.append(',');
        sb.append("commissionRate");
        sb.append('=');
        sb.append(((this.commissionRate == null)?"<null>":this.commissionRate));
        sb.append(',');
        sb.append("splitPercent");
        sb.append('=');
        sb.append(((this.splitPercent == null)?"<null>":this.splitPercent));
        sb.append(',');
        sb.append("paymentBasisAmt");
        sb.append('=');
        sb.append(((this.paymentBasisAmt == null)?"<null>":this.paymentBasisAmt));
        sb.append(',');
        sb.append("originatingBasisAmt");
        sb.append('=');
        sb.append(((this.originatingBasisAmt == null)?"<null>":this.originatingBasisAmt));
        sb.append(',');
        sb.append("originatingBasisType");
        sb.append('=');
        sb.append(((this.originatingBasisType == null)?"<null>":this.originatingBasisType));
        sb.append(',');
        sb.append("paymentBasisReason");
        sb.append('=');
        sb.append(((this.paymentBasisReason == null)?"<null>":this.paymentBasisReason));
        sb.append(',');
        sb.append("paymentRateCategory");
        sb.append('=');
        sb.append(((this.paymentRateCategory == null)?"<null>":this.paymentRateCategory));
        sb.append(',');
        sb.append("description");
        sb.append('=');
        sb.append(((this.description == null)?"<null>":this.description));
        sb.append(',');
        sb.append("commissionSchedule");
        sb.append('=');
        sb.append(((this.commissionSchedule == null)?"<null>":this.commissionSchedule));
        sb.append(',');
        sb.append("paidAmt");
        sb.append('=');
        sb.append(((this.paidAmt == null)?"<null>":this.paidAmt));
        sb.append(',');
        sb.append("earnedAmt");
        sb.append('=');
        sb.append(((this.earnedAmt == null)?"<null>":this.earnedAmt));
        sb.append(',');
        sb.append("polNumber");
        sb.append('=');
        sb.append(((this.polNumber == null)?"<null>":this.polNumber));
        sb.append(',');
        sb.append("productCode");
        sb.append('=');
        sb.append(((this.productCode == null)?"<null>":this.productCode));
        sb.append(',');
        sb.append("effDate");
        sb.append('=');
        sb.append(((this.effDate == null)?"<null>":this.effDate));
        sb.append(',');
        sb.append("commissionEarnedDate");
        sb.append('=');
        sb.append(((this.commissionEarnedDate == null)?"<null>":this.commissionEarnedDate));
        sb.append(',');
        sb.append("paidToDate");
        sb.append('=');
        sb.append(((this.paidToDate == null)?"<null>":this.paidToDate));
        sb.append(',');
        sb.append("coverageAmt");
        sb.append('=');
        sb.append(((this.coverageAmt == null)?"<null>":this.coverageAmt));
        sb.append(',');
        sb.append("writingProducerID");
        sb.append('=');
        sb.append(((this.writingProducerID == null)?"<null>":this.writingProducerID));
        sb.append(',');
        sb.append("paidProducerID");
        sb.append('=');
        sb.append(((this.paidProducerID == null)?"<null>":this.paidProducerID));
        sb.append(',');
        sb.append("debtRecaptureProducerID");
        sb.append('=');
        sb.append(((this.debtRecaptureProducerID == null)?"<null>":this.debtRecaptureProducerID));
        sb.append(',');
        sb.append("actualObjectType");
        sb.append('=');
        sb.append(((this.actualObjectType == null)?"<null>":this.actualObjectType));
        sb.append(',');
        sb.append("actualProductCode");
        sb.append('=');
        sb.append(((this.actualProductCode == null)?"<null>":this.actualProductCode));
        sb.append(',');
        sb.append("actualEffDate");
        sb.append('=');
        sb.append(((this.actualEffDate == null)?"<null>":this.actualEffDate));
        sb.append(',');
        sb.append("actualPlanName");
        sb.append('=');
        sb.append(((this.actualPlanName == null)?"<null>":this.actualPlanName));
        sb.append(',');
        sb.append("taxableInd");
        sb.append('=');
        sb.append(((this.taxableInd == null)?"<null>":this.taxableInd));
        sb.append(',');
        sb.append("commissionEvent");
        sb.append('=');
        sb.append(((this.commissionEvent == null)?"<null>":this.commissionEvent));
        sb.append(',');
        sb.append("paymentMode");
        sb.append('=');
        sb.append(((this.paymentMode == null)?"<null>":this.paymentMode));
        sb.append(',');
        sb.append("chargeBackRate");
        sb.append('=');
        sb.append(((this.chargeBackRate == null)?"<null>":this.chargeBackRate));
        sb.append(',');
        sb.append("clientName");
        sb.append('=');
        sb.append(((this.clientName == null)?"<null>":this.clientName));
        sb.append(',');
        sb.append("advancedInd");
        sb.append('=');
        sb.append(((this.advancedInd == null)?"<null>":this.advancedInd));
        sb.append(',');
        sb.append("settlementAmt");
        sb.append('=');
        sb.append(((this.settlementAmt == null)?"<null>":this.settlementAmt));
        sb.append(',');
        sb.append("settlementDate");
        sb.append('=');
        sb.append(((this.settlementDate == null)?"<null>":this.settlementDate));
        sb.append(',');
        sb.append("fundCarrierCode");
        sb.append('=');
        sb.append(((this.fundCarrierCode == null)?"<null>":this.fundCarrierCode));
        sb.append(',');
        sb.append("fundProductCode");
        sb.append('=');
        sb.append(((this.fundProductCode == null)?"<null>":this.fundProductCode));
        sb.append(',');
        sb.append("trailFrequency");
        sb.append('=');
        sb.append(((this.trailFrequency == null)?"<null>":this.trailFrequency));
        sb.append(',');
        sb.append("payType");
        sb.append('=');
        sb.append(((this.payType == null)?"<null>":this.payType));
        sb.append(',');
        sb.append("policyStatus");
        sb.append('=');
        sb.append(((this.policyStatus == null)?"<null>":this.policyStatus));
        sb.append(',');
        sb.append("ownerName");
        sb.append('=');
        sb.append(((this.ownerName == null)?"<null>":this.ownerName));
        sb.append(',');
        sb.append("cusipNum");
        sb.append('=');
        sb.append(((this.cusipNum == null)?"<null>":this.cusipNum));
        sb.append(',');
        sb.append("covNumber");
        sb.append('=');
        sb.append(((this.covNumber == null)?"<null>":this.covNumber));
        sb.append(',');
        sb.append("carrierAdminSystem");
        sb.append('=');
        sb.append(((this.carrierAdminSystem == null)?"<null>":this.carrierAdminSystem));
        sb.append(',');
        sb.append("commissionStatus");
        sb.append('=');
        sb.append(((this.commissionStatus == null)?"<null>":this.commissionStatus));
        sb.append(',');
        sb.append("sponsoringPlanName");
        sb.append('=');
        sb.append(((this.sponsoringPlanName == null)?"<null>":this.sponsoringPlanName));
        sb.append(',');
        sb.append("sponsoringPlanCode");
        sb.append('=');
        sb.append(((this.sponsoringPlanCode == null)?"<null>":this.sponsoringPlanCode));
        sb.append(',');
        sb.append("sponsorName");
        sb.append('=');
        sb.append(((this.sponsorName == null)?"<null>":this.sponsorName));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("holdingID");
        sb.append('=');
        sb.append(((this.holdingID == null)?"<null>":this.holdingID));
        sb.append(',');
        sb.append("writingProducerPartyID");
        sb.append('=');
        sb.append(((this.writingProducerPartyID == null)?"<null>":this.writingProducerPartyID));
        sb.append(',');
        sb.append("paidProducerPartyID");
        sb.append('=');
        sb.append(((this.paidProducerPartyID == null)?"<null>":this.paidProducerPartyID));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("actualObjectID");
        sb.append('=');
        sb.append(((this.actualObjectID == null)?"<null>":this.actualObjectID));
        sb.append(',');
        sb.append("coverageID");
        sb.append('=');
        sb.append(((this.coverageID == null)?"<null>":this.coverageID));
        sb.append(',');
        sb.append("ownerPartyID");
        sb.append('=');
        sb.append(((this.ownerPartyID == null)?"<null>":this.ownerPartyID));
        sb.append(',');
        sb.append("paidProducerAgreementID");
        sb.append('=');
        sb.append(((this.paidProducerAgreementID == null)?"<null>":this.paidProducerAgreementID));
        sb.append(',');
        sb.append("writingProducerAgreementID");
        sb.append('=');
        sb.append(((this.writingProducerAgreementID == null)?"<null>":this.writingProducerAgreementID));
        sb.append(',');
        sb.append("settlementVendorID");
        sb.append('=');
        sb.append(((this.settlementVendorID == null)?"<null>":this.settlementVendorID));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.paymentRateCategory == null)? 0 :this.paymentRateCategory.hashCode()));
        result = ((result* 31)+((this.fundProductCode == null)? 0 :this.fundProductCode.hashCode()));
        result = ((result* 31)+((this.writingProducerPartyID == null)? 0 :this.writingProducerPartyID.hashCode()));
        result = ((result* 31)+((this.settlementVendorID == null)? 0 :this.settlementVendorID.hashCode()));
        result = ((result* 31)+((this.covNumber == null)? 0 :this.covNumber.hashCode()));
        result = ((result* 31)+((this.polNumber == null)? 0 :this.polNumber.hashCode()));
        result = ((result* 31)+((this.paidProducerPartyID == null)? 0 :this.paidProducerPartyID.hashCode()));
        result = ((result* 31)+((this.commissionEvent == null)? 0 :this.commissionEvent.hashCode()));
        result = ((result* 31)+((this.advancedInd == null)? 0 :this.advancedInd.hashCode()));
        result = ((result* 31)+((this.actualProductCode == null)? 0 :this.actualProductCode.hashCode()));
        result = ((result* 31)+((this.effDate == null)? 0 :this.effDate.hashCode()));
        result = ((result* 31)+((this.commissionStatus == null)? 0 :this.commissionStatus.hashCode()));
        result = ((result* 31)+((this.payType == null)? 0 :this.payType.hashCode()));
        result = ((result* 31)+((this.actualEffDate == null)? 0 :this.actualEffDate.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.fundCarrierCode == null)? 0 :this.fundCarrierCode.hashCode()));
        result = ((result* 31)+((this.earnedAmt == null)? 0 :this.earnedAmt.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.carrierAdminSystem == null)? 0 :this.carrierAdminSystem.hashCode()));
        result = ((result* 31)+((this.commissionTransactionType == null)? 0 :this.commissionTransactionType.hashCode()));
        result = ((result* 31)+((this.actualPlanName == null)? 0 :this.actualPlanName.hashCode()));
        result = ((result* 31)+((this.commissionSchedule == null)? 0 :this.commissionSchedule.hashCode()));
        result = ((result* 31)+((this.settlementDate == null)? 0 :this.settlementDate.hashCode()));
        result = ((result* 31)+((this.holdingID == null)? 0 :this.holdingID.hashCode()));
        result = ((result* 31)+((this.paidProducerID == null)? 0 :this.paidProducerID.hashCode()));
        result = ((result* 31)+((this.commissionDetailSysKey == null)? 0 :this.commissionDetailSysKey.hashCode()));
        result = ((result* 31)+((this.debtRecaptureProducerID == null)? 0 :this.debtRecaptureProducerID.hashCode()));
        result = ((result* 31)+((this.carrierCode == null)? 0 :this.carrierCode.hashCode()));
        result = ((result* 31)+((this.originatingBasisAmt == null)? 0 :this.originatingBasisAmt.hashCode()));
        result = ((result* 31)+((this.cusipNum == null)? 0 :this.cusipNum.hashCode()));
        result = ((result* 31)+((this.paymentBasisAmt == null)? 0 :this.paymentBasisAmt.hashCode()));
        result = ((result* 31)+((this.writingProducerAgreementID == null)? 0 :this.writingProducerAgreementID.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.taxableInd == null)? 0 :this.taxableInd.hashCode()));
        result = ((result* 31)+((this.trailFrequency == null)? 0 :this.trailFrequency.hashCode()));
        result = ((result* 31)+((this.coverageID == null)? 0 :this.coverageID.hashCode()));
        result = ((result* 31)+((this.commissionRate == null)? 0 :this.commissionRate.hashCode()));
        result = ((result* 31)+((this.clientName == null)? 0 :this.clientName.hashCode()));
        result = ((result* 31)+((this.sponsorName == null)? 0 :this.sponsorName.hashCode()));
        result = ((result* 31)+((this.description == null)? 0 :this.description.hashCode()));
        result = ((result* 31)+((this.chargeBackRate == null)? 0 :this.chargeBackRate.hashCode()));
        result = ((result* 31)+((this.policyStatus == null)? 0 :this.policyStatus.hashCode()));
        result = ((result* 31)+((this.paidProducerAgreementID == null)? 0 :this.paidProducerAgreementID.hashCode()));
        result = ((result* 31)+((this.commissionEarnedDate == null)? 0 :this.commissionEarnedDate.hashCode()));
        result = ((result* 31)+((this.coverageAmt == null)? 0 :this.coverageAmt.hashCode()));
        result = ((result* 31)+((this.ownerPartyID == null)? 0 :this.ownerPartyID.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.ownerName == null)? 0 :this.ownerName.hashCode()));
        result = ((result* 31)+((this.originatingBasisType == null)? 0 :this.originatingBasisType.hashCode()));
        result = ((result* 31)+((this.commissionDetailKey == null)? 0 :this.commissionDetailKey.hashCode()));
        result = ((result* 31)+((this.paidToDate == null)? 0 :this.paidToDate.hashCode()));
        result = ((result* 31)+((this.sponsoringPlanCode == null)? 0 :this.sponsoringPlanCode.hashCode()));
        result = ((result* 31)+((this.actualObjectID == null)? 0 :this.actualObjectID.hashCode()));
        result = ((result* 31)+((this.paymentMode == null)? 0 :this.paymentMode.hashCode()));
        result = ((result* 31)+((this.paymentBasisReason == null)? 0 :this.paymentBasisReason.hashCode()));
        result = ((result* 31)+((this.paidAmt == null)? 0 :this.paidAmt.hashCode()));
        result = ((result* 31)+((this.settlementAmt == null)? 0 :this.settlementAmt.hashCode()));
        result = ((result* 31)+((this.transactionDate == null)? 0 :this.transactionDate.hashCode()));
        result = ((result* 31)+((this.commissionType == null)? 0 :this.commissionType.hashCode()));
        result = ((result* 31)+((this.writingProducerID == null)? 0 :this.writingProducerID.hashCode()));
        result = ((result* 31)+((this.productCode == null)? 0 :this.productCode.hashCode()));
        result = ((result* 31)+((this.actualObjectType == null)? 0 :this.actualObjectType.hashCode()));
        result = ((result* 31)+((this.sponsoringPlanName == null)? 0 :this.sponsoringPlanName.hashCode()));
        result = ((result* 31)+((this.splitPercent == null)? 0 :this.splitPercent.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CommissionDetail) == false) {
            return false;
        }
        CommissionDetail rhs = ((CommissionDetail) other);
        return (((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((this.paymentRateCategory == rhs.paymentRateCategory)||((this.paymentRateCategory!= null)&&this.paymentRateCategory.equals(rhs.paymentRateCategory)))&&((this.fundProductCode == rhs.fundProductCode)||((this.fundProductCode!= null)&&this.fundProductCode.equals(rhs.fundProductCode))))&&((this.writingProducerPartyID == rhs.writingProducerPartyID)||((this.writingProducerPartyID!= null)&&this.writingProducerPartyID.equals(rhs.writingProducerPartyID))))&&((this.settlementVendorID == rhs.settlementVendorID)||((this.settlementVendorID!= null)&&this.settlementVendorID.equals(rhs.settlementVendorID))))&&((this.covNumber == rhs.covNumber)||((this.covNumber!= null)&&this.covNumber.equals(rhs.covNumber))))&&((this.polNumber == rhs.polNumber)||((this.polNumber!= null)&&this.polNumber.equals(rhs.polNumber))))&&((this.paidProducerPartyID == rhs.paidProducerPartyID)||((this.paidProducerPartyID!= null)&&this.paidProducerPartyID.equals(rhs.paidProducerPartyID))))&&((this.commissionEvent == rhs.commissionEvent)||((this.commissionEvent!= null)&&this.commissionEvent.equals(rhs.commissionEvent))))&&((this.advancedInd == rhs.advancedInd)||((this.advancedInd!= null)&&this.advancedInd.equals(rhs.advancedInd))))&&((this.actualProductCode == rhs.actualProductCode)||((this.actualProductCode!= null)&&this.actualProductCode.equals(rhs.actualProductCode))))&&((this.effDate == rhs.effDate)||((this.effDate!= null)&&this.effDate.equals(rhs.effDate))))&&((this.commissionStatus == rhs.commissionStatus)||((this.commissionStatus!= null)&&this.commissionStatus.equals(rhs.commissionStatus))))&&((this.payType == rhs.payType)||((this.payType!= null)&&this.payType.equals(rhs.payType))))&&((this.actualEffDate == rhs.actualEffDate)||((this.actualEffDate!= null)&&this.actualEffDate.equals(rhs.actualEffDate))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.fundCarrierCode == rhs.fundCarrierCode)||((this.fundCarrierCode!= null)&&this.fundCarrierCode.equals(rhs.fundCarrierCode))))&&((this.earnedAmt == rhs.earnedAmt)||((this.earnedAmt!= null)&&this.earnedAmt.equals(rhs.earnedAmt))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.carrierAdminSystem == rhs.carrierAdminSystem)||((this.carrierAdminSystem!= null)&&this.carrierAdminSystem.equals(rhs.carrierAdminSystem))))&&((this.commissionTransactionType == rhs.commissionTransactionType)||((this.commissionTransactionType!= null)&&this.commissionTransactionType.equals(rhs.commissionTransactionType))))&&((this.actualPlanName == rhs.actualPlanName)||((this.actualPlanName!= null)&&this.actualPlanName.equals(rhs.actualPlanName))))&&((this.commissionSchedule == rhs.commissionSchedule)||((this.commissionSchedule!= null)&&this.commissionSchedule.equals(rhs.commissionSchedule))))&&((this.settlementDate == rhs.settlementDate)||((this.settlementDate!= null)&&this.settlementDate.equals(rhs.settlementDate))))&&((this.holdingID == rhs.holdingID)||((this.holdingID!= null)&&this.holdingID.equals(rhs.holdingID))))&&((this.paidProducerID == rhs.paidProducerID)||((this.paidProducerID!= null)&&this.paidProducerID.equals(rhs.paidProducerID))))&&((this.commissionDetailSysKey == rhs.commissionDetailSysKey)||((this.commissionDetailSysKey!= null)&&this.commissionDetailSysKey.equals(rhs.commissionDetailSysKey))))&&((this.debtRecaptureProducerID == rhs.debtRecaptureProducerID)||((this.debtRecaptureProducerID!= null)&&this.debtRecaptureProducerID.equals(rhs.debtRecaptureProducerID))))&&((this.carrierCode == rhs.carrierCode)||((this.carrierCode!= null)&&this.carrierCode.equals(rhs.carrierCode))))&&((this.originatingBasisAmt == rhs.originatingBasisAmt)||((this.originatingBasisAmt!= null)&&this.originatingBasisAmt.equals(rhs.originatingBasisAmt))))&&((this.cusipNum == rhs.cusipNum)||((this.cusipNum!= null)&&this.cusipNum.equals(rhs.cusipNum))))&&((this.paymentBasisAmt == rhs.paymentBasisAmt)||((this.paymentBasisAmt!= null)&&this.paymentBasisAmt.equals(rhs.paymentBasisAmt))))&&((this.writingProducerAgreementID == rhs.writingProducerAgreementID)||((this.writingProducerAgreementID!= null)&&this.writingProducerAgreementID.equals(rhs.writingProducerAgreementID))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.taxableInd == rhs.taxableInd)||((this.taxableInd!= null)&&this.taxableInd.equals(rhs.taxableInd))))&&((this.trailFrequency == rhs.trailFrequency)||((this.trailFrequency!= null)&&this.trailFrequency.equals(rhs.trailFrequency))))&&((this.coverageID == rhs.coverageID)||((this.coverageID!= null)&&this.coverageID.equals(rhs.coverageID))))&&((this.commissionRate == rhs.commissionRate)||((this.commissionRate!= null)&&this.commissionRate.equals(rhs.commissionRate))))&&((this.clientName == rhs.clientName)||((this.clientName!= null)&&this.clientName.equals(rhs.clientName))))&&((this.sponsorName == rhs.sponsorName)||((this.sponsorName!= null)&&this.sponsorName.equals(rhs.sponsorName))))&&((this.description == rhs.description)||((this.description!= null)&&this.description.equals(rhs.description))))&&((this.chargeBackRate == rhs.chargeBackRate)||((this.chargeBackRate!= null)&&this.chargeBackRate.equals(rhs.chargeBackRate))))&&((this.policyStatus == rhs.policyStatus)||((this.policyStatus!= null)&&this.policyStatus.equals(rhs.policyStatus))))&&((this.paidProducerAgreementID == rhs.paidProducerAgreementID)||((this.paidProducerAgreementID!= null)&&this.paidProducerAgreementID.equals(rhs.paidProducerAgreementID))))&&((this.commissionEarnedDate == rhs.commissionEarnedDate)||((this.commissionEarnedDate!= null)&&this.commissionEarnedDate.equals(rhs.commissionEarnedDate))))&&((this.coverageAmt == rhs.coverageAmt)||((this.coverageAmt!= null)&&this.coverageAmt.equals(rhs.coverageAmt))))&&((this.ownerPartyID == rhs.ownerPartyID)||((this.ownerPartyID!= null)&&this.ownerPartyID.equals(rhs.ownerPartyID))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.ownerName == rhs.ownerName)||((this.ownerName!= null)&&this.ownerName.equals(rhs.ownerName))))&&((this.originatingBasisType == rhs.originatingBasisType)||((this.originatingBasisType!= null)&&this.originatingBasisType.equals(rhs.originatingBasisType))))&&((this.commissionDetailKey == rhs.commissionDetailKey)||((this.commissionDetailKey!= null)&&this.commissionDetailKey.equals(rhs.commissionDetailKey))))&&((this.paidToDate == rhs.paidToDate)||((this.paidToDate!= null)&&this.paidToDate.equals(rhs.paidToDate))))&&((this.sponsoringPlanCode == rhs.sponsoringPlanCode)||((this.sponsoringPlanCode!= null)&&this.sponsoringPlanCode.equals(rhs.sponsoringPlanCode))))&&((this.actualObjectID == rhs.actualObjectID)||((this.actualObjectID!= null)&&this.actualObjectID.equals(rhs.actualObjectID))))&&((this.paymentMode == rhs.paymentMode)||((this.paymentMode!= null)&&this.paymentMode.equals(rhs.paymentMode))))&&((this.paymentBasisReason == rhs.paymentBasisReason)||((this.paymentBasisReason!= null)&&this.paymentBasisReason.equals(rhs.paymentBasisReason))))&&((this.paidAmt == rhs.paidAmt)||((this.paidAmt!= null)&&this.paidAmt.equals(rhs.paidAmt))))&&((this.settlementAmt == rhs.settlementAmt)||((this.settlementAmt!= null)&&this.settlementAmt.equals(rhs.settlementAmt))))&&((this.transactionDate == rhs.transactionDate)||((this.transactionDate!= null)&&this.transactionDate.equals(rhs.transactionDate))))&&((this.commissionType == rhs.commissionType)||((this.commissionType!= null)&&this.commissionType.equals(rhs.commissionType))))&&((this.writingProducerID == rhs.writingProducerID)||((this.writingProducerID!= null)&&this.writingProducerID.equals(rhs.writingProducerID))))&&((this.productCode == rhs.productCode)||((this.productCode!= null)&&this.productCode.equals(rhs.productCode))))&&((this.actualObjectType == rhs.actualObjectType)||((this.actualObjectType!= null)&&this.actualObjectType.equals(rhs.actualObjectType))))&&((this.sponsoringPlanName == rhs.sponsoringPlanName)||((this.sponsoringPlanName!= null)&&this.sponsoringPlanName.equals(rhs.sponsoringPlanName))))&&((this.splitPercent == rhs.splitPercent)||((this.splitPercent!= null)&&this.splitPercent.equals(rhs.splitPercent))));
    }

}
