
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "RateOfReturnInfoKey",
    "RateOfReturnInfoSysKey",
    "PeriodMode",
    "RateOfReturn",
    "CalculationMethod",
    "PeriodQuantity",
    "StartDate",
    "EndDate",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class RateOfReturnInfo {

    @JsonProperty("RateOfReturnInfoKey")
    private RateOfReturnInfoKey rateOfReturnInfoKey;
    @JsonProperty("RateOfReturnInfoSysKey")
    private List<Object> rateOfReturnInfoSysKey = new ArrayList<>();
    @JsonProperty("PeriodMode")
    private PeriodMode periodMode;
    @JsonProperty("RateOfReturn")
    private Integer rateOfReturn;
    @JsonProperty("CalculationMethod")
    private CalculationMethod calculationMethod;
    @JsonProperty("PeriodQuantity")
    private Integer periodQuantity;
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("RateOfReturnInfoKey")
    public RateOfReturnInfoKey getRateOfReturnInfoKey() {
        return rateOfReturnInfoKey;
    }

    @JsonProperty("RateOfReturnInfoKey")
    public void setRateOfReturnInfoKey(RateOfReturnInfoKey rateOfReturnInfoKey) {
        this.rateOfReturnInfoKey = rateOfReturnInfoKey;
    }

    public RateOfReturnInfo withRateOfReturnInfoKey(RateOfReturnInfoKey rateOfReturnInfoKey) {
        this.rateOfReturnInfoKey = rateOfReturnInfoKey;
        return this;
    }

    @JsonProperty("RateOfReturnInfoSysKey")
    public List<Object> getRateOfReturnInfoSysKey() {
        return rateOfReturnInfoSysKey;
    }

    @JsonProperty("RateOfReturnInfoSysKey")
    public void setRateOfReturnInfoSysKey(List<Object> rateOfReturnInfoSysKey) {
        this.rateOfReturnInfoSysKey = rateOfReturnInfoSysKey;
    }

    public RateOfReturnInfo withRateOfReturnInfoSysKey(List<Object> rateOfReturnInfoSysKey) {
        this.rateOfReturnInfoSysKey = rateOfReturnInfoSysKey;
        return this;
    }

    @JsonProperty("PeriodMode")
    public PeriodMode getPeriodMode() {
        return periodMode;
    }

    @JsonProperty("PeriodMode")
    public void setPeriodMode(PeriodMode periodMode) {
        this.periodMode = periodMode;
    }

    public RateOfReturnInfo withPeriodMode(PeriodMode periodMode) {
        this.periodMode = periodMode;
        return this;
    }

    @JsonProperty("RateOfReturn")
    public Integer getRateOfReturn() {
        return rateOfReturn;
    }

    @JsonProperty("RateOfReturn")
    public void setRateOfReturn(Integer rateOfReturn) {
        this.rateOfReturn = rateOfReturn;
    }

    public RateOfReturnInfo withRateOfReturn(Integer rateOfReturn) {
        this.rateOfReturn = rateOfReturn;
        return this;
    }

    @JsonProperty("CalculationMethod")
    public CalculationMethod getCalculationMethod() {
        return calculationMethod;
    }

    @JsonProperty("CalculationMethod")
    public void setCalculationMethod(CalculationMethod calculationMethod) {
        this.calculationMethod = calculationMethod;
    }

    public RateOfReturnInfo withCalculationMethod(CalculationMethod calculationMethod) {
        this.calculationMethod = calculationMethod;
        return this;
    }

    @JsonProperty("PeriodQuantity")
    public Integer getPeriodQuantity() {
        return periodQuantity;
    }

    @JsonProperty("PeriodQuantity")
    public void setPeriodQuantity(Integer periodQuantity) {
        this.periodQuantity = periodQuantity;
    }

    public RateOfReturnInfo withPeriodQuantity(Integer periodQuantity) {
        this.periodQuantity = periodQuantity;
        return this;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public RateOfReturnInfo withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public RateOfReturnInfo withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public RateOfReturnInfo withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public RateOfReturnInfo withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public RateOfReturnInfo withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RateOfReturnInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(RateOfReturnInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("rateOfReturnInfoKey");
        sb.append('=');
        sb.append(((this.rateOfReturnInfoKey == null)?"<null>":this.rateOfReturnInfoKey));
        sb.append(',');
        sb.append("rateOfReturnInfoSysKey");
        sb.append('=');
        sb.append(((this.rateOfReturnInfoSysKey == null)?"<null>":this.rateOfReturnInfoSysKey));
        sb.append(',');
        sb.append("periodMode");
        sb.append('=');
        sb.append(((this.periodMode == null)?"<null>":this.periodMode));
        sb.append(',');
        sb.append("rateOfReturn");
        sb.append('=');
        sb.append(((this.rateOfReturn == null)?"<null>":this.rateOfReturn));
        sb.append(',');
        sb.append("calculationMethod");
        sb.append('=');
        sb.append(((this.calculationMethod == null)?"<null>":this.calculationMethod));
        sb.append(',');
        sb.append("periodQuantity");
        sb.append('=');
        sb.append(((this.periodQuantity == null)?"<null>":this.periodQuantity));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.periodMode == null)? 0 :this.periodMode.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.rateOfReturnInfoKey == null)? 0 :this.rateOfReturnInfoKey.hashCode()));
        result = ((result* 31)+((this.calculationMethod == null)? 0 :this.calculationMethod.hashCode()));
        result = ((result* 31)+((this.rateOfReturn == null)? 0 :this.rateOfReturn.hashCode()));
        result = ((result* 31)+((this.rateOfReturnInfoSysKey == null)? 0 :this.rateOfReturnInfoSysKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.periodQuantity == null)? 0 :this.periodQuantity.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RateOfReturnInfo) == false) {
            return false;
        }
        RateOfReturnInfo rhs = ((RateOfReturnInfo) other);
        return (((((((((((((this.periodMode == rhs.periodMode)||((this.periodMode!= null)&&this.periodMode.equals(rhs.periodMode)))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.rateOfReturnInfoKey == rhs.rateOfReturnInfoKey)||((this.rateOfReturnInfoKey!= null)&&this.rateOfReturnInfoKey.equals(rhs.rateOfReturnInfoKey))))&&((this.calculationMethod == rhs.calculationMethod)||((this.calculationMethod!= null)&&this.calculationMethod.equals(rhs.calculationMethod))))&&((this.rateOfReturn == rhs.rateOfReturn)||((this.rateOfReturn!= null)&&this.rateOfReturn.equals(rhs.rateOfReturn))))&&((this.rateOfReturnInfoSysKey == rhs.rateOfReturnInfoSysKey)||((this.rateOfReturnInfoSysKey!= null)&&this.rateOfReturnInfoSysKey.equals(rhs.rateOfReturnInfoSysKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.periodQuantity == rhs.periodQuantity)||((this.periodQuantity!= null)&&this.periodQuantity.equals(rhs.periodQuantity))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))));
    }

}
