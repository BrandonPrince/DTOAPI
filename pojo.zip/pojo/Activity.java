
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ActivityKey",
    "ActivitySysKey",
    "ActivityTypeCode",
    "ActivityTypeDescription",
    "ActivityStatus",
    "ActivityStatusDescription",
    "ActivityDetails",
    "Priority",
    "UserCode",
    "DueDate",
    "DueTime",
    "DoneDate",
    "DoneTime",
    "StartTime",
    "EndTime",
    "RecurringFrequency",
    "Opened",
    "OpenedTime",
    "LastUpdate",
    "LastUpdateTime",
    "Closed",
    "ClosedTime",
    "ActivityCode",
    "ActivitySummary",
    "ActivityTrigger",
    "ReplyRequest",
    "VendorCode",
    "StartDate",
    "EndDate",
    "DateCreatedTime",
    "ScheduledChange",
    "Attachment",
    "KeyedValue",
    "OLifEExtension",
    "id",
    "PartyID",
    "HoldingID",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class Activity {

    @JsonProperty("ActivityKey")
    private ActivityKey activityKey;
    @JsonProperty("ActivitySysKey")
    private List<Object> activitySysKey = new ArrayList<>();
    @JsonProperty("ActivityTypeCode")
    private ActivityTypeCode activityTypeCode;
    @JsonProperty("ActivityTypeDescription")
    private ActivityTypeDescription activityTypeDescription;
    @JsonProperty("ActivityStatus")
    private ActivityStatus activityStatus;
    @JsonProperty("ActivityStatusDescription")
    private ActivityStatusDescription activityStatusDescription;
    @JsonProperty("ActivityDetails")
    private String activityDetails;
    @JsonProperty("Priority")
    private Priority priority;
    @JsonProperty("UserCode")
    private String userCode;
    @JsonProperty("DueDate")
    private String dueDate;
    @JsonProperty("DueTime")
    private String dueTime;
    @JsonProperty("DoneDate")
    private String doneDate;
    @JsonProperty("DoneTime")
    private String doneTime;
    @JsonProperty("StartTime")
    private String startTime;
    @JsonProperty("EndTime")
    private String endTime;
    @JsonProperty("RecurringFrequency")
    private RecurringFrequency recurringFrequency;
    @JsonProperty("Opened")
    private String opened;
    @JsonProperty("OpenedTime")
    private String openedTime;
    @JsonProperty("LastUpdate")
    private String lastUpdate;
    @JsonProperty("LastUpdateTime")
    private String lastUpdateTime;
    @JsonProperty("Closed")
    private String closed;
    @JsonProperty("ClosedTime")
    private String closedTime;
    @JsonProperty("ActivityCode")
    private String activityCode;
    @JsonProperty("ActivitySummary")
    private String activitySummary;
    @JsonProperty("ActivityTrigger")
    private String activityTrigger;
    @JsonProperty("ReplyRequest")
    private ReplyRequest replyRequest;
    @JsonProperty("VendorCode")
    private String vendorCode;
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("DateCreatedTime")
    private String dateCreatedTime;
    @JsonProperty("ScheduledChange")
    private ScheduledChange scheduledChange;
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("PartyID")
    private String partyID;
    @JsonProperty("HoldingID")
    private String holdingID;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ActivityKey")
    public ActivityKey getActivityKey() {
        return activityKey;
    }

    @JsonProperty("ActivityKey")
    public void setActivityKey(ActivityKey activityKey) {
        this.activityKey = activityKey;
    }

    public Activity withActivityKey(ActivityKey activityKey) {
        this.activityKey = activityKey;
        return this;
    }

    @JsonProperty("ActivitySysKey")
    public List<Object> getActivitySysKey() {
        return activitySysKey;
    }

    @JsonProperty("ActivitySysKey")
    public void setActivitySysKey(List<Object> activitySysKey) {
        this.activitySysKey = activitySysKey;
    }

    public Activity withActivitySysKey(List<Object> activitySysKey) {
        this.activitySysKey = activitySysKey;
        return this;
    }

    @JsonProperty("ActivityTypeCode")
    public ActivityTypeCode getActivityTypeCode() {
        return activityTypeCode;
    }

    @JsonProperty("ActivityTypeCode")
    public void setActivityTypeCode(ActivityTypeCode activityTypeCode) {
        this.activityTypeCode = activityTypeCode;
    }

    public Activity withActivityTypeCode(ActivityTypeCode activityTypeCode) {
        this.activityTypeCode = activityTypeCode;
        return this;
    }

    @JsonProperty("ActivityTypeDescription")
    public ActivityTypeDescription getActivityTypeDescription() {
        return activityTypeDescription;
    }

    @JsonProperty("ActivityTypeDescription")
    public void setActivityTypeDescription(ActivityTypeDescription activityTypeDescription) {
        this.activityTypeDescription = activityTypeDescription;
    }

    public Activity withActivityTypeDescription(ActivityTypeDescription activityTypeDescription) {
        this.activityTypeDescription = activityTypeDescription;
        return this;
    }

    @JsonProperty("ActivityStatus")
    public ActivityStatus getActivityStatus() {
        return activityStatus;
    }

    @JsonProperty("ActivityStatus")
    public void setActivityStatus(ActivityStatus activityStatus) {
        this.activityStatus = activityStatus;
    }

    public Activity withActivityStatus(ActivityStatus activityStatus) {
        this.activityStatus = activityStatus;
        return this;
    }

    @JsonProperty("ActivityStatusDescription")
    public ActivityStatusDescription getActivityStatusDescription() {
        return activityStatusDescription;
    }

    @JsonProperty("ActivityStatusDescription")
    public void setActivityStatusDescription(ActivityStatusDescription activityStatusDescription) {
        this.activityStatusDescription = activityStatusDescription;
    }

    public Activity withActivityStatusDescription(ActivityStatusDescription activityStatusDescription) {
        this.activityStatusDescription = activityStatusDescription;
        return this;
    }

    @JsonProperty("ActivityDetails")
    public String getActivityDetails() {
        return activityDetails;
    }

    @JsonProperty("ActivityDetails")
    public void setActivityDetails(String activityDetails) {
        this.activityDetails = activityDetails;
    }

    public Activity withActivityDetails(String activityDetails) {
        this.activityDetails = activityDetails;
        return this;
    }

    @JsonProperty("Priority")
    public Priority getPriority() {
        return priority;
    }

    @JsonProperty("Priority")
    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public Activity withPriority(Priority priority) {
        this.priority = priority;
        return this;
    }

    @JsonProperty("UserCode")
    public String getUserCode() {
        return userCode;
    }

    @JsonProperty("UserCode")
    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public Activity withUserCode(String userCode) {
        this.userCode = userCode;
        return this;
    }

    @JsonProperty("DueDate")
    public String getDueDate() {
        return dueDate;
    }

    @JsonProperty("DueDate")
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public Activity withDueDate(String dueDate) {
        this.dueDate = dueDate;
        return this;
    }

    @JsonProperty("DueTime")
    public String getDueTime() {
        return dueTime;
    }

    @JsonProperty("DueTime")
    public void setDueTime(String dueTime) {
        this.dueTime = dueTime;
    }

    public Activity withDueTime(String dueTime) {
        this.dueTime = dueTime;
        return this;
    }

    @JsonProperty("DoneDate")
    public String getDoneDate() {
        return doneDate;
    }

    @JsonProperty("DoneDate")
    public void setDoneDate(String doneDate) {
        this.doneDate = doneDate;
    }

    public Activity withDoneDate(String doneDate) {
        this.doneDate = doneDate;
        return this;
    }

    @JsonProperty("DoneTime")
    public String getDoneTime() {
        return doneTime;
    }

    @JsonProperty("DoneTime")
    public void setDoneTime(String doneTime) {
        this.doneTime = doneTime;
    }

    public Activity withDoneTime(String doneTime) {
        this.doneTime = doneTime;
        return this;
    }

    @JsonProperty("StartTime")
    public String getStartTime() {
        return startTime;
    }

    @JsonProperty("StartTime")
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public Activity withStartTime(String startTime) {
        this.startTime = startTime;
        return this;
    }

    @JsonProperty("EndTime")
    public String getEndTime() {
        return endTime;
    }

    @JsonProperty("EndTime")
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Activity withEndTime(String endTime) {
        this.endTime = endTime;
        return this;
    }

    @JsonProperty("RecurringFrequency")
    public RecurringFrequency getRecurringFrequency() {
        return recurringFrequency;
    }

    @JsonProperty("RecurringFrequency")
    public void setRecurringFrequency(RecurringFrequency recurringFrequency) {
        this.recurringFrequency = recurringFrequency;
    }

    public Activity withRecurringFrequency(RecurringFrequency recurringFrequency) {
        this.recurringFrequency = recurringFrequency;
        return this;
    }

    @JsonProperty("Opened")
    public String getOpened() {
        return opened;
    }

    @JsonProperty("Opened")
    public void setOpened(String opened) {
        this.opened = opened;
    }

    public Activity withOpened(String opened) {
        this.opened = opened;
        return this;
    }

    @JsonProperty("OpenedTime")
    public String getOpenedTime() {
        return openedTime;
    }

    @JsonProperty("OpenedTime")
    public void setOpenedTime(String openedTime) {
        this.openedTime = openedTime;
    }

    public Activity withOpenedTime(String openedTime) {
        this.openedTime = openedTime;
        return this;
    }

    @JsonProperty("LastUpdate")
    public String getLastUpdate() {
        return lastUpdate;
    }

    @JsonProperty("LastUpdate")
    public void setLastUpdate(String lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public Activity withLastUpdate(String lastUpdate) {
        this.lastUpdate = lastUpdate;
        return this;
    }

    @JsonProperty("LastUpdateTime")
    public String getLastUpdateTime() {
        return lastUpdateTime;
    }

    @JsonProperty("LastUpdateTime")
    public void setLastUpdateTime(String lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public Activity withLastUpdateTime(String lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
        return this;
    }

    @JsonProperty("Closed")
    public String getClosed() {
        return closed;
    }

    @JsonProperty("Closed")
    public void setClosed(String closed) {
        this.closed = closed;
    }

    public Activity withClosed(String closed) {
        this.closed = closed;
        return this;
    }

    @JsonProperty("ClosedTime")
    public String getClosedTime() {
        return closedTime;
    }

    @JsonProperty("ClosedTime")
    public void setClosedTime(String closedTime) {
        this.closedTime = closedTime;
    }

    public Activity withClosedTime(String closedTime) {
        this.closedTime = closedTime;
        return this;
    }

    @JsonProperty("ActivityCode")
    public String getActivityCode() {
        return activityCode;
    }

    @JsonProperty("ActivityCode")
    public void setActivityCode(String activityCode) {
        this.activityCode = activityCode;
    }

    public Activity withActivityCode(String activityCode) {
        this.activityCode = activityCode;
        return this;
    }

    @JsonProperty("ActivitySummary")
    public String getActivitySummary() {
        return activitySummary;
    }

    @JsonProperty("ActivitySummary")
    public void setActivitySummary(String activitySummary) {
        this.activitySummary = activitySummary;
    }

    public Activity withActivitySummary(String activitySummary) {
        this.activitySummary = activitySummary;
        return this;
    }

    @JsonProperty("ActivityTrigger")
    public String getActivityTrigger() {
        return activityTrigger;
    }

    @JsonProperty("ActivityTrigger")
    public void setActivityTrigger(String activityTrigger) {
        this.activityTrigger = activityTrigger;
    }

    public Activity withActivityTrigger(String activityTrigger) {
        this.activityTrigger = activityTrigger;
        return this;
    }

    @JsonProperty("ReplyRequest")
    public ReplyRequest getReplyRequest() {
        return replyRequest;
    }

    @JsonProperty("ReplyRequest")
    public void setReplyRequest(ReplyRequest replyRequest) {
        this.replyRequest = replyRequest;
    }

    public Activity withReplyRequest(ReplyRequest replyRequest) {
        this.replyRequest = replyRequest;
        return this;
    }

    @JsonProperty("VendorCode")
    public String getVendorCode() {
        return vendorCode;
    }

    @JsonProperty("VendorCode")
    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    public Activity withVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
        return this;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public Activity withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Activity withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("DateCreatedTime")
    public String getDateCreatedTime() {
        return dateCreatedTime;
    }

    @JsonProperty("DateCreatedTime")
    public void setDateCreatedTime(String dateCreatedTime) {
        this.dateCreatedTime = dateCreatedTime;
    }

    public Activity withDateCreatedTime(String dateCreatedTime) {
        this.dateCreatedTime = dateCreatedTime;
        return this;
    }

    @JsonProperty("ScheduledChange")
    public ScheduledChange getScheduledChange() {
        return scheduledChange;
    }

    @JsonProperty("ScheduledChange")
    public void setScheduledChange(ScheduledChange scheduledChange) {
        this.scheduledChange = scheduledChange;
    }

    public Activity withScheduledChange(ScheduledChange scheduledChange) {
        this.scheduledChange = scheduledChange;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public Activity withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public Activity withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Activity withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Activity withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("PartyID")
    public String getPartyID() {
        return partyID;
    }

    @JsonProperty("PartyID")
    public void setPartyID(String partyID) {
        this.partyID = partyID;
    }

    public Activity withPartyID(String partyID) {
        this.partyID = partyID;
        return this;
    }

    @JsonProperty("HoldingID")
    public String getHoldingID() {
        return holdingID;
    }

    @JsonProperty("HoldingID")
    public void setHoldingID(String holdingID) {
        this.holdingID = holdingID;
    }

    public Activity withHoldingID(String holdingID) {
        this.holdingID = holdingID;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public Activity withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Activity withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Activity.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("activityKey");
        sb.append('=');
        sb.append(((this.activityKey == null)?"<null>":this.activityKey));
        sb.append(',');
        sb.append("activitySysKey");
        sb.append('=');
        sb.append(((this.activitySysKey == null)?"<null>":this.activitySysKey));
        sb.append(',');
        sb.append("activityTypeCode");
        sb.append('=');
        sb.append(((this.activityTypeCode == null)?"<null>":this.activityTypeCode));
        sb.append(',');
        sb.append("activityTypeDescription");
        sb.append('=');
        sb.append(((this.activityTypeDescription == null)?"<null>":this.activityTypeDescription));
        sb.append(',');
        sb.append("activityStatus");
        sb.append('=');
        sb.append(((this.activityStatus == null)?"<null>":this.activityStatus));
        sb.append(',');
        sb.append("activityStatusDescription");
        sb.append('=');
        sb.append(((this.activityStatusDescription == null)?"<null>":this.activityStatusDescription));
        sb.append(',');
        sb.append("activityDetails");
        sb.append('=');
        sb.append(((this.activityDetails == null)?"<null>":this.activityDetails));
        sb.append(',');
        sb.append("priority");
        sb.append('=');
        sb.append(((this.priority == null)?"<null>":this.priority));
        sb.append(',');
        sb.append("userCode");
        sb.append('=');
        sb.append(((this.userCode == null)?"<null>":this.userCode));
        sb.append(',');
        sb.append("dueDate");
        sb.append('=');
        sb.append(((this.dueDate == null)?"<null>":this.dueDate));
        sb.append(',');
        sb.append("dueTime");
        sb.append('=');
        sb.append(((this.dueTime == null)?"<null>":this.dueTime));
        sb.append(',');
        sb.append("doneDate");
        sb.append('=');
        sb.append(((this.doneDate == null)?"<null>":this.doneDate));
        sb.append(',');
        sb.append("doneTime");
        sb.append('=');
        sb.append(((this.doneTime == null)?"<null>":this.doneTime));
        sb.append(',');
        sb.append("startTime");
        sb.append('=');
        sb.append(((this.startTime == null)?"<null>":this.startTime));
        sb.append(',');
        sb.append("endTime");
        sb.append('=');
        sb.append(((this.endTime == null)?"<null>":this.endTime));
        sb.append(',');
        sb.append("recurringFrequency");
        sb.append('=');
        sb.append(((this.recurringFrequency == null)?"<null>":this.recurringFrequency));
        sb.append(',');
        sb.append("opened");
        sb.append('=');
        sb.append(((this.opened == null)?"<null>":this.opened));
        sb.append(',');
        sb.append("openedTime");
        sb.append('=');
        sb.append(((this.openedTime == null)?"<null>":this.openedTime));
        sb.append(',');
        sb.append("lastUpdate");
        sb.append('=');
        sb.append(((this.lastUpdate == null)?"<null>":this.lastUpdate));
        sb.append(',');
        sb.append("lastUpdateTime");
        sb.append('=');
        sb.append(((this.lastUpdateTime == null)?"<null>":this.lastUpdateTime));
        sb.append(',');
        sb.append("closed");
        sb.append('=');
        sb.append(((this.closed == null)?"<null>":this.closed));
        sb.append(',');
        sb.append("closedTime");
        sb.append('=');
        sb.append(((this.closedTime == null)?"<null>":this.closedTime));
        sb.append(',');
        sb.append("activityCode");
        sb.append('=');
        sb.append(((this.activityCode == null)?"<null>":this.activityCode));
        sb.append(',');
        sb.append("activitySummary");
        sb.append('=');
        sb.append(((this.activitySummary == null)?"<null>":this.activitySummary));
        sb.append(',');
        sb.append("activityTrigger");
        sb.append('=');
        sb.append(((this.activityTrigger == null)?"<null>":this.activityTrigger));
        sb.append(',');
        sb.append("replyRequest");
        sb.append('=');
        sb.append(((this.replyRequest == null)?"<null>":this.replyRequest));
        sb.append(',');
        sb.append("vendorCode");
        sb.append('=');
        sb.append(((this.vendorCode == null)?"<null>":this.vendorCode));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("dateCreatedTime");
        sb.append('=');
        sb.append(((this.dateCreatedTime == null)?"<null>":this.dateCreatedTime));
        sb.append(',');
        sb.append("scheduledChange");
        sb.append('=');
        sb.append(((this.scheduledChange == null)?"<null>":this.scheduledChange));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("partyID");
        sb.append('=');
        sb.append(((this.partyID == null)?"<null>":this.partyID));
        sb.append(',');
        sb.append("holdingID");
        sb.append('=');
        sb.append(((this.holdingID == null)?"<null>":this.holdingID));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.activityKey == null)? 0 :this.activityKey.hashCode()));
        result = ((result* 31)+((this.recurringFrequency == null)? 0 :this.recurringFrequency.hashCode()));
        result = ((result* 31)+((this.activityTrigger == null)? 0 :this.activityTrigger.hashCode()));
        result = ((result* 31)+((this.activityTypeDescription == null)? 0 :this.activityTypeDescription.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.activitySysKey == null)? 0 :this.activitySysKey.hashCode()));
        result = ((result* 31)+((this.dueDate == null)? 0 :this.dueDate.hashCode()));
        result = ((result* 31)+((this.replyRequest == null)? 0 :this.replyRequest.hashCode()));
        result = ((result* 31)+((this.activitySummary == null)? 0 :this.activitySummary.hashCode()));
        result = ((result* 31)+((this.userCode == null)? 0 :this.userCode.hashCode()));
        result = ((result* 31)+((this.closedTime == null)? 0 :this.closedTime.hashCode()));
        result = ((result* 31)+((this.vendorCode == null)? 0 :this.vendorCode.hashCode()));
        result = ((result* 31)+((this.scheduledChange == null)? 0 :this.scheduledChange.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.activityCode == null)? 0 :this.activityCode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.activityTypeCode == null)? 0 :this.activityTypeCode.hashCode()));
        result = ((result* 31)+((this.activityStatus == null)? 0 :this.activityStatus.hashCode()));
        result = ((result* 31)+((this.openedTime == null)? 0 :this.openedTime.hashCode()));
        result = ((result* 31)+((this.doneTime == null)? 0 :this.doneTime.hashCode()));
        result = ((result* 31)+((this.startTime == null)? 0 :this.startTime.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.activityDetails == null)? 0 :this.activityDetails.hashCode()));
        result = ((result* 31)+((this.opened == null)? 0 :this.opened.hashCode()));
        result = ((result* 31)+((this.priority == null)? 0 :this.priority.hashCode()));
        result = ((result* 31)+((this.dueTime == null)? 0 :this.dueTime.hashCode()));
        result = ((result* 31)+((this.dateCreatedTime == null)? 0 :this.dateCreatedTime.hashCode()));
        result = ((result* 31)+((this.holdingID == null)? 0 :this.holdingID.hashCode()));
        result = ((result* 31)+((this.lastUpdate == null)? 0 :this.lastUpdate.hashCode()));
        result = ((result* 31)+((this.closed == null)? 0 :this.closed.hashCode()));
        result = ((result* 31)+((this.activityStatusDescription == null)? 0 :this.activityStatusDescription.hashCode()));
        result = ((result* 31)+((this.endTime == null)? 0 :this.endTime.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.partyID == null)? 0 :this.partyID.hashCode()));
        result = ((result* 31)+((this.doneDate == null)? 0 :this.doneDate.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        result = ((result* 31)+((this.lastUpdateTime == null)? 0 :this.lastUpdateTime.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Activity) == false) {
            return false;
        }
        Activity rhs = ((Activity) other);
        return ((((((((((((((((((((((((((((((((((((((((this.activityKey == rhs.activityKey)||((this.activityKey!= null)&&this.activityKey.equals(rhs.activityKey)))&&((this.recurringFrequency == rhs.recurringFrequency)||((this.recurringFrequency!= null)&&this.recurringFrequency.equals(rhs.recurringFrequency))))&&((this.activityTrigger == rhs.activityTrigger)||((this.activityTrigger!= null)&&this.activityTrigger.equals(rhs.activityTrigger))))&&((this.activityTypeDescription == rhs.activityTypeDescription)||((this.activityTypeDescription!= null)&&this.activityTypeDescription.equals(rhs.activityTypeDescription))))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.activitySysKey == rhs.activitySysKey)||((this.activitySysKey!= null)&&this.activitySysKey.equals(rhs.activitySysKey))))&&((this.dueDate == rhs.dueDate)||((this.dueDate!= null)&&this.dueDate.equals(rhs.dueDate))))&&((this.replyRequest == rhs.replyRequest)||((this.replyRequest!= null)&&this.replyRequest.equals(rhs.replyRequest))))&&((this.activitySummary == rhs.activitySummary)||((this.activitySummary!= null)&&this.activitySummary.equals(rhs.activitySummary))))&&((this.userCode == rhs.userCode)||((this.userCode!= null)&&this.userCode.equals(rhs.userCode))))&&((this.closedTime == rhs.closedTime)||((this.closedTime!= null)&&this.closedTime.equals(rhs.closedTime))))&&((this.vendorCode == rhs.vendorCode)||((this.vendorCode!= null)&&this.vendorCode.equals(rhs.vendorCode))))&&((this.scheduledChange == rhs.scheduledChange)||((this.scheduledChange!= null)&&this.scheduledChange.equals(rhs.scheduledChange))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.activityCode == rhs.activityCode)||((this.activityCode!= null)&&this.activityCode.equals(rhs.activityCode))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.activityTypeCode == rhs.activityTypeCode)||((this.activityTypeCode!= null)&&this.activityTypeCode.equals(rhs.activityTypeCode))))&&((this.activityStatus == rhs.activityStatus)||((this.activityStatus!= null)&&this.activityStatus.equals(rhs.activityStatus))))&&((this.openedTime == rhs.openedTime)||((this.openedTime!= null)&&this.openedTime.equals(rhs.openedTime))))&&((this.doneTime == rhs.doneTime)||((this.doneTime!= null)&&this.doneTime.equals(rhs.doneTime))))&&((this.startTime == rhs.startTime)||((this.startTime!= null)&&this.startTime.equals(rhs.startTime))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.activityDetails == rhs.activityDetails)||((this.activityDetails!= null)&&this.activityDetails.equals(rhs.activityDetails))))&&((this.opened == rhs.opened)||((this.opened!= null)&&this.opened.equals(rhs.opened))))&&((this.priority == rhs.priority)||((this.priority!= null)&&this.priority.equals(rhs.priority))))&&((this.dueTime == rhs.dueTime)||((this.dueTime!= null)&&this.dueTime.equals(rhs.dueTime))))&&((this.dateCreatedTime == rhs.dateCreatedTime)||((this.dateCreatedTime!= null)&&this.dateCreatedTime.equals(rhs.dateCreatedTime))))&&((this.holdingID == rhs.holdingID)||((this.holdingID!= null)&&this.holdingID.equals(rhs.holdingID))))&&((this.lastUpdate == rhs.lastUpdate)||((this.lastUpdate!= null)&&this.lastUpdate.equals(rhs.lastUpdate))))&&((this.closed == rhs.closed)||((this.closed!= null)&&this.closed.equals(rhs.closed))))&&((this.activityStatusDescription == rhs.activityStatusDescription)||((this.activityStatusDescription!= null)&&this.activityStatusDescription.equals(rhs.activityStatusDescription))))&&((this.endTime == rhs.endTime)||((this.endTime!= null)&&this.endTime.equals(rhs.endTime))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.partyID == rhs.partyID)||((this.partyID!= null)&&this.partyID.equals(rhs.partyID))))&&((this.doneDate == rhs.doneDate)||((this.doneDate!= null)&&this.doneDate.equals(rhs.doneDate))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))))&&((this.lastUpdateTime == rhs.lastUpdateTime)||((this.lastUpdateTime!= null)&&this.lastUpdateTime.equals(rhs.lastUpdateTime))));
    }

}
