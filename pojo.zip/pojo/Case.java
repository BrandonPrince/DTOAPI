
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CaseKey",
    "CaseSysKey",
    "CaseType",
    "CaseID",
    "CarrierCode",
    "CaseName",
    "CaseStatus",
    "CaseStatusDate",
    "CaseModificationDate",
    "StartDate",
    "EndDate",
    "NumHoldings",
    "RestrictionInfo",
    "FinancialActivity",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class Case {

    @JsonProperty("CaseKey")
    private CaseKey caseKey;
    @JsonProperty("CaseSysKey")
    private List<Object> caseSysKey = new ArrayList<>();
    @JsonProperty("CaseType")
    private CaseType caseType;
    @JsonProperty("CaseID")
    private String caseID;
    @JsonProperty("CarrierCode")
    private String carrierCode;
    @JsonProperty("CaseName")
    private String caseName;
    @JsonProperty("CaseStatus")
    private CaseStatus caseStatus;
    @JsonProperty("CaseStatusDate")
    private String caseStatusDate;
    @JsonProperty("CaseModificationDate")
    private String caseModificationDate;
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("NumHoldings")
    private Integer numHoldings;
    @JsonProperty("RestrictionInfo")
    private List<Object> restrictionInfo = new ArrayList<>();
    @JsonProperty("FinancialActivity")
    private List<Object> financialActivity = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("CaseKey")
    public CaseKey getCaseKey() {
        return caseKey;
    }

    @JsonProperty("CaseKey")
    public void setCaseKey(CaseKey caseKey) {
        this.caseKey = caseKey;
    }

    public Case withCaseKey(CaseKey caseKey) {
        this.caseKey = caseKey;
        return this;
    }

    @JsonProperty("CaseSysKey")
    public List<Object> getCaseSysKey() {
        return caseSysKey;
    }

    @JsonProperty("CaseSysKey")
    public void setCaseSysKey(List<Object> caseSysKey) {
        this.caseSysKey = caseSysKey;
    }

    public Case withCaseSysKey(List<Object> caseSysKey) {
        this.caseSysKey = caseSysKey;
        return this;
    }

    @JsonProperty("CaseType")
    public CaseType getCaseType() {
        return caseType;
    }

    @JsonProperty("CaseType")
    public void setCaseType(CaseType caseType) {
        this.caseType = caseType;
    }

    public Case withCaseType(CaseType caseType) {
        this.caseType = caseType;
        return this;
    }

    @JsonProperty("CaseID")
    public String getCaseID() {
        return caseID;
    }

    @JsonProperty("CaseID")
    public void setCaseID(String caseID) {
        this.caseID = caseID;
    }

    public Case withCaseID(String caseID) {
        this.caseID = caseID;
        return this;
    }

    @JsonProperty("CarrierCode")
    public String getCarrierCode() {
        return carrierCode;
    }

    @JsonProperty("CarrierCode")
    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    public Case withCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
        return this;
    }

    @JsonProperty("CaseName")
    public String getCaseName() {
        return caseName;
    }

    @JsonProperty("CaseName")
    public void setCaseName(String caseName) {
        this.caseName = caseName;
    }

    public Case withCaseName(String caseName) {
        this.caseName = caseName;
        return this;
    }

    @JsonProperty("CaseStatus")
    public CaseStatus getCaseStatus() {
        return caseStatus;
    }

    @JsonProperty("CaseStatus")
    public void setCaseStatus(CaseStatus caseStatus) {
        this.caseStatus = caseStatus;
    }

    public Case withCaseStatus(CaseStatus caseStatus) {
        this.caseStatus = caseStatus;
        return this;
    }

    @JsonProperty("CaseStatusDate")
    public String getCaseStatusDate() {
        return caseStatusDate;
    }

    @JsonProperty("CaseStatusDate")
    public void setCaseStatusDate(String caseStatusDate) {
        this.caseStatusDate = caseStatusDate;
    }

    public Case withCaseStatusDate(String caseStatusDate) {
        this.caseStatusDate = caseStatusDate;
        return this;
    }

    @JsonProperty("CaseModificationDate")
    public String getCaseModificationDate() {
        return caseModificationDate;
    }

    @JsonProperty("CaseModificationDate")
    public void setCaseModificationDate(String caseModificationDate) {
        this.caseModificationDate = caseModificationDate;
    }

    public Case withCaseModificationDate(String caseModificationDate) {
        this.caseModificationDate = caseModificationDate;
        return this;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public Case withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Case withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("NumHoldings")
    public Integer getNumHoldings() {
        return numHoldings;
    }

    @JsonProperty("NumHoldings")
    public void setNumHoldings(Integer numHoldings) {
        this.numHoldings = numHoldings;
    }

    public Case withNumHoldings(Integer numHoldings) {
        this.numHoldings = numHoldings;
        return this;
    }

    @JsonProperty("RestrictionInfo")
    public List<Object> getRestrictionInfo() {
        return restrictionInfo;
    }

    @JsonProperty("RestrictionInfo")
    public void setRestrictionInfo(List<Object> restrictionInfo) {
        this.restrictionInfo = restrictionInfo;
    }

    public Case withRestrictionInfo(List<Object> restrictionInfo) {
        this.restrictionInfo = restrictionInfo;
        return this;
    }

    @JsonProperty("FinancialActivity")
    public List<Object> getFinancialActivity() {
        return financialActivity;
    }

    @JsonProperty("FinancialActivity")
    public void setFinancialActivity(List<Object> financialActivity) {
        this.financialActivity = financialActivity;
    }

    public Case withFinancialActivity(List<Object> financialActivity) {
        this.financialActivity = financialActivity;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Case withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Case withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public Case withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Case withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Case.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("caseKey");
        sb.append('=');
        sb.append(((this.caseKey == null)?"<null>":this.caseKey));
        sb.append(',');
        sb.append("caseSysKey");
        sb.append('=');
        sb.append(((this.caseSysKey == null)?"<null>":this.caseSysKey));
        sb.append(',');
        sb.append("caseType");
        sb.append('=');
        sb.append(((this.caseType == null)?"<null>":this.caseType));
        sb.append(',');
        sb.append("caseID");
        sb.append('=');
        sb.append(((this.caseID == null)?"<null>":this.caseID));
        sb.append(',');
        sb.append("carrierCode");
        sb.append('=');
        sb.append(((this.carrierCode == null)?"<null>":this.carrierCode));
        sb.append(',');
        sb.append("caseName");
        sb.append('=');
        sb.append(((this.caseName == null)?"<null>":this.caseName));
        sb.append(',');
        sb.append("caseStatus");
        sb.append('=');
        sb.append(((this.caseStatus == null)?"<null>":this.caseStatus));
        sb.append(',');
        sb.append("caseStatusDate");
        sb.append('=');
        sb.append(((this.caseStatusDate == null)?"<null>":this.caseStatusDate));
        sb.append(',');
        sb.append("caseModificationDate");
        sb.append('=');
        sb.append(((this.caseModificationDate == null)?"<null>":this.caseModificationDate));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("numHoldings");
        sb.append('=');
        sb.append(((this.numHoldings == null)?"<null>":this.numHoldings));
        sb.append(',');
        sb.append("restrictionInfo");
        sb.append('=');
        sb.append(((this.restrictionInfo == null)?"<null>":this.restrictionInfo));
        sb.append(',');
        sb.append("financialActivity");
        sb.append('=');
        sb.append(((this.financialActivity == null)?"<null>":this.financialActivity));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.financialActivity == null)? 0 :this.financialActivity.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.caseStatus == null)? 0 :this.caseStatus.hashCode()));
        result = ((result* 31)+((this.numHoldings == null)? 0 :this.numHoldings.hashCode()));
        result = ((result* 31)+((this.restrictionInfo == null)? 0 :this.restrictionInfo.hashCode()));
        result = ((result* 31)+((this.caseType == null)? 0 :this.caseType.hashCode()));
        result = ((result* 31)+((this.caseSysKey == null)? 0 :this.caseSysKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.caseModificationDate == null)? 0 :this.caseModificationDate.hashCode()));
        result = ((result* 31)+((this.caseStatusDate == null)? 0 :this.caseStatusDate.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.caseID == null)? 0 :this.caseID.hashCode()));
        result = ((result* 31)+((this.carrierCode == null)? 0 :this.carrierCode.hashCode()));
        result = ((result* 31)+((this.caseName == null)? 0 :this.caseName.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.caseKey == null)? 0 :this.caseKey.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Case) == false) {
            return false;
        }
        Case rhs = ((Case) other);
        return (((((((((((((((((((this.financialActivity == rhs.financialActivity)||((this.financialActivity!= null)&&this.financialActivity.equals(rhs.financialActivity)))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.caseStatus == rhs.caseStatus)||((this.caseStatus!= null)&&this.caseStatus.equals(rhs.caseStatus))))&&((this.numHoldings == rhs.numHoldings)||((this.numHoldings!= null)&&this.numHoldings.equals(rhs.numHoldings))))&&((this.restrictionInfo == rhs.restrictionInfo)||((this.restrictionInfo!= null)&&this.restrictionInfo.equals(rhs.restrictionInfo))))&&((this.caseType == rhs.caseType)||((this.caseType!= null)&&this.caseType.equals(rhs.caseType))))&&((this.caseSysKey == rhs.caseSysKey)||((this.caseSysKey!= null)&&this.caseSysKey.equals(rhs.caseSysKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.caseModificationDate == rhs.caseModificationDate)||((this.caseModificationDate!= null)&&this.caseModificationDate.equals(rhs.caseModificationDate))))&&((this.caseStatusDate == rhs.caseStatusDate)||((this.caseStatusDate!= null)&&this.caseStatusDate.equals(rhs.caseStatusDate))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.caseID == rhs.caseID)||((this.caseID!= null)&&this.caseID.equals(rhs.caseID))))&&((this.carrierCode == rhs.carrierCode)||((this.carrierCode!= null)&&this.carrierCode.equals(rhs.carrierCode))))&&((this.caseName == rhs.caseName)||((this.caseName!= null)&&this.caseName.equals(rhs.caseName))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.caseKey == rhs.caseKey)||((this.caseKey!= null)&&this.caseKey.equals(rhs.caseKey))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))));
    }

}
