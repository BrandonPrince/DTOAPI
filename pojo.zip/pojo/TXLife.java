
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "UserAuthRequest",
    "TXLifeRequest",
    "UserAuthResponse",
    "TXLifeResponse",
    "TXLifeNotify",
    "OLifEExtension",
    "Version"
})
@Generated("jsonschema2pojo")
public class TXLife {

    @JsonProperty("UserAuthRequest")
    private UserAuthRequest userAuthRequest;
    @JsonProperty("TXLifeRequest")
    private List<Object> tXLifeRequest = new ArrayList<>();
    @JsonProperty("UserAuthResponse")
    private UserAuthResponse userAuthResponse;
    @JsonProperty("TXLifeResponse")
    private List<Object> tXLifeResponse = new ArrayList<>();
    @JsonProperty("TXLifeNotify")
    private List<Object> tXLifeNotify = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("Version")
    private String version;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("UserAuthRequest")
    public UserAuthRequest getUserAuthRequest() {
        return userAuthRequest;
    }

    @JsonProperty("UserAuthRequest")
    public void setUserAuthRequest(UserAuthRequest userAuthRequest) {
        this.userAuthRequest = userAuthRequest;
    }

    public TXLife withUserAuthRequest(UserAuthRequest userAuthRequest) {
        this.userAuthRequest = userAuthRequest;
        return this;
    }

    @JsonProperty("TXLifeRequest")
    public List<Object> getTXLifeRequest() {
        return tXLifeRequest;
    }

    @JsonProperty("TXLifeRequest")
    public void setTXLifeRequest(List<Object> tXLifeRequest) {
        this.tXLifeRequest = tXLifeRequest;
    }

    public TXLife withTXLifeRequest(List<Object> tXLifeRequest) {
        this.tXLifeRequest = tXLifeRequest;
        return this;
    }

    @JsonProperty("UserAuthResponse")
    public UserAuthResponse getUserAuthResponse() {
        return userAuthResponse;
    }

    @JsonProperty("UserAuthResponse")
    public void setUserAuthResponse(UserAuthResponse userAuthResponse) {
        this.userAuthResponse = userAuthResponse;
    }

    public TXLife withUserAuthResponse(UserAuthResponse userAuthResponse) {
        this.userAuthResponse = userAuthResponse;
        return this;
    }

    @JsonProperty("TXLifeResponse")
    public List<Object> getTXLifeResponse() {
        return tXLifeResponse;
    }

    @JsonProperty("TXLifeResponse")
    public void setTXLifeResponse(List<Object> tXLifeResponse) {
        this.tXLifeResponse = tXLifeResponse;
    }

    public TXLife withTXLifeResponse(List<Object> tXLifeResponse) {
        this.tXLifeResponse = tXLifeResponse;
        return this;
    }

    @JsonProperty("TXLifeNotify")
    public List<Object> getTXLifeNotify() {
        return tXLifeNotify;
    }

    @JsonProperty("TXLifeNotify")
    public void setTXLifeNotify(List<Object> tXLifeNotify) {
        this.tXLifeNotify = tXLifeNotify;
    }

    public TXLife withTXLifeNotify(List<Object> tXLifeNotify) {
        this.tXLifeNotify = tXLifeNotify;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public TXLife withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("Version")
    public String getVersion() {
        return version;
    }

    @JsonProperty("Version")
    public void setVersion(String version) {
        this.version = version;
    }

    public TXLife withVersion(String version) {
        this.version = version;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public TXLife withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(TXLife.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("userAuthRequest");
        sb.append('=');
        sb.append(((this.userAuthRequest == null)?"<null>":this.userAuthRequest));
        sb.append(',');
        sb.append("tXLifeRequest");
        sb.append('=');
        sb.append(((this.tXLifeRequest == null)?"<null>":this.tXLifeRequest));
        sb.append(',');
        sb.append("userAuthResponse");
        sb.append('=');
        sb.append(((this.userAuthResponse == null)?"<null>":this.userAuthResponse));
        sb.append(',');
        sb.append("tXLifeResponse");
        sb.append('=');
        sb.append(((this.tXLifeResponse == null)?"<null>":this.tXLifeResponse));
        sb.append(',');
        sb.append("tXLifeNotify");
        sb.append('=');
        sb.append(((this.tXLifeNotify == null)?"<null>":this.tXLifeNotify));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("version");
        sb.append('=');
        sb.append(((this.version == null)?"<null>":this.version));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.userAuthRequest == null)? 0 :this.userAuthRequest.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.tXLifeRequest == null)? 0 :this.tXLifeRequest.hashCode()));
        result = ((result* 31)+((this.tXLifeResponse == null)? 0 :this.tXLifeResponse.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.tXLifeNotify == null)? 0 :this.tXLifeNotify.hashCode()));
        result = ((result* 31)+((this.version == null)? 0 :this.version.hashCode()));
        result = ((result* 31)+((this.userAuthResponse == null)? 0 :this.userAuthResponse.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof TXLife) == false) {
            return false;
        }
        TXLife rhs = ((TXLife) other);
        return (((((((((this.userAuthRequest == rhs.userAuthRequest)||((this.userAuthRequest!= null)&&this.userAuthRequest.equals(rhs.userAuthRequest)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.tXLifeRequest == rhs.tXLifeRequest)||((this.tXLifeRequest!= null)&&this.tXLifeRequest.equals(rhs.tXLifeRequest))))&&((this.tXLifeResponse == rhs.tXLifeResponse)||((this.tXLifeResponse!= null)&&this.tXLifeResponse.equals(rhs.tXLifeResponse))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.tXLifeNotify == rhs.tXLifeNotify)||((this.tXLifeNotify!= null)&&this.tXLifeNotify.equals(rhs.tXLifeNotify))))&&((this.version == rhs.version)||((this.version!= null)&&this.version.equals(rhs.version))))&&((this.userAuthResponse == rhs.userAuthResponse)||((this.userAuthResponse!= null)&&this.userAuthResponse.equals(rhs.userAuthResponse))));
    }

}
