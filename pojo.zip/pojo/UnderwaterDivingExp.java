
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "UnderwaterDivingExpKey",
    "UnderwaterDivingExpSysKey",
    "MaxDepth",
    "MaxDepthDesc",
    "AvgDepth",
    "MaxMinute",
    "AvgMinute",
    "LastDiveDate",
    "LastDivePartialDate",
    "FutureDivingInd",
    "DivingType",
    "CertDiverInd",
    "CertificationLevel",
    "CertificationDesc",
    "CertifiedOrg",
    "DiveAloneInd",
    "DiveAloneDesc",
    "ExperimentalEquipmentInd",
    "ExperimentalEquipmentDesc",
    "CraftAssembly",
    "DivingLocationCountryDesc",
    "DivePurpose",
    "DiveDetail",
    "DiveLocation",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class UnderwaterDivingExp {

    @JsonProperty("UnderwaterDivingExpKey")
    private UnderwaterDivingExpKey underwaterDivingExpKey;
    @JsonProperty("UnderwaterDivingExpSysKey")
    private List<Object> underwaterDivingExpSysKey = new ArrayList<>();
    @JsonProperty("MaxDepth")
    private Integer maxDepth;
    @JsonProperty("MaxDepthDesc")
    private String maxDepthDesc;
    @JsonProperty("AvgDepth")
    private Integer avgDepth;
    @JsonProperty("MaxMinute")
    private Integer maxMinute;
    @JsonProperty("AvgMinute")
    private Integer avgMinute;
    @JsonProperty("LastDiveDate")
    private String lastDiveDate;
    @JsonProperty("LastDivePartialDate")
    private String lastDivePartialDate;
    @JsonProperty("FutureDivingInd")
    private FutureDivingInd futureDivingInd;
    @JsonProperty("DivingType")
    private DivingType divingType;
    @JsonProperty("CertDiverInd")
    private CertDiverInd certDiverInd;
    @JsonProperty("CertificationLevel")
    private CertificationLevel certificationLevel;
    @JsonProperty("CertificationDesc")
    private String certificationDesc;
    @JsonProperty("CertifiedOrg")
    private String certifiedOrg;
    @JsonProperty("DiveAloneInd")
    private DiveAloneInd diveAloneInd;
    @JsonProperty("DiveAloneDesc")
    private String diveAloneDesc;
    @JsonProperty("ExperimentalEquipmentInd")
    private ExperimentalEquipmentInd experimentalEquipmentInd;
    @JsonProperty("ExperimentalEquipmentDesc")
    private String experimentalEquipmentDesc;
    @JsonProperty("CraftAssembly")
    private CraftAssembly craftAssembly;
    @JsonProperty("DivingLocationCountryDesc")
    private String divingLocationCountryDesc;
    @JsonProperty("DivePurpose")
    private List<Object> divePurpose = new ArrayList<>();
    @JsonProperty("DiveDetail")
    private List<Object> diveDetail = new ArrayList<>();
    @JsonProperty("DiveLocation")
    private List<Object> diveLocation = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("UnderwaterDivingExpKey")
    public UnderwaterDivingExpKey getUnderwaterDivingExpKey() {
        return underwaterDivingExpKey;
    }

    @JsonProperty("UnderwaterDivingExpKey")
    public void setUnderwaterDivingExpKey(UnderwaterDivingExpKey underwaterDivingExpKey) {
        this.underwaterDivingExpKey = underwaterDivingExpKey;
    }

    public UnderwaterDivingExp withUnderwaterDivingExpKey(UnderwaterDivingExpKey underwaterDivingExpKey) {
        this.underwaterDivingExpKey = underwaterDivingExpKey;
        return this;
    }

    @JsonProperty("UnderwaterDivingExpSysKey")
    public List<Object> getUnderwaterDivingExpSysKey() {
        return underwaterDivingExpSysKey;
    }

    @JsonProperty("UnderwaterDivingExpSysKey")
    public void setUnderwaterDivingExpSysKey(List<Object> underwaterDivingExpSysKey) {
        this.underwaterDivingExpSysKey = underwaterDivingExpSysKey;
    }

    public UnderwaterDivingExp withUnderwaterDivingExpSysKey(List<Object> underwaterDivingExpSysKey) {
        this.underwaterDivingExpSysKey = underwaterDivingExpSysKey;
        return this;
    }

    @JsonProperty("MaxDepth")
    public Integer getMaxDepth() {
        return maxDepth;
    }

    @JsonProperty("MaxDepth")
    public void setMaxDepth(Integer maxDepth) {
        this.maxDepth = maxDepth;
    }

    public UnderwaterDivingExp withMaxDepth(Integer maxDepth) {
        this.maxDepth = maxDepth;
        return this;
    }

    @JsonProperty("MaxDepthDesc")
    public String getMaxDepthDesc() {
        return maxDepthDesc;
    }

    @JsonProperty("MaxDepthDesc")
    public void setMaxDepthDesc(String maxDepthDesc) {
        this.maxDepthDesc = maxDepthDesc;
    }

    public UnderwaterDivingExp withMaxDepthDesc(String maxDepthDesc) {
        this.maxDepthDesc = maxDepthDesc;
        return this;
    }

    @JsonProperty("AvgDepth")
    public Integer getAvgDepth() {
        return avgDepth;
    }

    @JsonProperty("AvgDepth")
    public void setAvgDepth(Integer avgDepth) {
        this.avgDepth = avgDepth;
    }

    public UnderwaterDivingExp withAvgDepth(Integer avgDepth) {
        this.avgDepth = avgDepth;
        return this;
    }

    @JsonProperty("MaxMinute")
    public Integer getMaxMinute() {
        return maxMinute;
    }

    @JsonProperty("MaxMinute")
    public void setMaxMinute(Integer maxMinute) {
        this.maxMinute = maxMinute;
    }

    public UnderwaterDivingExp withMaxMinute(Integer maxMinute) {
        this.maxMinute = maxMinute;
        return this;
    }

    @JsonProperty("AvgMinute")
    public Integer getAvgMinute() {
        return avgMinute;
    }

    @JsonProperty("AvgMinute")
    public void setAvgMinute(Integer avgMinute) {
        this.avgMinute = avgMinute;
    }

    public UnderwaterDivingExp withAvgMinute(Integer avgMinute) {
        this.avgMinute = avgMinute;
        return this;
    }

    @JsonProperty("LastDiveDate")
    public String getLastDiveDate() {
        return lastDiveDate;
    }

    @JsonProperty("LastDiveDate")
    public void setLastDiveDate(String lastDiveDate) {
        this.lastDiveDate = lastDiveDate;
    }

    public UnderwaterDivingExp withLastDiveDate(String lastDiveDate) {
        this.lastDiveDate = lastDiveDate;
        return this;
    }

    @JsonProperty("LastDivePartialDate")
    public String getLastDivePartialDate() {
        return lastDivePartialDate;
    }

    @JsonProperty("LastDivePartialDate")
    public void setLastDivePartialDate(String lastDivePartialDate) {
        this.lastDivePartialDate = lastDivePartialDate;
    }

    public UnderwaterDivingExp withLastDivePartialDate(String lastDivePartialDate) {
        this.lastDivePartialDate = lastDivePartialDate;
        return this;
    }

    @JsonProperty("FutureDivingInd")
    public FutureDivingInd getFutureDivingInd() {
        return futureDivingInd;
    }

    @JsonProperty("FutureDivingInd")
    public void setFutureDivingInd(FutureDivingInd futureDivingInd) {
        this.futureDivingInd = futureDivingInd;
    }

    public UnderwaterDivingExp withFutureDivingInd(FutureDivingInd futureDivingInd) {
        this.futureDivingInd = futureDivingInd;
        return this;
    }

    @JsonProperty("DivingType")
    public DivingType getDivingType() {
        return divingType;
    }

    @JsonProperty("DivingType")
    public void setDivingType(DivingType divingType) {
        this.divingType = divingType;
    }

    public UnderwaterDivingExp withDivingType(DivingType divingType) {
        this.divingType = divingType;
        return this;
    }

    @JsonProperty("CertDiverInd")
    public CertDiverInd getCertDiverInd() {
        return certDiverInd;
    }

    @JsonProperty("CertDiverInd")
    public void setCertDiverInd(CertDiverInd certDiverInd) {
        this.certDiverInd = certDiverInd;
    }

    public UnderwaterDivingExp withCertDiverInd(CertDiverInd certDiverInd) {
        this.certDiverInd = certDiverInd;
        return this;
    }

    @JsonProperty("CertificationLevel")
    public CertificationLevel getCertificationLevel() {
        return certificationLevel;
    }

    @JsonProperty("CertificationLevel")
    public void setCertificationLevel(CertificationLevel certificationLevel) {
        this.certificationLevel = certificationLevel;
    }

    public UnderwaterDivingExp withCertificationLevel(CertificationLevel certificationLevel) {
        this.certificationLevel = certificationLevel;
        return this;
    }

    @JsonProperty("CertificationDesc")
    public String getCertificationDesc() {
        return certificationDesc;
    }

    @JsonProperty("CertificationDesc")
    public void setCertificationDesc(String certificationDesc) {
        this.certificationDesc = certificationDesc;
    }

    public UnderwaterDivingExp withCertificationDesc(String certificationDesc) {
        this.certificationDesc = certificationDesc;
        return this;
    }

    @JsonProperty("CertifiedOrg")
    public String getCertifiedOrg() {
        return certifiedOrg;
    }

    @JsonProperty("CertifiedOrg")
    public void setCertifiedOrg(String certifiedOrg) {
        this.certifiedOrg = certifiedOrg;
    }

    public UnderwaterDivingExp withCertifiedOrg(String certifiedOrg) {
        this.certifiedOrg = certifiedOrg;
        return this;
    }

    @JsonProperty("DiveAloneInd")
    public DiveAloneInd getDiveAloneInd() {
        return diveAloneInd;
    }

    @JsonProperty("DiveAloneInd")
    public void setDiveAloneInd(DiveAloneInd diveAloneInd) {
        this.diveAloneInd = diveAloneInd;
    }

    public UnderwaterDivingExp withDiveAloneInd(DiveAloneInd diveAloneInd) {
        this.diveAloneInd = diveAloneInd;
        return this;
    }

    @JsonProperty("DiveAloneDesc")
    public String getDiveAloneDesc() {
        return diveAloneDesc;
    }

    @JsonProperty("DiveAloneDesc")
    public void setDiveAloneDesc(String diveAloneDesc) {
        this.diveAloneDesc = diveAloneDesc;
    }

    public UnderwaterDivingExp withDiveAloneDesc(String diveAloneDesc) {
        this.diveAloneDesc = diveAloneDesc;
        return this;
    }

    @JsonProperty("ExperimentalEquipmentInd")
    public ExperimentalEquipmentInd getExperimentalEquipmentInd() {
        return experimentalEquipmentInd;
    }

    @JsonProperty("ExperimentalEquipmentInd")
    public void setExperimentalEquipmentInd(ExperimentalEquipmentInd experimentalEquipmentInd) {
        this.experimentalEquipmentInd = experimentalEquipmentInd;
    }

    public UnderwaterDivingExp withExperimentalEquipmentInd(ExperimentalEquipmentInd experimentalEquipmentInd) {
        this.experimentalEquipmentInd = experimentalEquipmentInd;
        return this;
    }

    @JsonProperty("ExperimentalEquipmentDesc")
    public String getExperimentalEquipmentDesc() {
        return experimentalEquipmentDesc;
    }

    @JsonProperty("ExperimentalEquipmentDesc")
    public void setExperimentalEquipmentDesc(String experimentalEquipmentDesc) {
        this.experimentalEquipmentDesc = experimentalEquipmentDesc;
    }

    public UnderwaterDivingExp withExperimentalEquipmentDesc(String experimentalEquipmentDesc) {
        this.experimentalEquipmentDesc = experimentalEquipmentDesc;
        return this;
    }

    @JsonProperty("CraftAssembly")
    public CraftAssembly getCraftAssembly() {
        return craftAssembly;
    }

    @JsonProperty("CraftAssembly")
    public void setCraftAssembly(CraftAssembly craftAssembly) {
        this.craftAssembly = craftAssembly;
    }

    public UnderwaterDivingExp withCraftAssembly(CraftAssembly craftAssembly) {
        this.craftAssembly = craftAssembly;
        return this;
    }

    @JsonProperty("DivingLocationCountryDesc")
    public String getDivingLocationCountryDesc() {
        return divingLocationCountryDesc;
    }

    @JsonProperty("DivingLocationCountryDesc")
    public void setDivingLocationCountryDesc(String divingLocationCountryDesc) {
        this.divingLocationCountryDesc = divingLocationCountryDesc;
    }

    public UnderwaterDivingExp withDivingLocationCountryDesc(String divingLocationCountryDesc) {
        this.divingLocationCountryDesc = divingLocationCountryDesc;
        return this;
    }

    @JsonProperty("DivePurpose")
    public List<Object> getDivePurpose() {
        return divePurpose;
    }

    @JsonProperty("DivePurpose")
    public void setDivePurpose(List<Object> divePurpose) {
        this.divePurpose = divePurpose;
    }

    public UnderwaterDivingExp withDivePurpose(List<Object> divePurpose) {
        this.divePurpose = divePurpose;
        return this;
    }

    @JsonProperty("DiveDetail")
    public List<Object> getDiveDetail() {
        return diveDetail;
    }

    @JsonProperty("DiveDetail")
    public void setDiveDetail(List<Object> diveDetail) {
        this.diveDetail = diveDetail;
    }

    public UnderwaterDivingExp withDiveDetail(List<Object> diveDetail) {
        this.diveDetail = diveDetail;
        return this;
    }

    @JsonProperty("DiveLocation")
    public List<Object> getDiveLocation() {
        return diveLocation;
    }

    @JsonProperty("DiveLocation")
    public void setDiveLocation(List<Object> diveLocation) {
        this.diveLocation = diveLocation;
    }

    public UnderwaterDivingExp withDiveLocation(List<Object> diveLocation) {
        this.diveLocation = diveLocation;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public UnderwaterDivingExp withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public UnderwaterDivingExp withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public UnderwaterDivingExp withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public UnderwaterDivingExp withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(UnderwaterDivingExp.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("underwaterDivingExpKey");
        sb.append('=');
        sb.append(((this.underwaterDivingExpKey == null)?"<null>":this.underwaterDivingExpKey));
        sb.append(',');
        sb.append("underwaterDivingExpSysKey");
        sb.append('=');
        sb.append(((this.underwaterDivingExpSysKey == null)?"<null>":this.underwaterDivingExpSysKey));
        sb.append(',');
        sb.append("maxDepth");
        sb.append('=');
        sb.append(((this.maxDepth == null)?"<null>":this.maxDepth));
        sb.append(',');
        sb.append("maxDepthDesc");
        sb.append('=');
        sb.append(((this.maxDepthDesc == null)?"<null>":this.maxDepthDesc));
        sb.append(',');
        sb.append("avgDepth");
        sb.append('=');
        sb.append(((this.avgDepth == null)?"<null>":this.avgDepth));
        sb.append(',');
        sb.append("maxMinute");
        sb.append('=');
        sb.append(((this.maxMinute == null)?"<null>":this.maxMinute));
        sb.append(',');
        sb.append("avgMinute");
        sb.append('=');
        sb.append(((this.avgMinute == null)?"<null>":this.avgMinute));
        sb.append(',');
        sb.append("lastDiveDate");
        sb.append('=');
        sb.append(((this.lastDiveDate == null)?"<null>":this.lastDiveDate));
        sb.append(',');
        sb.append("lastDivePartialDate");
        sb.append('=');
        sb.append(((this.lastDivePartialDate == null)?"<null>":this.lastDivePartialDate));
        sb.append(',');
        sb.append("futureDivingInd");
        sb.append('=');
        sb.append(((this.futureDivingInd == null)?"<null>":this.futureDivingInd));
        sb.append(',');
        sb.append("divingType");
        sb.append('=');
        sb.append(((this.divingType == null)?"<null>":this.divingType));
        sb.append(',');
        sb.append("certDiverInd");
        sb.append('=');
        sb.append(((this.certDiverInd == null)?"<null>":this.certDiverInd));
        sb.append(',');
        sb.append("certificationLevel");
        sb.append('=');
        sb.append(((this.certificationLevel == null)?"<null>":this.certificationLevel));
        sb.append(',');
        sb.append("certificationDesc");
        sb.append('=');
        sb.append(((this.certificationDesc == null)?"<null>":this.certificationDesc));
        sb.append(',');
        sb.append("certifiedOrg");
        sb.append('=');
        sb.append(((this.certifiedOrg == null)?"<null>":this.certifiedOrg));
        sb.append(',');
        sb.append("diveAloneInd");
        sb.append('=');
        sb.append(((this.diveAloneInd == null)?"<null>":this.diveAloneInd));
        sb.append(',');
        sb.append("diveAloneDesc");
        sb.append('=');
        sb.append(((this.diveAloneDesc == null)?"<null>":this.diveAloneDesc));
        sb.append(',');
        sb.append("experimentalEquipmentInd");
        sb.append('=');
        sb.append(((this.experimentalEquipmentInd == null)?"<null>":this.experimentalEquipmentInd));
        sb.append(',');
        sb.append("experimentalEquipmentDesc");
        sb.append('=');
        sb.append(((this.experimentalEquipmentDesc == null)?"<null>":this.experimentalEquipmentDesc));
        sb.append(',');
        sb.append("craftAssembly");
        sb.append('=');
        sb.append(((this.craftAssembly == null)?"<null>":this.craftAssembly));
        sb.append(',');
        sb.append("divingLocationCountryDesc");
        sb.append('=');
        sb.append(((this.divingLocationCountryDesc == null)?"<null>":this.divingLocationCountryDesc));
        sb.append(',');
        sb.append("divePurpose");
        sb.append('=');
        sb.append(((this.divePurpose == null)?"<null>":this.divePurpose));
        sb.append(',');
        sb.append("diveDetail");
        sb.append('=');
        sb.append(((this.diveDetail == null)?"<null>":this.diveDetail));
        sb.append(',');
        sb.append("diveLocation");
        sb.append('=');
        sb.append(((this.diveLocation == null)?"<null>":this.diveLocation));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.certificationDesc == null)? 0 :this.certificationDesc.hashCode()));
        result = ((result* 31)+((this.certDiverInd == null)? 0 :this.certDiverInd.hashCode()));
        result = ((result* 31)+((this.divingType == null)? 0 :this.divingType.hashCode()));
        result = ((result* 31)+((this.certificationLevel == null)? 0 :this.certificationLevel.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.diveDetail == null)? 0 :this.diveDetail.hashCode()));
        result = ((result* 31)+((this.futureDivingInd == null)? 0 :this.futureDivingInd.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.certifiedOrg == null)? 0 :this.certifiedOrg.hashCode()));
        result = ((result* 31)+((this.diveAloneInd == null)? 0 :this.diveAloneInd.hashCode()));
        result = ((result* 31)+((this.maxMinute == null)? 0 :this.maxMinute.hashCode()));
        result = ((result* 31)+((this.lastDiveDate == null)? 0 :this.lastDiveDate.hashCode()));
        result = ((result* 31)+((this.lastDivePartialDate == null)? 0 :this.lastDivePartialDate.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.divePurpose == null)? 0 :this.divePurpose.hashCode()));
        result = ((result* 31)+((this.divingLocationCountryDesc == null)? 0 :this.divingLocationCountryDesc.hashCode()));
        result = ((result* 31)+((this.experimentalEquipmentDesc == null)? 0 :this.experimentalEquipmentDesc.hashCode()));
        result = ((result* 31)+((this.craftAssembly == null)? 0 :this.craftAssembly.hashCode()));
        result = ((result* 31)+((this.underwaterDivingExpKey == null)? 0 :this.underwaterDivingExpKey.hashCode()));
        result = ((result* 31)+((this.experimentalEquipmentInd == null)? 0 :this.experimentalEquipmentInd.hashCode()));
        result = ((result* 31)+((this.maxDepth == null)? 0 :this.maxDepth.hashCode()));
        result = ((result* 31)+((this.maxDepthDesc == null)? 0 :this.maxDepthDesc.hashCode()));
        result = ((result* 31)+((this.avgDepth == null)? 0 :this.avgDepth.hashCode()));
        result = ((result* 31)+((this.underwaterDivingExpSysKey == null)? 0 :this.underwaterDivingExpSysKey.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.diveLocation == null)? 0 :this.diveLocation.hashCode()));
        result = ((result* 31)+((this.avgMinute == null)? 0 :this.avgMinute.hashCode()));
        result = ((result* 31)+((this.diveAloneDesc == null)? 0 :this.diveAloneDesc.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UnderwaterDivingExp) == false) {
            return false;
        }
        UnderwaterDivingExp rhs = ((UnderwaterDivingExp) other);
        return (((((((((((((((((((((((((((((this.certificationDesc == rhs.certificationDesc)||((this.certificationDesc!= null)&&this.certificationDesc.equals(rhs.certificationDesc)))&&((this.certDiverInd == rhs.certDiverInd)||((this.certDiverInd!= null)&&this.certDiverInd.equals(rhs.certDiverInd))))&&((this.divingType == rhs.divingType)||((this.divingType!= null)&&this.divingType.equals(rhs.divingType))))&&((this.certificationLevel == rhs.certificationLevel)||((this.certificationLevel!= null)&&this.certificationLevel.equals(rhs.certificationLevel))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.diveDetail == rhs.diveDetail)||((this.diveDetail!= null)&&this.diveDetail.equals(rhs.diveDetail))))&&((this.futureDivingInd == rhs.futureDivingInd)||((this.futureDivingInd!= null)&&this.futureDivingInd.equals(rhs.futureDivingInd))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.certifiedOrg == rhs.certifiedOrg)||((this.certifiedOrg!= null)&&this.certifiedOrg.equals(rhs.certifiedOrg))))&&((this.diveAloneInd == rhs.diveAloneInd)||((this.diveAloneInd!= null)&&this.diveAloneInd.equals(rhs.diveAloneInd))))&&((this.maxMinute == rhs.maxMinute)||((this.maxMinute!= null)&&this.maxMinute.equals(rhs.maxMinute))))&&((this.lastDiveDate == rhs.lastDiveDate)||((this.lastDiveDate!= null)&&this.lastDiveDate.equals(rhs.lastDiveDate))))&&((this.lastDivePartialDate == rhs.lastDivePartialDate)||((this.lastDivePartialDate!= null)&&this.lastDivePartialDate.equals(rhs.lastDivePartialDate))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.divePurpose == rhs.divePurpose)||((this.divePurpose!= null)&&this.divePurpose.equals(rhs.divePurpose))))&&((this.divingLocationCountryDesc == rhs.divingLocationCountryDesc)||((this.divingLocationCountryDesc!= null)&&this.divingLocationCountryDesc.equals(rhs.divingLocationCountryDesc))))&&((this.experimentalEquipmentDesc == rhs.experimentalEquipmentDesc)||((this.experimentalEquipmentDesc!= null)&&this.experimentalEquipmentDesc.equals(rhs.experimentalEquipmentDesc))))&&((this.craftAssembly == rhs.craftAssembly)||((this.craftAssembly!= null)&&this.craftAssembly.equals(rhs.craftAssembly))))&&((this.underwaterDivingExpKey == rhs.underwaterDivingExpKey)||((this.underwaterDivingExpKey!= null)&&this.underwaterDivingExpKey.equals(rhs.underwaterDivingExpKey))))&&((this.experimentalEquipmentInd == rhs.experimentalEquipmentInd)||((this.experimentalEquipmentInd!= null)&&this.experimentalEquipmentInd.equals(rhs.experimentalEquipmentInd))))&&((this.maxDepth == rhs.maxDepth)||((this.maxDepth!= null)&&this.maxDepth.equals(rhs.maxDepth))))&&((this.maxDepthDesc == rhs.maxDepthDesc)||((this.maxDepthDesc!= null)&&this.maxDepthDesc.equals(rhs.maxDepthDesc))))&&((this.avgDepth == rhs.avgDepth)||((this.avgDepth!= null)&&this.avgDepth.equals(rhs.avgDepth))))&&((this.underwaterDivingExpSysKey == rhs.underwaterDivingExpSysKey)||((this.underwaterDivingExpSysKey!= null)&&this.underwaterDivingExpSysKey.equals(rhs.underwaterDivingExpSysKey))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.diveLocation == rhs.diveLocation)||((this.diveLocation!= null)&&this.diveLocation.equals(rhs.diveLocation))))&&((this.avgMinute == rhs.avgMinute)||((this.avgMinute!= null)&&this.avgMinute.equals(rhs.avgMinute))))&&((this.diveAloneDesc == rhs.diveAloneDesc)||((this.diveAloneDesc!= null)&&this.diveAloneDesc.equals(rhs.diveAloneDesc))));
    }

}
