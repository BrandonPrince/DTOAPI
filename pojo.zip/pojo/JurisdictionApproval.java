
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "JurisdictionApprovalKey",
    "JurisdictionApprovalSysKey",
    "Jurisdiction",
    "Name",
    "SaleEffectiveDate",
    "SaleExpirationDate",
    "InforceExclusionCalendarDate",
    "InforceExclusionContractDate",
    "NoNewMoneyDate",
    "FiledFormNumber",
    "ContractSitusCanDifferInd",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class JurisdictionApproval {

    @JsonProperty("JurisdictionApprovalKey")
    private JurisdictionApprovalKey jurisdictionApprovalKey;
    @JsonProperty("JurisdictionApprovalSysKey")
    private List<Object> jurisdictionApprovalSysKey = new ArrayList<>();
    @JsonProperty("Jurisdiction")
    private Jurisdiction jurisdiction;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("SaleEffectiveDate")
    private String saleEffectiveDate;
    @JsonProperty("SaleExpirationDate")
    private String saleExpirationDate;
    @JsonProperty("InforceExclusionCalendarDate")
    private String inforceExclusionCalendarDate;
    @JsonProperty("InforceExclusionContractDate")
    private String inforceExclusionContractDate;
    @JsonProperty("NoNewMoneyDate")
    private String noNewMoneyDate;
    @JsonProperty("FiledFormNumber")
    private String filedFormNumber;
    @JsonProperty("ContractSitusCanDifferInd")
    private ContractSitusCanDifferInd contractSitusCanDifferInd;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("JurisdictionApprovalKey")
    public JurisdictionApprovalKey getJurisdictionApprovalKey() {
        return jurisdictionApprovalKey;
    }

    @JsonProperty("JurisdictionApprovalKey")
    public void setJurisdictionApprovalKey(JurisdictionApprovalKey jurisdictionApprovalKey) {
        this.jurisdictionApprovalKey = jurisdictionApprovalKey;
    }

    public JurisdictionApproval withJurisdictionApprovalKey(JurisdictionApprovalKey jurisdictionApprovalKey) {
        this.jurisdictionApprovalKey = jurisdictionApprovalKey;
        return this;
    }

    @JsonProperty("JurisdictionApprovalSysKey")
    public List<Object> getJurisdictionApprovalSysKey() {
        return jurisdictionApprovalSysKey;
    }

    @JsonProperty("JurisdictionApprovalSysKey")
    public void setJurisdictionApprovalSysKey(List<Object> jurisdictionApprovalSysKey) {
        this.jurisdictionApprovalSysKey = jurisdictionApprovalSysKey;
    }

    public JurisdictionApproval withJurisdictionApprovalSysKey(List<Object> jurisdictionApprovalSysKey) {
        this.jurisdictionApprovalSysKey = jurisdictionApprovalSysKey;
        return this;
    }

    @JsonProperty("Jurisdiction")
    public Jurisdiction getJurisdiction() {
        return jurisdiction;
    }

    @JsonProperty("Jurisdiction")
    public void setJurisdiction(Jurisdiction jurisdiction) {
        this.jurisdiction = jurisdiction;
    }

    public JurisdictionApproval withJurisdiction(Jurisdiction jurisdiction) {
        this.jurisdiction = jurisdiction;
        return this;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    public JurisdictionApproval withName(String name) {
        this.name = name;
        return this;
    }

    @JsonProperty("SaleEffectiveDate")
    public String getSaleEffectiveDate() {
        return saleEffectiveDate;
    }

    @JsonProperty("SaleEffectiveDate")
    public void setSaleEffectiveDate(String saleEffectiveDate) {
        this.saleEffectiveDate = saleEffectiveDate;
    }

    public JurisdictionApproval withSaleEffectiveDate(String saleEffectiveDate) {
        this.saleEffectiveDate = saleEffectiveDate;
        return this;
    }

    @JsonProperty("SaleExpirationDate")
    public String getSaleExpirationDate() {
        return saleExpirationDate;
    }

    @JsonProperty("SaleExpirationDate")
    public void setSaleExpirationDate(String saleExpirationDate) {
        this.saleExpirationDate = saleExpirationDate;
    }

    public JurisdictionApproval withSaleExpirationDate(String saleExpirationDate) {
        this.saleExpirationDate = saleExpirationDate;
        return this;
    }

    @JsonProperty("InforceExclusionCalendarDate")
    public String getInforceExclusionCalendarDate() {
        return inforceExclusionCalendarDate;
    }

    @JsonProperty("InforceExclusionCalendarDate")
    public void setInforceExclusionCalendarDate(String inforceExclusionCalendarDate) {
        this.inforceExclusionCalendarDate = inforceExclusionCalendarDate;
    }

    public JurisdictionApproval withInforceExclusionCalendarDate(String inforceExclusionCalendarDate) {
        this.inforceExclusionCalendarDate = inforceExclusionCalendarDate;
        return this;
    }

    @JsonProperty("InforceExclusionContractDate")
    public String getInforceExclusionContractDate() {
        return inforceExclusionContractDate;
    }

    @JsonProperty("InforceExclusionContractDate")
    public void setInforceExclusionContractDate(String inforceExclusionContractDate) {
        this.inforceExclusionContractDate = inforceExclusionContractDate;
    }

    public JurisdictionApproval withInforceExclusionContractDate(String inforceExclusionContractDate) {
        this.inforceExclusionContractDate = inforceExclusionContractDate;
        return this;
    }

    @JsonProperty("NoNewMoneyDate")
    public String getNoNewMoneyDate() {
        return noNewMoneyDate;
    }

    @JsonProperty("NoNewMoneyDate")
    public void setNoNewMoneyDate(String noNewMoneyDate) {
        this.noNewMoneyDate = noNewMoneyDate;
    }

    public JurisdictionApproval withNoNewMoneyDate(String noNewMoneyDate) {
        this.noNewMoneyDate = noNewMoneyDate;
        return this;
    }

    @JsonProperty("FiledFormNumber")
    public String getFiledFormNumber() {
        return filedFormNumber;
    }

    @JsonProperty("FiledFormNumber")
    public void setFiledFormNumber(String filedFormNumber) {
        this.filedFormNumber = filedFormNumber;
    }

    public JurisdictionApproval withFiledFormNumber(String filedFormNumber) {
        this.filedFormNumber = filedFormNumber;
        return this;
    }

    @JsonProperty("ContractSitusCanDifferInd")
    public ContractSitusCanDifferInd getContractSitusCanDifferInd() {
        return contractSitusCanDifferInd;
    }

    @JsonProperty("ContractSitusCanDifferInd")
    public void setContractSitusCanDifferInd(ContractSitusCanDifferInd contractSitusCanDifferInd) {
        this.contractSitusCanDifferInd = contractSitusCanDifferInd;
    }

    public JurisdictionApproval withContractSitusCanDifferInd(ContractSitusCanDifferInd contractSitusCanDifferInd) {
        this.contractSitusCanDifferInd = contractSitusCanDifferInd;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public JurisdictionApproval withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public JurisdictionApproval withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public JurisdictionApproval withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public JurisdictionApproval withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(JurisdictionApproval.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("jurisdictionApprovalKey");
        sb.append('=');
        sb.append(((this.jurisdictionApprovalKey == null)?"<null>":this.jurisdictionApprovalKey));
        sb.append(',');
        sb.append("jurisdictionApprovalSysKey");
        sb.append('=');
        sb.append(((this.jurisdictionApprovalSysKey == null)?"<null>":this.jurisdictionApprovalSysKey));
        sb.append(',');
        sb.append("jurisdiction");
        sb.append('=');
        sb.append(((this.jurisdiction == null)?"<null>":this.jurisdiction));
        sb.append(',');
        sb.append("name");
        sb.append('=');
        sb.append(((this.name == null)?"<null>":this.name));
        sb.append(',');
        sb.append("saleEffectiveDate");
        sb.append('=');
        sb.append(((this.saleEffectiveDate == null)?"<null>":this.saleEffectiveDate));
        sb.append(',');
        sb.append("saleExpirationDate");
        sb.append('=');
        sb.append(((this.saleExpirationDate == null)?"<null>":this.saleExpirationDate));
        sb.append(',');
        sb.append("inforceExclusionCalendarDate");
        sb.append('=');
        sb.append(((this.inforceExclusionCalendarDate == null)?"<null>":this.inforceExclusionCalendarDate));
        sb.append(',');
        sb.append("inforceExclusionContractDate");
        sb.append('=');
        sb.append(((this.inforceExclusionContractDate == null)?"<null>":this.inforceExclusionContractDate));
        sb.append(',');
        sb.append("noNewMoneyDate");
        sb.append('=');
        sb.append(((this.noNewMoneyDate == null)?"<null>":this.noNewMoneyDate));
        sb.append(',');
        sb.append("filedFormNumber");
        sb.append('=');
        sb.append(((this.filedFormNumber == null)?"<null>":this.filedFormNumber));
        sb.append(',');
        sb.append("contractSitusCanDifferInd");
        sb.append('=');
        sb.append(((this.contractSitusCanDifferInd == null)?"<null>":this.contractSitusCanDifferInd));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.saleEffectiveDate == null)? 0 :this.saleEffectiveDate.hashCode()));
        result = ((result* 31)+((this.inforceExclusionContractDate == null)? 0 :this.inforceExclusionContractDate.hashCode()));
        result = ((result* 31)+((this.jurisdiction == null)? 0 :this.jurisdiction.hashCode()));
        result = ((result* 31)+((this.inforceExclusionCalendarDate == null)? 0 :this.inforceExclusionCalendarDate.hashCode()));
        result = ((result* 31)+((this.noNewMoneyDate == null)? 0 :this.noNewMoneyDate.hashCode()));
        result = ((result* 31)+((this.saleExpirationDate == null)? 0 :this.saleExpirationDate.hashCode()));
        result = ((result* 31)+((this.contractSitusCanDifferInd == null)? 0 :this.contractSitusCanDifferInd.hashCode()));
        result = ((result* 31)+((this.jurisdictionApprovalKey == null)? 0 :this.jurisdictionApprovalKey.hashCode()));
        result = ((result* 31)+((this.jurisdictionApprovalSysKey == null)? 0 :this.jurisdictionApprovalSysKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.filedFormNumber == null)? 0 :this.filedFormNumber.hashCode()));
        result = ((result* 31)+((this.name == null)? 0 :this.name.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof JurisdictionApproval) == false) {
            return false;
        }
        JurisdictionApproval rhs = ((JurisdictionApproval) other);
        return ((((((((((((((((this.saleEffectiveDate == rhs.saleEffectiveDate)||((this.saleEffectiveDate!= null)&&this.saleEffectiveDate.equals(rhs.saleEffectiveDate)))&&((this.inforceExclusionContractDate == rhs.inforceExclusionContractDate)||((this.inforceExclusionContractDate!= null)&&this.inforceExclusionContractDate.equals(rhs.inforceExclusionContractDate))))&&((this.jurisdiction == rhs.jurisdiction)||((this.jurisdiction!= null)&&this.jurisdiction.equals(rhs.jurisdiction))))&&((this.inforceExclusionCalendarDate == rhs.inforceExclusionCalendarDate)||((this.inforceExclusionCalendarDate!= null)&&this.inforceExclusionCalendarDate.equals(rhs.inforceExclusionCalendarDate))))&&((this.noNewMoneyDate == rhs.noNewMoneyDate)||((this.noNewMoneyDate!= null)&&this.noNewMoneyDate.equals(rhs.noNewMoneyDate))))&&((this.saleExpirationDate == rhs.saleExpirationDate)||((this.saleExpirationDate!= null)&&this.saleExpirationDate.equals(rhs.saleExpirationDate))))&&((this.contractSitusCanDifferInd == rhs.contractSitusCanDifferInd)||((this.contractSitusCanDifferInd!= null)&&this.contractSitusCanDifferInd.equals(rhs.contractSitusCanDifferInd))))&&((this.jurisdictionApprovalKey == rhs.jurisdictionApprovalKey)||((this.jurisdictionApprovalKey!= null)&&this.jurisdictionApprovalKey.equals(rhs.jurisdictionApprovalKey))))&&((this.jurisdictionApprovalSysKey == rhs.jurisdictionApprovalSysKey)||((this.jurisdictionApprovalSysKey!= null)&&this.jurisdictionApprovalSysKey.equals(rhs.jurisdictionApprovalSysKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.filedFormNumber == rhs.filedFormNumber)||((this.filedFormNumber!= null)&&this.filedFormNumber.equals(rhs.filedFormNumber))))&&((this.name == rhs.name)||((this.name!= null)&&this.name.equals(rhs.name))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
