
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "PremType",
    "PayoutType",
    "RateBasedOn",
    "NewMoneyAllocationRule",
    "LoadingType",
    "LOIROAType",
    "AnnuitizationDateRequired",
    "MaxNumPayoutsAtIssue",
    "MedicalUnderwriting",
    "DeathBenefitsBasedOn",
    "IncomePayoutProductOption",
    "FeatureProduct",
    "FeatureTransactionProduct",
    "AnnuitizationDateRestriction",
    "KeyedValue",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AnnuityProduct {

    @JsonProperty("PremType")
    private PremType premType;
    @JsonProperty("PayoutType")
    private PayoutType payoutType;
    @JsonProperty("RateBasedOn")
    private RateBasedOn rateBasedOn;
    @JsonProperty("NewMoneyAllocationRule")
    private NewMoneyAllocationRule newMoneyAllocationRule;
    @JsonProperty("LoadingType")
    private LoadingType loadingType;
    @JsonProperty("LOIROAType")
    private LOIROAType lOIROAType;
    @JsonProperty("AnnuitizationDateRequired")
    private AnnuitizationDateRequired annuitizationDateRequired;
    @JsonProperty("MaxNumPayoutsAtIssue")
    private Integer maxNumPayoutsAtIssue;
    @JsonProperty("MedicalUnderwriting")
    private MedicalUnderwriting medicalUnderwriting;
    @JsonProperty("DeathBenefitsBasedOn")
    private DeathBenefitsBasedOn deathBenefitsBasedOn;
    @JsonProperty("IncomePayoutProductOption")
    private List<Object> incomePayoutProductOption = new ArrayList<>();
    @JsonProperty("FeatureProduct")
    private List<Object> featureProduct = new ArrayList<>();
    @JsonProperty("FeatureTransactionProduct")
    private List<Object> featureTransactionProduct = new ArrayList<>();
    @JsonProperty("AnnuitizationDateRestriction")
    private List<Object> annuitizationDateRestriction = new ArrayList<>();
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("PremType")
    public PremType getPremType() {
        return premType;
    }

    @JsonProperty("PremType")
    public void setPremType(PremType premType) {
        this.premType = premType;
    }

    public AnnuityProduct withPremType(PremType premType) {
        this.premType = premType;
        return this;
    }

    @JsonProperty("PayoutType")
    public PayoutType getPayoutType() {
        return payoutType;
    }

    @JsonProperty("PayoutType")
    public void setPayoutType(PayoutType payoutType) {
        this.payoutType = payoutType;
    }

    public AnnuityProduct withPayoutType(PayoutType payoutType) {
        this.payoutType = payoutType;
        return this;
    }

    @JsonProperty("RateBasedOn")
    public RateBasedOn getRateBasedOn() {
        return rateBasedOn;
    }

    @JsonProperty("RateBasedOn")
    public void setRateBasedOn(RateBasedOn rateBasedOn) {
        this.rateBasedOn = rateBasedOn;
    }

    public AnnuityProduct withRateBasedOn(RateBasedOn rateBasedOn) {
        this.rateBasedOn = rateBasedOn;
        return this;
    }

    @JsonProperty("NewMoneyAllocationRule")
    public NewMoneyAllocationRule getNewMoneyAllocationRule() {
        return newMoneyAllocationRule;
    }

    @JsonProperty("NewMoneyAllocationRule")
    public void setNewMoneyAllocationRule(NewMoneyAllocationRule newMoneyAllocationRule) {
        this.newMoneyAllocationRule = newMoneyAllocationRule;
    }

    public AnnuityProduct withNewMoneyAllocationRule(NewMoneyAllocationRule newMoneyAllocationRule) {
        this.newMoneyAllocationRule = newMoneyAllocationRule;
        return this;
    }

    @JsonProperty("LoadingType")
    public LoadingType getLoadingType() {
        return loadingType;
    }

    @JsonProperty("LoadingType")
    public void setLoadingType(LoadingType loadingType) {
        this.loadingType = loadingType;
    }

    public AnnuityProduct withLoadingType(LoadingType loadingType) {
        this.loadingType = loadingType;
        return this;
    }

    @JsonProperty("LOIROAType")
    public LOIROAType getLOIROAType() {
        return lOIROAType;
    }

    @JsonProperty("LOIROAType")
    public void setLOIROAType(LOIROAType lOIROAType) {
        this.lOIROAType = lOIROAType;
    }

    public AnnuityProduct withLOIROAType(LOIROAType lOIROAType) {
        this.lOIROAType = lOIROAType;
        return this;
    }

    @JsonProperty("AnnuitizationDateRequired")
    public AnnuitizationDateRequired getAnnuitizationDateRequired() {
        return annuitizationDateRequired;
    }

    @JsonProperty("AnnuitizationDateRequired")
    public void setAnnuitizationDateRequired(AnnuitizationDateRequired annuitizationDateRequired) {
        this.annuitizationDateRequired = annuitizationDateRequired;
    }

    public AnnuityProduct withAnnuitizationDateRequired(AnnuitizationDateRequired annuitizationDateRequired) {
        this.annuitizationDateRequired = annuitizationDateRequired;
        return this;
    }

    @JsonProperty("MaxNumPayoutsAtIssue")
    public Integer getMaxNumPayoutsAtIssue() {
        return maxNumPayoutsAtIssue;
    }

    @JsonProperty("MaxNumPayoutsAtIssue")
    public void setMaxNumPayoutsAtIssue(Integer maxNumPayoutsAtIssue) {
        this.maxNumPayoutsAtIssue = maxNumPayoutsAtIssue;
    }

    public AnnuityProduct withMaxNumPayoutsAtIssue(Integer maxNumPayoutsAtIssue) {
        this.maxNumPayoutsAtIssue = maxNumPayoutsAtIssue;
        return this;
    }

    @JsonProperty("MedicalUnderwriting")
    public MedicalUnderwriting getMedicalUnderwriting() {
        return medicalUnderwriting;
    }

    @JsonProperty("MedicalUnderwriting")
    public void setMedicalUnderwriting(MedicalUnderwriting medicalUnderwriting) {
        this.medicalUnderwriting = medicalUnderwriting;
    }

    public AnnuityProduct withMedicalUnderwriting(MedicalUnderwriting medicalUnderwriting) {
        this.medicalUnderwriting = medicalUnderwriting;
        return this;
    }

    @JsonProperty("DeathBenefitsBasedOn")
    public DeathBenefitsBasedOn getDeathBenefitsBasedOn() {
        return deathBenefitsBasedOn;
    }

    @JsonProperty("DeathBenefitsBasedOn")
    public void setDeathBenefitsBasedOn(DeathBenefitsBasedOn deathBenefitsBasedOn) {
        this.deathBenefitsBasedOn = deathBenefitsBasedOn;
    }

    public AnnuityProduct withDeathBenefitsBasedOn(DeathBenefitsBasedOn deathBenefitsBasedOn) {
        this.deathBenefitsBasedOn = deathBenefitsBasedOn;
        return this;
    }

    @JsonProperty("IncomePayoutProductOption")
    public List<Object> getIncomePayoutProductOption() {
        return incomePayoutProductOption;
    }

    @JsonProperty("IncomePayoutProductOption")
    public void setIncomePayoutProductOption(List<Object> incomePayoutProductOption) {
        this.incomePayoutProductOption = incomePayoutProductOption;
    }

    public AnnuityProduct withIncomePayoutProductOption(List<Object> incomePayoutProductOption) {
        this.incomePayoutProductOption = incomePayoutProductOption;
        return this;
    }

    @JsonProperty("FeatureProduct")
    public List<Object> getFeatureProduct() {
        return featureProduct;
    }

    @JsonProperty("FeatureProduct")
    public void setFeatureProduct(List<Object> featureProduct) {
        this.featureProduct = featureProduct;
    }

    public AnnuityProduct withFeatureProduct(List<Object> featureProduct) {
        this.featureProduct = featureProduct;
        return this;
    }

    @JsonProperty("FeatureTransactionProduct")
    public List<Object> getFeatureTransactionProduct() {
        return featureTransactionProduct;
    }

    @JsonProperty("FeatureTransactionProduct")
    public void setFeatureTransactionProduct(List<Object> featureTransactionProduct) {
        this.featureTransactionProduct = featureTransactionProduct;
    }

    public AnnuityProduct withFeatureTransactionProduct(List<Object> featureTransactionProduct) {
        this.featureTransactionProduct = featureTransactionProduct;
        return this;
    }

    @JsonProperty("AnnuitizationDateRestriction")
    public List<Object> getAnnuitizationDateRestriction() {
        return annuitizationDateRestriction;
    }

    @JsonProperty("AnnuitizationDateRestriction")
    public void setAnnuitizationDateRestriction(List<Object> annuitizationDateRestriction) {
        this.annuitizationDateRestriction = annuitizationDateRestriction;
    }

    public AnnuityProduct withAnnuitizationDateRestriction(List<Object> annuitizationDateRestriction) {
        this.annuitizationDateRestriction = annuitizationDateRestriction;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public AnnuityProduct withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AnnuityProduct withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AnnuityProduct withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AnnuityProduct withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AnnuityProduct withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AnnuityProduct.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("premType");
        sb.append('=');
        sb.append(((this.premType == null)?"<null>":this.premType));
        sb.append(',');
        sb.append("payoutType");
        sb.append('=');
        sb.append(((this.payoutType == null)?"<null>":this.payoutType));
        sb.append(',');
        sb.append("rateBasedOn");
        sb.append('=');
        sb.append(((this.rateBasedOn == null)?"<null>":this.rateBasedOn));
        sb.append(',');
        sb.append("newMoneyAllocationRule");
        sb.append('=');
        sb.append(((this.newMoneyAllocationRule == null)?"<null>":this.newMoneyAllocationRule));
        sb.append(',');
        sb.append("loadingType");
        sb.append('=');
        sb.append(((this.loadingType == null)?"<null>":this.loadingType));
        sb.append(',');
        sb.append("lOIROAType");
        sb.append('=');
        sb.append(((this.lOIROAType == null)?"<null>":this.lOIROAType));
        sb.append(',');
        sb.append("annuitizationDateRequired");
        sb.append('=');
        sb.append(((this.annuitizationDateRequired == null)?"<null>":this.annuitizationDateRequired));
        sb.append(',');
        sb.append("maxNumPayoutsAtIssue");
        sb.append('=');
        sb.append(((this.maxNumPayoutsAtIssue == null)?"<null>":this.maxNumPayoutsAtIssue));
        sb.append(',');
        sb.append("medicalUnderwriting");
        sb.append('=');
        sb.append(((this.medicalUnderwriting == null)?"<null>":this.medicalUnderwriting));
        sb.append(',');
        sb.append("deathBenefitsBasedOn");
        sb.append('=');
        sb.append(((this.deathBenefitsBasedOn == null)?"<null>":this.deathBenefitsBasedOn));
        sb.append(',');
        sb.append("incomePayoutProductOption");
        sb.append('=');
        sb.append(((this.incomePayoutProductOption == null)?"<null>":this.incomePayoutProductOption));
        sb.append(',');
        sb.append("featureProduct");
        sb.append('=');
        sb.append(((this.featureProduct == null)?"<null>":this.featureProduct));
        sb.append(',');
        sb.append("featureTransactionProduct");
        sb.append('=');
        sb.append(((this.featureTransactionProduct == null)?"<null>":this.featureTransactionProduct));
        sb.append(',');
        sb.append("annuitizationDateRestriction");
        sb.append('=');
        sb.append(((this.annuitizationDateRestriction == null)?"<null>":this.annuitizationDateRestriction));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.medicalUnderwriting == null)? 0 :this.medicalUnderwriting.hashCode()));
        result = ((result* 31)+((this.lOIROAType == null)? 0 :this.lOIROAType.hashCode()));
        result = ((result* 31)+((this.payoutType == null)? 0 :this.payoutType.hashCode()));
        result = ((result* 31)+((this.annuitizationDateRequired == null)? 0 :this.annuitizationDateRequired.hashCode()));
        result = ((result* 31)+((this.featureTransactionProduct == null)? 0 :this.featureTransactionProduct.hashCode()));
        result = ((result* 31)+((this.incomePayoutProductOption == null)? 0 :this.incomePayoutProductOption.hashCode()));
        result = ((result* 31)+((this.premType == null)? 0 :this.premType.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.deathBenefitsBasedOn == null)? 0 :this.deathBenefitsBasedOn.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.annuitizationDateRestriction == null)? 0 :this.annuitizationDateRestriction.hashCode()));
        result = ((result* 31)+((this.maxNumPayoutsAtIssue == null)? 0 :this.maxNumPayoutsAtIssue.hashCode()));
        result = ((result* 31)+((this.newMoneyAllocationRule == null)? 0 :this.newMoneyAllocationRule.hashCode()));
        result = ((result* 31)+((this.rateBasedOn == null)? 0 :this.rateBasedOn.hashCode()));
        result = ((result* 31)+((this.loadingType == null)? 0 :this.loadingType.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.featureProduct == null)? 0 :this.featureProduct.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AnnuityProduct) == false) {
            return false;
        }
        AnnuityProduct rhs = ((AnnuityProduct) other);
        return ((((((((((((((((((((this.medicalUnderwriting == rhs.medicalUnderwriting)||((this.medicalUnderwriting!= null)&&this.medicalUnderwriting.equals(rhs.medicalUnderwriting)))&&((this.lOIROAType == rhs.lOIROAType)||((this.lOIROAType!= null)&&this.lOIROAType.equals(rhs.lOIROAType))))&&((this.payoutType == rhs.payoutType)||((this.payoutType!= null)&&this.payoutType.equals(rhs.payoutType))))&&((this.annuitizationDateRequired == rhs.annuitizationDateRequired)||((this.annuitizationDateRequired!= null)&&this.annuitizationDateRequired.equals(rhs.annuitizationDateRequired))))&&((this.featureTransactionProduct == rhs.featureTransactionProduct)||((this.featureTransactionProduct!= null)&&this.featureTransactionProduct.equals(rhs.featureTransactionProduct))))&&((this.incomePayoutProductOption == rhs.incomePayoutProductOption)||((this.incomePayoutProductOption!= null)&&this.incomePayoutProductOption.equals(rhs.incomePayoutProductOption))))&&((this.premType == rhs.premType)||((this.premType!= null)&&this.premType.equals(rhs.premType))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.deathBenefitsBasedOn == rhs.deathBenefitsBasedOn)||((this.deathBenefitsBasedOn!= null)&&this.deathBenefitsBasedOn.equals(rhs.deathBenefitsBasedOn))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.annuitizationDateRestriction == rhs.annuitizationDateRestriction)||((this.annuitizationDateRestriction!= null)&&this.annuitizationDateRestriction.equals(rhs.annuitizationDateRestriction))))&&((this.maxNumPayoutsAtIssue == rhs.maxNumPayoutsAtIssue)||((this.maxNumPayoutsAtIssue!= null)&&this.maxNumPayoutsAtIssue.equals(rhs.maxNumPayoutsAtIssue))))&&((this.newMoneyAllocationRule == rhs.newMoneyAllocationRule)||((this.newMoneyAllocationRule!= null)&&this.newMoneyAllocationRule.equals(rhs.newMoneyAllocationRule))))&&((this.rateBasedOn == rhs.rateBasedOn)||((this.rateBasedOn!= null)&&this.rateBasedOn.equals(rhs.rateBasedOn))))&&((this.loadingType == rhs.loadingType)||((this.loadingType!= null)&&this.loadingType.equals(rhs.loadingType))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.featureProduct == rhs.featureProduct)||((this.featureProduct!= null)&&this.featureProduct.equals(rhs.featureProduct))));
    }

}
