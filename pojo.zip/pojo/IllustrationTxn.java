
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "IllusTxnPrimaryType",
    "IllusTxnSecondaryType",
    "IllusTxnTertiaryType",
    "IllusTxnAmt",
    "IllusTxnMode",
    "StartDate",
    "EndDate",
    "IncreasePercent",
    "OverrideStatePremiumTaxInd",
    "OverrideStatePremiumTaxAmt",
    "SuppSolveType",
    "OLifEExtension",
    "CoverageRef",
    "CoverageID"
})
@Generated("jsonschema2pojo")
public class IllustrationTxn {

    @JsonProperty("IllusTxnPrimaryType")
    private IllusTxnPrimaryType illusTxnPrimaryType;
    @JsonProperty("IllusTxnSecondaryType")
    private IllusTxnSecondaryType illusTxnSecondaryType;
    @JsonProperty("IllusTxnTertiaryType")
    private IllusTxnTertiaryType illusTxnTertiaryType;
    @JsonProperty("IllusTxnAmt")
    private Integer illusTxnAmt;
    @JsonProperty("IllusTxnMode")
    private IllusTxnMode illusTxnMode;
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("IncreasePercent")
    private Integer increasePercent;
    @JsonProperty("OverrideStatePremiumTaxInd")
    private OverrideStatePremiumTaxInd overrideStatePremiumTaxInd;
    @JsonProperty("OverrideStatePremiumTaxAmt")
    private Integer overrideStatePremiumTaxAmt;
    @JsonProperty("SuppSolveType")
    private SuppSolveType suppSolveType;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("CoverageRef")
    private String coverageRef;
    @JsonProperty("CoverageID")
    private String coverageID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("IllusTxnPrimaryType")
    public IllusTxnPrimaryType getIllusTxnPrimaryType() {
        return illusTxnPrimaryType;
    }

    @JsonProperty("IllusTxnPrimaryType")
    public void setIllusTxnPrimaryType(IllusTxnPrimaryType illusTxnPrimaryType) {
        this.illusTxnPrimaryType = illusTxnPrimaryType;
    }

    public IllustrationTxn withIllusTxnPrimaryType(IllusTxnPrimaryType illusTxnPrimaryType) {
        this.illusTxnPrimaryType = illusTxnPrimaryType;
        return this;
    }

    @JsonProperty("IllusTxnSecondaryType")
    public IllusTxnSecondaryType getIllusTxnSecondaryType() {
        return illusTxnSecondaryType;
    }

    @JsonProperty("IllusTxnSecondaryType")
    public void setIllusTxnSecondaryType(IllusTxnSecondaryType illusTxnSecondaryType) {
        this.illusTxnSecondaryType = illusTxnSecondaryType;
    }

    public IllustrationTxn withIllusTxnSecondaryType(IllusTxnSecondaryType illusTxnSecondaryType) {
        this.illusTxnSecondaryType = illusTxnSecondaryType;
        return this;
    }

    @JsonProperty("IllusTxnTertiaryType")
    public IllusTxnTertiaryType getIllusTxnTertiaryType() {
        return illusTxnTertiaryType;
    }

    @JsonProperty("IllusTxnTertiaryType")
    public void setIllusTxnTertiaryType(IllusTxnTertiaryType illusTxnTertiaryType) {
        this.illusTxnTertiaryType = illusTxnTertiaryType;
    }

    public IllustrationTxn withIllusTxnTertiaryType(IllusTxnTertiaryType illusTxnTertiaryType) {
        this.illusTxnTertiaryType = illusTxnTertiaryType;
        return this;
    }

    @JsonProperty("IllusTxnAmt")
    public Integer getIllusTxnAmt() {
        return illusTxnAmt;
    }

    @JsonProperty("IllusTxnAmt")
    public void setIllusTxnAmt(Integer illusTxnAmt) {
        this.illusTxnAmt = illusTxnAmt;
    }

    public IllustrationTxn withIllusTxnAmt(Integer illusTxnAmt) {
        this.illusTxnAmt = illusTxnAmt;
        return this;
    }

    @JsonProperty("IllusTxnMode")
    public IllusTxnMode getIllusTxnMode() {
        return illusTxnMode;
    }

    @JsonProperty("IllusTxnMode")
    public void setIllusTxnMode(IllusTxnMode illusTxnMode) {
        this.illusTxnMode = illusTxnMode;
    }

    public IllustrationTxn withIllusTxnMode(IllusTxnMode illusTxnMode) {
        this.illusTxnMode = illusTxnMode;
        return this;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public IllustrationTxn withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public IllustrationTxn withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("IncreasePercent")
    public Integer getIncreasePercent() {
        return increasePercent;
    }

    @JsonProperty("IncreasePercent")
    public void setIncreasePercent(Integer increasePercent) {
        this.increasePercent = increasePercent;
    }

    public IllustrationTxn withIncreasePercent(Integer increasePercent) {
        this.increasePercent = increasePercent;
        return this;
    }

    @JsonProperty("OverrideStatePremiumTaxInd")
    public OverrideStatePremiumTaxInd getOverrideStatePremiumTaxInd() {
        return overrideStatePremiumTaxInd;
    }

    @JsonProperty("OverrideStatePremiumTaxInd")
    public void setOverrideStatePremiumTaxInd(OverrideStatePremiumTaxInd overrideStatePremiumTaxInd) {
        this.overrideStatePremiumTaxInd = overrideStatePremiumTaxInd;
    }

    public IllustrationTxn withOverrideStatePremiumTaxInd(OverrideStatePremiumTaxInd overrideStatePremiumTaxInd) {
        this.overrideStatePremiumTaxInd = overrideStatePremiumTaxInd;
        return this;
    }

    @JsonProperty("OverrideStatePremiumTaxAmt")
    public Integer getOverrideStatePremiumTaxAmt() {
        return overrideStatePremiumTaxAmt;
    }

    @JsonProperty("OverrideStatePremiumTaxAmt")
    public void setOverrideStatePremiumTaxAmt(Integer overrideStatePremiumTaxAmt) {
        this.overrideStatePremiumTaxAmt = overrideStatePremiumTaxAmt;
    }

    public IllustrationTxn withOverrideStatePremiumTaxAmt(Integer overrideStatePremiumTaxAmt) {
        this.overrideStatePremiumTaxAmt = overrideStatePremiumTaxAmt;
        return this;
    }

    @JsonProperty("SuppSolveType")
    public SuppSolveType getSuppSolveType() {
        return suppSolveType;
    }

    @JsonProperty("SuppSolveType")
    public void setSuppSolveType(SuppSolveType suppSolveType) {
        this.suppSolveType = suppSolveType;
    }

    public IllustrationTxn withSuppSolveType(SuppSolveType suppSolveType) {
        this.suppSolveType = suppSolveType;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public IllustrationTxn withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("CoverageRef")
    public String getCoverageRef() {
        return coverageRef;
    }

    @JsonProperty("CoverageRef")
    public void setCoverageRef(String coverageRef) {
        this.coverageRef = coverageRef;
    }

    public IllustrationTxn withCoverageRef(String coverageRef) {
        this.coverageRef = coverageRef;
        return this;
    }

    @JsonProperty("CoverageID")
    public String getCoverageID() {
        return coverageID;
    }

    @JsonProperty("CoverageID")
    public void setCoverageID(String coverageID) {
        this.coverageID = coverageID;
    }

    public IllustrationTxn withCoverageID(String coverageID) {
        this.coverageID = coverageID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public IllustrationTxn withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(IllustrationTxn.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("illusTxnPrimaryType");
        sb.append('=');
        sb.append(((this.illusTxnPrimaryType == null)?"<null>":this.illusTxnPrimaryType));
        sb.append(',');
        sb.append("illusTxnSecondaryType");
        sb.append('=');
        sb.append(((this.illusTxnSecondaryType == null)?"<null>":this.illusTxnSecondaryType));
        sb.append(',');
        sb.append("illusTxnTertiaryType");
        sb.append('=');
        sb.append(((this.illusTxnTertiaryType == null)?"<null>":this.illusTxnTertiaryType));
        sb.append(',');
        sb.append("illusTxnAmt");
        sb.append('=');
        sb.append(((this.illusTxnAmt == null)?"<null>":this.illusTxnAmt));
        sb.append(',');
        sb.append("illusTxnMode");
        sb.append('=');
        sb.append(((this.illusTxnMode == null)?"<null>":this.illusTxnMode));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("increasePercent");
        sb.append('=');
        sb.append(((this.increasePercent == null)?"<null>":this.increasePercent));
        sb.append(',');
        sb.append("overrideStatePremiumTaxInd");
        sb.append('=');
        sb.append(((this.overrideStatePremiumTaxInd == null)?"<null>":this.overrideStatePremiumTaxInd));
        sb.append(',');
        sb.append("overrideStatePremiumTaxAmt");
        sb.append('=');
        sb.append(((this.overrideStatePremiumTaxAmt == null)?"<null>":this.overrideStatePremiumTaxAmt));
        sb.append(',');
        sb.append("suppSolveType");
        sb.append('=');
        sb.append(((this.suppSolveType == null)?"<null>":this.suppSolveType));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("coverageRef");
        sb.append('=');
        sb.append(((this.coverageRef == null)?"<null>":this.coverageRef));
        sb.append(',');
        sb.append("coverageID");
        sb.append('=');
        sb.append(((this.coverageID == null)?"<null>":this.coverageID));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.coverageID == null)? 0 :this.coverageID.hashCode()));
        result = ((result* 31)+((this.illusTxnMode == null)? 0 :this.illusTxnMode.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.illusTxnAmt == null)? 0 :this.illusTxnAmt.hashCode()));
        result = ((result* 31)+((this.illusTxnTertiaryType == null)? 0 :this.illusTxnTertiaryType.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.illusTxnPrimaryType == null)? 0 :this.illusTxnPrimaryType.hashCode()));
        result = ((result* 31)+((this.increasePercent == null)? 0 :this.increasePercent.hashCode()));
        result = ((result* 31)+((this.suppSolveType == null)? 0 :this.suppSolveType.hashCode()));
        result = ((result* 31)+((this.overrideStatePremiumTaxAmt == null)? 0 :this.overrideStatePremiumTaxAmt.hashCode()));
        result = ((result* 31)+((this.coverageRef == null)? 0 :this.coverageRef.hashCode()));
        result = ((result* 31)+((this.illusTxnSecondaryType == null)? 0 :this.illusTxnSecondaryType.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        result = ((result* 31)+((this.overrideStatePremiumTaxInd == null)? 0 :this.overrideStatePremiumTaxInd.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof IllustrationTxn) == false) {
            return false;
        }
        IllustrationTxn rhs = ((IllustrationTxn) other);
        return ((((((((((((((((this.coverageID == rhs.coverageID)||((this.coverageID!= null)&&this.coverageID.equals(rhs.coverageID)))&&((this.illusTxnMode == rhs.illusTxnMode)||((this.illusTxnMode!= null)&&this.illusTxnMode.equals(rhs.illusTxnMode))))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.illusTxnAmt == rhs.illusTxnAmt)||((this.illusTxnAmt!= null)&&this.illusTxnAmt.equals(rhs.illusTxnAmt))))&&((this.illusTxnTertiaryType == rhs.illusTxnTertiaryType)||((this.illusTxnTertiaryType!= null)&&this.illusTxnTertiaryType.equals(rhs.illusTxnTertiaryType))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.illusTxnPrimaryType == rhs.illusTxnPrimaryType)||((this.illusTxnPrimaryType!= null)&&this.illusTxnPrimaryType.equals(rhs.illusTxnPrimaryType))))&&((this.increasePercent == rhs.increasePercent)||((this.increasePercent!= null)&&this.increasePercent.equals(rhs.increasePercent))))&&((this.suppSolveType == rhs.suppSolveType)||((this.suppSolveType!= null)&&this.suppSolveType.equals(rhs.suppSolveType))))&&((this.overrideStatePremiumTaxAmt == rhs.overrideStatePremiumTaxAmt)||((this.overrideStatePremiumTaxAmt!= null)&&this.overrideStatePremiumTaxAmt.equals(rhs.overrideStatePremiumTaxAmt))))&&((this.coverageRef == rhs.coverageRef)||((this.coverageRef!= null)&&this.coverageRef.equals(rhs.coverageRef))))&&((this.illusTxnSecondaryType == rhs.illusTxnSecondaryType)||((this.illusTxnSecondaryType!= null)&&this.illusTxnSecondaryType.equals(rhs.illusTxnSecondaryType))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))))&&((this.overrideStatePremiumTaxInd == rhs.overrideStatePremiumTaxInd)||((this.overrideStatePremiumTaxInd!= null)&&this.overrideStatePremiumTaxInd.equals(rhs.overrideStatePremiumTaxInd))));
    }

}
