
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "MedicalConditionGuidelineKey",
    "MedicalConditionGuidelineSysKey",
    "ConditionType",
    "GuidelineFailInstructionType",
    "HistoryDuration",
    "HistoryDurationQualifier",
    "MaxNumberOccurrences",
    "GuidelineDescription",
    "Attachment",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class MedicalConditionGuideline {

    @JsonProperty("MedicalConditionGuidelineKey")
    private MedicalConditionGuidelineKey medicalConditionGuidelineKey;
    @JsonProperty("MedicalConditionGuidelineSysKey")
    private List<Object> medicalConditionGuidelineSysKey = new ArrayList<>();
    @JsonProperty("ConditionType")
    private ConditionType conditionType;
    @JsonProperty("GuidelineFailInstructionType")
    private GuidelineFailInstructionType guidelineFailInstructionType;
    @JsonProperty("HistoryDuration")
    private Integer historyDuration;
    @JsonProperty("HistoryDurationQualifier")
    private HistoryDurationQualifier historyDurationQualifier;
    @JsonProperty("MaxNumberOccurrences")
    private Integer maxNumberOccurrences;
    @JsonProperty("GuidelineDescription")
    private String guidelineDescription;
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("MedicalConditionGuidelineKey")
    public MedicalConditionGuidelineKey getMedicalConditionGuidelineKey() {
        return medicalConditionGuidelineKey;
    }

    @JsonProperty("MedicalConditionGuidelineKey")
    public void setMedicalConditionGuidelineKey(MedicalConditionGuidelineKey medicalConditionGuidelineKey) {
        this.medicalConditionGuidelineKey = medicalConditionGuidelineKey;
    }

    public MedicalConditionGuideline withMedicalConditionGuidelineKey(MedicalConditionGuidelineKey medicalConditionGuidelineKey) {
        this.medicalConditionGuidelineKey = medicalConditionGuidelineKey;
        return this;
    }

    @JsonProperty("MedicalConditionGuidelineSysKey")
    public List<Object> getMedicalConditionGuidelineSysKey() {
        return medicalConditionGuidelineSysKey;
    }

    @JsonProperty("MedicalConditionGuidelineSysKey")
    public void setMedicalConditionGuidelineSysKey(List<Object> medicalConditionGuidelineSysKey) {
        this.medicalConditionGuidelineSysKey = medicalConditionGuidelineSysKey;
    }

    public MedicalConditionGuideline withMedicalConditionGuidelineSysKey(List<Object> medicalConditionGuidelineSysKey) {
        this.medicalConditionGuidelineSysKey = medicalConditionGuidelineSysKey;
        return this;
    }

    @JsonProperty("ConditionType")
    public ConditionType getConditionType() {
        return conditionType;
    }

    @JsonProperty("ConditionType")
    public void setConditionType(ConditionType conditionType) {
        this.conditionType = conditionType;
    }

    public MedicalConditionGuideline withConditionType(ConditionType conditionType) {
        this.conditionType = conditionType;
        return this;
    }

    @JsonProperty("GuidelineFailInstructionType")
    public GuidelineFailInstructionType getGuidelineFailInstructionType() {
        return guidelineFailInstructionType;
    }

    @JsonProperty("GuidelineFailInstructionType")
    public void setGuidelineFailInstructionType(GuidelineFailInstructionType guidelineFailInstructionType) {
        this.guidelineFailInstructionType = guidelineFailInstructionType;
    }

    public MedicalConditionGuideline withGuidelineFailInstructionType(GuidelineFailInstructionType guidelineFailInstructionType) {
        this.guidelineFailInstructionType = guidelineFailInstructionType;
        return this;
    }

    @JsonProperty("HistoryDuration")
    public Integer getHistoryDuration() {
        return historyDuration;
    }

    @JsonProperty("HistoryDuration")
    public void setHistoryDuration(Integer historyDuration) {
        this.historyDuration = historyDuration;
    }

    public MedicalConditionGuideline withHistoryDuration(Integer historyDuration) {
        this.historyDuration = historyDuration;
        return this;
    }

    @JsonProperty("HistoryDurationQualifier")
    public HistoryDurationQualifier getHistoryDurationQualifier() {
        return historyDurationQualifier;
    }

    @JsonProperty("HistoryDurationQualifier")
    public void setHistoryDurationQualifier(HistoryDurationQualifier historyDurationQualifier) {
        this.historyDurationQualifier = historyDurationQualifier;
    }

    public MedicalConditionGuideline withHistoryDurationQualifier(HistoryDurationQualifier historyDurationQualifier) {
        this.historyDurationQualifier = historyDurationQualifier;
        return this;
    }

    @JsonProperty("MaxNumberOccurrences")
    public Integer getMaxNumberOccurrences() {
        return maxNumberOccurrences;
    }

    @JsonProperty("MaxNumberOccurrences")
    public void setMaxNumberOccurrences(Integer maxNumberOccurrences) {
        this.maxNumberOccurrences = maxNumberOccurrences;
    }

    public MedicalConditionGuideline withMaxNumberOccurrences(Integer maxNumberOccurrences) {
        this.maxNumberOccurrences = maxNumberOccurrences;
        return this;
    }

    @JsonProperty("GuidelineDescription")
    public String getGuidelineDescription() {
        return guidelineDescription;
    }

    @JsonProperty("GuidelineDescription")
    public void setGuidelineDescription(String guidelineDescription) {
        this.guidelineDescription = guidelineDescription;
    }

    public MedicalConditionGuideline withGuidelineDescription(String guidelineDescription) {
        this.guidelineDescription = guidelineDescription;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public MedicalConditionGuideline withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public MedicalConditionGuideline withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public MedicalConditionGuideline withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public MedicalConditionGuideline withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MedicalConditionGuideline withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(MedicalConditionGuideline.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("medicalConditionGuidelineKey");
        sb.append('=');
        sb.append(((this.medicalConditionGuidelineKey == null)?"<null>":this.medicalConditionGuidelineKey));
        sb.append(',');
        sb.append("medicalConditionGuidelineSysKey");
        sb.append('=');
        sb.append(((this.medicalConditionGuidelineSysKey == null)?"<null>":this.medicalConditionGuidelineSysKey));
        sb.append(',');
        sb.append("conditionType");
        sb.append('=');
        sb.append(((this.conditionType == null)?"<null>":this.conditionType));
        sb.append(',');
        sb.append("guidelineFailInstructionType");
        sb.append('=');
        sb.append(((this.guidelineFailInstructionType == null)?"<null>":this.guidelineFailInstructionType));
        sb.append(',');
        sb.append("historyDuration");
        sb.append('=');
        sb.append(((this.historyDuration == null)?"<null>":this.historyDuration));
        sb.append(',');
        sb.append("historyDurationQualifier");
        sb.append('=');
        sb.append(((this.historyDurationQualifier == null)?"<null>":this.historyDurationQualifier));
        sb.append(',');
        sb.append("maxNumberOccurrences");
        sb.append('=');
        sb.append(((this.maxNumberOccurrences == null)?"<null>":this.maxNumberOccurrences));
        sb.append(',');
        sb.append("guidelineDescription");
        sb.append('=');
        sb.append(((this.guidelineDescription == null)?"<null>":this.guidelineDescription));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.medicalConditionGuidelineSysKey == null)? 0 :this.medicalConditionGuidelineSysKey.hashCode()));
        result = ((result* 31)+((this.historyDuration == null)? 0 :this.historyDuration.hashCode()));
        result = ((result* 31)+((this.maxNumberOccurrences == null)? 0 :this.maxNumberOccurrences.hashCode()));
        result = ((result* 31)+((this.historyDurationQualifier == null)? 0 :this.historyDurationQualifier.hashCode()));
        result = ((result* 31)+((this.guidelineDescription == null)? 0 :this.guidelineDescription.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.conditionType == null)? 0 :this.conditionType.hashCode()));
        result = ((result* 31)+((this.guidelineFailInstructionType == null)? 0 :this.guidelineFailInstructionType.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.medicalConditionGuidelineKey == null)? 0 :this.medicalConditionGuidelineKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MedicalConditionGuideline) == false) {
            return false;
        }
        MedicalConditionGuideline rhs = ((MedicalConditionGuideline) other);
        return ((((((((((((((this.medicalConditionGuidelineSysKey == rhs.medicalConditionGuidelineSysKey)||((this.medicalConditionGuidelineSysKey!= null)&&this.medicalConditionGuidelineSysKey.equals(rhs.medicalConditionGuidelineSysKey)))&&((this.historyDuration == rhs.historyDuration)||((this.historyDuration!= null)&&this.historyDuration.equals(rhs.historyDuration))))&&((this.maxNumberOccurrences == rhs.maxNumberOccurrences)||((this.maxNumberOccurrences!= null)&&this.maxNumberOccurrences.equals(rhs.maxNumberOccurrences))))&&((this.historyDurationQualifier == rhs.historyDurationQualifier)||((this.historyDurationQualifier!= null)&&this.historyDurationQualifier.equals(rhs.historyDurationQualifier))))&&((this.guidelineDescription == rhs.guidelineDescription)||((this.guidelineDescription!= null)&&this.guidelineDescription.equals(rhs.guidelineDescription))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.conditionType == rhs.conditionType)||((this.conditionType!= null)&&this.conditionType.equals(rhs.conditionType))))&&((this.guidelineFailInstructionType == rhs.guidelineFailInstructionType)||((this.guidelineFailInstructionType!= null)&&this.guidelineFailInstructionType.equals(rhs.guidelineFailInstructionType))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.medicalConditionGuidelineKey == rhs.medicalConditionGuidelineKey)||((this.medicalConditionGuidelineKey!= null)&&this.medicalConditionGuidelineKey.equals(rhs.medicalConditionGuidelineKey))));
    }

}
