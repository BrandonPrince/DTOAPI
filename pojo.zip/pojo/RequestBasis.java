
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "BasisName",
    "InterestAssumption",
    "InterestAssumptionRate",
    "MortalityAssumption",
    "MortalityAssumptionBlend",
    "MortalityReEntryInd",
    "DividendAssumption",
    "DividendAssumptionBlend",
    "IllustrateNonGuarBonusInd",
    "LifeExpectancy",
    "JointLifeExpectancy",
    "ExclusionRatio",
    "GtdPayoutAmt",
    "InternalRateOfReturn",
    "LastGtdPayoutDate",
    "MaxMortalityAge",
    "PayoutsCertain",
    "PayoutAmt",
    "SinglePremiumAmt",
    "StatePremiumTaxRate",
    "PolFee",
    "OverrideStatePremiumTaxInd",
    "OverrideStatePremiumTaxAmt",
    "RelativeUnderwritingBasis",
    "VectorRequest",
    "KeyedValue",
    "OLifEExtension",
    "id"
})
@Generated("jsonschema2pojo")
public class RequestBasis {

    @JsonProperty("BasisName")
    private String basisName;
    @JsonProperty("InterestAssumption")
    private InterestAssumption interestAssumption;
    @JsonProperty("InterestAssumptionRate")
    private Integer interestAssumptionRate;
    @JsonProperty("MortalityAssumption")
    private MortalityAssumption mortalityAssumption;
    @JsonProperty("MortalityAssumptionBlend")
    private Integer mortalityAssumptionBlend;
    @JsonProperty("MortalityReEntryInd")
    private MortalityReEntryInd mortalityReEntryInd;
    @JsonProperty("DividendAssumption")
    private DividendAssumption dividendAssumption;
    @JsonProperty("DividendAssumptionBlend")
    private Integer dividendAssumptionBlend;
    @JsonProperty("IllustrateNonGuarBonusInd")
    private IllustrateNonGuarBonusInd illustrateNonGuarBonusInd;
    @JsonProperty("LifeExpectancy")
    private Integer lifeExpectancy;
    @JsonProperty("JointLifeExpectancy")
    private Integer jointLifeExpectancy;
    @JsonProperty("ExclusionRatio")
    private Integer exclusionRatio;
    @JsonProperty("GtdPayoutAmt")
    private Integer gtdPayoutAmt;
    @JsonProperty("InternalRateOfReturn")
    private Integer internalRateOfReturn;
    @JsonProperty("LastGtdPayoutDate")
    private String lastGtdPayoutDate;
    @JsonProperty("MaxMortalityAge")
    private Integer maxMortalityAge;
    @JsonProperty("PayoutsCertain")
    private Integer payoutsCertain;
    @JsonProperty("PayoutAmt")
    private Integer payoutAmt;
    @JsonProperty("SinglePremiumAmt")
    private Integer singlePremiumAmt;
    @JsonProperty("StatePremiumTaxRate")
    private Integer statePremiumTaxRate;
    @JsonProperty("PolFee")
    private Integer polFee;
    @JsonProperty("OverrideStatePremiumTaxInd")
    private OverrideStatePremiumTaxInd overrideStatePremiumTaxInd;
    @JsonProperty("OverrideStatePremiumTaxAmt")
    private Integer overrideStatePremiumTaxAmt;
    @JsonProperty("RelativeUnderwritingBasis")
    private RelativeUnderwritingBasis relativeUnderwritingBasis;
    @JsonProperty("VectorRequest")
    private List<Object> vectorRequest = new ArrayList<>();
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("BasisName")
    public String getBasisName() {
        return basisName;
    }

    @JsonProperty("BasisName")
    public void setBasisName(String basisName) {
        this.basisName = basisName;
    }

    public RequestBasis withBasisName(String basisName) {
        this.basisName = basisName;
        return this;
    }

    @JsonProperty("InterestAssumption")
    public InterestAssumption getInterestAssumption() {
        return interestAssumption;
    }

    @JsonProperty("InterestAssumption")
    public void setInterestAssumption(InterestAssumption interestAssumption) {
        this.interestAssumption = interestAssumption;
    }

    public RequestBasis withInterestAssumption(InterestAssumption interestAssumption) {
        this.interestAssumption = interestAssumption;
        return this;
    }

    @JsonProperty("InterestAssumptionRate")
    public Integer getInterestAssumptionRate() {
        return interestAssumptionRate;
    }

    @JsonProperty("InterestAssumptionRate")
    public void setInterestAssumptionRate(Integer interestAssumptionRate) {
        this.interestAssumptionRate = interestAssumptionRate;
    }

    public RequestBasis withInterestAssumptionRate(Integer interestAssumptionRate) {
        this.interestAssumptionRate = interestAssumptionRate;
        return this;
    }

    @JsonProperty("MortalityAssumption")
    public MortalityAssumption getMortalityAssumption() {
        return mortalityAssumption;
    }

    @JsonProperty("MortalityAssumption")
    public void setMortalityAssumption(MortalityAssumption mortalityAssumption) {
        this.mortalityAssumption = mortalityAssumption;
    }

    public RequestBasis withMortalityAssumption(MortalityAssumption mortalityAssumption) {
        this.mortalityAssumption = mortalityAssumption;
        return this;
    }

    @JsonProperty("MortalityAssumptionBlend")
    public Integer getMortalityAssumptionBlend() {
        return mortalityAssumptionBlend;
    }

    @JsonProperty("MortalityAssumptionBlend")
    public void setMortalityAssumptionBlend(Integer mortalityAssumptionBlend) {
        this.mortalityAssumptionBlend = mortalityAssumptionBlend;
    }

    public RequestBasis withMortalityAssumptionBlend(Integer mortalityAssumptionBlend) {
        this.mortalityAssumptionBlend = mortalityAssumptionBlend;
        return this;
    }

    @JsonProperty("MortalityReEntryInd")
    public MortalityReEntryInd getMortalityReEntryInd() {
        return mortalityReEntryInd;
    }

    @JsonProperty("MortalityReEntryInd")
    public void setMortalityReEntryInd(MortalityReEntryInd mortalityReEntryInd) {
        this.mortalityReEntryInd = mortalityReEntryInd;
    }

    public RequestBasis withMortalityReEntryInd(MortalityReEntryInd mortalityReEntryInd) {
        this.mortalityReEntryInd = mortalityReEntryInd;
        return this;
    }

    @JsonProperty("DividendAssumption")
    public DividendAssumption getDividendAssumption() {
        return dividendAssumption;
    }

    @JsonProperty("DividendAssumption")
    public void setDividendAssumption(DividendAssumption dividendAssumption) {
        this.dividendAssumption = dividendAssumption;
    }

    public RequestBasis withDividendAssumption(DividendAssumption dividendAssumption) {
        this.dividendAssumption = dividendAssumption;
        return this;
    }

    @JsonProperty("DividendAssumptionBlend")
    public Integer getDividendAssumptionBlend() {
        return dividendAssumptionBlend;
    }

    @JsonProperty("DividendAssumptionBlend")
    public void setDividendAssumptionBlend(Integer dividendAssumptionBlend) {
        this.dividendAssumptionBlend = dividendAssumptionBlend;
    }

    public RequestBasis withDividendAssumptionBlend(Integer dividendAssumptionBlend) {
        this.dividendAssumptionBlend = dividendAssumptionBlend;
        return this;
    }

    @JsonProperty("IllustrateNonGuarBonusInd")
    public IllustrateNonGuarBonusInd getIllustrateNonGuarBonusInd() {
        return illustrateNonGuarBonusInd;
    }

    @JsonProperty("IllustrateNonGuarBonusInd")
    public void setIllustrateNonGuarBonusInd(IllustrateNonGuarBonusInd illustrateNonGuarBonusInd) {
        this.illustrateNonGuarBonusInd = illustrateNonGuarBonusInd;
    }

    public RequestBasis withIllustrateNonGuarBonusInd(IllustrateNonGuarBonusInd illustrateNonGuarBonusInd) {
        this.illustrateNonGuarBonusInd = illustrateNonGuarBonusInd;
        return this;
    }

    @JsonProperty("LifeExpectancy")
    public Integer getLifeExpectancy() {
        return lifeExpectancy;
    }

    @JsonProperty("LifeExpectancy")
    public void setLifeExpectancy(Integer lifeExpectancy) {
        this.lifeExpectancy = lifeExpectancy;
    }

    public RequestBasis withLifeExpectancy(Integer lifeExpectancy) {
        this.lifeExpectancy = lifeExpectancy;
        return this;
    }

    @JsonProperty("JointLifeExpectancy")
    public Integer getJointLifeExpectancy() {
        return jointLifeExpectancy;
    }

    @JsonProperty("JointLifeExpectancy")
    public void setJointLifeExpectancy(Integer jointLifeExpectancy) {
        this.jointLifeExpectancy = jointLifeExpectancy;
    }

    public RequestBasis withJointLifeExpectancy(Integer jointLifeExpectancy) {
        this.jointLifeExpectancy = jointLifeExpectancy;
        return this;
    }

    @JsonProperty("ExclusionRatio")
    public Integer getExclusionRatio() {
        return exclusionRatio;
    }

    @JsonProperty("ExclusionRatio")
    public void setExclusionRatio(Integer exclusionRatio) {
        this.exclusionRatio = exclusionRatio;
    }

    public RequestBasis withExclusionRatio(Integer exclusionRatio) {
        this.exclusionRatio = exclusionRatio;
        return this;
    }

    @JsonProperty("GtdPayoutAmt")
    public Integer getGtdPayoutAmt() {
        return gtdPayoutAmt;
    }

    @JsonProperty("GtdPayoutAmt")
    public void setGtdPayoutAmt(Integer gtdPayoutAmt) {
        this.gtdPayoutAmt = gtdPayoutAmt;
    }

    public RequestBasis withGtdPayoutAmt(Integer gtdPayoutAmt) {
        this.gtdPayoutAmt = gtdPayoutAmt;
        return this;
    }

    @JsonProperty("InternalRateOfReturn")
    public Integer getInternalRateOfReturn() {
        return internalRateOfReturn;
    }

    @JsonProperty("InternalRateOfReturn")
    public void setInternalRateOfReturn(Integer internalRateOfReturn) {
        this.internalRateOfReturn = internalRateOfReturn;
    }

    public RequestBasis withInternalRateOfReturn(Integer internalRateOfReturn) {
        this.internalRateOfReturn = internalRateOfReturn;
        return this;
    }

    @JsonProperty("LastGtdPayoutDate")
    public String getLastGtdPayoutDate() {
        return lastGtdPayoutDate;
    }

    @JsonProperty("LastGtdPayoutDate")
    public void setLastGtdPayoutDate(String lastGtdPayoutDate) {
        this.lastGtdPayoutDate = lastGtdPayoutDate;
    }

    public RequestBasis withLastGtdPayoutDate(String lastGtdPayoutDate) {
        this.lastGtdPayoutDate = lastGtdPayoutDate;
        return this;
    }

    @JsonProperty("MaxMortalityAge")
    public Integer getMaxMortalityAge() {
        return maxMortalityAge;
    }

    @JsonProperty("MaxMortalityAge")
    public void setMaxMortalityAge(Integer maxMortalityAge) {
        this.maxMortalityAge = maxMortalityAge;
    }

    public RequestBasis withMaxMortalityAge(Integer maxMortalityAge) {
        this.maxMortalityAge = maxMortalityAge;
        return this;
    }

    @JsonProperty("PayoutsCertain")
    public Integer getPayoutsCertain() {
        return payoutsCertain;
    }

    @JsonProperty("PayoutsCertain")
    public void setPayoutsCertain(Integer payoutsCertain) {
        this.payoutsCertain = payoutsCertain;
    }

    public RequestBasis withPayoutsCertain(Integer payoutsCertain) {
        this.payoutsCertain = payoutsCertain;
        return this;
    }

    @JsonProperty("PayoutAmt")
    public Integer getPayoutAmt() {
        return payoutAmt;
    }

    @JsonProperty("PayoutAmt")
    public void setPayoutAmt(Integer payoutAmt) {
        this.payoutAmt = payoutAmt;
    }

    public RequestBasis withPayoutAmt(Integer payoutAmt) {
        this.payoutAmt = payoutAmt;
        return this;
    }

    @JsonProperty("SinglePremiumAmt")
    public Integer getSinglePremiumAmt() {
        return singlePremiumAmt;
    }

    @JsonProperty("SinglePremiumAmt")
    public void setSinglePremiumAmt(Integer singlePremiumAmt) {
        this.singlePremiumAmt = singlePremiumAmt;
    }

    public RequestBasis withSinglePremiumAmt(Integer singlePremiumAmt) {
        this.singlePremiumAmt = singlePremiumAmt;
        return this;
    }

    @JsonProperty("StatePremiumTaxRate")
    public Integer getStatePremiumTaxRate() {
        return statePremiumTaxRate;
    }

    @JsonProperty("StatePremiumTaxRate")
    public void setStatePremiumTaxRate(Integer statePremiumTaxRate) {
        this.statePremiumTaxRate = statePremiumTaxRate;
    }

    public RequestBasis withStatePremiumTaxRate(Integer statePremiumTaxRate) {
        this.statePremiumTaxRate = statePremiumTaxRate;
        return this;
    }

    @JsonProperty("PolFee")
    public Integer getPolFee() {
        return polFee;
    }

    @JsonProperty("PolFee")
    public void setPolFee(Integer polFee) {
        this.polFee = polFee;
    }

    public RequestBasis withPolFee(Integer polFee) {
        this.polFee = polFee;
        return this;
    }

    @JsonProperty("OverrideStatePremiumTaxInd")
    public OverrideStatePremiumTaxInd getOverrideStatePremiumTaxInd() {
        return overrideStatePremiumTaxInd;
    }

    @JsonProperty("OverrideStatePremiumTaxInd")
    public void setOverrideStatePremiumTaxInd(OverrideStatePremiumTaxInd overrideStatePremiumTaxInd) {
        this.overrideStatePremiumTaxInd = overrideStatePremiumTaxInd;
    }

    public RequestBasis withOverrideStatePremiumTaxInd(OverrideStatePremiumTaxInd overrideStatePremiumTaxInd) {
        this.overrideStatePremiumTaxInd = overrideStatePremiumTaxInd;
        return this;
    }

    @JsonProperty("OverrideStatePremiumTaxAmt")
    public Integer getOverrideStatePremiumTaxAmt() {
        return overrideStatePremiumTaxAmt;
    }

    @JsonProperty("OverrideStatePremiumTaxAmt")
    public void setOverrideStatePremiumTaxAmt(Integer overrideStatePremiumTaxAmt) {
        this.overrideStatePremiumTaxAmt = overrideStatePremiumTaxAmt;
    }

    public RequestBasis withOverrideStatePremiumTaxAmt(Integer overrideStatePremiumTaxAmt) {
        this.overrideStatePremiumTaxAmt = overrideStatePremiumTaxAmt;
        return this;
    }

    @JsonProperty("RelativeUnderwritingBasis")
    public RelativeUnderwritingBasis getRelativeUnderwritingBasis() {
        return relativeUnderwritingBasis;
    }

    @JsonProperty("RelativeUnderwritingBasis")
    public void setRelativeUnderwritingBasis(RelativeUnderwritingBasis relativeUnderwritingBasis) {
        this.relativeUnderwritingBasis = relativeUnderwritingBasis;
    }

    public RequestBasis withRelativeUnderwritingBasis(RelativeUnderwritingBasis relativeUnderwritingBasis) {
        this.relativeUnderwritingBasis = relativeUnderwritingBasis;
        return this;
    }

    @JsonProperty("VectorRequest")
    public List<Object> getVectorRequest() {
        return vectorRequest;
    }

    @JsonProperty("VectorRequest")
    public void setVectorRequest(List<Object> vectorRequest) {
        this.vectorRequest = vectorRequest;
    }

    public RequestBasis withVectorRequest(List<Object> vectorRequest) {
        this.vectorRequest = vectorRequest;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public RequestBasis withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public RequestBasis withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public RequestBasis withId(String id) {
        this.id = id;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RequestBasis withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(RequestBasis.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("basisName");
        sb.append('=');
        sb.append(((this.basisName == null)?"<null>":this.basisName));
        sb.append(',');
        sb.append("interestAssumption");
        sb.append('=');
        sb.append(((this.interestAssumption == null)?"<null>":this.interestAssumption));
        sb.append(',');
        sb.append("interestAssumptionRate");
        sb.append('=');
        sb.append(((this.interestAssumptionRate == null)?"<null>":this.interestAssumptionRate));
        sb.append(',');
        sb.append("mortalityAssumption");
        sb.append('=');
        sb.append(((this.mortalityAssumption == null)?"<null>":this.mortalityAssumption));
        sb.append(',');
        sb.append("mortalityAssumptionBlend");
        sb.append('=');
        sb.append(((this.mortalityAssumptionBlend == null)?"<null>":this.mortalityAssumptionBlend));
        sb.append(',');
        sb.append("mortalityReEntryInd");
        sb.append('=');
        sb.append(((this.mortalityReEntryInd == null)?"<null>":this.mortalityReEntryInd));
        sb.append(',');
        sb.append("dividendAssumption");
        sb.append('=');
        sb.append(((this.dividendAssumption == null)?"<null>":this.dividendAssumption));
        sb.append(',');
        sb.append("dividendAssumptionBlend");
        sb.append('=');
        sb.append(((this.dividendAssumptionBlend == null)?"<null>":this.dividendAssumptionBlend));
        sb.append(',');
        sb.append("illustrateNonGuarBonusInd");
        sb.append('=');
        sb.append(((this.illustrateNonGuarBonusInd == null)?"<null>":this.illustrateNonGuarBonusInd));
        sb.append(',');
        sb.append("lifeExpectancy");
        sb.append('=');
        sb.append(((this.lifeExpectancy == null)?"<null>":this.lifeExpectancy));
        sb.append(',');
        sb.append("jointLifeExpectancy");
        sb.append('=');
        sb.append(((this.jointLifeExpectancy == null)?"<null>":this.jointLifeExpectancy));
        sb.append(',');
        sb.append("exclusionRatio");
        sb.append('=');
        sb.append(((this.exclusionRatio == null)?"<null>":this.exclusionRatio));
        sb.append(',');
        sb.append("gtdPayoutAmt");
        sb.append('=');
        sb.append(((this.gtdPayoutAmt == null)?"<null>":this.gtdPayoutAmt));
        sb.append(',');
        sb.append("internalRateOfReturn");
        sb.append('=');
        sb.append(((this.internalRateOfReturn == null)?"<null>":this.internalRateOfReturn));
        sb.append(',');
        sb.append("lastGtdPayoutDate");
        sb.append('=');
        sb.append(((this.lastGtdPayoutDate == null)?"<null>":this.lastGtdPayoutDate));
        sb.append(',');
        sb.append("maxMortalityAge");
        sb.append('=');
        sb.append(((this.maxMortalityAge == null)?"<null>":this.maxMortalityAge));
        sb.append(',');
        sb.append("payoutsCertain");
        sb.append('=');
        sb.append(((this.payoutsCertain == null)?"<null>":this.payoutsCertain));
        sb.append(',');
        sb.append("payoutAmt");
        sb.append('=');
        sb.append(((this.payoutAmt == null)?"<null>":this.payoutAmt));
        sb.append(',');
        sb.append("singlePremiumAmt");
        sb.append('=');
        sb.append(((this.singlePremiumAmt == null)?"<null>":this.singlePremiumAmt));
        sb.append(',');
        sb.append("statePremiumTaxRate");
        sb.append('=');
        sb.append(((this.statePremiumTaxRate == null)?"<null>":this.statePremiumTaxRate));
        sb.append(',');
        sb.append("polFee");
        sb.append('=');
        sb.append(((this.polFee == null)?"<null>":this.polFee));
        sb.append(',');
        sb.append("overrideStatePremiumTaxInd");
        sb.append('=');
        sb.append(((this.overrideStatePremiumTaxInd == null)?"<null>":this.overrideStatePremiumTaxInd));
        sb.append(',');
        sb.append("overrideStatePremiumTaxAmt");
        sb.append('=');
        sb.append(((this.overrideStatePremiumTaxAmt == null)?"<null>":this.overrideStatePremiumTaxAmt));
        sb.append(',');
        sb.append("relativeUnderwritingBasis");
        sb.append('=');
        sb.append(((this.relativeUnderwritingBasis == null)?"<null>":this.relativeUnderwritingBasis));
        sb.append(',');
        sb.append("vectorRequest");
        sb.append('=');
        sb.append(((this.vectorRequest == null)?"<null>":this.vectorRequest));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.lastGtdPayoutDate == null)? 0 :this.lastGtdPayoutDate.hashCode()));
        result = ((result* 31)+((this.dividendAssumptionBlend == null)? 0 :this.dividendAssumptionBlend.hashCode()));
        result = ((result* 31)+((this.internalRateOfReturn == null)? 0 :this.internalRateOfReturn.hashCode()));
        result = ((result* 31)+((this.singlePremiumAmt == null)? 0 :this.singlePremiumAmt.hashCode()));
        result = ((result* 31)+((this.gtdPayoutAmt == null)? 0 :this.gtdPayoutAmt.hashCode()));
        result = ((result* 31)+((this.interestAssumptionRate == null)? 0 :this.interestAssumptionRate.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.interestAssumption == null)? 0 :this.interestAssumption.hashCode()));
        result = ((result* 31)+((this.lifeExpectancy == null)? 0 :this.lifeExpectancy.hashCode()));
        result = ((result* 31)+((this.mortalityAssumption == null)? 0 :this.mortalityAssumption.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.polFee == null)? 0 :this.polFee.hashCode()));
        result = ((result* 31)+((this.mortalityReEntryInd == null)? 0 :this.mortalityReEntryInd.hashCode()));
        result = ((result* 31)+((this.mortalityAssumptionBlend == null)? 0 :this.mortalityAssumptionBlend.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.dividendAssumption == null)? 0 :this.dividendAssumption.hashCode()));
        result = ((result* 31)+((this.overrideStatePremiumTaxInd == null)? 0 :this.overrideStatePremiumTaxInd.hashCode()));
        result = ((result* 31)+((this.illustrateNonGuarBonusInd == null)? 0 :this.illustrateNonGuarBonusInd.hashCode()));
        result = ((result* 31)+((this.jointLifeExpectancy == null)? 0 :this.jointLifeExpectancy.hashCode()));
        result = ((result* 31)+((this.vectorRequest == null)? 0 :this.vectorRequest.hashCode()));
        result = ((result* 31)+((this.exclusionRatio == null)? 0 :this.exclusionRatio.hashCode()));
        result = ((result* 31)+((this.relativeUnderwritingBasis == null)? 0 :this.relativeUnderwritingBasis.hashCode()));
        result = ((result* 31)+((this.payoutAmt == null)? 0 :this.payoutAmt.hashCode()));
        result = ((result* 31)+((this.statePremiumTaxRate == null)? 0 :this.statePremiumTaxRate.hashCode()));
        result = ((result* 31)+((this.maxMortalityAge == null)? 0 :this.maxMortalityAge.hashCode()));
        result = ((result* 31)+((this.payoutsCertain == null)? 0 :this.payoutsCertain.hashCode()));
        result = ((result* 31)+((this.overrideStatePremiumTaxAmt == null)? 0 :this.overrideStatePremiumTaxAmt.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.basisName == null)? 0 :this.basisName.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RequestBasis) == false) {
            return false;
        }
        RequestBasis rhs = ((RequestBasis) other);
        return ((((((((((((((((((((((((((((((this.lastGtdPayoutDate == rhs.lastGtdPayoutDate)||((this.lastGtdPayoutDate!= null)&&this.lastGtdPayoutDate.equals(rhs.lastGtdPayoutDate)))&&((this.dividendAssumptionBlend == rhs.dividendAssumptionBlend)||((this.dividendAssumptionBlend!= null)&&this.dividendAssumptionBlend.equals(rhs.dividendAssumptionBlend))))&&((this.internalRateOfReturn == rhs.internalRateOfReturn)||((this.internalRateOfReturn!= null)&&this.internalRateOfReturn.equals(rhs.internalRateOfReturn))))&&((this.singlePremiumAmt == rhs.singlePremiumAmt)||((this.singlePremiumAmt!= null)&&this.singlePremiumAmt.equals(rhs.singlePremiumAmt))))&&((this.gtdPayoutAmt == rhs.gtdPayoutAmt)||((this.gtdPayoutAmt!= null)&&this.gtdPayoutAmt.equals(rhs.gtdPayoutAmt))))&&((this.interestAssumptionRate == rhs.interestAssumptionRate)||((this.interestAssumptionRate!= null)&&this.interestAssumptionRate.equals(rhs.interestAssumptionRate))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.interestAssumption == rhs.interestAssumption)||((this.interestAssumption!= null)&&this.interestAssumption.equals(rhs.interestAssumption))))&&((this.lifeExpectancy == rhs.lifeExpectancy)||((this.lifeExpectancy!= null)&&this.lifeExpectancy.equals(rhs.lifeExpectancy))))&&((this.mortalityAssumption == rhs.mortalityAssumption)||((this.mortalityAssumption!= null)&&this.mortalityAssumption.equals(rhs.mortalityAssumption))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.polFee == rhs.polFee)||((this.polFee!= null)&&this.polFee.equals(rhs.polFee))))&&((this.mortalityReEntryInd == rhs.mortalityReEntryInd)||((this.mortalityReEntryInd!= null)&&this.mortalityReEntryInd.equals(rhs.mortalityReEntryInd))))&&((this.mortalityAssumptionBlend == rhs.mortalityAssumptionBlend)||((this.mortalityAssumptionBlend!= null)&&this.mortalityAssumptionBlend.equals(rhs.mortalityAssumptionBlend))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.dividendAssumption == rhs.dividendAssumption)||((this.dividendAssumption!= null)&&this.dividendAssumption.equals(rhs.dividendAssumption))))&&((this.overrideStatePremiumTaxInd == rhs.overrideStatePremiumTaxInd)||((this.overrideStatePremiumTaxInd!= null)&&this.overrideStatePremiumTaxInd.equals(rhs.overrideStatePremiumTaxInd))))&&((this.illustrateNonGuarBonusInd == rhs.illustrateNonGuarBonusInd)||((this.illustrateNonGuarBonusInd!= null)&&this.illustrateNonGuarBonusInd.equals(rhs.illustrateNonGuarBonusInd))))&&((this.jointLifeExpectancy == rhs.jointLifeExpectancy)||((this.jointLifeExpectancy!= null)&&this.jointLifeExpectancy.equals(rhs.jointLifeExpectancy))))&&((this.vectorRequest == rhs.vectorRequest)||((this.vectorRequest!= null)&&this.vectorRequest.equals(rhs.vectorRequest))))&&((this.exclusionRatio == rhs.exclusionRatio)||((this.exclusionRatio!= null)&&this.exclusionRatio.equals(rhs.exclusionRatio))))&&((this.relativeUnderwritingBasis == rhs.relativeUnderwritingBasis)||((this.relativeUnderwritingBasis!= null)&&this.relativeUnderwritingBasis.equals(rhs.relativeUnderwritingBasis))))&&((this.payoutAmt == rhs.payoutAmt)||((this.payoutAmt!= null)&&this.payoutAmt.equals(rhs.payoutAmt))))&&((this.statePremiumTaxRate == rhs.statePremiumTaxRate)||((this.statePremiumTaxRate!= null)&&this.statePremiumTaxRate.equals(rhs.statePremiumTaxRate))))&&((this.maxMortalityAge == rhs.maxMortalityAge)||((this.maxMortalityAge!= null)&&this.maxMortalityAge.equals(rhs.maxMortalityAge))))&&((this.payoutsCertain == rhs.payoutsCertain)||((this.payoutsCertain!= null)&&this.payoutsCertain.equals(rhs.payoutsCertain))))&&((this.overrideStatePremiumTaxAmt == rhs.overrideStatePremiumTaxAmt)||((this.overrideStatePremiumTaxAmt!= null)&&this.overrideStatePremiumTaxAmt.equals(rhs.overrideStatePremiumTaxAmt))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.basisName == rhs.basisName)||((this.basisName!= null)&&this.basisName.equals(rhs.basisName))));
    }

}
