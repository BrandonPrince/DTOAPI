
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "MinBalanceCalcRuleKey",
    "MinBalanceCalcRuleSysKey",
    "AggregationMethod",
    "MinBalanceCalcRuleType",
    "FlatAmount",
    "MinMonthCOI",
    "BalanceType",
    "MinPct",
    "MinBalanceCalcRule",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class MinBalanceCalcRule {

    @JsonProperty("MinBalanceCalcRuleKey")
    private MinBalanceCalcRuleKey minBalanceCalcRuleKey;
    @JsonProperty("MinBalanceCalcRuleSysKey")
    private List<Object> minBalanceCalcRuleSysKey = new ArrayList<>();
    @JsonProperty("AggregationMethod")
    private AggregationMethod aggregationMethod;
    @JsonProperty("MinBalanceCalcRuleType")
    private MinBalanceCalcRuleType minBalanceCalcRuleType;
    @JsonProperty("FlatAmount")
    private Integer flatAmount;
    @JsonProperty("MinMonthCOI")
    private Integer minMonthCOI;
    @JsonProperty("BalanceType")
    private BalanceType balanceType;
    @JsonProperty("MinPct")
    private Integer minPct;
    @JsonProperty("MinBalanceCalcRule")
    private List<Object> minBalanceCalcRule = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("MinBalanceCalcRuleKey")
    public MinBalanceCalcRuleKey getMinBalanceCalcRuleKey() {
        return minBalanceCalcRuleKey;
    }

    @JsonProperty("MinBalanceCalcRuleKey")
    public void setMinBalanceCalcRuleKey(MinBalanceCalcRuleKey minBalanceCalcRuleKey) {
        this.minBalanceCalcRuleKey = minBalanceCalcRuleKey;
    }

    public MinBalanceCalcRule withMinBalanceCalcRuleKey(MinBalanceCalcRuleKey minBalanceCalcRuleKey) {
        this.minBalanceCalcRuleKey = minBalanceCalcRuleKey;
        return this;
    }

    @JsonProperty("MinBalanceCalcRuleSysKey")
    public List<Object> getMinBalanceCalcRuleSysKey() {
        return minBalanceCalcRuleSysKey;
    }

    @JsonProperty("MinBalanceCalcRuleSysKey")
    public void setMinBalanceCalcRuleSysKey(List<Object> minBalanceCalcRuleSysKey) {
        this.minBalanceCalcRuleSysKey = minBalanceCalcRuleSysKey;
    }

    public MinBalanceCalcRule withMinBalanceCalcRuleSysKey(List<Object> minBalanceCalcRuleSysKey) {
        this.minBalanceCalcRuleSysKey = minBalanceCalcRuleSysKey;
        return this;
    }

    @JsonProperty("AggregationMethod")
    public AggregationMethod getAggregationMethod() {
        return aggregationMethod;
    }

    @JsonProperty("AggregationMethod")
    public void setAggregationMethod(AggregationMethod aggregationMethod) {
        this.aggregationMethod = aggregationMethod;
    }

    public MinBalanceCalcRule withAggregationMethod(AggregationMethod aggregationMethod) {
        this.aggregationMethod = aggregationMethod;
        return this;
    }

    @JsonProperty("MinBalanceCalcRuleType")
    public MinBalanceCalcRuleType getMinBalanceCalcRuleType() {
        return minBalanceCalcRuleType;
    }

    @JsonProperty("MinBalanceCalcRuleType")
    public void setMinBalanceCalcRuleType(MinBalanceCalcRuleType minBalanceCalcRuleType) {
        this.minBalanceCalcRuleType = minBalanceCalcRuleType;
    }

    public MinBalanceCalcRule withMinBalanceCalcRuleType(MinBalanceCalcRuleType minBalanceCalcRuleType) {
        this.minBalanceCalcRuleType = minBalanceCalcRuleType;
        return this;
    }

    @JsonProperty("FlatAmount")
    public Integer getFlatAmount() {
        return flatAmount;
    }

    @JsonProperty("FlatAmount")
    public void setFlatAmount(Integer flatAmount) {
        this.flatAmount = flatAmount;
    }

    public MinBalanceCalcRule withFlatAmount(Integer flatAmount) {
        this.flatAmount = flatAmount;
        return this;
    }

    @JsonProperty("MinMonthCOI")
    public Integer getMinMonthCOI() {
        return minMonthCOI;
    }

    @JsonProperty("MinMonthCOI")
    public void setMinMonthCOI(Integer minMonthCOI) {
        this.minMonthCOI = minMonthCOI;
    }

    public MinBalanceCalcRule withMinMonthCOI(Integer minMonthCOI) {
        this.minMonthCOI = minMonthCOI;
        return this;
    }

    @JsonProperty("BalanceType")
    public BalanceType getBalanceType() {
        return balanceType;
    }

    @JsonProperty("BalanceType")
    public void setBalanceType(BalanceType balanceType) {
        this.balanceType = balanceType;
    }

    public MinBalanceCalcRule withBalanceType(BalanceType balanceType) {
        this.balanceType = balanceType;
        return this;
    }

    @JsonProperty("MinPct")
    public Integer getMinPct() {
        return minPct;
    }

    @JsonProperty("MinPct")
    public void setMinPct(Integer minPct) {
        this.minPct = minPct;
    }

    public MinBalanceCalcRule withMinPct(Integer minPct) {
        this.minPct = minPct;
        return this;
    }

    @JsonProperty("MinBalanceCalcRule")
    public List<Object> getMinBalanceCalcRule() {
        return minBalanceCalcRule;
    }

    @JsonProperty("MinBalanceCalcRule")
    public void setMinBalanceCalcRule(List<Object> minBalanceCalcRule) {
        this.minBalanceCalcRule = minBalanceCalcRule;
    }

    public MinBalanceCalcRule withMinBalanceCalcRule(List<Object> minBalanceCalcRule) {
        this.minBalanceCalcRule = minBalanceCalcRule;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public MinBalanceCalcRule withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public MinBalanceCalcRule withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public MinBalanceCalcRule withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MinBalanceCalcRule withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(MinBalanceCalcRule.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("minBalanceCalcRuleKey");
        sb.append('=');
        sb.append(((this.minBalanceCalcRuleKey == null)?"<null>":this.minBalanceCalcRuleKey));
        sb.append(',');
        sb.append("minBalanceCalcRuleSysKey");
        sb.append('=');
        sb.append(((this.minBalanceCalcRuleSysKey == null)?"<null>":this.minBalanceCalcRuleSysKey));
        sb.append(',');
        sb.append("aggregationMethod");
        sb.append('=');
        sb.append(((this.aggregationMethod == null)?"<null>":this.aggregationMethod));
        sb.append(',');
        sb.append("minBalanceCalcRuleType");
        sb.append('=');
        sb.append(((this.minBalanceCalcRuleType == null)?"<null>":this.minBalanceCalcRuleType));
        sb.append(',');
        sb.append("flatAmount");
        sb.append('=');
        sb.append(((this.flatAmount == null)?"<null>":this.flatAmount));
        sb.append(',');
        sb.append("minMonthCOI");
        sb.append('=');
        sb.append(((this.minMonthCOI == null)?"<null>":this.minMonthCOI));
        sb.append(',');
        sb.append("balanceType");
        sb.append('=');
        sb.append(((this.balanceType == null)?"<null>":this.balanceType));
        sb.append(',');
        sb.append("minPct");
        sb.append('=');
        sb.append(((this.minPct == null)?"<null>":this.minPct));
        sb.append(',');
        sb.append("minBalanceCalcRule");
        sb.append('=');
        sb.append(((this.minBalanceCalcRule == null)?"<null>":this.minBalanceCalcRule));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.minBalanceCalcRuleSysKey == null)? 0 :this.minBalanceCalcRuleSysKey.hashCode()));
        result = ((result* 31)+((this.minBalanceCalcRuleKey == null)? 0 :this.minBalanceCalcRuleKey.hashCode()));
        result = ((result* 31)+((this.minMonthCOI == null)? 0 :this.minMonthCOI.hashCode()));
        result = ((result* 31)+((this.balanceType == null)? 0 :this.balanceType.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.flatAmount == null)? 0 :this.flatAmount.hashCode()));
        result = ((result* 31)+((this.minPct == null)? 0 :this.minPct.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.minBalanceCalcRule == null)? 0 :this.minBalanceCalcRule.hashCode()));
        result = ((result* 31)+((this.minBalanceCalcRuleType == null)? 0 :this.minBalanceCalcRuleType.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.aggregationMethod == null)? 0 :this.aggregationMethod.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MinBalanceCalcRule) == false) {
            return false;
        }
        MinBalanceCalcRule rhs = ((MinBalanceCalcRule) other);
        return ((((((((((((((this.minBalanceCalcRuleSysKey == rhs.minBalanceCalcRuleSysKey)||((this.minBalanceCalcRuleSysKey!= null)&&this.minBalanceCalcRuleSysKey.equals(rhs.minBalanceCalcRuleSysKey)))&&((this.minBalanceCalcRuleKey == rhs.minBalanceCalcRuleKey)||((this.minBalanceCalcRuleKey!= null)&&this.minBalanceCalcRuleKey.equals(rhs.minBalanceCalcRuleKey))))&&((this.minMonthCOI == rhs.minMonthCOI)||((this.minMonthCOI!= null)&&this.minMonthCOI.equals(rhs.minMonthCOI))))&&((this.balanceType == rhs.balanceType)||((this.balanceType!= null)&&this.balanceType.equals(rhs.balanceType))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.flatAmount == rhs.flatAmount)||((this.flatAmount!= null)&&this.flatAmount.equals(rhs.flatAmount))))&&((this.minPct == rhs.minPct)||((this.minPct!= null)&&this.minPct.equals(rhs.minPct))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.minBalanceCalcRule == rhs.minBalanceCalcRule)||((this.minBalanceCalcRule!= null)&&this.minBalanceCalcRule.equals(rhs.minBalanceCalcRule))))&&((this.minBalanceCalcRuleType == rhs.minBalanceCalcRuleType)||((this.minBalanceCalcRuleType!= null)&&this.minBalanceCalcRuleType.equals(rhs.minBalanceCalcRuleType))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.aggregationMethod == rhs.aggregationMethod)||((this.aggregationMethod!= null)&&this.aggregationMethod.equals(rhs.aggregationMethod))));
    }

}
