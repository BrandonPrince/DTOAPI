
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AvocationInfoKey",
    "AvocationInfoSysKey",
    "AvocationType",
    "AvocationDetails",
    "MaxAvocationValue",
    "MinAvocationValue",
    "AvocationValueQualifier",
    "Attachment",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AvocationInfo {

    @JsonProperty("AvocationInfoKey")
    private AvocationInfoKey avocationInfoKey;
    @JsonProperty("AvocationInfoSysKey")
    private List<Object> avocationInfoSysKey = new ArrayList<>();
    @JsonProperty("AvocationType")
    private AvocationType avocationType;
    @JsonProperty("AvocationDetails")
    private String avocationDetails;
    @JsonProperty("MaxAvocationValue")
    private String maxAvocationValue;
    @JsonProperty("MinAvocationValue")
    private String minAvocationValue;
    @JsonProperty("AvocationValueQualifier")
    private AvocationValueQualifier avocationValueQualifier;
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AvocationInfoKey")
    public AvocationInfoKey getAvocationInfoKey() {
        return avocationInfoKey;
    }

    @JsonProperty("AvocationInfoKey")
    public void setAvocationInfoKey(AvocationInfoKey avocationInfoKey) {
        this.avocationInfoKey = avocationInfoKey;
    }

    public AvocationInfo withAvocationInfoKey(AvocationInfoKey avocationInfoKey) {
        this.avocationInfoKey = avocationInfoKey;
        return this;
    }

    @JsonProperty("AvocationInfoSysKey")
    public List<Object> getAvocationInfoSysKey() {
        return avocationInfoSysKey;
    }

    @JsonProperty("AvocationInfoSysKey")
    public void setAvocationInfoSysKey(List<Object> avocationInfoSysKey) {
        this.avocationInfoSysKey = avocationInfoSysKey;
    }

    public AvocationInfo withAvocationInfoSysKey(List<Object> avocationInfoSysKey) {
        this.avocationInfoSysKey = avocationInfoSysKey;
        return this;
    }

    @JsonProperty("AvocationType")
    public AvocationType getAvocationType() {
        return avocationType;
    }

    @JsonProperty("AvocationType")
    public void setAvocationType(AvocationType avocationType) {
        this.avocationType = avocationType;
    }

    public AvocationInfo withAvocationType(AvocationType avocationType) {
        this.avocationType = avocationType;
        return this;
    }

    @JsonProperty("AvocationDetails")
    public String getAvocationDetails() {
        return avocationDetails;
    }

    @JsonProperty("AvocationDetails")
    public void setAvocationDetails(String avocationDetails) {
        this.avocationDetails = avocationDetails;
    }

    public AvocationInfo withAvocationDetails(String avocationDetails) {
        this.avocationDetails = avocationDetails;
        return this;
    }

    @JsonProperty("MaxAvocationValue")
    public String getMaxAvocationValue() {
        return maxAvocationValue;
    }

    @JsonProperty("MaxAvocationValue")
    public void setMaxAvocationValue(String maxAvocationValue) {
        this.maxAvocationValue = maxAvocationValue;
    }

    public AvocationInfo withMaxAvocationValue(String maxAvocationValue) {
        this.maxAvocationValue = maxAvocationValue;
        return this;
    }

    @JsonProperty("MinAvocationValue")
    public String getMinAvocationValue() {
        return minAvocationValue;
    }

    @JsonProperty("MinAvocationValue")
    public void setMinAvocationValue(String minAvocationValue) {
        this.minAvocationValue = minAvocationValue;
    }

    public AvocationInfo withMinAvocationValue(String minAvocationValue) {
        this.minAvocationValue = minAvocationValue;
        return this;
    }

    @JsonProperty("AvocationValueQualifier")
    public AvocationValueQualifier getAvocationValueQualifier() {
        return avocationValueQualifier;
    }

    @JsonProperty("AvocationValueQualifier")
    public void setAvocationValueQualifier(AvocationValueQualifier avocationValueQualifier) {
        this.avocationValueQualifier = avocationValueQualifier;
    }

    public AvocationInfo withAvocationValueQualifier(AvocationValueQualifier avocationValueQualifier) {
        this.avocationValueQualifier = avocationValueQualifier;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public AvocationInfo withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AvocationInfo withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AvocationInfo withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AvocationInfo withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AvocationInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AvocationInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("avocationInfoKey");
        sb.append('=');
        sb.append(((this.avocationInfoKey == null)?"<null>":this.avocationInfoKey));
        sb.append(',');
        sb.append("avocationInfoSysKey");
        sb.append('=');
        sb.append(((this.avocationInfoSysKey == null)?"<null>":this.avocationInfoSysKey));
        sb.append(',');
        sb.append("avocationType");
        sb.append('=');
        sb.append(((this.avocationType == null)?"<null>":this.avocationType));
        sb.append(',');
        sb.append("avocationDetails");
        sb.append('=');
        sb.append(((this.avocationDetails == null)?"<null>":this.avocationDetails));
        sb.append(',');
        sb.append("maxAvocationValue");
        sb.append('=');
        sb.append(((this.maxAvocationValue == null)?"<null>":this.maxAvocationValue));
        sb.append(',');
        sb.append("minAvocationValue");
        sb.append('=');
        sb.append(((this.minAvocationValue == null)?"<null>":this.minAvocationValue));
        sb.append(',');
        sb.append("avocationValueQualifier");
        sb.append('=');
        sb.append(((this.avocationValueQualifier == null)?"<null>":this.avocationValueQualifier));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.avocationInfoSysKey == null)? 0 :this.avocationInfoSysKey.hashCode()));
        result = ((result* 31)+((this.maxAvocationValue == null)? 0 :this.maxAvocationValue.hashCode()));
        result = ((result* 31)+((this.avocationInfoKey == null)? 0 :this.avocationInfoKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.minAvocationValue == null)? 0 :this.minAvocationValue.hashCode()));
        result = ((result* 31)+((this.avocationValueQualifier == null)? 0 :this.avocationValueQualifier.hashCode()));
        result = ((result* 31)+((this.avocationType == null)? 0 :this.avocationType.hashCode()));
        result = ((result* 31)+((this.avocationDetails == null)? 0 :this.avocationDetails.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AvocationInfo) == false) {
            return false;
        }
        AvocationInfo rhs = ((AvocationInfo) other);
        return (((((((((((((this.avocationInfoSysKey == rhs.avocationInfoSysKey)||((this.avocationInfoSysKey!= null)&&this.avocationInfoSysKey.equals(rhs.avocationInfoSysKey)))&&((this.maxAvocationValue == rhs.maxAvocationValue)||((this.maxAvocationValue!= null)&&this.maxAvocationValue.equals(rhs.maxAvocationValue))))&&((this.avocationInfoKey == rhs.avocationInfoKey)||((this.avocationInfoKey!= null)&&this.avocationInfoKey.equals(rhs.avocationInfoKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.minAvocationValue == rhs.minAvocationValue)||((this.minAvocationValue!= null)&&this.minAvocationValue.equals(rhs.minAvocationValue))))&&((this.avocationValueQualifier == rhs.avocationValueQualifier)||((this.avocationValueQualifier!= null)&&this.avocationValueQualifier.equals(rhs.avocationValueQualifier))))&&((this.avocationType == rhs.avocationType)||((this.avocationType!= null)&&this.avocationType.equals(rhs.avocationType))))&&((this.avocationDetails == rhs.avocationDetails)||((this.avocationDetails!= null)&&this.avocationDetails.equals(rhs.avocationDetails))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
