
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "StartDate",
    "EndDate",
    "RelaxLapseRulesInd",
    "WaivePolicyFeesInd",
    "StopOption",
    "StopAgeYears",
    "VariableProjectionType",
    "ImageType",
    "AttachmentLocation",
    "RevisedIllustrationInd",
    "RequestBasis",
    "IllustrationTxn",
    "IllustrationReportRequest",
    "OLifEExtension",
    "AnchorBasisID"
})
@Generated("jsonschema2pojo")
public class IllustrationRequest {

    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("RelaxLapseRulesInd")
    private RelaxLapseRulesInd relaxLapseRulesInd;
    @JsonProperty("WaivePolicyFeesInd")
    private WaivePolicyFeesInd waivePolicyFeesInd;
    @JsonProperty("StopOption")
    private StopOption stopOption;
    @JsonProperty("StopAgeYears")
    private Integer stopAgeYears;
    @JsonProperty("VariableProjectionType")
    private VariableProjectionType variableProjectionType;
    @JsonProperty("ImageType")
    private ImageType imageType;
    @JsonProperty("AttachmentLocation")
    private AttachmentLocation attachmentLocation;
    @JsonProperty("RevisedIllustrationInd")
    private RevisedIllustrationInd revisedIllustrationInd;
    @JsonProperty("RequestBasis")
    private List<Object> requestBasis = new ArrayList<>();
    @JsonProperty("IllustrationTxn")
    private List<Object> illustrationTxn = new ArrayList<>();
    @JsonProperty("IllustrationReportRequest")
    private List<Object> illustrationReportRequest = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("AnchorBasisID")
    private String anchorBasisID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public IllustrationRequest withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public IllustrationRequest withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("RelaxLapseRulesInd")
    public RelaxLapseRulesInd getRelaxLapseRulesInd() {
        return relaxLapseRulesInd;
    }

    @JsonProperty("RelaxLapseRulesInd")
    public void setRelaxLapseRulesInd(RelaxLapseRulesInd relaxLapseRulesInd) {
        this.relaxLapseRulesInd = relaxLapseRulesInd;
    }

    public IllustrationRequest withRelaxLapseRulesInd(RelaxLapseRulesInd relaxLapseRulesInd) {
        this.relaxLapseRulesInd = relaxLapseRulesInd;
        return this;
    }

    @JsonProperty("WaivePolicyFeesInd")
    public WaivePolicyFeesInd getWaivePolicyFeesInd() {
        return waivePolicyFeesInd;
    }

    @JsonProperty("WaivePolicyFeesInd")
    public void setWaivePolicyFeesInd(WaivePolicyFeesInd waivePolicyFeesInd) {
        this.waivePolicyFeesInd = waivePolicyFeesInd;
    }

    public IllustrationRequest withWaivePolicyFeesInd(WaivePolicyFeesInd waivePolicyFeesInd) {
        this.waivePolicyFeesInd = waivePolicyFeesInd;
        return this;
    }

    @JsonProperty("StopOption")
    public StopOption getStopOption() {
        return stopOption;
    }

    @JsonProperty("StopOption")
    public void setStopOption(StopOption stopOption) {
        this.stopOption = stopOption;
    }

    public IllustrationRequest withStopOption(StopOption stopOption) {
        this.stopOption = stopOption;
        return this;
    }

    @JsonProperty("StopAgeYears")
    public Integer getStopAgeYears() {
        return stopAgeYears;
    }

    @JsonProperty("StopAgeYears")
    public void setStopAgeYears(Integer stopAgeYears) {
        this.stopAgeYears = stopAgeYears;
    }

    public IllustrationRequest withStopAgeYears(Integer stopAgeYears) {
        this.stopAgeYears = stopAgeYears;
        return this;
    }

    @JsonProperty("VariableProjectionType")
    public VariableProjectionType getVariableProjectionType() {
        return variableProjectionType;
    }

    @JsonProperty("VariableProjectionType")
    public void setVariableProjectionType(VariableProjectionType variableProjectionType) {
        this.variableProjectionType = variableProjectionType;
    }

    public IllustrationRequest withVariableProjectionType(VariableProjectionType variableProjectionType) {
        this.variableProjectionType = variableProjectionType;
        return this;
    }

    @JsonProperty("ImageType")
    public ImageType getImageType() {
        return imageType;
    }

    @JsonProperty("ImageType")
    public void setImageType(ImageType imageType) {
        this.imageType = imageType;
    }

    public IllustrationRequest withImageType(ImageType imageType) {
        this.imageType = imageType;
        return this;
    }

    @JsonProperty("AttachmentLocation")
    public AttachmentLocation getAttachmentLocation() {
        return attachmentLocation;
    }

    @JsonProperty("AttachmentLocation")
    public void setAttachmentLocation(AttachmentLocation attachmentLocation) {
        this.attachmentLocation = attachmentLocation;
    }

    public IllustrationRequest withAttachmentLocation(AttachmentLocation attachmentLocation) {
        this.attachmentLocation = attachmentLocation;
        return this;
    }

    @JsonProperty("RevisedIllustrationInd")
    public RevisedIllustrationInd getRevisedIllustrationInd() {
        return revisedIllustrationInd;
    }

    @JsonProperty("RevisedIllustrationInd")
    public void setRevisedIllustrationInd(RevisedIllustrationInd revisedIllustrationInd) {
        this.revisedIllustrationInd = revisedIllustrationInd;
    }

    public IllustrationRequest withRevisedIllustrationInd(RevisedIllustrationInd revisedIllustrationInd) {
        this.revisedIllustrationInd = revisedIllustrationInd;
        return this;
    }

    @JsonProperty("RequestBasis")
    public List<Object> getRequestBasis() {
        return requestBasis;
    }

    @JsonProperty("RequestBasis")
    public void setRequestBasis(List<Object> requestBasis) {
        this.requestBasis = requestBasis;
    }

    public IllustrationRequest withRequestBasis(List<Object> requestBasis) {
        this.requestBasis = requestBasis;
        return this;
    }

    @JsonProperty("IllustrationTxn")
    public List<Object> getIllustrationTxn() {
        return illustrationTxn;
    }

    @JsonProperty("IllustrationTxn")
    public void setIllustrationTxn(List<Object> illustrationTxn) {
        this.illustrationTxn = illustrationTxn;
    }

    public IllustrationRequest withIllustrationTxn(List<Object> illustrationTxn) {
        this.illustrationTxn = illustrationTxn;
        return this;
    }

    @JsonProperty("IllustrationReportRequest")
    public List<Object> getIllustrationReportRequest() {
        return illustrationReportRequest;
    }

    @JsonProperty("IllustrationReportRequest")
    public void setIllustrationReportRequest(List<Object> illustrationReportRequest) {
        this.illustrationReportRequest = illustrationReportRequest;
    }

    public IllustrationRequest withIllustrationReportRequest(List<Object> illustrationReportRequest) {
        this.illustrationReportRequest = illustrationReportRequest;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public IllustrationRequest withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("AnchorBasisID")
    public String getAnchorBasisID() {
        return anchorBasisID;
    }

    @JsonProperty("AnchorBasisID")
    public void setAnchorBasisID(String anchorBasisID) {
        this.anchorBasisID = anchorBasisID;
    }

    public IllustrationRequest withAnchorBasisID(String anchorBasisID) {
        this.anchorBasisID = anchorBasisID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public IllustrationRequest withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(IllustrationRequest.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("relaxLapseRulesInd");
        sb.append('=');
        sb.append(((this.relaxLapseRulesInd == null)?"<null>":this.relaxLapseRulesInd));
        sb.append(',');
        sb.append("waivePolicyFeesInd");
        sb.append('=');
        sb.append(((this.waivePolicyFeesInd == null)?"<null>":this.waivePolicyFeesInd));
        sb.append(',');
        sb.append("stopOption");
        sb.append('=');
        sb.append(((this.stopOption == null)?"<null>":this.stopOption));
        sb.append(',');
        sb.append("stopAgeYears");
        sb.append('=');
        sb.append(((this.stopAgeYears == null)?"<null>":this.stopAgeYears));
        sb.append(',');
        sb.append("variableProjectionType");
        sb.append('=');
        sb.append(((this.variableProjectionType == null)?"<null>":this.variableProjectionType));
        sb.append(',');
        sb.append("imageType");
        sb.append('=');
        sb.append(((this.imageType == null)?"<null>":this.imageType));
        sb.append(',');
        sb.append("attachmentLocation");
        sb.append('=');
        sb.append(((this.attachmentLocation == null)?"<null>":this.attachmentLocation));
        sb.append(',');
        sb.append("revisedIllustrationInd");
        sb.append('=');
        sb.append(((this.revisedIllustrationInd == null)?"<null>":this.revisedIllustrationInd));
        sb.append(',');
        sb.append("requestBasis");
        sb.append('=');
        sb.append(((this.requestBasis == null)?"<null>":this.requestBasis));
        sb.append(',');
        sb.append("illustrationTxn");
        sb.append('=');
        sb.append(((this.illustrationTxn == null)?"<null>":this.illustrationTxn));
        sb.append(',');
        sb.append("illustrationReportRequest");
        sb.append('=');
        sb.append(((this.illustrationReportRequest == null)?"<null>":this.illustrationReportRequest));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("anchorBasisID");
        sb.append('=');
        sb.append(((this.anchorBasisID == null)?"<null>":this.anchorBasisID));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.requestBasis == null)? 0 :this.requestBasis.hashCode()));
        result = ((result* 31)+((this.revisedIllustrationInd == null)? 0 :this.revisedIllustrationInd.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.illustrationReportRequest == null)? 0 :this.illustrationReportRequest.hashCode()));
        result = ((result* 31)+((this.attachmentLocation == null)? 0 :this.attachmentLocation.hashCode()));
        result = ((result* 31)+((this.relaxLapseRulesInd == null)? 0 :this.relaxLapseRulesInd.hashCode()));
        result = ((result* 31)+((this.stopAgeYears == null)? 0 :this.stopAgeYears.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.variableProjectionType == null)? 0 :this.variableProjectionType.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.stopOption == null)? 0 :this.stopOption.hashCode()));
        result = ((result* 31)+((this.waivePolicyFeesInd == null)? 0 :this.waivePolicyFeesInd.hashCode()));
        result = ((result* 31)+((this.imageType == null)? 0 :this.imageType.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        result = ((result* 31)+((this.illustrationTxn == null)? 0 :this.illustrationTxn.hashCode()));
        result = ((result* 31)+((this.anchorBasisID == null)? 0 :this.anchorBasisID.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof IllustrationRequest) == false) {
            return false;
        }
        IllustrationRequest rhs = ((IllustrationRequest) other);
        return (((((((((((((((((this.requestBasis == rhs.requestBasis)||((this.requestBasis!= null)&&this.requestBasis.equals(rhs.requestBasis)))&&((this.revisedIllustrationInd == rhs.revisedIllustrationInd)||((this.revisedIllustrationInd!= null)&&this.revisedIllustrationInd.equals(rhs.revisedIllustrationInd))))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.illustrationReportRequest == rhs.illustrationReportRequest)||((this.illustrationReportRequest!= null)&&this.illustrationReportRequest.equals(rhs.illustrationReportRequest))))&&((this.attachmentLocation == rhs.attachmentLocation)||((this.attachmentLocation!= null)&&this.attachmentLocation.equals(rhs.attachmentLocation))))&&((this.relaxLapseRulesInd == rhs.relaxLapseRulesInd)||((this.relaxLapseRulesInd!= null)&&this.relaxLapseRulesInd.equals(rhs.relaxLapseRulesInd))))&&((this.stopAgeYears == rhs.stopAgeYears)||((this.stopAgeYears!= null)&&this.stopAgeYears.equals(rhs.stopAgeYears))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.variableProjectionType == rhs.variableProjectionType)||((this.variableProjectionType!= null)&&this.variableProjectionType.equals(rhs.variableProjectionType))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.stopOption == rhs.stopOption)||((this.stopOption!= null)&&this.stopOption.equals(rhs.stopOption))))&&((this.waivePolicyFeesInd == rhs.waivePolicyFeesInd)||((this.waivePolicyFeesInd!= null)&&this.waivePolicyFeesInd.equals(rhs.waivePolicyFeesInd))))&&((this.imageType == rhs.imageType)||((this.imageType!= null)&&this.imageType.equals(rhs.imageType))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))))&&((this.illustrationTxn == rhs.illustrationTxn)||((this.illustrationTxn!= null)&&this.illustrationTxn.equals(rhs.illustrationTxn))))&&((this.anchorBasisID == rhs.anchorBasisID)||((this.anchorBasisID!= null)&&this.anchorBasisID.equals(rhs.anchorBasisID))));
    }

}
