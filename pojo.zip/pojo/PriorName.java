
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "PriorNameKey",
    "PriorNameSysKey",
    "NameType",
    "FullName",
    "FirstName",
    "MiddleName",
    "MiddleName1",
    "MiddleName2",
    "LastName",
    "Suffix",
    "AbbrName",
    "DBA",
    "Prefix",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class PriorName {

    @JsonProperty("PriorNameKey")
    private PriorNameKey priorNameKey;
    @JsonProperty("PriorNameSysKey")
    private List<Object> priorNameSysKey = new ArrayList<>();
    @JsonProperty("NameType")
    private NameType nameType;
    @JsonProperty("FullName")
    private String fullName;
    @JsonProperty("FirstName")
    private String firstName;
    @JsonProperty("MiddleName")
    private String middleName;
    @JsonProperty("MiddleName1")
    private String middleName1;
    @JsonProperty("MiddleName2")
    private String middleName2;
    @JsonProperty("LastName")
    private String lastName;
    @JsonProperty("Suffix")
    private String suffix;
    @JsonProperty("AbbrName")
    private String abbrName;
    @JsonProperty("DBA")
    private String dba;
    @JsonProperty("Prefix")
    private String prefix;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("PriorNameKey")
    public PriorNameKey getPriorNameKey() {
        return priorNameKey;
    }

    @JsonProperty("PriorNameKey")
    public void setPriorNameKey(PriorNameKey priorNameKey) {
        this.priorNameKey = priorNameKey;
    }

    public PriorName withPriorNameKey(PriorNameKey priorNameKey) {
        this.priorNameKey = priorNameKey;
        return this;
    }

    @JsonProperty("PriorNameSysKey")
    public List<Object> getPriorNameSysKey() {
        return priorNameSysKey;
    }

    @JsonProperty("PriorNameSysKey")
    public void setPriorNameSysKey(List<Object> priorNameSysKey) {
        this.priorNameSysKey = priorNameSysKey;
    }

    public PriorName withPriorNameSysKey(List<Object> priorNameSysKey) {
        this.priorNameSysKey = priorNameSysKey;
        return this;
    }

    @JsonProperty("NameType")
    public NameType getNameType() {
        return nameType;
    }

    @JsonProperty("NameType")
    public void setNameType(NameType nameType) {
        this.nameType = nameType;
    }

    public PriorName withNameType(NameType nameType) {
        this.nameType = nameType;
        return this;
    }

    @JsonProperty("FullName")
    public String getFullName() {
        return fullName;
    }

    @JsonProperty("FullName")
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public PriorName withFullName(String fullName) {
        this.fullName = fullName;
        return this;
    }

    @JsonProperty("FirstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("FirstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public PriorName withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("MiddleName")
    public String getMiddleName() {
        return middleName;
    }

    @JsonProperty("MiddleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public PriorName withMiddleName(String middleName) {
        this.middleName = middleName;
        return this;
    }

    @JsonProperty("MiddleName1")
    public String getMiddleName1() {
        return middleName1;
    }

    @JsonProperty("MiddleName1")
    public void setMiddleName1(String middleName1) {
        this.middleName1 = middleName1;
    }

    public PriorName withMiddleName1(String middleName1) {
        this.middleName1 = middleName1;
        return this;
    }

    @JsonProperty("MiddleName2")
    public String getMiddleName2() {
        return middleName2;
    }

    @JsonProperty("MiddleName2")
    public void setMiddleName2(String middleName2) {
        this.middleName2 = middleName2;
    }

    public PriorName withMiddleName2(String middleName2) {
        this.middleName2 = middleName2;
        return this;
    }

    @JsonProperty("LastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("LastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public PriorName withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("Suffix")
    public String getSuffix() {
        return suffix;
    }

    @JsonProperty("Suffix")
    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public PriorName withSuffix(String suffix) {
        this.suffix = suffix;
        return this;
    }

    @JsonProperty("AbbrName")
    public String getAbbrName() {
        return abbrName;
    }

    @JsonProperty("AbbrName")
    public void setAbbrName(String abbrName) {
        this.abbrName = abbrName;
    }

    public PriorName withAbbrName(String abbrName) {
        this.abbrName = abbrName;
        return this;
    }

    @JsonProperty("DBA")
    public String getDba() {
        return dba;
    }

    @JsonProperty("DBA")
    public void setDba(String dba) {
        this.dba = dba;
    }

    public PriorName withDba(String dba) {
        this.dba = dba;
        return this;
    }

    @JsonProperty("Prefix")
    public String getPrefix() {
        return prefix;
    }

    @JsonProperty("Prefix")
    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public PriorName withPrefix(String prefix) {
        this.prefix = prefix;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public PriorName withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public PriorName withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public PriorName withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PriorName withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(PriorName.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("priorNameKey");
        sb.append('=');
        sb.append(((this.priorNameKey == null)?"<null>":this.priorNameKey));
        sb.append(',');
        sb.append("priorNameSysKey");
        sb.append('=');
        sb.append(((this.priorNameSysKey == null)?"<null>":this.priorNameSysKey));
        sb.append(',');
        sb.append("nameType");
        sb.append('=');
        sb.append(((this.nameType == null)?"<null>":this.nameType));
        sb.append(',');
        sb.append("fullName");
        sb.append('=');
        sb.append(((this.fullName == null)?"<null>":this.fullName));
        sb.append(',');
        sb.append("firstName");
        sb.append('=');
        sb.append(((this.firstName == null)?"<null>":this.firstName));
        sb.append(',');
        sb.append("middleName");
        sb.append('=');
        sb.append(((this.middleName == null)?"<null>":this.middleName));
        sb.append(',');
        sb.append("middleName1");
        sb.append('=');
        sb.append(((this.middleName1 == null)?"<null>":this.middleName1));
        sb.append(',');
        sb.append("middleName2");
        sb.append('=');
        sb.append(((this.middleName2 == null)?"<null>":this.middleName2));
        sb.append(',');
        sb.append("lastName");
        sb.append('=');
        sb.append(((this.lastName == null)?"<null>":this.lastName));
        sb.append(',');
        sb.append("suffix");
        sb.append('=');
        sb.append(((this.suffix == null)?"<null>":this.suffix));
        sb.append(',');
        sb.append("abbrName");
        sb.append('=');
        sb.append(((this.abbrName == null)?"<null>":this.abbrName));
        sb.append(',');
        sb.append("dba");
        sb.append('=');
        sb.append(((this.dba == null)?"<null>":this.dba));
        sb.append(',');
        sb.append("prefix");
        sb.append('=');
        sb.append(((this.prefix == null)?"<null>":this.prefix));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.lastName == null)? 0 :this.lastName.hashCode()));
        result = ((result* 31)+((this.dba == null)? 0 :this.dba.hashCode()));
        result = ((result* 31)+((this.priorNameSysKey == null)? 0 :this.priorNameSysKey.hashCode()));
        result = ((result* 31)+((this.prefix == null)? 0 :this.prefix.hashCode()));
        result = ((result* 31)+((this.abbrName == null)? 0 :this.abbrName.hashCode()));
        result = ((result* 31)+((this.fullName == null)? 0 :this.fullName.hashCode()));
        result = ((result* 31)+((this.suffix == null)? 0 :this.suffix.hashCode()));
        result = ((result* 31)+((this.nameType == null)? 0 :this.nameType.hashCode()));
        result = ((result* 31)+((this.firstName == null)? 0 :this.firstName.hashCode()));
        result = ((result* 31)+((this.middleName2 == null)? 0 :this.middleName2 .hashCode()));
        result = ((result* 31)+((this.middleName1 == null)? 0 :this.middleName1 .hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.priorNameKey == null)? 0 :this.priorNameKey.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.middleName == null)? 0 :this.middleName.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PriorName) == false) {
            return false;
        }
        PriorName rhs = ((PriorName) other);
        return ((((((((((((((((((this.lastName == rhs.lastName)||((this.lastName!= null)&&this.lastName.equals(rhs.lastName)))&&((this.dba == rhs.dba)||((this.dba!= null)&&this.dba.equals(rhs.dba))))&&((this.priorNameSysKey == rhs.priorNameSysKey)||((this.priorNameSysKey!= null)&&this.priorNameSysKey.equals(rhs.priorNameSysKey))))&&((this.prefix == rhs.prefix)||((this.prefix!= null)&&this.prefix.equals(rhs.prefix))))&&((this.abbrName == rhs.abbrName)||((this.abbrName!= null)&&this.abbrName.equals(rhs.abbrName))))&&((this.fullName == rhs.fullName)||((this.fullName!= null)&&this.fullName.equals(rhs.fullName))))&&((this.suffix == rhs.suffix)||((this.suffix!= null)&&this.suffix.equals(rhs.suffix))))&&((this.nameType == rhs.nameType)||((this.nameType!= null)&&this.nameType.equals(rhs.nameType))))&&((this.firstName == rhs.firstName)||((this.firstName!= null)&&this.firstName.equals(rhs.firstName))))&&((this.middleName2 == rhs.middleName2)||((this.middleName2 != null)&&this.middleName2 .equals(rhs.middleName2))))&&((this.middleName1 == rhs.middleName1)||((this.middleName1 != null)&&this.middleName1 .equals(rhs.middleName1))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.priorNameKey == rhs.priorNameKey)||((this.priorNameKey!= null)&&this.priorNameKey.equals(rhs.priorNameKey))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.middleName == rhs.middleName)||((this.middleName!= null)&&this.middleName.equals(rhs.middleName))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
