
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "EmploymentClassOptionKey",
    "EmploymentClassOptionSysKey",
    "EmploymentClass",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class EmploymentClassOption {

    @JsonProperty("EmploymentClassOptionKey")
    private EmploymentClassOptionKey employmentClassOptionKey;
    @JsonProperty("EmploymentClassOptionSysKey")
    private List<Object> employmentClassOptionSysKey = new ArrayList<>();
    @JsonProperty("EmploymentClass")
    private EmploymentClass employmentClass;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("EmploymentClassOptionKey")
    public EmploymentClassOptionKey getEmploymentClassOptionKey() {
        return employmentClassOptionKey;
    }

    @JsonProperty("EmploymentClassOptionKey")
    public void setEmploymentClassOptionKey(EmploymentClassOptionKey employmentClassOptionKey) {
        this.employmentClassOptionKey = employmentClassOptionKey;
    }

    public EmploymentClassOption withEmploymentClassOptionKey(EmploymentClassOptionKey employmentClassOptionKey) {
        this.employmentClassOptionKey = employmentClassOptionKey;
        return this;
    }

    @JsonProperty("EmploymentClassOptionSysKey")
    public List<Object> getEmploymentClassOptionSysKey() {
        return employmentClassOptionSysKey;
    }

    @JsonProperty("EmploymentClassOptionSysKey")
    public void setEmploymentClassOptionSysKey(List<Object> employmentClassOptionSysKey) {
        this.employmentClassOptionSysKey = employmentClassOptionSysKey;
    }

    public EmploymentClassOption withEmploymentClassOptionSysKey(List<Object> employmentClassOptionSysKey) {
        this.employmentClassOptionSysKey = employmentClassOptionSysKey;
        return this;
    }

    @JsonProperty("EmploymentClass")
    public EmploymentClass getEmploymentClass() {
        return employmentClass;
    }

    @JsonProperty("EmploymentClass")
    public void setEmploymentClass(EmploymentClass employmentClass) {
        this.employmentClass = employmentClass;
    }

    public EmploymentClassOption withEmploymentClass(EmploymentClass employmentClass) {
        this.employmentClass = employmentClass;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public EmploymentClassOption withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public EmploymentClassOption withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public EmploymentClassOption withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public EmploymentClassOption withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(EmploymentClassOption.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("employmentClassOptionKey");
        sb.append('=');
        sb.append(((this.employmentClassOptionKey == null)?"<null>":this.employmentClassOptionKey));
        sb.append(',');
        sb.append("employmentClassOptionSysKey");
        sb.append('=');
        sb.append(((this.employmentClassOptionSysKey == null)?"<null>":this.employmentClassOptionSysKey));
        sb.append(',');
        sb.append("employmentClass");
        sb.append('=');
        sb.append(((this.employmentClass == null)?"<null>":this.employmentClass));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.employmentClassOptionSysKey == null)? 0 :this.employmentClassOptionSysKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.employmentClass == null)? 0 :this.employmentClass.hashCode()));
        result = ((result* 31)+((this.employmentClassOptionKey == null)? 0 :this.employmentClassOptionKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof EmploymentClassOption) == false) {
            return false;
        }
        EmploymentClassOption rhs = ((EmploymentClassOption) other);
        return ((((((((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension)))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.employmentClassOptionSysKey == rhs.employmentClassOptionSysKey)||((this.employmentClassOptionSysKey!= null)&&this.employmentClassOptionSysKey.equals(rhs.employmentClassOptionSysKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.employmentClass == rhs.employmentClass)||((this.employmentClass!= null)&&this.employmentClass.equals(rhs.employmentClass))))&&((this.employmentClassOptionKey == rhs.employmentClassOptionKey)||((this.employmentClassOptionKey!= null)&&this.employmentClassOptionKey.equals(rhs.employmentClassOptionKey))));
    }

}
