
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AccountingStatementKey",
    "AccountingStatementSysKey",
    "TotalCreditAmt",
    "TotalDebitAmt",
    "AccountingActivityDate",
    "TotalCreditCount",
    "TotalDebitCount",
    "AccountingActivity",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AccountingStatement {

    @JsonProperty("AccountingStatementKey")
    private AccountingStatementKey accountingStatementKey;
    @JsonProperty("AccountingStatementSysKey")
    private List<Object> accountingStatementSysKey = new ArrayList<>();
    @JsonProperty("TotalCreditAmt")
    private Integer totalCreditAmt;
    @JsonProperty("TotalDebitAmt")
    private Integer totalDebitAmt;
    @JsonProperty("AccountingActivityDate")
    private String accountingActivityDate;
    @JsonProperty("TotalCreditCount")
    private Integer totalCreditCount;
    @JsonProperty("TotalDebitCount")
    private Integer totalDebitCount;
    @JsonProperty("AccountingActivity")
    private List<Object> accountingActivity = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AccountingStatementKey")
    public AccountingStatementKey getAccountingStatementKey() {
        return accountingStatementKey;
    }

    @JsonProperty("AccountingStatementKey")
    public void setAccountingStatementKey(AccountingStatementKey accountingStatementKey) {
        this.accountingStatementKey = accountingStatementKey;
    }

    public AccountingStatement withAccountingStatementKey(AccountingStatementKey accountingStatementKey) {
        this.accountingStatementKey = accountingStatementKey;
        return this;
    }

    @JsonProperty("AccountingStatementSysKey")
    public List<Object> getAccountingStatementSysKey() {
        return accountingStatementSysKey;
    }

    @JsonProperty("AccountingStatementSysKey")
    public void setAccountingStatementSysKey(List<Object> accountingStatementSysKey) {
        this.accountingStatementSysKey = accountingStatementSysKey;
    }

    public AccountingStatement withAccountingStatementSysKey(List<Object> accountingStatementSysKey) {
        this.accountingStatementSysKey = accountingStatementSysKey;
        return this;
    }

    @JsonProperty("TotalCreditAmt")
    public Integer getTotalCreditAmt() {
        return totalCreditAmt;
    }

    @JsonProperty("TotalCreditAmt")
    public void setTotalCreditAmt(Integer totalCreditAmt) {
        this.totalCreditAmt = totalCreditAmt;
    }

    public AccountingStatement withTotalCreditAmt(Integer totalCreditAmt) {
        this.totalCreditAmt = totalCreditAmt;
        return this;
    }

    @JsonProperty("TotalDebitAmt")
    public Integer getTotalDebitAmt() {
        return totalDebitAmt;
    }

    @JsonProperty("TotalDebitAmt")
    public void setTotalDebitAmt(Integer totalDebitAmt) {
        this.totalDebitAmt = totalDebitAmt;
    }

    public AccountingStatement withTotalDebitAmt(Integer totalDebitAmt) {
        this.totalDebitAmt = totalDebitAmt;
        return this;
    }

    @JsonProperty("AccountingActivityDate")
    public String getAccountingActivityDate() {
        return accountingActivityDate;
    }

    @JsonProperty("AccountingActivityDate")
    public void setAccountingActivityDate(String accountingActivityDate) {
        this.accountingActivityDate = accountingActivityDate;
    }

    public AccountingStatement withAccountingActivityDate(String accountingActivityDate) {
        this.accountingActivityDate = accountingActivityDate;
        return this;
    }

    @JsonProperty("TotalCreditCount")
    public Integer getTotalCreditCount() {
        return totalCreditCount;
    }

    @JsonProperty("TotalCreditCount")
    public void setTotalCreditCount(Integer totalCreditCount) {
        this.totalCreditCount = totalCreditCount;
    }

    public AccountingStatement withTotalCreditCount(Integer totalCreditCount) {
        this.totalCreditCount = totalCreditCount;
        return this;
    }

    @JsonProperty("TotalDebitCount")
    public Integer getTotalDebitCount() {
        return totalDebitCount;
    }

    @JsonProperty("TotalDebitCount")
    public void setTotalDebitCount(Integer totalDebitCount) {
        this.totalDebitCount = totalDebitCount;
    }

    public AccountingStatement withTotalDebitCount(Integer totalDebitCount) {
        this.totalDebitCount = totalDebitCount;
        return this;
    }

    @JsonProperty("AccountingActivity")
    public List<Object> getAccountingActivity() {
        return accountingActivity;
    }

    @JsonProperty("AccountingActivity")
    public void setAccountingActivity(List<Object> accountingActivity) {
        this.accountingActivity = accountingActivity;
    }

    public AccountingStatement withAccountingActivity(List<Object> accountingActivity) {
        this.accountingActivity = accountingActivity;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AccountingStatement withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AccountingStatement withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AccountingStatement withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AccountingStatement withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AccountingStatement.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("accountingStatementKey");
        sb.append('=');
        sb.append(((this.accountingStatementKey == null)?"<null>":this.accountingStatementKey));
        sb.append(',');
        sb.append("accountingStatementSysKey");
        sb.append('=');
        sb.append(((this.accountingStatementSysKey == null)?"<null>":this.accountingStatementSysKey));
        sb.append(',');
        sb.append("totalCreditAmt");
        sb.append('=');
        sb.append(((this.totalCreditAmt == null)?"<null>":this.totalCreditAmt));
        sb.append(',');
        sb.append("totalDebitAmt");
        sb.append('=');
        sb.append(((this.totalDebitAmt == null)?"<null>":this.totalDebitAmt));
        sb.append(',');
        sb.append("accountingActivityDate");
        sb.append('=');
        sb.append(((this.accountingActivityDate == null)?"<null>":this.accountingActivityDate));
        sb.append(',');
        sb.append("totalCreditCount");
        sb.append('=');
        sb.append(((this.totalCreditCount == null)?"<null>":this.totalCreditCount));
        sb.append(',');
        sb.append("totalDebitCount");
        sb.append('=');
        sb.append(((this.totalDebitCount == null)?"<null>":this.totalDebitCount));
        sb.append(',');
        sb.append("accountingActivity");
        sb.append('=');
        sb.append(((this.accountingActivity == null)?"<null>":this.accountingActivity));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.totalCreditCount == null)? 0 :this.totalCreditCount.hashCode()));
        result = ((result* 31)+((this.accountingActivity == null)? 0 :this.accountingActivity.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.accountingActivityDate == null)? 0 :this.accountingActivityDate.hashCode()));
        result = ((result* 31)+((this.totalDebitAmt == null)? 0 :this.totalDebitAmt.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.accountingStatementSysKey == null)? 0 :this.accountingStatementSysKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.accountingStatementKey == null)? 0 :this.accountingStatementKey.hashCode()));
        result = ((result* 31)+((this.totalCreditAmt == null)? 0 :this.totalCreditAmt.hashCode()));
        result = ((result* 31)+((this.totalDebitCount == null)? 0 :this.totalDebitCount.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AccountingStatement) == false) {
            return false;
        }
        AccountingStatement rhs = ((AccountingStatement) other);
        return (((((((((((((this.totalCreditCount == rhs.totalCreditCount)||((this.totalCreditCount!= null)&&this.totalCreditCount.equals(rhs.totalCreditCount)))&&((this.accountingActivity == rhs.accountingActivity)||((this.accountingActivity!= null)&&this.accountingActivity.equals(rhs.accountingActivity))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.accountingActivityDate == rhs.accountingActivityDate)||((this.accountingActivityDate!= null)&&this.accountingActivityDate.equals(rhs.accountingActivityDate))))&&((this.totalDebitAmt == rhs.totalDebitAmt)||((this.totalDebitAmt!= null)&&this.totalDebitAmt.equals(rhs.totalDebitAmt))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.accountingStatementSysKey == rhs.accountingStatementSysKey)||((this.accountingStatementSysKey!= null)&&this.accountingStatementSysKey.equals(rhs.accountingStatementSysKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.accountingStatementKey == rhs.accountingStatementKey)||((this.accountingStatementKey!= null)&&this.accountingStatementKey.equals(rhs.accountingStatementKey))))&&((this.totalCreditAmt == rhs.totalCreditAmt)||((this.totalCreditAmt!= null)&&this.totalCreditAmt.equals(rhs.totalCreditAmt))))&&((this.totalDebitCount == rhs.totalDebitCount)||((this.totalDebitCount!= null)&&this.totalDebitCount.equals(rhs.totalDebitCount))));
    }

}
