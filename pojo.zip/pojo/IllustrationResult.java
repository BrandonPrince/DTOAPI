
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "TaxFailDate",
    "ResultBasis",
    "Attachment",
    "OLifEExtension"
})
@Generated("jsonschema2pojo")
public class IllustrationResult {

    @JsonProperty("TaxFailDate")
    private String taxFailDate;
    @JsonProperty("ResultBasis")
    private List<Object> resultBasis = new ArrayList<>();
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("TaxFailDate")
    public String getTaxFailDate() {
        return taxFailDate;
    }

    @JsonProperty("TaxFailDate")
    public void setTaxFailDate(String taxFailDate) {
        this.taxFailDate = taxFailDate;
    }

    public IllustrationResult withTaxFailDate(String taxFailDate) {
        this.taxFailDate = taxFailDate;
        return this;
    }

    @JsonProperty("ResultBasis")
    public List<Object> getResultBasis() {
        return resultBasis;
    }

    @JsonProperty("ResultBasis")
    public void setResultBasis(List<Object> resultBasis) {
        this.resultBasis = resultBasis;
    }

    public IllustrationResult withResultBasis(List<Object> resultBasis) {
        this.resultBasis = resultBasis;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public IllustrationResult withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public IllustrationResult withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public IllustrationResult withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(IllustrationResult.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("taxFailDate");
        sb.append('=');
        sb.append(((this.taxFailDate == null)?"<null>":this.taxFailDate));
        sb.append(',');
        sb.append("resultBasis");
        sb.append('=');
        sb.append(((this.resultBasis == null)?"<null>":this.resultBasis));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.taxFailDate == null)? 0 :this.taxFailDate.hashCode()));
        result = ((result* 31)+((this.resultBasis == null)? 0 :this.resultBasis.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof IllustrationResult) == false) {
            return false;
        }
        IllustrationResult rhs = ((IllustrationResult) other);
        return ((((((this.taxFailDate == rhs.taxFailDate)||((this.taxFailDate!= null)&&this.taxFailDate.equals(rhs.taxFailDate)))&&((this.resultBasis == rhs.resultBasis)||((this.resultBasis!= null)&&this.resultBasis.equals(rhs.resultBasis))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))));
    }

}
