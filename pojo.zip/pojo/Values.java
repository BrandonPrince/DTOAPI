
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Key",
    "Axis",
    "Y",
    "Extension"
})
@Generated("jsonschema2pojo")
public class Values {

    @JsonProperty("Key")
    private List<Object> key = new ArrayList<>();
    @JsonProperty("Axis")
    private List<Object> axis = new ArrayList<>();
    @JsonProperty("Y")
    private List<Object> y = new ArrayList<>();
    @JsonProperty("Extension")
    private List<Object> extension = new ArrayList<>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("Key")
    public List<Object> getKey() {
        return key;
    }

    @JsonProperty("Key")
    public void setKey(List<Object> key) {
        this.key = key;
    }

    public Values withKey(List<Object> key) {
        this.key = key;
        return this;
    }

    @JsonProperty("Axis")
    public List<Object> getAxis() {
        return axis;
    }

    @JsonProperty("Axis")
    public void setAxis(List<Object> axis) {
        this.axis = axis;
    }

    public Values withAxis(List<Object> axis) {
        this.axis = axis;
        return this;
    }

    @JsonProperty("Y")
    public List<Object> getY() {
        return y;
    }

    @JsonProperty("Y")
    public void setY(List<Object> y) {
        this.y = y;
    }

    public Values withY(List<Object> y) {
        this.y = y;
        return this;
    }

    @JsonProperty("Extension")
    public List<Object> getExtension() {
        return extension;
    }

    @JsonProperty("Extension")
    public void setExtension(List<Object> extension) {
        this.extension = extension;
    }

    public Values withExtension(List<Object> extension) {
        this.extension = extension;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Values withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Values.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("key");
        sb.append('=');
        sb.append(((this.key == null)?"<null>":this.key));
        sb.append(',');
        sb.append("axis");
        sb.append('=');
        sb.append(((this.axis == null)?"<null>":this.axis));
        sb.append(',');
        sb.append("y");
        sb.append('=');
        sb.append(((this.y == null)?"<null>":this.y));
        sb.append(',');
        sb.append("extension");
        sb.append('=');
        sb.append(((this.extension == null)?"<null>":this.extension));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.y == null)? 0 :this.y.hashCode()));
        result = ((result* 31)+((this.extension == null)? 0 :this.extension.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.axis == null)? 0 :this.axis.hashCode()));
        result = ((result* 31)+((this.key == null)? 0 :this.key.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Values) == false) {
            return false;
        }
        Values rhs = ((Values) other);
        return ((((((this.y == rhs.y)||((this.y!= null)&&this.y.equals(rhs.y)))&&((this.extension == rhs.extension)||((this.extension!= null)&&this.extension.equals(rhs.extension))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.axis == rhs.axis)||((this.axis!= null)&&this.axis.equals(rhs.axis))))&&((this.key == rhs.key)||((this.key!= null)&&this.key.equals(rhs.key))));
    }

}
