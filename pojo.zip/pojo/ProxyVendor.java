
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "VendorName",
    "AppName",
    "AppVer",
    "SeqNum",
    "CreationDate",
    "CreationTime",
    "Description",
    "Comments",
    "OLifEExtension"
})
@Generated("jsonschema2pojo")
public class ProxyVendor {

    @JsonProperty("VendorName")
    private VendorName vendorName;
    @JsonProperty("AppName")
    private String appName;
    @JsonProperty("AppVer")
    private String appVer;
    @JsonProperty("SeqNum")
    private Integer seqNum;
    @JsonProperty("CreationDate")
    private String creationDate;
    @JsonProperty("CreationTime")
    private String creationTime;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("Comments")
    private String comments;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("VendorName")
    public VendorName getVendorName() {
        return vendorName;
    }

    @JsonProperty("VendorName")
    public void setVendorName(VendorName vendorName) {
        this.vendorName = vendorName;
    }

    public ProxyVendor withVendorName(VendorName vendorName) {
        this.vendorName = vendorName;
        return this;
    }

    @JsonProperty("AppName")
    public String getAppName() {
        return appName;
    }

    @JsonProperty("AppName")
    public void setAppName(String appName) {
        this.appName = appName;
    }

    public ProxyVendor withAppName(String appName) {
        this.appName = appName;
        return this;
    }

    @JsonProperty("AppVer")
    public String getAppVer() {
        return appVer;
    }

    @JsonProperty("AppVer")
    public void setAppVer(String appVer) {
        this.appVer = appVer;
    }

    public ProxyVendor withAppVer(String appVer) {
        this.appVer = appVer;
        return this;
    }

    @JsonProperty("SeqNum")
    public Integer getSeqNum() {
        return seqNum;
    }

    @JsonProperty("SeqNum")
    public void setSeqNum(Integer seqNum) {
        this.seqNum = seqNum;
    }

    public ProxyVendor withSeqNum(Integer seqNum) {
        this.seqNum = seqNum;
        return this;
    }

    @JsonProperty("CreationDate")
    public String getCreationDate() {
        return creationDate;
    }

    @JsonProperty("CreationDate")
    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public ProxyVendor withCreationDate(String creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    @JsonProperty("CreationTime")
    public String getCreationTime() {
        return creationTime;
    }

    @JsonProperty("CreationTime")
    public void setCreationTime(String creationTime) {
        this.creationTime = creationTime;
    }

    public ProxyVendor withCreationTime(String creationTime) {
        this.creationTime = creationTime;
        return this;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    public ProxyVendor withDescription(String description) {
        this.description = description;
        return this;
    }

    @JsonProperty("Comments")
    public String getComments() {
        return comments;
    }

    @JsonProperty("Comments")
    public void setComments(String comments) {
        this.comments = comments;
    }

    public ProxyVendor withComments(String comments) {
        this.comments = comments;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public ProxyVendor withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ProxyVendor withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ProxyVendor.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("vendorName");
        sb.append('=');
        sb.append(((this.vendorName == null)?"<null>":this.vendorName));
        sb.append(',');
        sb.append("appName");
        sb.append('=');
        sb.append(((this.appName == null)?"<null>":this.appName));
        sb.append(',');
        sb.append("appVer");
        sb.append('=');
        sb.append(((this.appVer == null)?"<null>":this.appVer));
        sb.append(',');
        sb.append("seqNum");
        sb.append('=');
        sb.append(((this.seqNum == null)?"<null>":this.seqNum));
        sb.append(',');
        sb.append("creationDate");
        sb.append('=');
        sb.append(((this.creationDate == null)?"<null>":this.creationDate));
        sb.append(',');
        sb.append("creationTime");
        sb.append('=');
        sb.append(((this.creationTime == null)?"<null>":this.creationTime));
        sb.append(',');
        sb.append("description");
        sb.append('=');
        sb.append(((this.description == null)?"<null>":this.description));
        sb.append(',');
        sb.append("comments");
        sb.append('=');
        sb.append(((this.comments == null)?"<null>":this.comments));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.comments == null)? 0 :this.comments.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.creationTime == null)? 0 :this.creationTime.hashCode()));
        result = ((result* 31)+((this.appName == null)? 0 :this.appName.hashCode()));
        result = ((result* 31)+((this.appVer == null)? 0 :this.appVer.hashCode()));
        result = ((result* 31)+((this.seqNum == null)? 0 :this.seqNum.hashCode()));
        result = ((result* 31)+((this.description == null)? 0 :this.description.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.vendorName == null)? 0 :this.vendorName.hashCode()));
        result = ((result* 31)+((this.creationDate == null)? 0 :this.creationDate.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ProxyVendor) == false) {
            return false;
        }
        ProxyVendor rhs = ((ProxyVendor) other);
        return (((((((((((this.comments == rhs.comments)||((this.comments!= null)&&this.comments.equals(rhs.comments)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.creationTime == rhs.creationTime)||((this.creationTime!= null)&&this.creationTime.equals(rhs.creationTime))))&&((this.appName == rhs.appName)||((this.appName!= null)&&this.appName.equals(rhs.appName))))&&((this.appVer == rhs.appVer)||((this.appVer!= null)&&this.appVer.equals(rhs.appVer))))&&((this.seqNum == rhs.seqNum)||((this.seqNum!= null)&&this.seqNum.equals(rhs.seqNum))))&&((this.description == rhs.description)||((this.description!= null)&&this.description.equals(rhs.description))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.vendorName == rhs.vendorName)||((this.vendorName!= null)&&this.vendorName.equals(rhs.vendorName))))&&((this.creationDate == rhs.creationDate)||((this.creationDate!= null)&&this.creationDate.equals(rhs.creationDate))));
    }

}
