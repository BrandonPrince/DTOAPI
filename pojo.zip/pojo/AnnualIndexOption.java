
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AnnualIndexOptionKey",
    "AnnualIndexOptionSysKey",
    "AnnualIndex",
    "AnnualIndexType",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AnnualIndexOption {

    @JsonProperty("AnnualIndexOptionKey")
    private AnnualIndexOptionKey annualIndexOptionKey;
    @JsonProperty("AnnualIndexOptionSysKey")
    private List<Object> annualIndexOptionSysKey = new ArrayList<>();
    @JsonProperty("AnnualIndex")
    private Integer annualIndex;
    @JsonProperty("AnnualIndexType")
    private AnnualIndexType annualIndexType;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AnnualIndexOptionKey")
    public AnnualIndexOptionKey getAnnualIndexOptionKey() {
        return annualIndexOptionKey;
    }

    @JsonProperty("AnnualIndexOptionKey")
    public void setAnnualIndexOptionKey(AnnualIndexOptionKey annualIndexOptionKey) {
        this.annualIndexOptionKey = annualIndexOptionKey;
    }

    public AnnualIndexOption withAnnualIndexOptionKey(AnnualIndexOptionKey annualIndexOptionKey) {
        this.annualIndexOptionKey = annualIndexOptionKey;
        return this;
    }

    @JsonProperty("AnnualIndexOptionSysKey")
    public List<Object> getAnnualIndexOptionSysKey() {
        return annualIndexOptionSysKey;
    }

    @JsonProperty("AnnualIndexOptionSysKey")
    public void setAnnualIndexOptionSysKey(List<Object> annualIndexOptionSysKey) {
        this.annualIndexOptionSysKey = annualIndexOptionSysKey;
    }

    public AnnualIndexOption withAnnualIndexOptionSysKey(List<Object> annualIndexOptionSysKey) {
        this.annualIndexOptionSysKey = annualIndexOptionSysKey;
        return this;
    }

    @JsonProperty("AnnualIndex")
    public Integer getAnnualIndex() {
        return annualIndex;
    }

    @JsonProperty("AnnualIndex")
    public void setAnnualIndex(Integer annualIndex) {
        this.annualIndex = annualIndex;
    }

    public AnnualIndexOption withAnnualIndex(Integer annualIndex) {
        this.annualIndex = annualIndex;
        return this;
    }

    @JsonProperty("AnnualIndexType")
    public AnnualIndexType getAnnualIndexType() {
        return annualIndexType;
    }

    @JsonProperty("AnnualIndexType")
    public void setAnnualIndexType(AnnualIndexType annualIndexType) {
        this.annualIndexType = annualIndexType;
    }

    public AnnualIndexOption withAnnualIndexType(AnnualIndexType annualIndexType) {
        this.annualIndexType = annualIndexType;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AnnualIndexOption withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AnnualIndexOption withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AnnualIndexOption withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AnnualIndexOption withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AnnualIndexOption.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("annualIndexOptionKey");
        sb.append('=');
        sb.append(((this.annualIndexOptionKey == null)?"<null>":this.annualIndexOptionKey));
        sb.append(',');
        sb.append("annualIndexOptionSysKey");
        sb.append('=');
        sb.append(((this.annualIndexOptionSysKey == null)?"<null>":this.annualIndexOptionSysKey));
        sb.append(',');
        sb.append("annualIndex");
        sb.append('=');
        sb.append(((this.annualIndex == null)?"<null>":this.annualIndex));
        sb.append(',');
        sb.append("annualIndexType");
        sb.append('=');
        sb.append(((this.annualIndexType == null)?"<null>":this.annualIndexType));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.annualIndex == null)? 0 :this.annualIndex.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.annualIndexType == null)? 0 :this.annualIndexType.hashCode()));
        result = ((result* 31)+((this.annualIndexOptionSysKey == null)? 0 :this.annualIndexOptionSysKey.hashCode()));
        result = ((result* 31)+((this.annualIndexOptionKey == null)? 0 :this.annualIndexOptionKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AnnualIndexOption) == false) {
            return false;
        }
        AnnualIndexOption rhs = ((AnnualIndexOption) other);
        return (((((((((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension)))&&((this.annualIndex == rhs.annualIndex)||((this.annualIndex!= null)&&this.annualIndex.equals(rhs.annualIndex))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.annualIndexType == rhs.annualIndexType)||((this.annualIndexType!= null)&&this.annualIndexType.equals(rhs.annualIndexType))))&&((this.annualIndexOptionSysKey == rhs.annualIndexOptionSysKey)||((this.annualIndexOptionSysKey!= null)&&this.annualIndexOptionSysKey.equals(rhs.annualIndexOptionSysKey))))&&((this.annualIndexOptionKey == rhs.annualIndexOptionKey)||((this.annualIndexOptionKey!= null)&&this.annualIndexOptionKey.equals(rhs.annualIndexOptionKey))));
    }

}
