
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CryptType",
    "Pswd",
    "CryptPswd",
    "OLifEExtension"
})
@Generated("jsonschema2pojo")
public class UserPswd {

    @JsonProperty("CryptType")
    private String cryptType;
    @JsonProperty("Pswd")
    private String pswd;
    @JsonProperty("CryptPswd")
    private String cryptPswd;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("CryptType")
    public String getCryptType() {
        return cryptType;
    }

    @JsonProperty("CryptType")
    public void setCryptType(String cryptType) {
        this.cryptType = cryptType;
    }

    public UserPswd withCryptType(String cryptType) {
        this.cryptType = cryptType;
        return this;
    }

    @JsonProperty("Pswd")
    public String getPswd() {
        return pswd;
    }

    @JsonProperty("Pswd")
    public void setPswd(String pswd) {
        this.pswd = pswd;
    }

    public UserPswd withPswd(String pswd) {
        this.pswd = pswd;
        return this;
    }

    @JsonProperty("CryptPswd")
    public String getCryptPswd() {
        return cryptPswd;
    }

    @JsonProperty("CryptPswd")
    public void setCryptPswd(String cryptPswd) {
        this.cryptPswd = cryptPswd;
    }

    public UserPswd withCryptPswd(String cryptPswd) {
        this.cryptPswd = cryptPswd;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public UserPswd withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public UserPswd withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(UserPswd.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("cryptType");
        sb.append('=');
        sb.append(((this.cryptType == null)?"<null>":this.cryptType));
        sb.append(',');
        sb.append("pswd");
        sb.append('=');
        sb.append(((this.pswd == null)?"<null>":this.pswd));
        sb.append(',');
        sb.append("cryptPswd");
        sb.append('=');
        sb.append(((this.cryptPswd == null)?"<null>":this.cryptPswd));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.cryptType == null)? 0 :this.cryptType.hashCode()));
        result = ((result* 31)+((this.cryptPswd == null)? 0 :this.cryptPswd.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.pswd == null)? 0 :this.pswd.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UserPswd) == false) {
            return false;
        }
        UserPswd rhs = ((UserPswd) other);
        return ((((((this.cryptType == rhs.cryptType)||((this.cryptType!= null)&&this.cryptType.equals(rhs.cryptType)))&&((this.cryptPswd == rhs.cryptPswd)||((this.cryptPswd!= null)&&this.cryptPswd.equals(rhs.cryptPswd))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.pswd == rhs.pswd)||((this.pswd!= null)&&this.pswd.equals(rhs.pswd))));
    }

}
