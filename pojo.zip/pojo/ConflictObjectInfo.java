
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ConflictObjectInfoKey",
    "ConflictObjectInfoSysKey",
    "ObjectType",
    "ProductCode",
    "OLifEExtension",
    "id",
    "DataRep",
    "ObjectIDRef"
})
@Generated("jsonschema2pojo")
public class ConflictObjectInfo {

    @JsonProperty("ConflictObjectInfoKey")
    private ConflictObjectInfoKey conflictObjectInfoKey;
    @JsonProperty("ConflictObjectInfoSysKey")
    private List<Object> conflictObjectInfoSysKey = new ArrayList<>();
    @JsonProperty("ObjectType")
    private ObjectType objectType;
    @JsonProperty("ProductCode")
    private String productCode;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonProperty("ObjectIDRef")
    private String objectIDRef;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ConflictObjectInfoKey")
    public ConflictObjectInfoKey getConflictObjectInfoKey() {
        return conflictObjectInfoKey;
    }

    @JsonProperty("ConflictObjectInfoKey")
    public void setConflictObjectInfoKey(ConflictObjectInfoKey conflictObjectInfoKey) {
        this.conflictObjectInfoKey = conflictObjectInfoKey;
    }

    public ConflictObjectInfo withConflictObjectInfoKey(ConflictObjectInfoKey conflictObjectInfoKey) {
        this.conflictObjectInfoKey = conflictObjectInfoKey;
        return this;
    }

    @JsonProperty("ConflictObjectInfoSysKey")
    public List<Object> getConflictObjectInfoSysKey() {
        return conflictObjectInfoSysKey;
    }

    @JsonProperty("ConflictObjectInfoSysKey")
    public void setConflictObjectInfoSysKey(List<Object> conflictObjectInfoSysKey) {
        this.conflictObjectInfoSysKey = conflictObjectInfoSysKey;
    }

    public ConflictObjectInfo withConflictObjectInfoSysKey(List<Object> conflictObjectInfoSysKey) {
        this.conflictObjectInfoSysKey = conflictObjectInfoSysKey;
        return this;
    }

    @JsonProperty("ObjectType")
    public ObjectType getObjectType() {
        return objectType;
    }

    @JsonProperty("ObjectType")
    public void setObjectType(ObjectType objectType) {
        this.objectType = objectType;
    }

    public ConflictObjectInfo withObjectType(ObjectType objectType) {
        this.objectType = objectType;
        return this;
    }

    @JsonProperty("ProductCode")
    public String getProductCode() {
        return productCode;
    }

    @JsonProperty("ProductCode")
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public ConflictObjectInfo withProductCode(String productCode) {
        this.productCode = productCode;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public ConflictObjectInfo withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public ConflictObjectInfo withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public ConflictObjectInfo withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonProperty("ObjectIDRef")
    public String getObjectIDRef() {
        return objectIDRef;
    }

    @JsonProperty("ObjectIDRef")
    public void setObjectIDRef(String objectIDRef) {
        this.objectIDRef = objectIDRef;
    }

    public ConflictObjectInfo withObjectIDRef(String objectIDRef) {
        this.objectIDRef = objectIDRef;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ConflictObjectInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ConflictObjectInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("conflictObjectInfoKey");
        sb.append('=');
        sb.append(((this.conflictObjectInfoKey == null)?"<null>":this.conflictObjectInfoKey));
        sb.append(',');
        sb.append("conflictObjectInfoSysKey");
        sb.append('=');
        sb.append(((this.conflictObjectInfoSysKey == null)?"<null>":this.conflictObjectInfoSysKey));
        sb.append(',');
        sb.append("objectType");
        sb.append('=');
        sb.append(((this.objectType == null)?"<null>":this.objectType));
        sb.append(',');
        sb.append("productCode");
        sb.append('=');
        sb.append(((this.productCode == null)?"<null>":this.productCode));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("objectIDRef");
        sb.append('=');
        sb.append(((this.objectIDRef == null)?"<null>":this.objectIDRef));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.conflictObjectInfoSysKey == null)? 0 :this.conflictObjectInfoSysKey.hashCode()));
        result = ((result* 31)+((this.productCode == null)? 0 :this.productCode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.conflictObjectInfoKey == null)? 0 :this.conflictObjectInfoKey.hashCode()));
        result = ((result* 31)+((this.objectIDRef == null)? 0 :this.objectIDRef.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.objectType == null)? 0 :this.objectType.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ConflictObjectInfo) == false) {
            return false;
        }
        ConflictObjectInfo rhs = ((ConflictObjectInfo) other);
        return ((((((((((this.conflictObjectInfoSysKey == rhs.conflictObjectInfoSysKey)||((this.conflictObjectInfoSysKey!= null)&&this.conflictObjectInfoSysKey.equals(rhs.conflictObjectInfoSysKey)))&&((this.productCode == rhs.productCode)||((this.productCode!= null)&&this.productCode.equals(rhs.productCode))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.conflictObjectInfoKey == rhs.conflictObjectInfoKey)||((this.conflictObjectInfoKey!= null)&&this.conflictObjectInfoKey.equals(rhs.conflictObjectInfoKey))))&&((this.objectIDRef == rhs.objectIDRef)||((this.objectIDRef!= null)&&this.objectIDRef.equals(rhs.objectIDRef))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.objectType == rhs.objectType)||((this.objectType!= null)&&this.objectType.equals(rhs.objectType))));
    }

}
