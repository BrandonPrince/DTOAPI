
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "PartyTypeCode",
    "CarrierAdminSystem",
    "PartyKey",
    "PartySysKey",
    "FullName",
    "GovtID",
    "GovtIDStat",
    "GovtIDTC",
    "GovtIDCertificationDate",
    "ResidenceState",
    "ResidenceCountry",
    "ResidenceCounty",
    "ResidenceZip",
    "EstNetWorth",
    "EstTotLiabilitiesAmt",
    "CurrencyTypeCode",
    "PrefComm",
    "BestTimeToCallFrom",
    "BestTimeToCallTo",
    "IDReferenceNo",
    "IDReferenceType",
    "TaxOffice",
    "LiquidNetWorthAmt",
    "EstTotAssetsAmt",
    "BusinessAssetAmt",
    "WithholdingRequiredInd",
    "ResidenceCountyTC",
    "Person",
    "Organization",
    "Address",
    "Phone",
    "Attachment",
    "Carrier",
    "Client",
    "Producer",
    "EMailAddress",
    "URL",
    "PriorName",
    "Risk",
    "Physician",
    "Pharmacy",
    "Employment",
    "GovtIDInfo",
    "RatingAgencyInfo",
    "PartialIdentification",
    "ResidenceStateDuration",
    "DeliveryInfo",
    "RestrictionInfo",
    "KeyedValue",
    "PartyXLat",
    "DesignationInfo",
    "Availability",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class Party {

    @JsonProperty("PartyTypeCode")
    private PartyTypeCode partyTypeCode;
    @JsonProperty("CarrierAdminSystem")
    private String carrierAdminSystem;
    @JsonProperty("PartyKey")
    private PartyKey partyKey;
    @JsonProperty("PartySysKey")
    private List<Object> partySysKey = new ArrayList<>();
    @JsonProperty("FullName")
    private String fullName;
    @JsonProperty("GovtID")
    private String govtID;
    @JsonProperty("GovtIDStat")
    private GovtIDStat govtIDStat;
    @JsonProperty("GovtIDTC")
    private GovtIDTC govtIDTC;
    @JsonProperty("GovtIDCertificationDate")
    private String govtIDCertificationDate;
    @JsonProperty("ResidenceState")
    private ResidenceState residenceState;
    @JsonProperty("ResidenceCountry")
    private ResidenceCountry residenceCountry;
    @JsonProperty("ResidenceCounty")
    private String residenceCounty;
    @JsonProperty("ResidenceZip")
    private String residenceZip;
    @JsonProperty("EstNetWorth")
    private Integer estNetWorth;
    @JsonProperty("EstTotLiabilitiesAmt")
    private Integer estTotLiabilitiesAmt;
    @JsonProperty("CurrencyTypeCode")
    private CurrencyTypeCode currencyTypeCode;
    @JsonProperty("PrefComm")
    private PrefComm prefComm;
    @JsonProperty("BestTimeToCallFrom")
    private String bestTimeToCallFrom;
    @JsonProperty("BestTimeToCallTo")
    private String bestTimeToCallTo;
    @JsonProperty("IDReferenceNo")
    private String iDReferenceNo;
    @JsonProperty("IDReferenceType")
    private IDReferenceType iDReferenceType;
    @JsonProperty("TaxOffice")
    private String taxOffice;
    @JsonProperty("LiquidNetWorthAmt")
    private Integer liquidNetWorthAmt;
    @JsonProperty("EstTotAssetsAmt")
    private Integer estTotAssetsAmt;
    @JsonProperty("BusinessAssetAmt")
    private Integer businessAssetAmt;
    @JsonProperty("WithholdingRequiredInd")
    private WithholdingRequiredInd withholdingRequiredInd;
    @JsonProperty("ResidenceCountyTC")
    private ResidenceCountyTC residenceCountyTC;
    @JsonProperty("Person")
    private Person person;
    @JsonProperty("Organization")
    private Organization organization;
    @JsonProperty("Address")
    private List<Object> address = new ArrayList<>();
    @JsonProperty("Phone")
    private List<Object> phone = new ArrayList<>();
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("Carrier")
    private Carrier carrier;
    @JsonProperty("Client")
    private Client client;
    @JsonProperty("Producer")
    private Producer producer;
    @JsonProperty("EMailAddress")
    private List<Object> eMailAddress = new ArrayList<>();
    @JsonProperty("URL")
    private List<Object> url = new ArrayList<>();
    @JsonProperty("PriorName")
    private List<Object> priorName = new ArrayList<>();
    @JsonProperty("Risk")
    private Risk risk;
    @JsonProperty("Physician")
    private Physician physician;
    @JsonProperty("Pharmacy")
    private Pharmacy pharmacy;
    @JsonProperty("Employment")
    private List<Object> employment = new ArrayList<>();
    @JsonProperty("GovtIDInfo")
    private List<Object> govtIDInfo = new ArrayList<>();
    @JsonProperty("RatingAgencyInfo")
    private List<Object> ratingAgencyInfo = new ArrayList<>();
    @JsonProperty("PartialIdentification")
    private List<Object> partialIdentification = new ArrayList<>();
    @JsonProperty("ResidenceStateDuration")
    private Integer residenceStateDuration;
    @JsonProperty("DeliveryInfo")
    private List<Object> deliveryInfo = new ArrayList<>();
    @JsonProperty("RestrictionInfo")
    private List<Object> restrictionInfo = new ArrayList<>();
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("PartyXLat")
    private List<Object> partyXLat = new ArrayList<>();
    @JsonProperty("DesignationInfo")
    private List<Object> designationInfo = new ArrayList<>();
    @JsonProperty("Availability")
    private List<Object> availability = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("PartyTypeCode")
    public PartyTypeCode getPartyTypeCode() {
        return partyTypeCode;
    }

    @JsonProperty("PartyTypeCode")
    public void setPartyTypeCode(PartyTypeCode partyTypeCode) {
        this.partyTypeCode = partyTypeCode;
    }

    public Party withPartyTypeCode(PartyTypeCode partyTypeCode) {
        this.partyTypeCode = partyTypeCode;
        return this;
    }

    @JsonProperty("CarrierAdminSystem")
    public String getCarrierAdminSystem() {
        return carrierAdminSystem;
    }

    @JsonProperty("CarrierAdminSystem")
    public void setCarrierAdminSystem(String carrierAdminSystem) {
        this.carrierAdminSystem = carrierAdminSystem;
    }

    public Party withCarrierAdminSystem(String carrierAdminSystem) {
        this.carrierAdminSystem = carrierAdminSystem;
        return this;
    }

    @JsonProperty("PartyKey")
    public PartyKey getPartyKey() {
        return partyKey;
    }

    @JsonProperty("PartyKey")
    public void setPartyKey(PartyKey partyKey) {
        this.partyKey = partyKey;
    }

    public Party withPartyKey(PartyKey partyKey) {
        this.partyKey = partyKey;
        return this;
    }

    @JsonProperty("PartySysKey")
    public List<Object> getPartySysKey() {
        return partySysKey;
    }

    @JsonProperty("PartySysKey")
    public void setPartySysKey(List<Object> partySysKey) {
        this.partySysKey = partySysKey;
    }

    public Party withPartySysKey(List<Object> partySysKey) {
        this.partySysKey = partySysKey;
        return this;
    }

    @JsonProperty("FullName")
    public String getFullName() {
        return fullName;
    }

    @JsonProperty("FullName")
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Party withFullName(String fullName) {
        this.fullName = fullName;
        return this;
    }

    @JsonProperty("GovtID")
    public String getGovtID() {
        return govtID;
    }

    @JsonProperty("GovtID")
    public void setGovtID(String govtID) {
        this.govtID = govtID;
    }

    public Party withGovtID(String govtID) {
        this.govtID = govtID;
        return this;
    }

    @JsonProperty("GovtIDStat")
    public GovtIDStat getGovtIDStat() {
        return govtIDStat;
    }

    @JsonProperty("GovtIDStat")
    public void setGovtIDStat(GovtIDStat govtIDStat) {
        this.govtIDStat = govtIDStat;
    }

    public Party withGovtIDStat(GovtIDStat govtIDStat) {
        this.govtIDStat = govtIDStat;
        return this;
    }

    @JsonProperty("GovtIDTC")
    public GovtIDTC getGovtIDTC() {
        return govtIDTC;
    }

    @JsonProperty("GovtIDTC")
    public void setGovtIDTC(GovtIDTC govtIDTC) {
        this.govtIDTC = govtIDTC;
    }

    public Party withGovtIDTC(GovtIDTC govtIDTC) {
        this.govtIDTC = govtIDTC;
        return this;
    }

    @JsonProperty("GovtIDCertificationDate")
    public String getGovtIDCertificationDate() {
        return govtIDCertificationDate;
    }

    @JsonProperty("GovtIDCertificationDate")
    public void setGovtIDCertificationDate(String govtIDCertificationDate) {
        this.govtIDCertificationDate = govtIDCertificationDate;
    }

    public Party withGovtIDCertificationDate(String govtIDCertificationDate) {
        this.govtIDCertificationDate = govtIDCertificationDate;
        return this;
    }

    @JsonProperty("ResidenceState")
    public ResidenceState getResidenceState() {
        return residenceState;
    }

    @JsonProperty("ResidenceState")
    public void setResidenceState(ResidenceState residenceState) {
        this.residenceState = residenceState;
    }

    public Party withResidenceState(ResidenceState residenceState) {
        this.residenceState = residenceState;
        return this;
    }

    @JsonProperty("ResidenceCountry")
    public ResidenceCountry getResidenceCountry() {
        return residenceCountry;
    }

    @JsonProperty("ResidenceCountry")
    public void setResidenceCountry(ResidenceCountry residenceCountry) {
        this.residenceCountry = residenceCountry;
    }

    public Party withResidenceCountry(ResidenceCountry residenceCountry) {
        this.residenceCountry = residenceCountry;
        return this;
    }

    @JsonProperty("ResidenceCounty")
    public String getResidenceCounty() {
        return residenceCounty;
    }

    @JsonProperty("ResidenceCounty")
    public void setResidenceCounty(String residenceCounty) {
        this.residenceCounty = residenceCounty;
    }

    public Party withResidenceCounty(String residenceCounty) {
        this.residenceCounty = residenceCounty;
        return this;
    }

    @JsonProperty("ResidenceZip")
    public String getResidenceZip() {
        return residenceZip;
    }

    @JsonProperty("ResidenceZip")
    public void setResidenceZip(String residenceZip) {
        this.residenceZip = residenceZip;
    }

    public Party withResidenceZip(String residenceZip) {
        this.residenceZip = residenceZip;
        return this;
    }

    @JsonProperty("EstNetWorth")
    public Integer getEstNetWorth() {
        return estNetWorth;
    }

    @JsonProperty("EstNetWorth")
    public void setEstNetWorth(Integer estNetWorth) {
        this.estNetWorth = estNetWorth;
    }

    public Party withEstNetWorth(Integer estNetWorth) {
        this.estNetWorth = estNetWorth;
        return this;
    }

    @JsonProperty("EstTotLiabilitiesAmt")
    public Integer getEstTotLiabilitiesAmt() {
        return estTotLiabilitiesAmt;
    }

    @JsonProperty("EstTotLiabilitiesAmt")
    public void setEstTotLiabilitiesAmt(Integer estTotLiabilitiesAmt) {
        this.estTotLiabilitiesAmt = estTotLiabilitiesAmt;
    }

    public Party withEstTotLiabilitiesAmt(Integer estTotLiabilitiesAmt) {
        this.estTotLiabilitiesAmt = estTotLiabilitiesAmt;
        return this;
    }

    @JsonProperty("CurrencyTypeCode")
    public CurrencyTypeCode getCurrencyTypeCode() {
        return currencyTypeCode;
    }

    @JsonProperty("CurrencyTypeCode")
    public void setCurrencyTypeCode(CurrencyTypeCode currencyTypeCode) {
        this.currencyTypeCode = currencyTypeCode;
    }

    public Party withCurrencyTypeCode(CurrencyTypeCode currencyTypeCode) {
        this.currencyTypeCode = currencyTypeCode;
        return this;
    }

    @JsonProperty("PrefComm")
    public PrefComm getPrefComm() {
        return prefComm;
    }

    @JsonProperty("PrefComm")
    public void setPrefComm(PrefComm prefComm) {
        this.prefComm = prefComm;
    }

    public Party withPrefComm(PrefComm prefComm) {
        this.prefComm = prefComm;
        return this;
    }

    @JsonProperty("BestTimeToCallFrom")
    public String getBestTimeToCallFrom() {
        return bestTimeToCallFrom;
    }

    @JsonProperty("BestTimeToCallFrom")
    public void setBestTimeToCallFrom(String bestTimeToCallFrom) {
        this.bestTimeToCallFrom = bestTimeToCallFrom;
    }

    public Party withBestTimeToCallFrom(String bestTimeToCallFrom) {
        this.bestTimeToCallFrom = bestTimeToCallFrom;
        return this;
    }

    @JsonProperty("BestTimeToCallTo")
    public String getBestTimeToCallTo() {
        return bestTimeToCallTo;
    }

    @JsonProperty("BestTimeToCallTo")
    public void setBestTimeToCallTo(String bestTimeToCallTo) {
        this.bestTimeToCallTo = bestTimeToCallTo;
    }

    public Party withBestTimeToCallTo(String bestTimeToCallTo) {
        this.bestTimeToCallTo = bestTimeToCallTo;
        return this;
    }

    @JsonProperty("IDReferenceNo")
    public String getIDReferenceNo() {
        return iDReferenceNo;
    }

    @JsonProperty("IDReferenceNo")
    public void setIDReferenceNo(String iDReferenceNo) {
        this.iDReferenceNo = iDReferenceNo;
    }

    public Party withIDReferenceNo(String iDReferenceNo) {
        this.iDReferenceNo = iDReferenceNo;
        return this;
    }

    @JsonProperty("IDReferenceType")
    public IDReferenceType getIDReferenceType() {
        return iDReferenceType;
    }

    @JsonProperty("IDReferenceType")
    public void setIDReferenceType(IDReferenceType iDReferenceType) {
        this.iDReferenceType = iDReferenceType;
    }

    public Party withIDReferenceType(IDReferenceType iDReferenceType) {
        this.iDReferenceType = iDReferenceType;
        return this;
    }

    @JsonProperty("TaxOffice")
    public String getTaxOffice() {
        return taxOffice;
    }

    @JsonProperty("TaxOffice")
    public void setTaxOffice(String taxOffice) {
        this.taxOffice = taxOffice;
    }

    public Party withTaxOffice(String taxOffice) {
        this.taxOffice = taxOffice;
        return this;
    }

    @JsonProperty("LiquidNetWorthAmt")
    public Integer getLiquidNetWorthAmt() {
        return liquidNetWorthAmt;
    }

    @JsonProperty("LiquidNetWorthAmt")
    public void setLiquidNetWorthAmt(Integer liquidNetWorthAmt) {
        this.liquidNetWorthAmt = liquidNetWorthAmt;
    }

    public Party withLiquidNetWorthAmt(Integer liquidNetWorthAmt) {
        this.liquidNetWorthAmt = liquidNetWorthAmt;
        return this;
    }

    @JsonProperty("EstTotAssetsAmt")
    public Integer getEstTotAssetsAmt() {
        return estTotAssetsAmt;
    }

    @JsonProperty("EstTotAssetsAmt")
    public void setEstTotAssetsAmt(Integer estTotAssetsAmt) {
        this.estTotAssetsAmt = estTotAssetsAmt;
    }

    public Party withEstTotAssetsAmt(Integer estTotAssetsAmt) {
        this.estTotAssetsAmt = estTotAssetsAmt;
        return this;
    }

    @JsonProperty("BusinessAssetAmt")
    public Integer getBusinessAssetAmt() {
        return businessAssetAmt;
    }

    @JsonProperty("BusinessAssetAmt")
    public void setBusinessAssetAmt(Integer businessAssetAmt) {
        this.businessAssetAmt = businessAssetAmt;
    }

    public Party withBusinessAssetAmt(Integer businessAssetAmt) {
        this.businessAssetAmt = businessAssetAmt;
        return this;
    }

    @JsonProperty("WithholdingRequiredInd")
    public WithholdingRequiredInd getWithholdingRequiredInd() {
        return withholdingRequiredInd;
    }

    @JsonProperty("WithholdingRequiredInd")
    public void setWithholdingRequiredInd(WithholdingRequiredInd withholdingRequiredInd) {
        this.withholdingRequiredInd = withholdingRequiredInd;
    }

    public Party withWithholdingRequiredInd(WithholdingRequiredInd withholdingRequiredInd) {
        this.withholdingRequiredInd = withholdingRequiredInd;
        return this;
    }

    @JsonProperty("ResidenceCountyTC")
    public ResidenceCountyTC getResidenceCountyTC() {
        return residenceCountyTC;
    }

    @JsonProperty("ResidenceCountyTC")
    public void setResidenceCountyTC(ResidenceCountyTC residenceCountyTC) {
        this.residenceCountyTC = residenceCountyTC;
    }

    public Party withResidenceCountyTC(ResidenceCountyTC residenceCountyTC) {
        this.residenceCountyTC = residenceCountyTC;
        return this;
    }

    @JsonProperty("Person")
    public Person getPerson() {
        return person;
    }

    @JsonProperty("Person")
    public void setPerson(Person person) {
        this.person = person;
    }

    public Party withPerson(Person person) {
        this.person = person;
        return this;
    }

    @JsonProperty("Organization")
    public Organization getOrganization() {
        return organization;
    }

    @JsonProperty("Organization")
    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public Party withOrganization(Organization organization) {
        this.organization = organization;
        return this;
    }

    @JsonProperty("Address")
    public List<Object> getAddress() {
        return address;
    }

    @JsonProperty("Address")
    public void setAddress(List<Object> address) {
        this.address = address;
    }

    public Party withAddress(List<Object> address) {
        this.address = address;
        return this;
    }

    @JsonProperty("Phone")
    public List<Object> getPhone() {
        return phone;
    }

    @JsonProperty("Phone")
    public void setPhone(List<Object> phone) {
        this.phone = phone;
    }

    public Party withPhone(List<Object> phone) {
        this.phone = phone;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public Party withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("Carrier")
    public Carrier getCarrier() {
        return carrier;
    }

    @JsonProperty("Carrier")
    public void setCarrier(Carrier carrier) {
        this.carrier = carrier;
    }

    public Party withCarrier(Carrier carrier) {
        this.carrier = carrier;
        return this;
    }

    @JsonProperty("Client")
    public Client getClient() {
        return client;
    }

    @JsonProperty("Client")
    public void setClient(Client client) {
        this.client = client;
    }

    public Party withClient(Client client) {
        this.client = client;
        return this;
    }

    @JsonProperty("Producer")
    public Producer getProducer() {
        return producer;
    }

    @JsonProperty("Producer")
    public void setProducer(Producer producer) {
        this.producer = producer;
    }

    public Party withProducer(Producer producer) {
        this.producer = producer;
        return this;
    }

    @JsonProperty("EMailAddress")
    public List<Object> getEMailAddress() {
        return eMailAddress;
    }

    @JsonProperty("EMailAddress")
    public void setEMailAddress(List<Object> eMailAddress) {
        this.eMailAddress = eMailAddress;
    }

    public Party withEMailAddress(List<Object> eMailAddress) {
        this.eMailAddress = eMailAddress;
        return this;
    }

    @JsonProperty("URL")
    public List<Object> getUrl() {
        return url;
    }

    @JsonProperty("URL")
    public void setUrl(List<Object> url) {
        this.url = url;
    }

    public Party withUrl(List<Object> url) {
        this.url = url;
        return this;
    }

    @JsonProperty("PriorName")
    public List<Object> getPriorName() {
        return priorName;
    }

    @JsonProperty("PriorName")
    public void setPriorName(List<Object> priorName) {
        this.priorName = priorName;
    }

    public Party withPriorName(List<Object> priorName) {
        this.priorName = priorName;
        return this;
    }

    @JsonProperty("Risk")
    public Risk getRisk() {
        return risk;
    }

    @JsonProperty("Risk")
    public void setRisk(Risk risk) {
        this.risk = risk;
    }

    public Party withRisk(Risk risk) {
        this.risk = risk;
        return this;
    }

    @JsonProperty("Physician")
    public Physician getPhysician() {
        return physician;
    }

    @JsonProperty("Physician")
    public void setPhysician(Physician physician) {
        this.physician = physician;
    }

    public Party withPhysician(Physician physician) {
        this.physician = physician;
        return this;
    }

    @JsonProperty("Pharmacy")
    public Pharmacy getPharmacy() {
        return pharmacy;
    }

    @JsonProperty("Pharmacy")
    public void setPharmacy(Pharmacy pharmacy) {
        this.pharmacy = pharmacy;
    }

    public Party withPharmacy(Pharmacy pharmacy) {
        this.pharmacy = pharmacy;
        return this;
    }

    @JsonProperty("Employment")
    public List<Object> getEmployment() {
        return employment;
    }

    @JsonProperty("Employment")
    public void setEmployment(List<Object> employment) {
        this.employment = employment;
    }

    public Party withEmployment(List<Object> employment) {
        this.employment = employment;
        return this;
    }

    @JsonProperty("GovtIDInfo")
    public List<Object> getGovtIDInfo() {
        return govtIDInfo;
    }

    @JsonProperty("GovtIDInfo")
    public void setGovtIDInfo(List<Object> govtIDInfo) {
        this.govtIDInfo = govtIDInfo;
    }

    public Party withGovtIDInfo(List<Object> govtIDInfo) {
        this.govtIDInfo = govtIDInfo;
        return this;
    }

    @JsonProperty("RatingAgencyInfo")
    public List<Object> getRatingAgencyInfo() {
        return ratingAgencyInfo;
    }

    @JsonProperty("RatingAgencyInfo")
    public void setRatingAgencyInfo(List<Object> ratingAgencyInfo) {
        this.ratingAgencyInfo = ratingAgencyInfo;
    }

    public Party withRatingAgencyInfo(List<Object> ratingAgencyInfo) {
        this.ratingAgencyInfo = ratingAgencyInfo;
        return this;
    }

    @JsonProperty("PartialIdentification")
    public List<Object> getPartialIdentification() {
        return partialIdentification;
    }

    @JsonProperty("PartialIdentification")
    public void setPartialIdentification(List<Object> partialIdentification) {
        this.partialIdentification = partialIdentification;
    }

    public Party withPartialIdentification(List<Object> partialIdentification) {
        this.partialIdentification = partialIdentification;
        return this;
    }

    @JsonProperty("ResidenceStateDuration")
    public Integer getResidenceStateDuration() {
        return residenceStateDuration;
    }

    @JsonProperty("ResidenceStateDuration")
    public void setResidenceStateDuration(Integer residenceStateDuration) {
        this.residenceStateDuration = residenceStateDuration;
    }

    public Party withResidenceStateDuration(Integer residenceStateDuration) {
        this.residenceStateDuration = residenceStateDuration;
        return this;
    }

    @JsonProperty("DeliveryInfo")
    public List<Object> getDeliveryInfo() {
        return deliveryInfo;
    }

    @JsonProperty("DeliveryInfo")
    public void setDeliveryInfo(List<Object> deliveryInfo) {
        this.deliveryInfo = deliveryInfo;
    }

    public Party withDeliveryInfo(List<Object> deliveryInfo) {
        this.deliveryInfo = deliveryInfo;
        return this;
    }

    @JsonProperty("RestrictionInfo")
    public List<Object> getRestrictionInfo() {
        return restrictionInfo;
    }

    @JsonProperty("RestrictionInfo")
    public void setRestrictionInfo(List<Object> restrictionInfo) {
        this.restrictionInfo = restrictionInfo;
    }

    public Party withRestrictionInfo(List<Object> restrictionInfo) {
        this.restrictionInfo = restrictionInfo;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public Party withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("PartyXLat")
    public List<Object> getPartyXLat() {
        return partyXLat;
    }

    @JsonProperty("PartyXLat")
    public void setPartyXLat(List<Object> partyXLat) {
        this.partyXLat = partyXLat;
    }

    public Party withPartyXLat(List<Object> partyXLat) {
        this.partyXLat = partyXLat;
        return this;
    }

    @JsonProperty("DesignationInfo")
    public List<Object> getDesignationInfo() {
        return designationInfo;
    }

    @JsonProperty("DesignationInfo")
    public void setDesignationInfo(List<Object> designationInfo) {
        this.designationInfo = designationInfo;
    }

    public Party withDesignationInfo(List<Object> designationInfo) {
        this.designationInfo = designationInfo;
        return this;
    }

    @JsonProperty("Availability")
    public List<Object> getAvailability() {
        return availability;
    }

    @JsonProperty("Availability")
    public void setAvailability(List<Object> availability) {
        this.availability = availability;
    }

    public Party withAvailability(List<Object> availability) {
        this.availability = availability;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Party withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Party withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public Party withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Party withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Party.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("partyTypeCode");
        sb.append('=');
        sb.append(((this.partyTypeCode == null)?"<null>":this.partyTypeCode));
        sb.append(',');
        sb.append("carrierAdminSystem");
        sb.append('=');
        sb.append(((this.carrierAdminSystem == null)?"<null>":this.carrierAdminSystem));
        sb.append(',');
        sb.append("partyKey");
        sb.append('=');
        sb.append(((this.partyKey == null)?"<null>":this.partyKey));
        sb.append(',');
        sb.append("partySysKey");
        sb.append('=');
        sb.append(((this.partySysKey == null)?"<null>":this.partySysKey));
        sb.append(',');
        sb.append("fullName");
        sb.append('=');
        sb.append(((this.fullName == null)?"<null>":this.fullName));
        sb.append(',');
        sb.append("govtID");
        sb.append('=');
        sb.append(((this.govtID == null)?"<null>":this.govtID));
        sb.append(',');
        sb.append("govtIDStat");
        sb.append('=');
        sb.append(((this.govtIDStat == null)?"<null>":this.govtIDStat));
        sb.append(',');
        sb.append("govtIDTC");
        sb.append('=');
        sb.append(((this.govtIDTC == null)?"<null>":this.govtIDTC));
        sb.append(',');
        sb.append("govtIDCertificationDate");
        sb.append('=');
        sb.append(((this.govtIDCertificationDate == null)?"<null>":this.govtIDCertificationDate));
        sb.append(',');
        sb.append("residenceState");
        sb.append('=');
        sb.append(((this.residenceState == null)?"<null>":this.residenceState));
        sb.append(',');
        sb.append("residenceCountry");
        sb.append('=');
        sb.append(((this.residenceCountry == null)?"<null>":this.residenceCountry));
        sb.append(',');
        sb.append("residenceCounty");
        sb.append('=');
        sb.append(((this.residenceCounty == null)?"<null>":this.residenceCounty));
        sb.append(',');
        sb.append("residenceZip");
        sb.append('=');
        sb.append(((this.residenceZip == null)?"<null>":this.residenceZip));
        sb.append(',');
        sb.append("estNetWorth");
        sb.append('=');
        sb.append(((this.estNetWorth == null)?"<null>":this.estNetWorth));
        sb.append(',');
        sb.append("estTotLiabilitiesAmt");
        sb.append('=');
        sb.append(((this.estTotLiabilitiesAmt == null)?"<null>":this.estTotLiabilitiesAmt));
        sb.append(',');
        sb.append("currencyTypeCode");
        sb.append('=');
        sb.append(((this.currencyTypeCode == null)?"<null>":this.currencyTypeCode));
        sb.append(',');
        sb.append("prefComm");
        sb.append('=');
        sb.append(((this.prefComm == null)?"<null>":this.prefComm));
        sb.append(',');
        sb.append("bestTimeToCallFrom");
        sb.append('=');
        sb.append(((this.bestTimeToCallFrom == null)?"<null>":this.bestTimeToCallFrom));
        sb.append(',');
        sb.append("bestTimeToCallTo");
        sb.append('=');
        sb.append(((this.bestTimeToCallTo == null)?"<null>":this.bestTimeToCallTo));
        sb.append(',');
        sb.append("iDReferenceNo");
        sb.append('=');
        sb.append(((this.iDReferenceNo == null)?"<null>":this.iDReferenceNo));
        sb.append(',');
        sb.append("iDReferenceType");
        sb.append('=');
        sb.append(((this.iDReferenceType == null)?"<null>":this.iDReferenceType));
        sb.append(',');
        sb.append("taxOffice");
        sb.append('=');
        sb.append(((this.taxOffice == null)?"<null>":this.taxOffice));
        sb.append(',');
        sb.append("liquidNetWorthAmt");
        sb.append('=');
        sb.append(((this.liquidNetWorthAmt == null)?"<null>":this.liquidNetWorthAmt));
        sb.append(',');
        sb.append("estTotAssetsAmt");
        sb.append('=');
        sb.append(((this.estTotAssetsAmt == null)?"<null>":this.estTotAssetsAmt));
        sb.append(',');
        sb.append("businessAssetAmt");
        sb.append('=');
        sb.append(((this.businessAssetAmt == null)?"<null>":this.businessAssetAmt));
        sb.append(',');
        sb.append("withholdingRequiredInd");
        sb.append('=');
        sb.append(((this.withholdingRequiredInd == null)?"<null>":this.withholdingRequiredInd));
        sb.append(',');
        sb.append("residenceCountyTC");
        sb.append('=');
        sb.append(((this.residenceCountyTC == null)?"<null>":this.residenceCountyTC));
        sb.append(',');
        sb.append("person");
        sb.append('=');
        sb.append(((this.person == null)?"<null>":this.person));
        sb.append(',');
        sb.append("organization");
        sb.append('=');
        sb.append(((this.organization == null)?"<null>":this.organization));
        sb.append(',');
        sb.append("address");
        sb.append('=');
        sb.append(((this.address == null)?"<null>":this.address));
        sb.append(',');
        sb.append("phone");
        sb.append('=');
        sb.append(((this.phone == null)?"<null>":this.phone));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("carrier");
        sb.append('=');
        sb.append(((this.carrier == null)?"<null>":this.carrier));
        sb.append(',');
        sb.append("client");
        sb.append('=');
        sb.append(((this.client == null)?"<null>":this.client));
        sb.append(',');
        sb.append("producer");
        sb.append('=');
        sb.append(((this.producer == null)?"<null>":this.producer));
        sb.append(',');
        sb.append("eMailAddress");
        sb.append('=');
        sb.append(((this.eMailAddress == null)?"<null>":this.eMailAddress));
        sb.append(',');
        sb.append("url");
        sb.append('=');
        sb.append(((this.url == null)?"<null>":this.url));
        sb.append(',');
        sb.append("priorName");
        sb.append('=');
        sb.append(((this.priorName == null)?"<null>":this.priorName));
        sb.append(',');
        sb.append("risk");
        sb.append('=');
        sb.append(((this.risk == null)?"<null>":this.risk));
        sb.append(',');
        sb.append("physician");
        sb.append('=');
        sb.append(((this.physician == null)?"<null>":this.physician));
        sb.append(',');
        sb.append("pharmacy");
        sb.append('=');
        sb.append(((this.pharmacy == null)?"<null>":this.pharmacy));
        sb.append(',');
        sb.append("employment");
        sb.append('=');
        sb.append(((this.employment == null)?"<null>":this.employment));
        sb.append(',');
        sb.append("govtIDInfo");
        sb.append('=');
        sb.append(((this.govtIDInfo == null)?"<null>":this.govtIDInfo));
        sb.append(',');
        sb.append("ratingAgencyInfo");
        sb.append('=');
        sb.append(((this.ratingAgencyInfo == null)?"<null>":this.ratingAgencyInfo));
        sb.append(',');
        sb.append("partialIdentification");
        sb.append('=');
        sb.append(((this.partialIdentification == null)?"<null>":this.partialIdentification));
        sb.append(',');
        sb.append("residenceStateDuration");
        sb.append('=');
        sb.append(((this.residenceStateDuration == null)?"<null>":this.residenceStateDuration));
        sb.append(',');
        sb.append("deliveryInfo");
        sb.append('=');
        sb.append(((this.deliveryInfo == null)?"<null>":this.deliveryInfo));
        sb.append(',');
        sb.append("restrictionInfo");
        sb.append('=');
        sb.append(((this.restrictionInfo == null)?"<null>":this.restrictionInfo));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("partyXLat");
        sb.append('=');
        sb.append(((this.partyXLat == null)?"<null>":this.partyXLat));
        sb.append(',');
        sb.append("designationInfo");
        sb.append('=');
        sb.append(((this.designationInfo == null)?"<null>":this.designationInfo));
        sb.append(',');
        sb.append("availability");
        sb.append('=');
        sb.append(((this.availability == null)?"<null>":this.availability));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.residenceState == null)? 0 :this.residenceState.hashCode()));
        result = ((result* 31)+((this.residenceCountry == null)? 0 :this.residenceCountry.hashCode()));
        result = ((result* 31)+((this.partyXLat == null)? 0 :this.partyXLat.hashCode()));
        result = ((result* 31)+((this.residenceCountyTC == null)? 0 :this.residenceCountyTC.hashCode()));
        result = ((result* 31)+((this.restrictionInfo == null)? 0 :this.restrictionInfo.hashCode()));
        result = ((result* 31)+((this.estNetWorth == null)? 0 :this.estNetWorth.hashCode()));
        result = ((result* 31)+((this.eMailAddress == null)? 0 :this.eMailAddress.hashCode()));
        result = ((result* 31)+((this.ratingAgencyInfo == null)? 0 :this.ratingAgencyInfo.hashCode()));
        result = ((result* 31)+((this.priorName == null)? 0 :this.priorName.hashCode()));
        result = ((result* 31)+((this.currencyTypeCode == null)? 0 :this.currencyTypeCode.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.iDReferenceType == null)? 0 :this.iDReferenceType.hashCode()));
        result = ((result* 31)+((this.taxOffice == null)? 0 :this.taxOffice.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.bestTimeToCallTo == null)? 0 :this.bestTimeToCallTo.hashCode()));
        result = ((result* 31)+((this.carrierAdminSystem == null)? 0 :this.carrierAdminSystem.hashCode()));
        result = ((result* 31)+((this.estTotAssetsAmt == null)? 0 :this.estTotAssetsAmt.hashCode()));
        result = ((result* 31)+((this.withholdingRequiredInd == null)? 0 :this.withholdingRequiredInd.hashCode()));
        result = ((result* 31)+((this.iDReferenceNo == null)? 0 :this.iDReferenceNo.hashCode()));
        result = ((result* 31)+((this.partialIdentification == null)? 0 :this.partialIdentification.hashCode()));
        result = ((result* 31)+((this.phone == null)? 0 :this.phone.hashCode()));
        result = ((result* 31)+((this.person == null)? 0 :this.person.hashCode()));
        result = ((result* 31)+((this.pharmacy == null)? 0 :this.pharmacy.hashCode()));
        result = ((result* 31)+((this.producer == null)? 0 :this.producer.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.residenceZip == null)? 0 :this.residenceZip.hashCode()));
        result = ((result* 31)+((this.govtIDTC == null)? 0 :this.govtIDTC.hashCode()));
        result = ((result* 31)+((this.estTotLiabilitiesAmt == null)? 0 :this.estTotLiabilitiesAmt.hashCode()));
        result = ((result* 31)+((this.designationInfo == null)? 0 :this.designationInfo.hashCode()));
        result = ((result* 31)+((this.govtIDInfo == null)? 0 :this.govtIDInfo.hashCode()));
        result = ((result* 31)+((this.residenceCounty == null)? 0 :this.residenceCounty.hashCode()));
        result = ((result* 31)+((this.availability == null)? 0 :this.availability.hashCode()));
        result = ((result* 31)+((this.liquidNetWorthAmt == null)? 0 :this.liquidNetWorthAmt.hashCode()));
        result = ((result* 31)+((this.govtIDCertificationDate == null)? 0 :this.govtIDCertificationDate.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.partyTypeCode == null)? 0 :this.partyTypeCode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        result = ((result* 31)+((this.residenceStateDuration == null)? 0 :this.residenceStateDuration.hashCode()));
        result = ((result* 31)+((this.govtID == null)? 0 :this.govtID.hashCode()));
        result = ((result* 31)+((this.client == null)? 0 :this.client.hashCode()));
        result = ((result* 31)+((this.physician == null)? 0 :this.physician.hashCode()));
        result = ((result* 31)+((this.deliveryInfo == null)? 0 :this.deliveryInfo.hashCode()));
        result = ((result* 31)+((this.address == null)? 0 :this.address.hashCode()));
        result = ((result* 31)+((this.fullName == null)? 0 :this.fullName.hashCode()));
        result = ((result* 31)+((this.employment == null)? 0 :this.employment.hashCode()));
        result = ((result* 31)+((this.partySysKey == null)? 0 :this.partySysKey.hashCode()));
        result = ((result* 31)+((this.url == null)? 0 :this.url.hashCode()));
        result = ((result* 31)+((this.prefComm == null)? 0 :this.prefComm.hashCode()));
        result = ((result* 31)+((this.carrier == null)? 0 :this.carrier.hashCode()));
        result = ((result* 31)+((this.bestTimeToCallFrom == null)? 0 :this.bestTimeToCallFrom.hashCode()));
        result = ((result* 31)+((this.organization == null)? 0 :this.organization.hashCode()));
        result = ((result* 31)+((this.govtIDStat == null)? 0 :this.govtIDStat.hashCode()));
        result = ((result* 31)+((this.partyKey == null)? 0 :this.partyKey.hashCode()));
        result = ((result* 31)+((this.risk == null)? 0 :this.risk.hashCode()));
        result = ((result* 31)+((this.businessAssetAmt == null)? 0 :this.businessAssetAmt.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Party) == false) {
            return false;
        }
        Party rhs = ((Party) other);
        return (((((((((((((((((((((((((((((((((((((((((((((((((((((((((this.residenceState == rhs.residenceState)||((this.residenceState!= null)&&this.residenceState.equals(rhs.residenceState)))&&((this.residenceCountry == rhs.residenceCountry)||((this.residenceCountry!= null)&&this.residenceCountry.equals(rhs.residenceCountry))))&&((this.partyXLat == rhs.partyXLat)||((this.partyXLat!= null)&&this.partyXLat.equals(rhs.partyXLat))))&&((this.residenceCountyTC == rhs.residenceCountyTC)||((this.residenceCountyTC!= null)&&this.residenceCountyTC.equals(rhs.residenceCountyTC))))&&((this.restrictionInfo == rhs.restrictionInfo)||((this.restrictionInfo!= null)&&this.restrictionInfo.equals(rhs.restrictionInfo))))&&((this.estNetWorth == rhs.estNetWorth)||((this.estNetWorth!= null)&&this.estNetWorth.equals(rhs.estNetWorth))))&&((this.eMailAddress == rhs.eMailAddress)||((this.eMailAddress!= null)&&this.eMailAddress.equals(rhs.eMailAddress))))&&((this.ratingAgencyInfo == rhs.ratingAgencyInfo)||((this.ratingAgencyInfo!= null)&&this.ratingAgencyInfo.equals(rhs.ratingAgencyInfo))))&&((this.priorName == rhs.priorName)||((this.priorName!= null)&&this.priorName.equals(rhs.priorName))))&&((this.currencyTypeCode == rhs.currencyTypeCode)||((this.currencyTypeCode!= null)&&this.currencyTypeCode.equals(rhs.currencyTypeCode))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.iDReferenceType == rhs.iDReferenceType)||((this.iDReferenceType!= null)&&this.iDReferenceType.equals(rhs.iDReferenceType))))&&((this.taxOffice == rhs.taxOffice)||((this.taxOffice!= null)&&this.taxOffice.equals(rhs.taxOffice))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.bestTimeToCallTo == rhs.bestTimeToCallTo)||((this.bestTimeToCallTo!= null)&&this.bestTimeToCallTo.equals(rhs.bestTimeToCallTo))))&&((this.carrierAdminSystem == rhs.carrierAdminSystem)||((this.carrierAdminSystem!= null)&&this.carrierAdminSystem.equals(rhs.carrierAdminSystem))))&&((this.estTotAssetsAmt == rhs.estTotAssetsAmt)||((this.estTotAssetsAmt!= null)&&this.estTotAssetsAmt.equals(rhs.estTotAssetsAmt))))&&((this.withholdingRequiredInd == rhs.withholdingRequiredInd)||((this.withholdingRequiredInd!= null)&&this.withholdingRequiredInd.equals(rhs.withholdingRequiredInd))))&&((this.iDReferenceNo == rhs.iDReferenceNo)||((this.iDReferenceNo!= null)&&this.iDReferenceNo.equals(rhs.iDReferenceNo))))&&((this.partialIdentification == rhs.partialIdentification)||((this.partialIdentification!= null)&&this.partialIdentification.equals(rhs.partialIdentification))))&&((this.phone == rhs.phone)||((this.phone!= null)&&this.phone.equals(rhs.phone))))&&((this.person == rhs.person)||((this.person!= null)&&this.person.equals(rhs.person))))&&((this.pharmacy == rhs.pharmacy)||((this.pharmacy!= null)&&this.pharmacy.equals(rhs.pharmacy))))&&((this.producer == rhs.producer)||((this.producer!= null)&&this.producer.equals(rhs.producer))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.residenceZip == rhs.residenceZip)||((this.residenceZip!= null)&&this.residenceZip.equals(rhs.residenceZip))))&&((this.govtIDTC == rhs.govtIDTC)||((this.govtIDTC!= null)&&this.govtIDTC.equals(rhs.govtIDTC))))&&((this.estTotLiabilitiesAmt == rhs.estTotLiabilitiesAmt)||((this.estTotLiabilitiesAmt!= null)&&this.estTotLiabilitiesAmt.equals(rhs.estTotLiabilitiesAmt))))&&((this.designationInfo == rhs.designationInfo)||((this.designationInfo!= null)&&this.designationInfo.equals(rhs.designationInfo))))&&((this.govtIDInfo == rhs.govtIDInfo)||((this.govtIDInfo!= null)&&this.govtIDInfo.equals(rhs.govtIDInfo))))&&((this.residenceCounty == rhs.residenceCounty)||((this.residenceCounty!= null)&&this.residenceCounty.equals(rhs.residenceCounty))))&&((this.availability == rhs.availability)||((this.availability!= null)&&this.availability.equals(rhs.availability))))&&((this.liquidNetWorthAmt == rhs.liquidNetWorthAmt)||((this.liquidNetWorthAmt!= null)&&this.liquidNetWorthAmt.equals(rhs.liquidNetWorthAmt))))&&((this.govtIDCertificationDate == rhs.govtIDCertificationDate)||((this.govtIDCertificationDate!= null)&&this.govtIDCertificationDate.equals(rhs.govtIDCertificationDate))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.partyTypeCode == rhs.partyTypeCode)||((this.partyTypeCode!= null)&&this.partyTypeCode.equals(rhs.partyTypeCode))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))))&&((this.residenceStateDuration == rhs.residenceStateDuration)||((this.residenceStateDuration!= null)&&this.residenceStateDuration.equals(rhs.residenceStateDuration))))&&((this.govtID == rhs.govtID)||((this.govtID!= null)&&this.govtID.equals(rhs.govtID))))&&((this.client == rhs.client)||((this.client!= null)&&this.client.equals(rhs.client))))&&((this.physician == rhs.physician)||((this.physician!= null)&&this.physician.equals(rhs.physician))))&&((this.deliveryInfo == rhs.deliveryInfo)||((this.deliveryInfo!= null)&&this.deliveryInfo.equals(rhs.deliveryInfo))))&&((this.address == rhs.address)||((this.address!= null)&&this.address.equals(rhs.address))))&&((this.fullName == rhs.fullName)||((this.fullName!= null)&&this.fullName.equals(rhs.fullName))))&&((this.employment == rhs.employment)||((this.employment!= null)&&this.employment.equals(rhs.employment))))&&((this.partySysKey == rhs.partySysKey)||((this.partySysKey!= null)&&this.partySysKey.equals(rhs.partySysKey))))&&((this.url == rhs.url)||((this.url!= null)&&this.url.equals(rhs.url))))&&((this.prefComm == rhs.prefComm)||((this.prefComm!= null)&&this.prefComm.equals(rhs.prefComm))))&&((this.carrier == rhs.carrier)||((this.carrier!= null)&&this.carrier.equals(rhs.carrier))))&&((this.bestTimeToCallFrom == rhs.bestTimeToCallFrom)||((this.bestTimeToCallFrom!= null)&&this.bestTimeToCallFrom.equals(rhs.bestTimeToCallFrom))))&&((this.organization == rhs.organization)||((this.organization!= null)&&this.organization.equals(rhs.organization))))&&((this.govtIDStat == rhs.govtIDStat)||((this.govtIDStat!= null)&&this.govtIDStat.equals(rhs.govtIDStat))))&&((this.partyKey == rhs.partyKey)||((this.partyKey!= null)&&this.partyKey.equals(rhs.partyKey))))&&((this.risk == rhs.risk)||((this.risk!= null)&&this.risk.equals(rhs.risk))))&&((this.businessAssetAmt == rhs.businessAssetAmt)||((this.businessAssetAmt!= null)&&this.businessAssetAmt.equals(rhs.businessAssetAmt))));
    }

}
