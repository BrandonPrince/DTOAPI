
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ClaimMedConditionInfoKey",
    "ClaimMedConditionInfoSysKey",
    "StartDate",
    "EndDate",
    "CausePrecedence",
    "LostCapability",
    "ClaimMedTreatmentInfo",
    "OLifEExtension",
    "id",
    "MedicalConditionID",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class ClaimMedConditionInfo {

    @JsonProperty("ClaimMedConditionInfoKey")
    private ClaimMedConditionInfoKey claimMedConditionInfoKey;
    @JsonProperty("ClaimMedConditionInfoSysKey")
    private List<Object> claimMedConditionInfoSysKey = new ArrayList<>();
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("CausePrecedence")
    private CausePrecedence causePrecedence;
    @JsonProperty("LostCapability")
    private List<Object> lostCapability = new ArrayList<>();
    @JsonProperty("ClaimMedTreatmentInfo")
    private List<Object> claimMedTreatmentInfo = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("MedicalConditionID")
    private String medicalConditionID;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ClaimMedConditionInfoKey")
    public ClaimMedConditionInfoKey getClaimMedConditionInfoKey() {
        return claimMedConditionInfoKey;
    }

    @JsonProperty("ClaimMedConditionInfoKey")
    public void setClaimMedConditionInfoKey(ClaimMedConditionInfoKey claimMedConditionInfoKey) {
        this.claimMedConditionInfoKey = claimMedConditionInfoKey;
    }

    public ClaimMedConditionInfo withClaimMedConditionInfoKey(ClaimMedConditionInfoKey claimMedConditionInfoKey) {
        this.claimMedConditionInfoKey = claimMedConditionInfoKey;
        return this;
    }

    @JsonProperty("ClaimMedConditionInfoSysKey")
    public List<Object> getClaimMedConditionInfoSysKey() {
        return claimMedConditionInfoSysKey;
    }

    @JsonProperty("ClaimMedConditionInfoSysKey")
    public void setClaimMedConditionInfoSysKey(List<Object> claimMedConditionInfoSysKey) {
        this.claimMedConditionInfoSysKey = claimMedConditionInfoSysKey;
    }

    public ClaimMedConditionInfo withClaimMedConditionInfoSysKey(List<Object> claimMedConditionInfoSysKey) {
        this.claimMedConditionInfoSysKey = claimMedConditionInfoSysKey;
        return this;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public ClaimMedConditionInfo withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public ClaimMedConditionInfo withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("CausePrecedence")
    public CausePrecedence getCausePrecedence() {
        return causePrecedence;
    }

    @JsonProperty("CausePrecedence")
    public void setCausePrecedence(CausePrecedence causePrecedence) {
        this.causePrecedence = causePrecedence;
    }

    public ClaimMedConditionInfo withCausePrecedence(CausePrecedence causePrecedence) {
        this.causePrecedence = causePrecedence;
        return this;
    }

    @JsonProperty("LostCapability")
    public List<Object> getLostCapability() {
        return lostCapability;
    }

    @JsonProperty("LostCapability")
    public void setLostCapability(List<Object> lostCapability) {
        this.lostCapability = lostCapability;
    }

    public ClaimMedConditionInfo withLostCapability(List<Object> lostCapability) {
        this.lostCapability = lostCapability;
        return this;
    }

    @JsonProperty("ClaimMedTreatmentInfo")
    public List<Object> getClaimMedTreatmentInfo() {
        return claimMedTreatmentInfo;
    }

    @JsonProperty("ClaimMedTreatmentInfo")
    public void setClaimMedTreatmentInfo(List<Object> claimMedTreatmentInfo) {
        this.claimMedTreatmentInfo = claimMedTreatmentInfo;
    }

    public ClaimMedConditionInfo withClaimMedTreatmentInfo(List<Object> claimMedTreatmentInfo) {
        this.claimMedTreatmentInfo = claimMedTreatmentInfo;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public ClaimMedConditionInfo withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public ClaimMedConditionInfo withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("MedicalConditionID")
    public String getMedicalConditionID() {
        return medicalConditionID;
    }

    @JsonProperty("MedicalConditionID")
    public void setMedicalConditionID(String medicalConditionID) {
        this.medicalConditionID = medicalConditionID;
    }

    public ClaimMedConditionInfo withMedicalConditionID(String medicalConditionID) {
        this.medicalConditionID = medicalConditionID;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public ClaimMedConditionInfo withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ClaimMedConditionInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ClaimMedConditionInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("claimMedConditionInfoKey");
        sb.append('=');
        sb.append(((this.claimMedConditionInfoKey == null)?"<null>":this.claimMedConditionInfoKey));
        sb.append(',');
        sb.append("claimMedConditionInfoSysKey");
        sb.append('=');
        sb.append(((this.claimMedConditionInfoSysKey == null)?"<null>":this.claimMedConditionInfoSysKey));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("causePrecedence");
        sb.append('=');
        sb.append(((this.causePrecedence == null)?"<null>":this.causePrecedence));
        sb.append(',');
        sb.append("lostCapability");
        sb.append('=');
        sb.append(((this.lostCapability == null)?"<null>":this.lostCapability));
        sb.append(',');
        sb.append("claimMedTreatmentInfo");
        sb.append('=');
        sb.append(((this.claimMedTreatmentInfo == null)?"<null>":this.claimMedTreatmentInfo));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("medicalConditionID");
        sb.append('=');
        sb.append(((this.medicalConditionID == null)?"<null>":this.medicalConditionID));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.claimMedConditionInfoKey == null)? 0 :this.claimMedConditionInfoKey.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.claimMedTreatmentInfo == null)? 0 :this.claimMedTreatmentInfo.hashCode()));
        result = ((result* 31)+((this.medicalConditionID == null)? 0 :this.medicalConditionID.hashCode()));
        result = ((result* 31)+((this.causePrecedence == null)? 0 :this.causePrecedence.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.claimMedConditionInfoSysKey == null)? 0 :this.claimMedConditionInfoSysKey.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.lostCapability == null)? 0 :this.lostCapability.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ClaimMedConditionInfo) == false) {
            return false;
        }
        ClaimMedConditionInfo rhs = ((ClaimMedConditionInfo) other);
        return (((((((((((((this.claimMedConditionInfoKey == rhs.claimMedConditionInfoKey)||((this.claimMedConditionInfoKey!= null)&&this.claimMedConditionInfoKey.equals(rhs.claimMedConditionInfoKey)))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.claimMedTreatmentInfo == rhs.claimMedTreatmentInfo)||((this.claimMedTreatmentInfo!= null)&&this.claimMedTreatmentInfo.equals(rhs.claimMedTreatmentInfo))))&&((this.medicalConditionID == rhs.medicalConditionID)||((this.medicalConditionID!= null)&&this.medicalConditionID.equals(rhs.medicalConditionID))))&&((this.causePrecedence == rhs.causePrecedence)||((this.causePrecedence!= null)&&this.causePrecedence.equals(rhs.causePrecedence))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.claimMedConditionInfoSysKey == rhs.claimMedConditionInfoSysKey)||((this.claimMedConditionInfoSysKey!= null)&&this.claimMedConditionInfoSysKey.equals(rhs.claimMedConditionInfoSysKey))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.lostCapability == rhs.lostCapability)||((this.lostCapability!= null)&&this.lostCapability.equals(rhs.lostCapability))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))));
    }

}
