
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "StatusEventKey",
    "StatusEventSysKey",
    "StatusEventCode",
    "ProviderEventCode",
    "StatusEventDate",
    "StatusEventTime",
    "StatusEventDetail",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class StatusEvent {

    @JsonProperty("StatusEventKey")
    private StatusEventKey statusEventKey;
    @JsonProperty("StatusEventSysKey")
    private List<Object> statusEventSysKey = new ArrayList<>();
    @JsonProperty("StatusEventCode")
    private StatusEventCode statusEventCode;
    @JsonProperty("ProviderEventCode")
    private String providerEventCode;
    @JsonProperty("StatusEventDate")
    private String statusEventDate;
    @JsonProperty("StatusEventTime")
    private String statusEventTime;
    @JsonProperty("StatusEventDetail")
    private String statusEventDetail;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("StatusEventKey")
    public StatusEventKey getStatusEventKey() {
        return statusEventKey;
    }

    @JsonProperty("StatusEventKey")
    public void setStatusEventKey(StatusEventKey statusEventKey) {
        this.statusEventKey = statusEventKey;
    }

    public StatusEvent withStatusEventKey(StatusEventKey statusEventKey) {
        this.statusEventKey = statusEventKey;
        return this;
    }

    @JsonProperty("StatusEventSysKey")
    public List<Object> getStatusEventSysKey() {
        return statusEventSysKey;
    }

    @JsonProperty("StatusEventSysKey")
    public void setStatusEventSysKey(List<Object> statusEventSysKey) {
        this.statusEventSysKey = statusEventSysKey;
    }

    public StatusEvent withStatusEventSysKey(List<Object> statusEventSysKey) {
        this.statusEventSysKey = statusEventSysKey;
        return this;
    }

    @JsonProperty("StatusEventCode")
    public StatusEventCode getStatusEventCode() {
        return statusEventCode;
    }

    @JsonProperty("StatusEventCode")
    public void setStatusEventCode(StatusEventCode statusEventCode) {
        this.statusEventCode = statusEventCode;
    }

    public StatusEvent withStatusEventCode(StatusEventCode statusEventCode) {
        this.statusEventCode = statusEventCode;
        return this;
    }

    @JsonProperty("ProviderEventCode")
    public String getProviderEventCode() {
        return providerEventCode;
    }

    @JsonProperty("ProviderEventCode")
    public void setProviderEventCode(String providerEventCode) {
        this.providerEventCode = providerEventCode;
    }

    public StatusEvent withProviderEventCode(String providerEventCode) {
        this.providerEventCode = providerEventCode;
        return this;
    }

    @JsonProperty("StatusEventDate")
    public String getStatusEventDate() {
        return statusEventDate;
    }

    @JsonProperty("StatusEventDate")
    public void setStatusEventDate(String statusEventDate) {
        this.statusEventDate = statusEventDate;
    }

    public StatusEvent withStatusEventDate(String statusEventDate) {
        this.statusEventDate = statusEventDate;
        return this;
    }

    @JsonProperty("StatusEventTime")
    public String getStatusEventTime() {
        return statusEventTime;
    }

    @JsonProperty("StatusEventTime")
    public void setStatusEventTime(String statusEventTime) {
        this.statusEventTime = statusEventTime;
    }

    public StatusEvent withStatusEventTime(String statusEventTime) {
        this.statusEventTime = statusEventTime;
        return this;
    }

    @JsonProperty("StatusEventDetail")
    public String getStatusEventDetail() {
        return statusEventDetail;
    }

    @JsonProperty("StatusEventDetail")
    public void setStatusEventDetail(String statusEventDetail) {
        this.statusEventDetail = statusEventDetail;
    }

    public StatusEvent withStatusEventDetail(String statusEventDetail) {
        this.statusEventDetail = statusEventDetail;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public StatusEvent withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public StatusEvent withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public StatusEvent withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public StatusEvent withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(StatusEvent.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("statusEventKey");
        sb.append('=');
        sb.append(((this.statusEventKey == null)?"<null>":this.statusEventKey));
        sb.append(',');
        sb.append("statusEventSysKey");
        sb.append('=');
        sb.append(((this.statusEventSysKey == null)?"<null>":this.statusEventSysKey));
        sb.append(',');
        sb.append("statusEventCode");
        sb.append('=');
        sb.append(((this.statusEventCode == null)?"<null>":this.statusEventCode));
        sb.append(',');
        sb.append("providerEventCode");
        sb.append('=');
        sb.append(((this.providerEventCode == null)?"<null>":this.providerEventCode));
        sb.append(',');
        sb.append("statusEventDate");
        sb.append('=');
        sb.append(((this.statusEventDate == null)?"<null>":this.statusEventDate));
        sb.append(',');
        sb.append("statusEventTime");
        sb.append('=');
        sb.append(((this.statusEventTime == null)?"<null>":this.statusEventTime));
        sb.append(',');
        sb.append("statusEventDetail");
        sb.append('=');
        sb.append(((this.statusEventDetail == null)?"<null>":this.statusEventDetail));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.statusEventDetail == null)? 0 :this.statusEventDetail.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.statusEventCode == null)? 0 :this.statusEventCode.hashCode()));
        result = ((result* 31)+((this.statusEventDate == null)? 0 :this.statusEventDate.hashCode()));
        result = ((result* 31)+((this.statusEventSysKey == null)? 0 :this.statusEventSysKey.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.providerEventCode == null)? 0 :this.providerEventCode.hashCode()));
        result = ((result* 31)+((this.statusEventKey == null)? 0 :this.statusEventKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.statusEventTime == null)? 0 :this.statusEventTime.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof StatusEvent) == false) {
            return false;
        }
        StatusEvent rhs = ((StatusEvent) other);
        return ((((((((((((this.statusEventDetail == rhs.statusEventDetail)||((this.statusEventDetail!= null)&&this.statusEventDetail.equals(rhs.statusEventDetail)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.statusEventCode == rhs.statusEventCode)||((this.statusEventCode!= null)&&this.statusEventCode.equals(rhs.statusEventCode))))&&((this.statusEventDate == rhs.statusEventDate)||((this.statusEventDate!= null)&&this.statusEventDate.equals(rhs.statusEventDate))))&&((this.statusEventSysKey == rhs.statusEventSysKey)||((this.statusEventSysKey!= null)&&this.statusEventSysKey.equals(rhs.statusEventSysKey))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.providerEventCode == rhs.providerEventCode)||((this.providerEventCode!= null)&&this.providerEventCode.equals(rhs.providerEventCode))))&&((this.statusEventKey == rhs.statusEventKey)||((this.statusEventKey!= null)&&this.statusEventKey.equals(rhs.statusEventKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.statusEventTime == rhs.statusEventTime)||((this.statusEventTime!= null)&&this.statusEventTime.equals(rhs.statusEventTime))));
    }

}
