
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ParticipantKey",
    "ParticipantSysKey",
    "ParticipantName",
    "ParticipantRoleCode",
    "ParticipationPct",
    "IssueAge",
    "ClosedAge",
    "IssueGender",
    "ResidenceNationAtIssue",
    "ResidenceJurisdictionAtIssue",
    "SmokerStat",
    "TobaccoPremiumBasis",
    "Occupation",
    "OccupClass",
    "UnderwritingClass",
    "UnderwritingSubClass",
    "FlatExtraPremBasis",
    "ModalGrossFlatExtraPremAmt",
    "ModalGrossFlatExtraAllowanceAmt",
    "BeneficiarySeqNum",
    "BeneficiaryPercentDistribution",
    "BeneficiaryAmountDistribution",
    "IrrevokableInd",
    "BeneficiaryShareMethod",
    "BeneficiaryCommonDisasterPeriod",
    "DistributionOption",
    "BeneficiaryDesignation",
    "BeneficiaryRoleCode",
    "BeneficiaryRoleCodeDesc",
    "ASCOCode",
    "ClassName",
    "CommissionLink",
    "ModalGrossTempFlatAllowAmt",
    "EffDate",
    "ParticipantStatus",
    "IssueAgeSource",
    "AgeSetBackQuantity",
    "AgeCalculationType",
    "InsuredSeqNum",
    "TempFlatExtraDuration",
    "TempPercentageLoading",
    "PermPercentageLoading",
    "OccupRating",
    "PermFlatExtraAmt",
    "PermFlatExtraEndDate",
    "PermTableRating",
    "PermTableRatingEndDate",
    "RatingCommissionRule",
    "RatingOverriddenInd",
    "RatingReason",
    "ReconsiderationDate",
    "TempFlatEndDate",
    "TempFlatExtraAmt",
    "TempTableRating",
    "TempTableRatingStartDate",
    "TempTableRatingEndDate",
    "IssuedAsAppliedInd",
    "PrivacyLastCommunicationDate",
    "BeneficiaryIncomeOption",
    "TempRatingType",
    "ProceedsHoldDuration",
    "ProceedsHoldDurUnitMeasure",
    "LastRatingDate",
    "BeneficiaryClaimPeriod",
    "BeneClaimPeriodMeasureUnit",
    "EmploymentClass",
    "PermRatingType",
    "FaceAmt",
    "ModalGrossPermFlatExtraAllowanceAmt",
    "OriginalIssueAge",
    "PermTableRatingAlphaCode",
    "TempTableRatingCode",
    "TermDate",
    "LivesWithPrimaryInsInd",
    "DependentOnPrimaryInsInd",
    "TempFlatStartDate",
    "PermRatingAmtPerThou",
    "TempRatingAmtPerThou",
    "TempFlatExtraOverrideEndDate",
    "TempFlatExtraOverrideEffDate",
    "TemporaryRoleInd",
    "PreferredBeneficiaryInd",
    "ModalPermRatingAmt",
    "ModalTempRatingAmt",
    "SubstandardRating",
    "AssocParticipantObjectInfo",
    "UnderwritingResult",
    "DeliveryInfo",
    "BeneficiaryIncomeOptionInfo",
    "OLifEExtension",
    "id",
    "PartyID",
    "MailingAddressID",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class Participant {

    @JsonProperty("ParticipantKey")
    private ParticipantKey participantKey;
    @JsonProperty("ParticipantSysKey")
    private List<Object> participantSysKey = new ArrayList<>();
    @JsonProperty("ParticipantName")
    private String participantName;
    @JsonProperty("ParticipantRoleCode")
    private ParticipantRoleCode participantRoleCode;
    @JsonProperty("ParticipationPct")
    private Integer participationPct;
    @JsonProperty("IssueAge")
    private Integer issueAge;
    @JsonProperty("ClosedAge")
    private Integer closedAge;
    @JsonProperty("IssueGender")
    private IssueGender issueGender;
    @JsonProperty("ResidenceNationAtIssue")
    private ResidenceNationAtIssue residenceNationAtIssue;
    @JsonProperty("ResidenceJurisdictionAtIssue")
    private ResidenceJurisdictionAtIssue residenceJurisdictionAtIssue;
    @JsonProperty("SmokerStat")
    private SmokerStat smokerStat;
    @JsonProperty("TobaccoPremiumBasis")
    private TobaccoPremiumBasis tobaccoPremiumBasis;
    @JsonProperty("Occupation")
    private String occupation;
    @JsonProperty("OccupClass")
    private OccupClass occupClass;
    @JsonProperty("UnderwritingClass")
    private UnderwritingClass underwritingClass;
    @JsonProperty("UnderwritingSubClass")
    private UnderwritingSubClass underwritingSubClass;
    @JsonProperty("FlatExtraPremBasis")
    private FlatExtraPremBasis flatExtraPremBasis;
    @JsonProperty("ModalGrossFlatExtraPremAmt")
    private Integer modalGrossFlatExtraPremAmt;
    @JsonProperty("ModalGrossFlatExtraAllowanceAmt")
    private Integer modalGrossFlatExtraAllowanceAmt;
    @JsonProperty("BeneficiarySeqNum")
    private Integer beneficiarySeqNum;
    @JsonProperty("BeneficiaryPercentDistribution")
    private Integer beneficiaryPercentDistribution;
    @JsonProperty("BeneficiaryAmountDistribution")
    private Integer beneficiaryAmountDistribution;
    @JsonProperty("IrrevokableInd")
    private IrrevokableInd irrevokableInd;
    @JsonProperty("BeneficiaryShareMethod")
    private BeneficiaryShareMethod beneficiaryShareMethod;
    @JsonProperty("BeneficiaryCommonDisasterPeriod")
    private Integer beneficiaryCommonDisasterPeriod;
    @JsonProperty("DistributionOption")
    private DistributionOption distributionOption;
    @JsonProperty("BeneficiaryDesignation")
    private BeneficiaryDesignation beneficiaryDesignation;
    @JsonProperty("BeneficiaryRoleCode")
    private BeneficiaryRoleCode beneficiaryRoleCode;
    @JsonProperty("BeneficiaryRoleCodeDesc")
    private BeneficiaryRoleCodeDesc beneficiaryRoleCodeDesc;
    @JsonProperty("ASCOCode")
    private String aSCOCode;
    @JsonProperty("ClassName")
    private String className;
    @JsonProperty("CommissionLink")
    private String commissionLink;
    @JsonProperty("ModalGrossTempFlatAllowAmt")
    private Integer modalGrossTempFlatAllowAmt;
    @JsonProperty("EffDate")
    private String effDate;
    @JsonProperty("ParticipantStatus")
    private ParticipantStatus participantStatus;
    @JsonProperty("IssueAgeSource")
    private IssueAgeSource issueAgeSource;
    @JsonProperty("AgeSetBackQuantity")
    private Integer ageSetBackQuantity;
    @JsonProperty("AgeCalculationType")
    private AgeCalculationType ageCalculationType;
    @JsonProperty("InsuredSeqNum")
    private Integer insuredSeqNum;
    @JsonProperty("TempFlatExtraDuration")
    private Integer tempFlatExtraDuration;
    @JsonProperty("TempPercentageLoading")
    private Integer tempPercentageLoading;
    @JsonProperty("PermPercentageLoading")
    private Integer permPercentageLoading;
    @JsonProperty("OccupRating")
    private OccupRating occupRating;
    @JsonProperty("PermFlatExtraAmt")
    private Integer permFlatExtraAmt;
    @JsonProperty("PermFlatExtraEndDate")
    private String permFlatExtraEndDate;
    @JsonProperty("PermTableRating")
    private PermTableRating permTableRating;
    @JsonProperty("PermTableRatingEndDate")
    private String permTableRatingEndDate;
    @JsonProperty("RatingCommissionRule")
    private RatingCommissionRule ratingCommissionRule;
    @JsonProperty("RatingOverriddenInd")
    private RatingOverriddenInd ratingOverriddenInd;
    @JsonProperty("RatingReason")
    private String ratingReason;
    @JsonProperty("ReconsiderationDate")
    private String reconsiderationDate;
    @JsonProperty("TempFlatEndDate")
    private String tempFlatEndDate;
    @JsonProperty("TempFlatExtraAmt")
    private Integer tempFlatExtraAmt;
    @JsonProperty("TempTableRating")
    private TempTableRating tempTableRating;
    @JsonProperty("TempTableRatingStartDate")
    private String tempTableRatingStartDate;
    @JsonProperty("TempTableRatingEndDate")
    private String tempTableRatingEndDate;
    @JsonProperty("IssuedAsAppliedInd")
    private IssuedAsAppliedInd issuedAsAppliedInd;
    @JsonProperty("PrivacyLastCommunicationDate")
    private String privacyLastCommunicationDate;
    @JsonProperty("BeneficiaryIncomeOption")
    private BeneficiaryIncomeOption beneficiaryIncomeOption;
    @JsonProperty("TempRatingType")
    private TempRatingType tempRatingType;
    @JsonProperty("ProceedsHoldDuration")
    private Integer proceedsHoldDuration;
    @JsonProperty("ProceedsHoldDurUnitMeasure")
    private ProceedsHoldDurUnitMeasure proceedsHoldDurUnitMeasure;
    @JsonProperty("LastRatingDate")
    private String lastRatingDate;
    @JsonProperty("BeneficiaryClaimPeriod")
    private Integer beneficiaryClaimPeriod;
    @JsonProperty("BeneClaimPeriodMeasureUnit")
    private BeneClaimPeriodMeasureUnit beneClaimPeriodMeasureUnit;
    @JsonProperty("EmploymentClass")
    private EmploymentClass employmentClass;
    @JsonProperty("PermRatingType")
    private PermRatingType permRatingType;
    @JsonProperty("FaceAmt")
    private Integer faceAmt;
    @JsonProperty("ModalGrossPermFlatExtraAllowanceAmt")
    private Integer modalGrossPermFlatExtraAllowanceAmt;
    @JsonProperty("OriginalIssueAge")
    private Integer originalIssueAge;
    @JsonProperty("PermTableRatingAlphaCode")
    private String permTableRatingAlphaCode;
    @JsonProperty("TempTableRatingCode")
    private String tempTableRatingCode;
    @JsonProperty("TermDate")
    private String termDate;
    @JsonProperty("LivesWithPrimaryInsInd")
    private LivesWithPrimaryInsInd livesWithPrimaryInsInd;
    @JsonProperty("DependentOnPrimaryInsInd")
    private DependentOnPrimaryInsInd dependentOnPrimaryInsInd;
    @JsonProperty("TempFlatStartDate")
    private String tempFlatStartDate;
    @JsonProperty("PermRatingAmtPerThou")
    private Integer permRatingAmtPerThou;
    @JsonProperty("TempRatingAmtPerThou")
    private Integer tempRatingAmtPerThou;
    @JsonProperty("TempFlatExtraOverrideEndDate")
    private String tempFlatExtraOverrideEndDate;
    @JsonProperty("TempFlatExtraOverrideEffDate")
    private String tempFlatExtraOverrideEffDate;
    @JsonProperty("TemporaryRoleInd")
    private TemporaryRoleInd temporaryRoleInd;
    @JsonProperty("PreferredBeneficiaryInd")
    private PreferredBeneficiaryInd preferredBeneficiaryInd;
    @JsonProperty("ModalPermRatingAmt")
    private Integer modalPermRatingAmt;
    @JsonProperty("ModalTempRatingAmt")
    private Integer modalTempRatingAmt;
    @JsonProperty("SubstandardRating")
    private List<Object> substandardRating = new ArrayList<>();
    @JsonProperty("AssocParticipantObjectInfo")
    private List<Object> assocParticipantObjectInfo = new ArrayList<>();
    @JsonProperty("UnderwritingResult")
    private List<Object> underwritingResult = new ArrayList<>();
    @JsonProperty("DeliveryInfo")
    private List<Object> deliveryInfo = new ArrayList<>();
    @JsonProperty("BeneficiaryIncomeOptionInfo")
    private List<Object> beneficiaryIncomeOptionInfo = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("PartyID")
    private String partyID;
    @JsonProperty("MailingAddressID")
    private String mailingAddressID;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ParticipantKey")
    public ParticipantKey getParticipantKey() {
        return participantKey;
    }

    @JsonProperty("ParticipantKey")
    public void setParticipantKey(ParticipantKey participantKey) {
        this.participantKey = participantKey;
    }

    public Participant withParticipantKey(ParticipantKey participantKey) {
        this.participantKey = participantKey;
        return this;
    }

    @JsonProperty("ParticipantSysKey")
    public List<Object> getParticipantSysKey() {
        return participantSysKey;
    }

    @JsonProperty("ParticipantSysKey")
    public void setParticipantSysKey(List<Object> participantSysKey) {
        this.participantSysKey = participantSysKey;
    }

    public Participant withParticipantSysKey(List<Object> participantSysKey) {
        this.participantSysKey = participantSysKey;
        return this;
    }

    @JsonProperty("ParticipantName")
    public String getParticipantName() {
        return participantName;
    }

    @JsonProperty("ParticipantName")
    public void setParticipantName(String participantName) {
        this.participantName = participantName;
    }

    public Participant withParticipantName(String participantName) {
        this.participantName = participantName;
        return this;
    }

    @JsonProperty("ParticipantRoleCode")
    public ParticipantRoleCode getParticipantRoleCode() {
        return participantRoleCode;
    }

    @JsonProperty("ParticipantRoleCode")
    public void setParticipantRoleCode(ParticipantRoleCode participantRoleCode) {
        this.participantRoleCode = participantRoleCode;
    }

    public Participant withParticipantRoleCode(ParticipantRoleCode participantRoleCode) {
        this.participantRoleCode = participantRoleCode;
        return this;
    }

    @JsonProperty("ParticipationPct")
    public Integer getParticipationPct() {
        return participationPct;
    }

    @JsonProperty("ParticipationPct")
    public void setParticipationPct(Integer participationPct) {
        this.participationPct = participationPct;
    }

    public Participant withParticipationPct(Integer participationPct) {
        this.participationPct = participationPct;
        return this;
    }

    @JsonProperty("IssueAge")
    public Integer getIssueAge() {
        return issueAge;
    }

    @JsonProperty("IssueAge")
    public void setIssueAge(Integer issueAge) {
        this.issueAge = issueAge;
    }

    public Participant withIssueAge(Integer issueAge) {
        this.issueAge = issueAge;
        return this;
    }

    @JsonProperty("ClosedAge")
    public Integer getClosedAge() {
        return closedAge;
    }

    @JsonProperty("ClosedAge")
    public void setClosedAge(Integer closedAge) {
        this.closedAge = closedAge;
    }

    public Participant withClosedAge(Integer closedAge) {
        this.closedAge = closedAge;
        return this;
    }

    @JsonProperty("IssueGender")
    public IssueGender getIssueGender() {
        return issueGender;
    }

    @JsonProperty("IssueGender")
    public void setIssueGender(IssueGender issueGender) {
        this.issueGender = issueGender;
    }

    public Participant withIssueGender(IssueGender issueGender) {
        this.issueGender = issueGender;
        return this;
    }

    @JsonProperty("ResidenceNationAtIssue")
    public ResidenceNationAtIssue getResidenceNationAtIssue() {
        return residenceNationAtIssue;
    }

    @JsonProperty("ResidenceNationAtIssue")
    public void setResidenceNationAtIssue(ResidenceNationAtIssue residenceNationAtIssue) {
        this.residenceNationAtIssue = residenceNationAtIssue;
    }

    public Participant withResidenceNationAtIssue(ResidenceNationAtIssue residenceNationAtIssue) {
        this.residenceNationAtIssue = residenceNationAtIssue;
        return this;
    }

    @JsonProperty("ResidenceJurisdictionAtIssue")
    public ResidenceJurisdictionAtIssue getResidenceJurisdictionAtIssue() {
        return residenceJurisdictionAtIssue;
    }

    @JsonProperty("ResidenceJurisdictionAtIssue")
    public void setResidenceJurisdictionAtIssue(ResidenceJurisdictionAtIssue residenceJurisdictionAtIssue) {
        this.residenceJurisdictionAtIssue = residenceJurisdictionAtIssue;
    }

    public Participant withResidenceJurisdictionAtIssue(ResidenceJurisdictionAtIssue residenceJurisdictionAtIssue) {
        this.residenceJurisdictionAtIssue = residenceJurisdictionAtIssue;
        return this;
    }

    @JsonProperty("SmokerStat")
    public SmokerStat getSmokerStat() {
        return smokerStat;
    }

    @JsonProperty("SmokerStat")
    public void setSmokerStat(SmokerStat smokerStat) {
        this.smokerStat = smokerStat;
    }

    public Participant withSmokerStat(SmokerStat smokerStat) {
        this.smokerStat = smokerStat;
        return this;
    }

    @JsonProperty("TobaccoPremiumBasis")
    public TobaccoPremiumBasis getTobaccoPremiumBasis() {
        return tobaccoPremiumBasis;
    }

    @JsonProperty("TobaccoPremiumBasis")
    public void setTobaccoPremiumBasis(TobaccoPremiumBasis tobaccoPremiumBasis) {
        this.tobaccoPremiumBasis = tobaccoPremiumBasis;
    }

    public Participant withTobaccoPremiumBasis(TobaccoPremiumBasis tobaccoPremiumBasis) {
        this.tobaccoPremiumBasis = tobaccoPremiumBasis;
        return this;
    }

    @JsonProperty("Occupation")
    public String getOccupation() {
        return occupation;
    }

    @JsonProperty("Occupation")
    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public Participant withOccupation(String occupation) {
        this.occupation = occupation;
        return this;
    }

    @JsonProperty("OccupClass")
    public OccupClass getOccupClass() {
        return occupClass;
    }

    @JsonProperty("OccupClass")
    public void setOccupClass(OccupClass occupClass) {
        this.occupClass = occupClass;
    }

    public Participant withOccupClass(OccupClass occupClass) {
        this.occupClass = occupClass;
        return this;
    }

    @JsonProperty("UnderwritingClass")
    public UnderwritingClass getUnderwritingClass() {
        return underwritingClass;
    }

    @JsonProperty("UnderwritingClass")
    public void setUnderwritingClass(UnderwritingClass underwritingClass) {
        this.underwritingClass = underwritingClass;
    }

    public Participant withUnderwritingClass(UnderwritingClass underwritingClass) {
        this.underwritingClass = underwritingClass;
        return this;
    }

    @JsonProperty("UnderwritingSubClass")
    public UnderwritingSubClass getUnderwritingSubClass() {
        return underwritingSubClass;
    }

    @JsonProperty("UnderwritingSubClass")
    public void setUnderwritingSubClass(UnderwritingSubClass underwritingSubClass) {
        this.underwritingSubClass = underwritingSubClass;
    }

    public Participant withUnderwritingSubClass(UnderwritingSubClass underwritingSubClass) {
        this.underwritingSubClass = underwritingSubClass;
        return this;
    }

    @JsonProperty("FlatExtraPremBasis")
    public FlatExtraPremBasis getFlatExtraPremBasis() {
        return flatExtraPremBasis;
    }

    @JsonProperty("FlatExtraPremBasis")
    public void setFlatExtraPremBasis(FlatExtraPremBasis flatExtraPremBasis) {
        this.flatExtraPremBasis = flatExtraPremBasis;
    }

    public Participant withFlatExtraPremBasis(FlatExtraPremBasis flatExtraPremBasis) {
        this.flatExtraPremBasis = flatExtraPremBasis;
        return this;
    }

    @JsonProperty("ModalGrossFlatExtraPremAmt")
    public Integer getModalGrossFlatExtraPremAmt() {
        return modalGrossFlatExtraPremAmt;
    }

    @JsonProperty("ModalGrossFlatExtraPremAmt")
    public void setModalGrossFlatExtraPremAmt(Integer modalGrossFlatExtraPremAmt) {
        this.modalGrossFlatExtraPremAmt = modalGrossFlatExtraPremAmt;
    }

    public Participant withModalGrossFlatExtraPremAmt(Integer modalGrossFlatExtraPremAmt) {
        this.modalGrossFlatExtraPremAmt = modalGrossFlatExtraPremAmt;
        return this;
    }

    @JsonProperty("ModalGrossFlatExtraAllowanceAmt")
    public Integer getModalGrossFlatExtraAllowanceAmt() {
        return modalGrossFlatExtraAllowanceAmt;
    }

    @JsonProperty("ModalGrossFlatExtraAllowanceAmt")
    public void setModalGrossFlatExtraAllowanceAmt(Integer modalGrossFlatExtraAllowanceAmt) {
        this.modalGrossFlatExtraAllowanceAmt = modalGrossFlatExtraAllowanceAmt;
    }

    public Participant withModalGrossFlatExtraAllowanceAmt(Integer modalGrossFlatExtraAllowanceAmt) {
        this.modalGrossFlatExtraAllowanceAmt = modalGrossFlatExtraAllowanceAmt;
        return this;
    }

    @JsonProperty("BeneficiarySeqNum")
    public Integer getBeneficiarySeqNum() {
        return beneficiarySeqNum;
    }

    @JsonProperty("BeneficiarySeqNum")
    public void setBeneficiarySeqNum(Integer beneficiarySeqNum) {
        this.beneficiarySeqNum = beneficiarySeqNum;
    }

    public Participant withBeneficiarySeqNum(Integer beneficiarySeqNum) {
        this.beneficiarySeqNum = beneficiarySeqNum;
        return this;
    }

    @JsonProperty("BeneficiaryPercentDistribution")
    public Integer getBeneficiaryPercentDistribution() {
        return beneficiaryPercentDistribution;
    }

    @JsonProperty("BeneficiaryPercentDistribution")
    public void setBeneficiaryPercentDistribution(Integer beneficiaryPercentDistribution) {
        this.beneficiaryPercentDistribution = beneficiaryPercentDistribution;
    }

    public Participant withBeneficiaryPercentDistribution(Integer beneficiaryPercentDistribution) {
        this.beneficiaryPercentDistribution = beneficiaryPercentDistribution;
        return this;
    }

    @JsonProperty("BeneficiaryAmountDistribution")
    public Integer getBeneficiaryAmountDistribution() {
        return beneficiaryAmountDistribution;
    }

    @JsonProperty("BeneficiaryAmountDistribution")
    public void setBeneficiaryAmountDistribution(Integer beneficiaryAmountDistribution) {
        this.beneficiaryAmountDistribution = beneficiaryAmountDistribution;
    }

    public Participant withBeneficiaryAmountDistribution(Integer beneficiaryAmountDistribution) {
        this.beneficiaryAmountDistribution = beneficiaryAmountDistribution;
        return this;
    }

    @JsonProperty("IrrevokableInd")
    public IrrevokableInd getIrrevokableInd() {
        return irrevokableInd;
    }

    @JsonProperty("IrrevokableInd")
    public void setIrrevokableInd(IrrevokableInd irrevokableInd) {
        this.irrevokableInd = irrevokableInd;
    }

    public Participant withIrrevokableInd(IrrevokableInd irrevokableInd) {
        this.irrevokableInd = irrevokableInd;
        return this;
    }

    @JsonProperty("BeneficiaryShareMethod")
    public BeneficiaryShareMethod getBeneficiaryShareMethod() {
        return beneficiaryShareMethod;
    }

    @JsonProperty("BeneficiaryShareMethod")
    public void setBeneficiaryShareMethod(BeneficiaryShareMethod beneficiaryShareMethod) {
        this.beneficiaryShareMethod = beneficiaryShareMethod;
    }

    public Participant withBeneficiaryShareMethod(BeneficiaryShareMethod beneficiaryShareMethod) {
        this.beneficiaryShareMethod = beneficiaryShareMethod;
        return this;
    }

    @JsonProperty("BeneficiaryCommonDisasterPeriod")
    public Integer getBeneficiaryCommonDisasterPeriod() {
        return beneficiaryCommonDisasterPeriod;
    }

    @JsonProperty("BeneficiaryCommonDisasterPeriod")
    public void setBeneficiaryCommonDisasterPeriod(Integer beneficiaryCommonDisasterPeriod) {
        this.beneficiaryCommonDisasterPeriod = beneficiaryCommonDisasterPeriod;
    }

    public Participant withBeneficiaryCommonDisasterPeriod(Integer beneficiaryCommonDisasterPeriod) {
        this.beneficiaryCommonDisasterPeriod = beneficiaryCommonDisasterPeriod;
        return this;
    }

    @JsonProperty("DistributionOption")
    public DistributionOption getDistributionOption() {
        return distributionOption;
    }

    @JsonProperty("DistributionOption")
    public void setDistributionOption(DistributionOption distributionOption) {
        this.distributionOption = distributionOption;
    }

    public Participant withDistributionOption(DistributionOption distributionOption) {
        this.distributionOption = distributionOption;
        return this;
    }

    @JsonProperty("BeneficiaryDesignation")
    public BeneficiaryDesignation getBeneficiaryDesignation() {
        return beneficiaryDesignation;
    }

    @JsonProperty("BeneficiaryDesignation")
    public void setBeneficiaryDesignation(BeneficiaryDesignation beneficiaryDesignation) {
        this.beneficiaryDesignation = beneficiaryDesignation;
    }

    public Participant withBeneficiaryDesignation(BeneficiaryDesignation beneficiaryDesignation) {
        this.beneficiaryDesignation = beneficiaryDesignation;
        return this;
    }

    @JsonProperty("BeneficiaryRoleCode")
    public BeneficiaryRoleCode getBeneficiaryRoleCode() {
        return beneficiaryRoleCode;
    }

    @JsonProperty("BeneficiaryRoleCode")
    public void setBeneficiaryRoleCode(BeneficiaryRoleCode beneficiaryRoleCode) {
        this.beneficiaryRoleCode = beneficiaryRoleCode;
    }

    public Participant withBeneficiaryRoleCode(BeneficiaryRoleCode beneficiaryRoleCode) {
        this.beneficiaryRoleCode = beneficiaryRoleCode;
        return this;
    }

    @JsonProperty("BeneficiaryRoleCodeDesc")
    public BeneficiaryRoleCodeDesc getBeneficiaryRoleCodeDesc() {
        return beneficiaryRoleCodeDesc;
    }

    @JsonProperty("BeneficiaryRoleCodeDesc")
    public void setBeneficiaryRoleCodeDesc(BeneficiaryRoleCodeDesc beneficiaryRoleCodeDesc) {
        this.beneficiaryRoleCodeDesc = beneficiaryRoleCodeDesc;
    }

    public Participant withBeneficiaryRoleCodeDesc(BeneficiaryRoleCodeDesc beneficiaryRoleCodeDesc) {
        this.beneficiaryRoleCodeDesc = beneficiaryRoleCodeDesc;
        return this;
    }

    @JsonProperty("ASCOCode")
    public String getASCOCode() {
        return aSCOCode;
    }

    @JsonProperty("ASCOCode")
    public void setASCOCode(String aSCOCode) {
        this.aSCOCode = aSCOCode;
    }

    public Participant withASCOCode(String aSCOCode) {
        this.aSCOCode = aSCOCode;
        return this;
    }

    @JsonProperty("ClassName")
    public String getClassName() {
        return className;
    }

    @JsonProperty("ClassName")
    public void setClassName(String className) {
        this.className = className;
    }

    public Participant withClassName(String className) {
        this.className = className;
        return this;
    }

    @JsonProperty("CommissionLink")
    public String getCommissionLink() {
        return commissionLink;
    }

    @JsonProperty("CommissionLink")
    public void setCommissionLink(String commissionLink) {
        this.commissionLink = commissionLink;
    }

    public Participant withCommissionLink(String commissionLink) {
        this.commissionLink = commissionLink;
        return this;
    }

    @JsonProperty("ModalGrossTempFlatAllowAmt")
    public Integer getModalGrossTempFlatAllowAmt() {
        return modalGrossTempFlatAllowAmt;
    }

    @JsonProperty("ModalGrossTempFlatAllowAmt")
    public void setModalGrossTempFlatAllowAmt(Integer modalGrossTempFlatAllowAmt) {
        this.modalGrossTempFlatAllowAmt = modalGrossTempFlatAllowAmt;
    }

    public Participant withModalGrossTempFlatAllowAmt(Integer modalGrossTempFlatAllowAmt) {
        this.modalGrossTempFlatAllowAmt = modalGrossTempFlatAllowAmt;
        return this;
    }

    @JsonProperty("EffDate")
    public String getEffDate() {
        return effDate;
    }

    @JsonProperty("EffDate")
    public void setEffDate(String effDate) {
        this.effDate = effDate;
    }

    public Participant withEffDate(String effDate) {
        this.effDate = effDate;
        return this;
    }

    @JsonProperty("ParticipantStatus")
    public ParticipantStatus getParticipantStatus() {
        return participantStatus;
    }

    @JsonProperty("ParticipantStatus")
    public void setParticipantStatus(ParticipantStatus participantStatus) {
        this.participantStatus = participantStatus;
    }

    public Participant withParticipantStatus(ParticipantStatus participantStatus) {
        this.participantStatus = participantStatus;
        return this;
    }

    @JsonProperty("IssueAgeSource")
    public IssueAgeSource getIssueAgeSource() {
        return issueAgeSource;
    }

    @JsonProperty("IssueAgeSource")
    public void setIssueAgeSource(IssueAgeSource issueAgeSource) {
        this.issueAgeSource = issueAgeSource;
    }

    public Participant withIssueAgeSource(IssueAgeSource issueAgeSource) {
        this.issueAgeSource = issueAgeSource;
        return this;
    }

    @JsonProperty("AgeSetBackQuantity")
    public Integer getAgeSetBackQuantity() {
        return ageSetBackQuantity;
    }

    @JsonProperty("AgeSetBackQuantity")
    public void setAgeSetBackQuantity(Integer ageSetBackQuantity) {
        this.ageSetBackQuantity = ageSetBackQuantity;
    }

    public Participant withAgeSetBackQuantity(Integer ageSetBackQuantity) {
        this.ageSetBackQuantity = ageSetBackQuantity;
        return this;
    }

    @JsonProperty("AgeCalculationType")
    public AgeCalculationType getAgeCalculationType() {
        return ageCalculationType;
    }

    @JsonProperty("AgeCalculationType")
    public void setAgeCalculationType(AgeCalculationType ageCalculationType) {
        this.ageCalculationType = ageCalculationType;
    }

    public Participant withAgeCalculationType(AgeCalculationType ageCalculationType) {
        this.ageCalculationType = ageCalculationType;
        return this;
    }

    @JsonProperty("InsuredSeqNum")
    public Integer getInsuredSeqNum() {
        return insuredSeqNum;
    }

    @JsonProperty("InsuredSeqNum")
    public void setInsuredSeqNum(Integer insuredSeqNum) {
        this.insuredSeqNum = insuredSeqNum;
    }

    public Participant withInsuredSeqNum(Integer insuredSeqNum) {
        this.insuredSeqNum = insuredSeqNum;
        return this;
    }

    @JsonProperty("TempFlatExtraDuration")
    public Integer getTempFlatExtraDuration() {
        return tempFlatExtraDuration;
    }

    @JsonProperty("TempFlatExtraDuration")
    public void setTempFlatExtraDuration(Integer tempFlatExtraDuration) {
        this.tempFlatExtraDuration = tempFlatExtraDuration;
    }

    public Participant withTempFlatExtraDuration(Integer tempFlatExtraDuration) {
        this.tempFlatExtraDuration = tempFlatExtraDuration;
        return this;
    }

    @JsonProperty("TempPercentageLoading")
    public Integer getTempPercentageLoading() {
        return tempPercentageLoading;
    }

    @JsonProperty("TempPercentageLoading")
    public void setTempPercentageLoading(Integer tempPercentageLoading) {
        this.tempPercentageLoading = tempPercentageLoading;
    }

    public Participant withTempPercentageLoading(Integer tempPercentageLoading) {
        this.tempPercentageLoading = tempPercentageLoading;
        return this;
    }

    @JsonProperty("PermPercentageLoading")
    public Integer getPermPercentageLoading() {
        return permPercentageLoading;
    }

    @JsonProperty("PermPercentageLoading")
    public void setPermPercentageLoading(Integer permPercentageLoading) {
        this.permPercentageLoading = permPercentageLoading;
    }

    public Participant withPermPercentageLoading(Integer permPercentageLoading) {
        this.permPercentageLoading = permPercentageLoading;
        return this;
    }

    @JsonProperty("OccupRating")
    public OccupRating getOccupRating() {
        return occupRating;
    }

    @JsonProperty("OccupRating")
    public void setOccupRating(OccupRating occupRating) {
        this.occupRating = occupRating;
    }

    public Participant withOccupRating(OccupRating occupRating) {
        this.occupRating = occupRating;
        return this;
    }

    @JsonProperty("PermFlatExtraAmt")
    public Integer getPermFlatExtraAmt() {
        return permFlatExtraAmt;
    }

    @JsonProperty("PermFlatExtraAmt")
    public void setPermFlatExtraAmt(Integer permFlatExtraAmt) {
        this.permFlatExtraAmt = permFlatExtraAmt;
    }

    public Participant withPermFlatExtraAmt(Integer permFlatExtraAmt) {
        this.permFlatExtraAmt = permFlatExtraAmt;
        return this;
    }

    @JsonProperty("PermFlatExtraEndDate")
    public String getPermFlatExtraEndDate() {
        return permFlatExtraEndDate;
    }

    @JsonProperty("PermFlatExtraEndDate")
    public void setPermFlatExtraEndDate(String permFlatExtraEndDate) {
        this.permFlatExtraEndDate = permFlatExtraEndDate;
    }

    public Participant withPermFlatExtraEndDate(String permFlatExtraEndDate) {
        this.permFlatExtraEndDate = permFlatExtraEndDate;
        return this;
    }

    @JsonProperty("PermTableRating")
    public PermTableRating getPermTableRating() {
        return permTableRating;
    }

    @JsonProperty("PermTableRating")
    public void setPermTableRating(PermTableRating permTableRating) {
        this.permTableRating = permTableRating;
    }

    public Participant withPermTableRating(PermTableRating permTableRating) {
        this.permTableRating = permTableRating;
        return this;
    }

    @JsonProperty("PermTableRatingEndDate")
    public String getPermTableRatingEndDate() {
        return permTableRatingEndDate;
    }

    @JsonProperty("PermTableRatingEndDate")
    public void setPermTableRatingEndDate(String permTableRatingEndDate) {
        this.permTableRatingEndDate = permTableRatingEndDate;
    }

    public Participant withPermTableRatingEndDate(String permTableRatingEndDate) {
        this.permTableRatingEndDate = permTableRatingEndDate;
        return this;
    }

    @JsonProperty("RatingCommissionRule")
    public RatingCommissionRule getRatingCommissionRule() {
        return ratingCommissionRule;
    }

    @JsonProperty("RatingCommissionRule")
    public void setRatingCommissionRule(RatingCommissionRule ratingCommissionRule) {
        this.ratingCommissionRule = ratingCommissionRule;
    }

    public Participant withRatingCommissionRule(RatingCommissionRule ratingCommissionRule) {
        this.ratingCommissionRule = ratingCommissionRule;
        return this;
    }

    @JsonProperty("RatingOverriddenInd")
    public RatingOverriddenInd getRatingOverriddenInd() {
        return ratingOverriddenInd;
    }

    @JsonProperty("RatingOverriddenInd")
    public void setRatingOverriddenInd(RatingOverriddenInd ratingOverriddenInd) {
        this.ratingOverriddenInd = ratingOverriddenInd;
    }

    public Participant withRatingOverriddenInd(RatingOverriddenInd ratingOverriddenInd) {
        this.ratingOverriddenInd = ratingOverriddenInd;
        return this;
    }

    @JsonProperty("RatingReason")
    public String getRatingReason() {
        return ratingReason;
    }

    @JsonProperty("RatingReason")
    public void setRatingReason(String ratingReason) {
        this.ratingReason = ratingReason;
    }

    public Participant withRatingReason(String ratingReason) {
        this.ratingReason = ratingReason;
        return this;
    }

    @JsonProperty("ReconsiderationDate")
    public String getReconsiderationDate() {
        return reconsiderationDate;
    }

    @JsonProperty("ReconsiderationDate")
    public void setReconsiderationDate(String reconsiderationDate) {
        this.reconsiderationDate = reconsiderationDate;
    }

    public Participant withReconsiderationDate(String reconsiderationDate) {
        this.reconsiderationDate = reconsiderationDate;
        return this;
    }

    @JsonProperty("TempFlatEndDate")
    public String getTempFlatEndDate() {
        return tempFlatEndDate;
    }

    @JsonProperty("TempFlatEndDate")
    public void setTempFlatEndDate(String tempFlatEndDate) {
        this.tempFlatEndDate = tempFlatEndDate;
    }

    public Participant withTempFlatEndDate(String tempFlatEndDate) {
        this.tempFlatEndDate = tempFlatEndDate;
        return this;
    }

    @JsonProperty("TempFlatExtraAmt")
    public Integer getTempFlatExtraAmt() {
        return tempFlatExtraAmt;
    }

    @JsonProperty("TempFlatExtraAmt")
    public void setTempFlatExtraAmt(Integer tempFlatExtraAmt) {
        this.tempFlatExtraAmt = tempFlatExtraAmt;
    }

    public Participant withTempFlatExtraAmt(Integer tempFlatExtraAmt) {
        this.tempFlatExtraAmt = tempFlatExtraAmt;
        return this;
    }

    @JsonProperty("TempTableRating")
    public TempTableRating getTempTableRating() {
        return tempTableRating;
    }

    @JsonProperty("TempTableRating")
    public void setTempTableRating(TempTableRating tempTableRating) {
        this.tempTableRating = tempTableRating;
    }

    public Participant withTempTableRating(TempTableRating tempTableRating) {
        this.tempTableRating = tempTableRating;
        return this;
    }

    @JsonProperty("TempTableRatingStartDate")
    public String getTempTableRatingStartDate() {
        return tempTableRatingStartDate;
    }

    @JsonProperty("TempTableRatingStartDate")
    public void setTempTableRatingStartDate(String tempTableRatingStartDate) {
        this.tempTableRatingStartDate = tempTableRatingStartDate;
    }

    public Participant withTempTableRatingStartDate(String tempTableRatingStartDate) {
        this.tempTableRatingStartDate = tempTableRatingStartDate;
        return this;
    }

    @JsonProperty("TempTableRatingEndDate")
    public String getTempTableRatingEndDate() {
        return tempTableRatingEndDate;
    }

    @JsonProperty("TempTableRatingEndDate")
    public void setTempTableRatingEndDate(String tempTableRatingEndDate) {
        this.tempTableRatingEndDate = tempTableRatingEndDate;
    }

    public Participant withTempTableRatingEndDate(String tempTableRatingEndDate) {
        this.tempTableRatingEndDate = tempTableRatingEndDate;
        return this;
    }

    @JsonProperty("IssuedAsAppliedInd")
    public IssuedAsAppliedInd getIssuedAsAppliedInd() {
        return issuedAsAppliedInd;
    }

    @JsonProperty("IssuedAsAppliedInd")
    public void setIssuedAsAppliedInd(IssuedAsAppliedInd issuedAsAppliedInd) {
        this.issuedAsAppliedInd = issuedAsAppliedInd;
    }

    public Participant withIssuedAsAppliedInd(IssuedAsAppliedInd issuedAsAppliedInd) {
        this.issuedAsAppliedInd = issuedAsAppliedInd;
        return this;
    }

    @JsonProperty("PrivacyLastCommunicationDate")
    public String getPrivacyLastCommunicationDate() {
        return privacyLastCommunicationDate;
    }

    @JsonProperty("PrivacyLastCommunicationDate")
    public void setPrivacyLastCommunicationDate(String privacyLastCommunicationDate) {
        this.privacyLastCommunicationDate = privacyLastCommunicationDate;
    }

    public Participant withPrivacyLastCommunicationDate(String privacyLastCommunicationDate) {
        this.privacyLastCommunicationDate = privacyLastCommunicationDate;
        return this;
    }

    @JsonProperty("BeneficiaryIncomeOption")
    public BeneficiaryIncomeOption getBeneficiaryIncomeOption() {
        return beneficiaryIncomeOption;
    }

    @JsonProperty("BeneficiaryIncomeOption")
    public void setBeneficiaryIncomeOption(BeneficiaryIncomeOption beneficiaryIncomeOption) {
        this.beneficiaryIncomeOption = beneficiaryIncomeOption;
    }

    public Participant withBeneficiaryIncomeOption(BeneficiaryIncomeOption beneficiaryIncomeOption) {
        this.beneficiaryIncomeOption = beneficiaryIncomeOption;
        return this;
    }

    @JsonProperty("TempRatingType")
    public TempRatingType getTempRatingType() {
        return tempRatingType;
    }

    @JsonProperty("TempRatingType")
    public void setTempRatingType(TempRatingType tempRatingType) {
        this.tempRatingType = tempRatingType;
    }

    public Participant withTempRatingType(TempRatingType tempRatingType) {
        this.tempRatingType = tempRatingType;
        return this;
    }

    @JsonProperty("ProceedsHoldDuration")
    public Integer getProceedsHoldDuration() {
        return proceedsHoldDuration;
    }

    @JsonProperty("ProceedsHoldDuration")
    public void setProceedsHoldDuration(Integer proceedsHoldDuration) {
        this.proceedsHoldDuration = proceedsHoldDuration;
    }

    public Participant withProceedsHoldDuration(Integer proceedsHoldDuration) {
        this.proceedsHoldDuration = proceedsHoldDuration;
        return this;
    }

    @JsonProperty("ProceedsHoldDurUnitMeasure")
    public ProceedsHoldDurUnitMeasure getProceedsHoldDurUnitMeasure() {
        return proceedsHoldDurUnitMeasure;
    }

    @JsonProperty("ProceedsHoldDurUnitMeasure")
    public void setProceedsHoldDurUnitMeasure(ProceedsHoldDurUnitMeasure proceedsHoldDurUnitMeasure) {
        this.proceedsHoldDurUnitMeasure = proceedsHoldDurUnitMeasure;
    }

    public Participant withProceedsHoldDurUnitMeasure(ProceedsHoldDurUnitMeasure proceedsHoldDurUnitMeasure) {
        this.proceedsHoldDurUnitMeasure = proceedsHoldDurUnitMeasure;
        return this;
    }

    @JsonProperty("LastRatingDate")
    public String getLastRatingDate() {
        return lastRatingDate;
    }

    @JsonProperty("LastRatingDate")
    public void setLastRatingDate(String lastRatingDate) {
        this.lastRatingDate = lastRatingDate;
    }

    public Participant withLastRatingDate(String lastRatingDate) {
        this.lastRatingDate = lastRatingDate;
        return this;
    }

    @JsonProperty("BeneficiaryClaimPeriod")
    public Integer getBeneficiaryClaimPeriod() {
        return beneficiaryClaimPeriod;
    }

    @JsonProperty("BeneficiaryClaimPeriod")
    public void setBeneficiaryClaimPeriod(Integer beneficiaryClaimPeriod) {
        this.beneficiaryClaimPeriod = beneficiaryClaimPeriod;
    }

    public Participant withBeneficiaryClaimPeriod(Integer beneficiaryClaimPeriod) {
        this.beneficiaryClaimPeriod = beneficiaryClaimPeriod;
        return this;
    }

    @JsonProperty("BeneClaimPeriodMeasureUnit")
    public BeneClaimPeriodMeasureUnit getBeneClaimPeriodMeasureUnit() {
        return beneClaimPeriodMeasureUnit;
    }

    @JsonProperty("BeneClaimPeriodMeasureUnit")
    public void setBeneClaimPeriodMeasureUnit(BeneClaimPeriodMeasureUnit beneClaimPeriodMeasureUnit) {
        this.beneClaimPeriodMeasureUnit = beneClaimPeriodMeasureUnit;
    }

    public Participant withBeneClaimPeriodMeasureUnit(BeneClaimPeriodMeasureUnit beneClaimPeriodMeasureUnit) {
        this.beneClaimPeriodMeasureUnit = beneClaimPeriodMeasureUnit;
        return this;
    }

    @JsonProperty("EmploymentClass")
    public EmploymentClass getEmploymentClass() {
        return employmentClass;
    }

    @JsonProperty("EmploymentClass")
    public void setEmploymentClass(EmploymentClass employmentClass) {
        this.employmentClass = employmentClass;
    }

    public Participant withEmploymentClass(EmploymentClass employmentClass) {
        this.employmentClass = employmentClass;
        return this;
    }

    @JsonProperty("PermRatingType")
    public PermRatingType getPermRatingType() {
        return permRatingType;
    }

    @JsonProperty("PermRatingType")
    public void setPermRatingType(PermRatingType permRatingType) {
        this.permRatingType = permRatingType;
    }

    public Participant withPermRatingType(PermRatingType permRatingType) {
        this.permRatingType = permRatingType;
        return this;
    }

    @JsonProperty("FaceAmt")
    public Integer getFaceAmt() {
        return faceAmt;
    }

    @JsonProperty("FaceAmt")
    public void setFaceAmt(Integer faceAmt) {
        this.faceAmt = faceAmt;
    }

    public Participant withFaceAmt(Integer faceAmt) {
        this.faceAmt = faceAmt;
        return this;
    }

    @JsonProperty("ModalGrossPermFlatExtraAllowanceAmt")
    public Integer getModalGrossPermFlatExtraAllowanceAmt() {
        return modalGrossPermFlatExtraAllowanceAmt;
    }

    @JsonProperty("ModalGrossPermFlatExtraAllowanceAmt")
    public void setModalGrossPermFlatExtraAllowanceAmt(Integer modalGrossPermFlatExtraAllowanceAmt) {
        this.modalGrossPermFlatExtraAllowanceAmt = modalGrossPermFlatExtraAllowanceAmt;
    }

    public Participant withModalGrossPermFlatExtraAllowanceAmt(Integer modalGrossPermFlatExtraAllowanceAmt) {
        this.modalGrossPermFlatExtraAllowanceAmt = modalGrossPermFlatExtraAllowanceAmt;
        return this;
    }

    @JsonProperty("OriginalIssueAge")
    public Integer getOriginalIssueAge() {
        return originalIssueAge;
    }

    @JsonProperty("OriginalIssueAge")
    public void setOriginalIssueAge(Integer originalIssueAge) {
        this.originalIssueAge = originalIssueAge;
    }

    public Participant withOriginalIssueAge(Integer originalIssueAge) {
        this.originalIssueAge = originalIssueAge;
        return this;
    }

    @JsonProperty("PermTableRatingAlphaCode")
    public String getPermTableRatingAlphaCode() {
        return permTableRatingAlphaCode;
    }

    @JsonProperty("PermTableRatingAlphaCode")
    public void setPermTableRatingAlphaCode(String permTableRatingAlphaCode) {
        this.permTableRatingAlphaCode = permTableRatingAlphaCode;
    }

    public Participant withPermTableRatingAlphaCode(String permTableRatingAlphaCode) {
        this.permTableRatingAlphaCode = permTableRatingAlphaCode;
        return this;
    }

    @JsonProperty("TempTableRatingCode")
    public String getTempTableRatingCode() {
        return tempTableRatingCode;
    }

    @JsonProperty("TempTableRatingCode")
    public void setTempTableRatingCode(String tempTableRatingCode) {
        this.tempTableRatingCode = tempTableRatingCode;
    }

    public Participant withTempTableRatingCode(String tempTableRatingCode) {
        this.tempTableRatingCode = tempTableRatingCode;
        return this;
    }

    @JsonProperty("TermDate")
    public String getTermDate() {
        return termDate;
    }

    @JsonProperty("TermDate")
    public void setTermDate(String termDate) {
        this.termDate = termDate;
    }

    public Participant withTermDate(String termDate) {
        this.termDate = termDate;
        return this;
    }

    @JsonProperty("LivesWithPrimaryInsInd")
    public LivesWithPrimaryInsInd getLivesWithPrimaryInsInd() {
        return livesWithPrimaryInsInd;
    }

    @JsonProperty("LivesWithPrimaryInsInd")
    public void setLivesWithPrimaryInsInd(LivesWithPrimaryInsInd livesWithPrimaryInsInd) {
        this.livesWithPrimaryInsInd = livesWithPrimaryInsInd;
    }

    public Participant withLivesWithPrimaryInsInd(LivesWithPrimaryInsInd livesWithPrimaryInsInd) {
        this.livesWithPrimaryInsInd = livesWithPrimaryInsInd;
        return this;
    }

    @JsonProperty("DependentOnPrimaryInsInd")
    public DependentOnPrimaryInsInd getDependentOnPrimaryInsInd() {
        return dependentOnPrimaryInsInd;
    }

    @JsonProperty("DependentOnPrimaryInsInd")
    public void setDependentOnPrimaryInsInd(DependentOnPrimaryInsInd dependentOnPrimaryInsInd) {
        this.dependentOnPrimaryInsInd = dependentOnPrimaryInsInd;
    }

    public Participant withDependentOnPrimaryInsInd(DependentOnPrimaryInsInd dependentOnPrimaryInsInd) {
        this.dependentOnPrimaryInsInd = dependentOnPrimaryInsInd;
        return this;
    }

    @JsonProperty("TempFlatStartDate")
    public String getTempFlatStartDate() {
        return tempFlatStartDate;
    }

    @JsonProperty("TempFlatStartDate")
    public void setTempFlatStartDate(String tempFlatStartDate) {
        this.tempFlatStartDate = tempFlatStartDate;
    }

    public Participant withTempFlatStartDate(String tempFlatStartDate) {
        this.tempFlatStartDate = tempFlatStartDate;
        return this;
    }

    @JsonProperty("PermRatingAmtPerThou")
    public Integer getPermRatingAmtPerThou() {
        return permRatingAmtPerThou;
    }

    @JsonProperty("PermRatingAmtPerThou")
    public void setPermRatingAmtPerThou(Integer permRatingAmtPerThou) {
        this.permRatingAmtPerThou = permRatingAmtPerThou;
    }

    public Participant withPermRatingAmtPerThou(Integer permRatingAmtPerThou) {
        this.permRatingAmtPerThou = permRatingAmtPerThou;
        return this;
    }

    @JsonProperty("TempRatingAmtPerThou")
    public Integer getTempRatingAmtPerThou() {
        return tempRatingAmtPerThou;
    }

    @JsonProperty("TempRatingAmtPerThou")
    public void setTempRatingAmtPerThou(Integer tempRatingAmtPerThou) {
        this.tempRatingAmtPerThou = tempRatingAmtPerThou;
    }

    public Participant withTempRatingAmtPerThou(Integer tempRatingAmtPerThou) {
        this.tempRatingAmtPerThou = tempRatingAmtPerThou;
        return this;
    }

    @JsonProperty("TempFlatExtraOverrideEndDate")
    public String getTempFlatExtraOverrideEndDate() {
        return tempFlatExtraOverrideEndDate;
    }

    @JsonProperty("TempFlatExtraOverrideEndDate")
    public void setTempFlatExtraOverrideEndDate(String tempFlatExtraOverrideEndDate) {
        this.tempFlatExtraOverrideEndDate = tempFlatExtraOverrideEndDate;
    }

    public Participant withTempFlatExtraOverrideEndDate(String tempFlatExtraOverrideEndDate) {
        this.tempFlatExtraOverrideEndDate = tempFlatExtraOverrideEndDate;
        return this;
    }

    @JsonProperty("TempFlatExtraOverrideEffDate")
    public String getTempFlatExtraOverrideEffDate() {
        return tempFlatExtraOverrideEffDate;
    }

    @JsonProperty("TempFlatExtraOverrideEffDate")
    public void setTempFlatExtraOverrideEffDate(String tempFlatExtraOverrideEffDate) {
        this.tempFlatExtraOverrideEffDate = tempFlatExtraOverrideEffDate;
    }

    public Participant withTempFlatExtraOverrideEffDate(String tempFlatExtraOverrideEffDate) {
        this.tempFlatExtraOverrideEffDate = tempFlatExtraOverrideEffDate;
        return this;
    }

    @JsonProperty("TemporaryRoleInd")
    public TemporaryRoleInd getTemporaryRoleInd() {
        return temporaryRoleInd;
    }

    @JsonProperty("TemporaryRoleInd")
    public void setTemporaryRoleInd(TemporaryRoleInd temporaryRoleInd) {
        this.temporaryRoleInd = temporaryRoleInd;
    }

    public Participant withTemporaryRoleInd(TemporaryRoleInd temporaryRoleInd) {
        this.temporaryRoleInd = temporaryRoleInd;
        return this;
    }

    @JsonProperty("PreferredBeneficiaryInd")
    public PreferredBeneficiaryInd getPreferredBeneficiaryInd() {
        return preferredBeneficiaryInd;
    }

    @JsonProperty("PreferredBeneficiaryInd")
    public void setPreferredBeneficiaryInd(PreferredBeneficiaryInd preferredBeneficiaryInd) {
        this.preferredBeneficiaryInd = preferredBeneficiaryInd;
    }

    public Participant withPreferredBeneficiaryInd(PreferredBeneficiaryInd preferredBeneficiaryInd) {
        this.preferredBeneficiaryInd = preferredBeneficiaryInd;
        return this;
    }

    @JsonProperty("ModalPermRatingAmt")
    public Integer getModalPermRatingAmt() {
        return modalPermRatingAmt;
    }

    @JsonProperty("ModalPermRatingAmt")
    public void setModalPermRatingAmt(Integer modalPermRatingAmt) {
        this.modalPermRatingAmt = modalPermRatingAmt;
    }

    public Participant withModalPermRatingAmt(Integer modalPermRatingAmt) {
        this.modalPermRatingAmt = modalPermRatingAmt;
        return this;
    }

    @JsonProperty("ModalTempRatingAmt")
    public Integer getModalTempRatingAmt() {
        return modalTempRatingAmt;
    }

    @JsonProperty("ModalTempRatingAmt")
    public void setModalTempRatingAmt(Integer modalTempRatingAmt) {
        this.modalTempRatingAmt = modalTempRatingAmt;
    }

    public Participant withModalTempRatingAmt(Integer modalTempRatingAmt) {
        this.modalTempRatingAmt = modalTempRatingAmt;
        return this;
    }

    @JsonProperty("SubstandardRating")
    public List<Object> getSubstandardRating() {
        return substandardRating;
    }

    @JsonProperty("SubstandardRating")
    public void setSubstandardRating(List<Object> substandardRating) {
        this.substandardRating = substandardRating;
    }

    public Participant withSubstandardRating(List<Object> substandardRating) {
        this.substandardRating = substandardRating;
        return this;
    }

    @JsonProperty("AssocParticipantObjectInfo")
    public List<Object> getAssocParticipantObjectInfo() {
        return assocParticipantObjectInfo;
    }

    @JsonProperty("AssocParticipantObjectInfo")
    public void setAssocParticipantObjectInfo(List<Object> assocParticipantObjectInfo) {
        this.assocParticipantObjectInfo = assocParticipantObjectInfo;
    }

    public Participant withAssocParticipantObjectInfo(List<Object> assocParticipantObjectInfo) {
        this.assocParticipantObjectInfo = assocParticipantObjectInfo;
        return this;
    }

    @JsonProperty("UnderwritingResult")
    public List<Object> getUnderwritingResult() {
        return underwritingResult;
    }

    @JsonProperty("UnderwritingResult")
    public void setUnderwritingResult(List<Object> underwritingResult) {
        this.underwritingResult = underwritingResult;
    }

    public Participant withUnderwritingResult(List<Object> underwritingResult) {
        this.underwritingResult = underwritingResult;
        return this;
    }

    @JsonProperty("DeliveryInfo")
    public List<Object> getDeliveryInfo() {
        return deliveryInfo;
    }

    @JsonProperty("DeliveryInfo")
    public void setDeliveryInfo(List<Object> deliveryInfo) {
        this.deliveryInfo = deliveryInfo;
    }

    public Participant withDeliveryInfo(List<Object> deliveryInfo) {
        this.deliveryInfo = deliveryInfo;
        return this;
    }

    @JsonProperty("BeneficiaryIncomeOptionInfo")
    public List<Object> getBeneficiaryIncomeOptionInfo() {
        return beneficiaryIncomeOptionInfo;
    }

    @JsonProperty("BeneficiaryIncomeOptionInfo")
    public void setBeneficiaryIncomeOptionInfo(List<Object> beneficiaryIncomeOptionInfo) {
        this.beneficiaryIncomeOptionInfo = beneficiaryIncomeOptionInfo;
    }

    public Participant withBeneficiaryIncomeOptionInfo(List<Object> beneficiaryIncomeOptionInfo) {
        this.beneficiaryIncomeOptionInfo = beneficiaryIncomeOptionInfo;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Participant withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Participant withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("PartyID")
    public String getPartyID() {
        return partyID;
    }

    @JsonProperty("PartyID")
    public void setPartyID(String partyID) {
        this.partyID = partyID;
    }

    public Participant withPartyID(String partyID) {
        this.partyID = partyID;
        return this;
    }

    @JsonProperty("MailingAddressID")
    public String getMailingAddressID() {
        return mailingAddressID;
    }

    @JsonProperty("MailingAddressID")
    public void setMailingAddressID(String mailingAddressID) {
        this.mailingAddressID = mailingAddressID;
    }

    public Participant withMailingAddressID(String mailingAddressID) {
        this.mailingAddressID = mailingAddressID;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public Participant withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Participant withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Participant.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("participantKey");
        sb.append('=');
        sb.append(((this.participantKey == null)?"<null>":this.participantKey));
        sb.append(',');
        sb.append("participantSysKey");
        sb.append('=');
        sb.append(((this.participantSysKey == null)?"<null>":this.participantSysKey));
        sb.append(',');
        sb.append("participantName");
        sb.append('=');
        sb.append(((this.participantName == null)?"<null>":this.participantName));
        sb.append(',');
        sb.append("participantRoleCode");
        sb.append('=');
        sb.append(((this.participantRoleCode == null)?"<null>":this.participantRoleCode));
        sb.append(',');
        sb.append("participationPct");
        sb.append('=');
        sb.append(((this.participationPct == null)?"<null>":this.participationPct));
        sb.append(',');
        sb.append("issueAge");
        sb.append('=');
        sb.append(((this.issueAge == null)?"<null>":this.issueAge));
        sb.append(',');
        sb.append("closedAge");
        sb.append('=');
        sb.append(((this.closedAge == null)?"<null>":this.closedAge));
        sb.append(',');
        sb.append("issueGender");
        sb.append('=');
        sb.append(((this.issueGender == null)?"<null>":this.issueGender));
        sb.append(',');
        sb.append("residenceNationAtIssue");
        sb.append('=');
        sb.append(((this.residenceNationAtIssue == null)?"<null>":this.residenceNationAtIssue));
        sb.append(',');
        sb.append("residenceJurisdictionAtIssue");
        sb.append('=');
        sb.append(((this.residenceJurisdictionAtIssue == null)?"<null>":this.residenceJurisdictionAtIssue));
        sb.append(',');
        sb.append("smokerStat");
        sb.append('=');
        sb.append(((this.smokerStat == null)?"<null>":this.smokerStat));
        sb.append(',');
        sb.append("tobaccoPremiumBasis");
        sb.append('=');
        sb.append(((this.tobaccoPremiumBasis == null)?"<null>":this.tobaccoPremiumBasis));
        sb.append(',');
        sb.append("occupation");
        sb.append('=');
        sb.append(((this.occupation == null)?"<null>":this.occupation));
        sb.append(',');
        sb.append("occupClass");
        sb.append('=');
        sb.append(((this.occupClass == null)?"<null>":this.occupClass));
        sb.append(',');
        sb.append("underwritingClass");
        sb.append('=');
        sb.append(((this.underwritingClass == null)?"<null>":this.underwritingClass));
        sb.append(',');
        sb.append("underwritingSubClass");
        sb.append('=');
        sb.append(((this.underwritingSubClass == null)?"<null>":this.underwritingSubClass));
        sb.append(',');
        sb.append("flatExtraPremBasis");
        sb.append('=');
        sb.append(((this.flatExtraPremBasis == null)?"<null>":this.flatExtraPremBasis));
        sb.append(',');
        sb.append("modalGrossFlatExtraPremAmt");
        sb.append('=');
        sb.append(((this.modalGrossFlatExtraPremAmt == null)?"<null>":this.modalGrossFlatExtraPremAmt));
        sb.append(',');
        sb.append("modalGrossFlatExtraAllowanceAmt");
        sb.append('=');
        sb.append(((this.modalGrossFlatExtraAllowanceAmt == null)?"<null>":this.modalGrossFlatExtraAllowanceAmt));
        sb.append(',');
        sb.append("beneficiarySeqNum");
        sb.append('=');
        sb.append(((this.beneficiarySeqNum == null)?"<null>":this.beneficiarySeqNum));
        sb.append(',');
        sb.append("beneficiaryPercentDistribution");
        sb.append('=');
        sb.append(((this.beneficiaryPercentDistribution == null)?"<null>":this.beneficiaryPercentDistribution));
        sb.append(',');
        sb.append("beneficiaryAmountDistribution");
        sb.append('=');
        sb.append(((this.beneficiaryAmountDistribution == null)?"<null>":this.beneficiaryAmountDistribution));
        sb.append(',');
        sb.append("irrevokableInd");
        sb.append('=');
        sb.append(((this.irrevokableInd == null)?"<null>":this.irrevokableInd));
        sb.append(',');
        sb.append("beneficiaryShareMethod");
        sb.append('=');
        sb.append(((this.beneficiaryShareMethod == null)?"<null>":this.beneficiaryShareMethod));
        sb.append(',');
        sb.append("beneficiaryCommonDisasterPeriod");
        sb.append('=');
        sb.append(((this.beneficiaryCommonDisasterPeriod == null)?"<null>":this.beneficiaryCommonDisasterPeriod));
        sb.append(',');
        sb.append("distributionOption");
        sb.append('=');
        sb.append(((this.distributionOption == null)?"<null>":this.distributionOption));
        sb.append(',');
        sb.append("beneficiaryDesignation");
        sb.append('=');
        sb.append(((this.beneficiaryDesignation == null)?"<null>":this.beneficiaryDesignation));
        sb.append(',');
        sb.append("beneficiaryRoleCode");
        sb.append('=');
        sb.append(((this.beneficiaryRoleCode == null)?"<null>":this.beneficiaryRoleCode));
        sb.append(',');
        sb.append("beneficiaryRoleCodeDesc");
        sb.append('=');
        sb.append(((this.beneficiaryRoleCodeDesc == null)?"<null>":this.beneficiaryRoleCodeDesc));
        sb.append(',');
        sb.append("aSCOCode");
        sb.append('=');
        sb.append(((this.aSCOCode == null)?"<null>":this.aSCOCode));
        sb.append(',');
        sb.append("className");
        sb.append('=');
        sb.append(((this.className == null)?"<null>":this.className));
        sb.append(',');
        sb.append("commissionLink");
        sb.append('=');
        sb.append(((this.commissionLink == null)?"<null>":this.commissionLink));
        sb.append(',');
        sb.append("modalGrossTempFlatAllowAmt");
        sb.append('=');
        sb.append(((this.modalGrossTempFlatAllowAmt == null)?"<null>":this.modalGrossTempFlatAllowAmt));
        sb.append(',');
        sb.append("effDate");
        sb.append('=');
        sb.append(((this.effDate == null)?"<null>":this.effDate));
        sb.append(',');
        sb.append("participantStatus");
        sb.append('=');
        sb.append(((this.participantStatus == null)?"<null>":this.participantStatus));
        sb.append(',');
        sb.append("issueAgeSource");
        sb.append('=');
        sb.append(((this.issueAgeSource == null)?"<null>":this.issueAgeSource));
        sb.append(',');
        sb.append("ageSetBackQuantity");
        sb.append('=');
        sb.append(((this.ageSetBackQuantity == null)?"<null>":this.ageSetBackQuantity));
        sb.append(',');
        sb.append("ageCalculationType");
        sb.append('=');
        sb.append(((this.ageCalculationType == null)?"<null>":this.ageCalculationType));
        sb.append(',');
        sb.append("insuredSeqNum");
        sb.append('=');
        sb.append(((this.insuredSeqNum == null)?"<null>":this.insuredSeqNum));
        sb.append(',');
        sb.append("tempFlatExtraDuration");
        sb.append('=');
        sb.append(((this.tempFlatExtraDuration == null)?"<null>":this.tempFlatExtraDuration));
        sb.append(',');
        sb.append("tempPercentageLoading");
        sb.append('=');
        sb.append(((this.tempPercentageLoading == null)?"<null>":this.tempPercentageLoading));
        sb.append(',');
        sb.append("permPercentageLoading");
        sb.append('=');
        sb.append(((this.permPercentageLoading == null)?"<null>":this.permPercentageLoading));
        sb.append(',');
        sb.append("occupRating");
        sb.append('=');
        sb.append(((this.occupRating == null)?"<null>":this.occupRating));
        sb.append(',');
        sb.append("permFlatExtraAmt");
        sb.append('=');
        sb.append(((this.permFlatExtraAmt == null)?"<null>":this.permFlatExtraAmt));
        sb.append(',');
        sb.append("permFlatExtraEndDate");
        sb.append('=');
        sb.append(((this.permFlatExtraEndDate == null)?"<null>":this.permFlatExtraEndDate));
        sb.append(',');
        sb.append("permTableRating");
        sb.append('=');
        sb.append(((this.permTableRating == null)?"<null>":this.permTableRating));
        sb.append(',');
        sb.append("permTableRatingEndDate");
        sb.append('=');
        sb.append(((this.permTableRatingEndDate == null)?"<null>":this.permTableRatingEndDate));
        sb.append(',');
        sb.append("ratingCommissionRule");
        sb.append('=');
        sb.append(((this.ratingCommissionRule == null)?"<null>":this.ratingCommissionRule));
        sb.append(',');
        sb.append("ratingOverriddenInd");
        sb.append('=');
        sb.append(((this.ratingOverriddenInd == null)?"<null>":this.ratingOverriddenInd));
        sb.append(',');
        sb.append("ratingReason");
        sb.append('=');
        sb.append(((this.ratingReason == null)?"<null>":this.ratingReason));
        sb.append(',');
        sb.append("reconsiderationDate");
        sb.append('=');
        sb.append(((this.reconsiderationDate == null)?"<null>":this.reconsiderationDate));
        sb.append(',');
        sb.append("tempFlatEndDate");
        sb.append('=');
        sb.append(((this.tempFlatEndDate == null)?"<null>":this.tempFlatEndDate));
        sb.append(',');
        sb.append("tempFlatExtraAmt");
        sb.append('=');
        sb.append(((this.tempFlatExtraAmt == null)?"<null>":this.tempFlatExtraAmt));
        sb.append(',');
        sb.append("tempTableRating");
        sb.append('=');
        sb.append(((this.tempTableRating == null)?"<null>":this.tempTableRating));
        sb.append(',');
        sb.append("tempTableRatingStartDate");
        sb.append('=');
        sb.append(((this.tempTableRatingStartDate == null)?"<null>":this.tempTableRatingStartDate));
        sb.append(',');
        sb.append("tempTableRatingEndDate");
        sb.append('=');
        sb.append(((this.tempTableRatingEndDate == null)?"<null>":this.tempTableRatingEndDate));
        sb.append(',');
        sb.append("issuedAsAppliedInd");
        sb.append('=');
        sb.append(((this.issuedAsAppliedInd == null)?"<null>":this.issuedAsAppliedInd));
        sb.append(',');
        sb.append("privacyLastCommunicationDate");
        sb.append('=');
        sb.append(((this.privacyLastCommunicationDate == null)?"<null>":this.privacyLastCommunicationDate));
        sb.append(',');
        sb.append("beneficiaryIncomeOption");
        sb.append('=');
        sb.append(((this.beneficiaryIncomeOption == null)?"<null>":this.beneficiaryIncomeOption));
        sb.append(',');
        sb.append("tempRatingType");
        sb.append('=');
        sb.append(((this.tempRatingType == null)?"<null>":this.tempRatingType));
        sb.append(',');
        sb.append("proceedsHoldDuration");
        sb.append('=');
        sb.append(((this.proceedsHoldDuration == null)?"<null>":this.proceedsHoldDuration));
        sb.append(',');
        sb.append("proceedsHoldDurUnitMeasure");
        sb.append('=');
        sb.append(((this.proceedsHoldDurUnitMeasure == null)?"<null>":this.proceedsHoldDurUnitMeasure));
        sb.append(',');
        sb.append("lastRatingDate");
        sb.append('=');
        sb.append(((this.lastRatingDate == null)?"<null>":this.lastRatingDate));
        sb.append(',');
        sb.append("beneficiaryClaimPeriod");
        sb.append('=');
        sb.append(((this.beneficiaryClaimPeriod == null)?"<null>":this.beneficiaryClaimPeriod));
        sb.append(',');
        sb.append("beneClaimPeriodMeasureUnit");
        sb.append('=');
        sb.append(((this.beneClaimPeriodMeasureUnit == null)?"<null>":this.beneClaimPeriodMeasureUnit));
        sb.append(',');
        sb.append("employmentClass");
        sb.append('=');
        sb.append(((this.employmentClass == null)?"<null>":this.employmentClass));
        sb.append(',');
        sb.append("permRatingType");
        sb.append('=');
        sb.append(((this.permRatingType == null)?"<null>":this.permRatingType));
        sb.append(',');
        sb.append("faceAmt");
        sb.append('=');
        sb.append(((this.faceAmt == null)?"<null>":this.faceAmt));
        sb.append(',');
        sb.append("modalGrossPermFlatExtraAllowanceAmt");
        sb.append('=');
        sb.append(((this.modalGrossPermFlatExtraAllowanceAmt == null)?"<null>":this.modalGrossPermFlatExtraAllowanceAmt));
        sb.append(',');
        sb.append("originalIssueAge");
        sb.append('=');
        sb.append(((this.originalIssueAge == null)?"<null>":this.originalIssueAge));
        sb.append(',');
        sb.append("permTableRatingAlphaCode");
        sb.append('=');
        sb.append(((this.permTableRatingAlphaCode == null)?"<null>":this.permTableRatingAlphaCode));
        sb.append(',');
        sb.append("tempTableRatingCode");
        sb.append('=');
        sb.append(((this.tempTableRatingCode == null)?"<null>":this.tempTableRatingCode));
        sb.append(',');
        sb.append("termDate");
        sb.append('=');
        sb.append(((this.termDate == null)?"<null>":this.termDate));
        sb.append(',');
        sb.append("livesWithPrimaryInsInd");
        sb.append('=');
        sb.append(((this.livesWithPrimaryInsInd == null)?"<null>":this.livesWithPrimaryInsInd));
        sb.append(',');
        sb.append("dependentOnPrimaryInsInd");
        sb.append('=');
        sb.append(((this.dependentOnPrimaryInsInd == null)?"<null>":this.dependentOnPrimaryInsInd));
        sb.append(',');
        sb.append("tempFlatStartDate");
        sb.append('=');
        sb.append(((this.tempFlatStartDate == null)?"<null>":this.tempFlatStartDate));
        sb.append(',');
        sb.append("permRatingAmtPerThou");
        sb.append('=');
        sb.append(((this.permRatingAmtPerThou == null)?"<null>":this.permRatingAmtPerThou));
        sb.append(',');
        sb.append("tempRatingAmtPerThou");
        sb.append('=');
        sb.append(((this.tempRatingAmtPerThou == null)?"<null>":this.tempRatingAmtPerThou));
        sb.append(',');
        sb.append("tempFlatExtraOverrideEndDate");
        sb.append('=');
        sb.append(((this.tempFlatExtraOverrideEndDate == null)?"<null>":this.tempFlatExtraOverrideEndDate));
        sb.append(',');
        sb.append("tempFlatExtraOverrideEffDate");
        sb.append('=');
        sb.append(((this.tempFlatExtraOverrideEffDate == null)?"<null>":this.tempFlatExtraOverrideEffDate));
        sb.append(',');
        sb.append("temporaryRoleInd");
        sb.append('=');
        sb.append(((this.temporaryRoleInd == null)?"<null>":this.temporaryRoleInd));
        sb.append(',');
        sb.append("preferredBeneficiaryInd");
        sb.append('=');
        sb.append(((this.preferredBeneficiaryInd == null)?"<null>":this.preferredBeneficiaryInd));
        sb.append(',');
        sb.append("modalPermRatingAmt");
        sb.append('=');
        sb.append(((this.modalPermRatingAmt == null)?"<null>":this.modalPermRatingAmt));
        sb.append(',');
        sb.append("modalTempRatingAmt");
        sb.append('=');
        sb.append(((this.modalTempRatingAmt == null)?"<null>":this.modalTempRatingAmt));
        sb.append(',');
        sb.append("substandardRating");
        sb.append('=');
        sb.append(((this.substandardRating == null)?"<null>":this.substandardRating));
        sb.append(',');
        sb.append("assocParticipantObjectInfo");
        sb.append('=');
        sb.append(((this.assocParticipantObjectInfo == null)?"<null>":this.assocParticipantObjectInfo));
        sb.append(',');
        sb.append("underwritingResult");
        sb.append('=');
        sb.append(((this.underwritingResult == null)?"<null>":this.underwritingResult));
        sb.append(',');
        sb.append("deliveryInfo");
        sb.append('=');
        sb.append(((this.deliveryInfo == null)?"<null>":this.deliveryInfo));
        sb.append(',');
        sb.append("beneficiaryIncomeOptionInfo");
        sb.append('=');
        sb.append(((this.beneficiaryIncomeOptionInfo == null)?"<null>":this.beneficiaryIncomeOptionInfo));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("partyID");
        sb.append('=');
        sb.append(((this.partyID == null)?"<null>":this.partyID));
        sb.append(',');
        sb.append("mailingAddressID");
        sb.append('=');
        sb.append(((this.mailingAddressID == null)?"<null>":this.mailingAddressID));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.occupRating == null)? 0 :this.occupRating.hashCode()));
        result = ((result* 31)+((this.reconsiderationDate == null)? 0 :this.reconsiderationDate.hashCode()));
        result = ((result* 31)+((this.occupation == null)? 0 :this.occupation.hashCode()));
        result = ((result* 31)+((this.modalGrossTempFlatAllowAmt == null)? 0 :this.modalGrossTempFlatAllowAmt.hashCode()));
        result = ((result* 31)+((this.beneficiarySeqNum == null)? 0 :this.beneficiarySeqNum.hashCode()));
        result = ((result* 31)+((this.ageCalculationType == null)? 0 :this.ageCalculationType.hashCode()));
        result = ((result* 31)+((this.tempPercentageLoading == null)? 0 :this.tempPercentageLoading.hashCode()));
        result = ((result* 31)+((this.tempTableRatingCode == null)? 0 :this.tempTableRatingCode.hashCode()));
        result = ((result* 31)+((this.employmentClass == null)? 0 :this.employmentClass.hashCode()));
        result = ((result* 31)+((this.underwritingClass == null)? 0 :this.underwritingClass.hashCode()));
        result = ((result* 31)+((this.ratingOverriddenInd == null)? 0 :this.ratingOverriddenInd.hashCode()));
        result = ((result* 31)+((this.tobaccoPremiumBasis == null)? 0 :this.tobaccoPremiumBasis.hashCode()));
        result = ((result* 31)+((this.modalGrossPermFlatExtraAllowanceAmt == null)? 0 :this.modalGrossPermFlatExtraAllowanceAmt.hashCode()));
        result = ((result* 31)+((this.smokerStat == null)? 0 :this.smokerStat.hashCode()));
        result = ((result* 31)+((this.effDate == null)? 0 :this.effDate.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.permFlatExtraAmt == null)? 0 :this.permFlatExtraAmt.hashCode()));
        result = ((result* 31)+((this.permFlatExtraEndDate == null)? 0 :this.permFlatExtraEndDate.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.modalGrossFlatExtraPremAmt == null)? 0 :this.modalGrossFlatExtraPremAmt.hashCode()));
        result = ((result* 31)+((this.proceedsHoldDurUnitMeasure == null)? 0 :this.proceedsHoldDurUnitMeasure.hashCode()));
        result = ((result* 31)+((this.permTableRating == null)? 0 :this.permTableRating.hashCode()));
        result = ((result* 31)+((this.originalIssueAge == null)? 0 :this.originalIssueAge.hashCode()));
        result = ((result* 31)+((this.substandardRating == null)? 0 :this.substandardRating.hashCode()));
        result = ((result* 31)+((this.issuedAsAppliedInd == null)? 0 :this.issuedAsAppliedInd.hashCode()));
        result = ((result* 31)+((this.assocParticipantObjectInfo == null)? 0 :this.assocParticipantObjectInfo.hashCode()));
        result = ((result* 31)+((this.distributionOption == null)? 0 :this.distributionOption.hashCode()));
        result = ((result* 31)+((this.commissionLink == null)? 0 :this.commissionLink.hashCode()));
        result = ((result* 31)+((this.permTableRatingEndDate == null)? 0 :this.permTableRatingEndDate.hashCode()));
        result = ((result* 31)+((this.proceedsHoldDuration == null)? 0 :this.proceedsHoldDuration.hashCode()));
        result = ((result* 31)+((this.permRatingType == null)? 0 :this.permRatingType.hashCode()));
        result = ((result* 31)+((this.beneficiaryCommonDisasterPeriod == null)? 0 :this.beneficiaryCommonDisasterPeriod.hashCode()));
        result = ((result* 31)+((this.permPercentageLoading == null)? 0 :this.permPercentageLoading.hashCode()));
        result = ((result* 31)+((this.lastRatingDate == null)? 0 :this.lastRatingDate.hashCode()));
        result = ((result* 31)+((this.beneficiaryClaimPeriod == null)? 0 :this.beneficiaryClaimPeriod.hashCode()));
        result = ((result* 31)+((this.tempFlatEndDate == null)? 0 :this.tempFlatEndDate.hashCode()));
        result = ((result* 31)+((this.occupClass == null)? 0 :this.occupClass.hashCode()));
        result = ((result* 31)+((this.insuredSeqNum == null)? 0 :this.insuredSeqNum.hashCode()));
        result = ((result* 31)+((this.residenceNationAtIssue == null)? 0 :this.residenceNationAtIssue.hashCode()));
        result = ((result* 31)+((this.temporaryRoleInd == null)? 0 :this.temporaryRoleInd.hashCode()));
        result = ((result* 31)+((this.closedAge == null)? 0 :this.closedAge.hashCode()));
        result = ((result* 31)+((this.participantRoleCode == null)? 0 :this.participantRoleCode.hashCode()));
        result = ((result* 31)+((this.mailingAddressID == null)? 0 :this.mailingAddressID.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.permTableRatingAlphaCode == null)? 0 :this.permTableRatingAlphaCode.hashCode()));
        result = ((result* 31)+((this.termDate == null)? 0 :this.termDate.hashCode()));
        result = ((result* 31)+((this.partyID == null)? 0 :this.partyID.hashCode()));
        result = ((result* 31)+((this.tempRatingType == null)? 0 :this.tempRatingType.hashCode()));
        result = ((result* 31)+((this.modalPermRatingAmt == null)? 0 :this.modalPermRatingAmt.hashCode()));
        result = ((result* 31)+((this.beneficiaryRoleCodeDesc == null)? 0 :this.beneficiaryRoleCodeDesc.hashCode()));
        result = ((result* 31)+((this.residenceJurisdictionAtIssue == null)? 0 :this.residenceJurisdictionAtIssue.hashCode()));
        result = ((result* 31)+((this.issueAge == null)? 0 :this.issueAge.hashCode()));
        result = ((result* 31)+((this.beneficiaryDesignation == null)? 0 :this.beneficiaryDesignation.hashCode()));
        result = ((result* 31)+((this.privacyLastCommunicationDate == null)? 0 :this.privacyLastCommunicationDate.hashCode()));
        result = ((result* 31)+((this.tempFlatExtraOverrideEndDate == null)? 0 :this.tempFlatExtraOverrideEndDate.hashCode()));
        result = ((result* 31)+((this.issueAgeSource == null)? 0 :this.issueAgeSource.hashCode()));
        result = ((result* 31)+((this.beneficiaryIncomeOptionInfo == null)? 0 :this.beneficiaryIncomeOptionInfo.hashCode()));
        result = ((result* 31)+((this.participantSysKey == null)? 0 :this.participantSysKey.hashCode()));
        result = ((result* 31)+((this.issueGender == null)? 0 :this.issueGender.hashCode()));
        result = ((result* 31)+((this.faceAmt == null)? 0 :this.faceAmt.hashCode()));
        result = ((result* 31)+((this.tempFlatExtraDuration == null)? 0 :this.tempFlatExtraDuration.hashCode()));
        result = ((result* 31)+((this.ratingCommissionRule == null)? 0 :this.ratingCommissionRule.hashCode()));
        result = ((result* 31)+((this.className == null)? 0 :this.className.hashCode()));
        result = ((result* 31)+((this.beneficiaryIncomeOption == null)? 0 :this.beneficiaryIncomeOption.hashCode()));
        result = ((result* 31)+((this.participantKey == null)? 0 :this.participantKey.hashCode()));
        result = ((result* 31)+((this.irrevokableInd == null)? 0 :this.irrevokableInd.hashCode()));
        result = ((result* 31)+((this.aSCOCode == null)? 0 :this.aSCOCode.hashCode()));
        result = ((result* 31)+((this.modalTempRatingAmt == null)? 0 :this.modalTempRatingAmt.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.beneClaimPeriodMeasureUnit == null)? 0 :this.beneClaimPeriodMeasureUnit.hashCode()));
        result = ((result* 31)+((this.modalGrossFlatExtraAllowanceAmt == null)? 0 :this.modalGrossFlatExtraAllowanceAmt.hashCode()));
        result = ((result* 31)+((this.livesWithPrimaryInsInd == null)? 0 :this.livesWithPrimaryInsInd.hashCode()));
        result = ((result* 31)+((this.dependentOnPrimaryInsInd == null)? 0 :this.dependentOnPrimaryInsInd.hashCode()));
        result = ((result* 31)+((this.tempTableRating == null)? 0 :this.tempTableRating.hashCode()));
        result = ((result* 31)+((this.tempRatingAmtPerThou == null)? 0 :this.tempRatingAmtPerThou.hashCode()));
        result = ((result* 31)+((this.participantStatus == null)? 0 :this.participantStatus.hashCode()));
        result = ((result* 31)+((this.tempTableRatingStartDate == null)? 0 :this.tempTableRatingStartDate.hashCode()));
        result = ((result* 31)+((this.underwritingSubClass == null)? 0 :this.underwritingSubClass.hashCode()));
        result = ((result* 31)+((this.deliveryInfo == null)? 0 :this.deliveryInfo.hashCode()));
        result = ((result* 31)+((this.tempTableRatingEndDate == null)? 0 :this.tempTableRatingEndDate.hashCode()));
        result = ((result* 31)+((this.ratingReason == null)? 0 :this.ratingReason.hashCode()));
        result = ((result* 31)+((this.beneficiaryRoleCode == null)? 0 :this.beneficiaryRoleCode.hashCode()));
        result = ((result* 31)+((this.tempFlatStartDate == null)? 0 :this.tempFlatStartDate.hashCode()));
        result = ((result* 31)+((this.preferredBeneficiaryInd == null)? 0 :this.preferredBeneficiaryInd.hashCode()));
        result = ((result* 31)+((this.beneficiaryShareMethod == null)? 0 :this.beneficiaryShareMethod.hashCode()));
        result = ((result* 31)+((this.beneficiaryPercentDistribution == null)? 0 :this.beneficiaryPercentDistribution.hashCode()));
        result = ((result* 31)+((this.permRatingAmtPerThou == null)? 0 :this.permRatingAmtPerThou.hashCode()));
        result = ((result* 31)+((this.ageSetBackQuantity == null)? 0 :this.ageSetBackQuantity.hashCode()));
        result = ((result* 31)+((this.participationPct == null)? 0 :this.participationPct.hashCode()));
        result = ((result* 31)+((this.tempFlatExtraAmt == null)? 0 :this.tempFlatExtraAmt.hashCode()));
        result = ((result* 31)+((this.tempFlatExtraOverrideEffDate == null)? 0 :this.tempFlatExtraOverrideEffDate.hashCode()));
        result = ((result* 31)+((this.flatExtraPremBasis == null)? 0 :this.flatExtraPremBasis.hashCode()));
        result = ((result* 31)+((this.underwritingResult == null)? 0 :this.underwritingResult.hashCode()));
        result = ((result* 31)+((this.participantName == null)? 0 :this.participantName.hashCode()));
        result = ((result* 31)+((this.beneficiaryAmountDistribution == null)? 0 :this.beneficiaryAmountDistribution.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Participant) == false) {
            return false;
        }
        Participant rhs = ((Participant) other);
        return ((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((this.occupRating == rhs.occupRating)||((this.occupRating!= null)&&this.occupRating.equals(rhs.occupRating)))&&((this.reconsiderationDate == rhs.reconsiderationDate)||((this.reconsiderationDate!= null)&&this.reconsiderationDate.equals(rhs.reconsiderationDate))))&&((this.occupation == rhs.occupation)||((this.occupation!= null)&&this.occupation.equals(rhs.occupation))))&&((this.modalGrossTempFlatAllowAmt == rhs.modalGrossTempFlatAllowAmt)||((this.modalGrossTempFlatAllowAmt!= null)&&this.modalGrossTempFlatAllowAmt.equals(rhs.modalGrossTempFlatAllowAmt))))&&((this.beneficiarySeqNum == rhs.beneficiarySeqNum)||((this.beneficiarySeqNum!= null)&&this.beneficiarySeqNum.equals(rhs.beneficiarySeqNum))))&&((this.ageCalculationType == rhs.ageCalculationType)||((this.ageCalculationType!= null)&&this.ageCalculationType.equals(rhs.ageCalculationType))))&&((this.tempPercentageLoading == rhs.tempPercentageLoading)||((this.tempPercentageLoading!= null)&&this.tempPercentageLoading.equals(rhs.tempPercentageLoading))))&&((this.tempTableRatingCode == rhs.tempTableRatingCode)||((this.tempTableRatingCode!= null)&&this.tempTableRatingCode.equals(rhs.tempTableRatingCode))))&&((this.employmentClass == rhs.employmentClass)||((this.employmentClass!= null)&&this.employmentClass.equals(rhs.employmentClass))))&&((this.underwritingClass == rhs.underwritingClass)||((this.underwritingClass!= null)&&this.underwritingClass.equals(rhs.underwritingClass))))&&((this.ratingOverriddenInd == rhs.ratingOverriddenInd)||((this.ratingOverriddenInd!= null)&&this.ratingOverriddenInd.equals(rhs.ratingOverriddenInd))))&&((this.tobaccoPremiumBasis == rhs.tobaccoPremiumBasis)||((this.tobaccoPremiumBasis!= null)&&this.tobaccoPremiumBasis.equals(rhs.tobaccoPremiumBasis))))&&((this.modalGrossPermFlatExtraAllowanceAmt == rhs.modalGrossPermFlatExtraAllowanceAmt)||((this.modalGrossPermFlatExtraAllowanceAmt!= null)&&this.modalGrossPermFlatExtraAllowanceAmt.equals(rhs.modalGrossPermFlatExtraAllowanceAmt))))&&((this.smokerStat == rhs.smokerStat)||((this.smokerStat!= null)&&this.smokerStat.equals(rhs.smokerStat))))&&((this.effDate == rhs.effDate)||((this.effDate!= null)&&this.effDate.equals(rhs.effDate))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.permFlatExtraAmt == rhs.permFlatExtraAmt)||((this.permFlatExtraAmt!= null)&&this.permFlatExtraAmt.equals(rhs.permFlatExtraAmt))))&&((this.permFlatExtraEndDate == rhs.permFlatExtraEndDate)||((this.permFlatExtraEndDate!= null)&&this.permFlatExtraEndDate.equals(rhs.permFlatExtraEndDate))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.modalGrossFlatExtraPremAmt == rhs.modalGrossFlatExtraPremAmt)||((this.modalGrossFlatExtraPremAmt!= null)&&this.modalGrossFlatExtraPremAmt.equals(rhs.modalGrossFlatExtraPremAmt))))&&((this.proceedsHoldDurUnitMeasure == rhs.proceedsHoldDurUnitMeasure)||((this.proceedsHoldDurUnitMeasure!= null)&&this.proceedsHoldDurUnitMeasure.equals(rhs.proceedsHoldDurUnitMeasure))))&&((this.permTableRating == rhs.permTableRating)||((this.permTableRating!= null)&&this.permTableRating.equals(rhs.permTableRating))))&&((this.originalIssueAge == rhs.originalIssueAge)||((this.originalIssueAge!= null)&&this.originalIssueAge.equals(rhs.originalIssueAge))))&&((this.substandardRating == rhs.substandardRating)||((this.substandardRating!= null)&&this.substandardRating.equals(rhs.substandardRating))))&&((this.issuedAsAppliedInd == rhs.issuedAsAppliedInd)||((this.issuedAsAppliedInd!= null)&&this.issuedAsAppliedInd.equals(rhs.issuedAsAppliedInd))))&&((this.assocParticipantObjectInfo == rhs.assocParticipantObjectInfo)||((this.assocParticipantObjectInfo!= null)&&this.assocParticipantObjectInfo.equals(rhs.assocParticipantObjectInfo))))&&((this.distributionOption == rhs.distributionOption)||((this.distributionOption!= null)&&this.distributionOption.equals(rhs.distributionOption))))&&((this.commissionLink == rhs.commissionLink)||((this.commissionLink!= null)&&this.commissionLink.equals(rhs.commissionLink))))&&((this.permTableRatingEndDate == rhs.permTableRatingEndDate)||((this.permTableRatingEndDate!= null)&&this.permTableRatingEndDate.equals(rhs.permTableRatingEndDate))))&&((this.proceedsHoldDuration == rhs.proceedsHoldDuration)||((this.proceedsHoldDuration!= null)&&this.proceedsHoldDuration.equals(rhs.proceedsHoldDuration))))&&((this.permRatingType == rhs.permRatingType)||((this.permRatingType!= null)&&this.permRatingType.equals(rhs.permRatingType))))&&((this.beneficiaryCommonDisasterPeriod == rhs.beneficiaryCommonDisasterPeriod)||((this.beneficiaryCommonDisasterPeriod!= null)&&this.beneficiaryCommonDisasterPeriod.equals(rhs.beneficiaryCommonDisasterPeriod))))&&((this.permPercentageLoading == rhs.permPercentageLoading)||((this.permPercentageLoading!= null)&&this.permPercentageLoading.equals(rhs.permPercentageLoading))))&&((this.lastRatingDate == rhs.lastRatingDate)||((this.lastRatingDate!= null)&&this.lastRatingDate.equals(rhs.lastRatingDate))))&&((this.beneficiaryClaimPeriod == rhs.beneficiaryClaimPeriod)||((this.beneficiaryClaimPeriod!= null)&&this.beneficiaryClaimPeriod.equals(rhs.beneficiaryClaimPeriod))))&&((this.tempFlatEndDate == rhs.tempFlatEndDate)||((this.tempFlatEndDate!= null)&&this.tempFlatEndDate.equals(rhs.tempFlatEndDate))))&&((this.occupClass == rhs.occupClass)||((this.occupClass!= null)&&this.occupClass.equals(rhs.occupClass))))&&((this.insuredSeqNum == rhs.insuredSeqNum)||((this.insuredSeqNum!= null)&&this.insuredSeqNum.equals(rhs.insuredSeqNum))))&&((this.residenceNationAtIssue == rhs.residenceNationAtIssue)||((this.residenceNationAtIssue!= null)&&this.residenceNationAtIssue.equals(rhs.residenceNationAtIssue))))&&((this.temporaryRoleInd == rhs.temporaryRoleInd)||((this.temporaryRoleInd!= null)&&this.temporaryRoleInd.equals(rhs.temporaryRoleInd))))&&((this.closedAge == rhs.closedAge)||((this.closedAge!= null)&&this.closedAge.equals(rhs.closedAge))))&&((this.participantRoleCode == rhs.participantRoleCode)||((this.participantRoleCode!= null)&&this.participantRoleCode.equals(rhs.participantRoleCode))))&&((this.mailingAddressID == rhs.mailingAddressID)||((this.mailingAddressID!= null)&&this.mailingAddressID.equals(rhs.mailingAddressID))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.permTableRatingAlphaCode == rhs.permTableRatingAlphaCode)||((this.permTableRatingAlphaCode!= null)&&this.permTableRatingAlphaCode.equals(rhs.permTableRatingAlphaCode))))&&((this.termDate == rhs.termDate)||((this.termDate!= null)&&this.termDate.equals(rhs.termDate))))&&((this.partyID == rhs.partyID)||((this.partyID!= null)&&this.partyID.equals(rhs.partyID))))&&((this.tempRatingType == rhs.tempRatingType)||((this.tempRatingType!= null)&&this.tempRatingType.equals(rhs.tempRatingType))))&&((this.modalPermRatingAmt == rhs.modalPermRatingAmt)||((this.modalPermRatingAmt!= null)&&this.modalPermRatingAmt.equals(rhs.modalPermRatingAmt))))&&((this.beneficiaryRoleCodeDesc == rhs.beneficiaryRoleCodeDesc)||((this.beneficiaryRoleCodeDesc!= null)&&this.beneficiaryRoleCodeDesc.equals(rhs.beneficiaryRoleCodeDesc))))&&((this.residenceJurisdictionAtIssue == rhs.residenceJurisdictionAtIssue)||((this.residenceJurisdictionAtIssue!= null)&&this.residenceJurisdictionAtIssue.equals(rhs.residenceJurisdictionAtIssue))))&&((this.issueAge == rhs.issueAge)||((this.issueAge!= null)&&this.issueAge.equals(rhs.issueAge))))&&((this.beneficiaryDesignation == rhs.beneficiaryDesignation)||((this.beneficiaryDesignation!= null)&&this.beneficiaryDesignation.equals(rhs.beneficiaryDesignation))))&&((this.privacyLastCommunicationDate == rhs.privacyLastCommunicationDate)||((this.privacyLastCommunicationDate!= null)&&this.privacyLastCommunicationDate.equals(rhs.privacyLastCommunicationDate))))&&((this.tempFlatExtraOverrideEndDate == rhs.tempFlatExtraOverrideEndDate)||((this.tempFlatExtraOverrideEndDate!= null)&&this.tempFlatExtraOverrideEndDate.equals(rhs.tempFlatExtraOverrideEndDate))))&&((this.issueAgeSource == rhs.issueAgeSource)||((this.issueAgeSource!= null)&&this.issueAgeSource.equals(rhs.issueAgeSource))))&&((this.beneficiaryIncomeOptionInfo == rhs.beneficiaryIncomeOptionInfo)||((this.beneficiaryIncomeOptionInfo!= null)&&this.beneficiaryIncomeOptionInfo.equals(rhs.beneficiaryIncomeOptionInfo))))&&((this.participantSysKey == rhs.participantSysKey)||((this.participantSysKey!= null)&&this.participantSysKey.equals(rhs.participantSysKey))))&&((this.issueGender == rhs.issueGender)||((this.issueGender!= null)&&this.issueGender.equals(rhs.issueGender))))&&((this.faceAmt == rhs.faceAmt)||((this.faceAmt!= null)&&this.faceAmt.equals(rhs.faceAmt))))&&((this.tempFlatExtraDuration == rhs.tempFlatExtraDuration)||((this.tempFlatExtraDuration!= null)&&this.tempFlatExtraDuration.equals(rhs.tempFlatExtraDuration))))&&((this.ratingCommissionRule == rhs.ratingCommissionRule)||((this.ratingCommissionRule!= null)&&this.ratingCommissionRule.equals(rhs.ratingCommissionRule))))&&((this.className == rhs.className)||((this.className!= null)&&this.className.equals(rhs.className))))&&((this.beneficiaryIncomeOption == rhs.beneficiaryIncomeOption)||((this.beneficiaryIncomeOption!= null)&&this.beneficiaryIncomeOption.equals(rhs.beneficiaryIncomeOption))))&&((this.participantKey == rhs.participantKey)||((this.participantKey!= null)&&this.participantKey.equals(rhs.participantKey))))&&((this.irrevokableInd == rhs.irrevokableInd)||((this.irrevokableInd!= null)&&this.irrevokableInd.equals(rhs.irrevokableInd))))&&((this.aSCOCode == rhs.aSCOCode)||((this.aSCOCode!= null)&&this.aSCOCode.equals(rhs.aSCOCode))))&&((this.modalTempRatingAmt == rhs.modalTempRatingAmt)||((this.modalTempRatingAmt!= null)&&this.modalTempRatingAmt.equals(rhs.modalTempRatingAmt))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.beneClaimPeriodMeasureUnit == rhs.beneClaimPeriodMeasureUnit)||((this.beneClaimPeriodMeasureUnit!= null)&&this.beneClaimPeriodMeasureUnit.equals(rhs.beneClaimPeriodMeasureUnit))))&&((this.modalGrossFlatExtraAllowanceAmt == rhs.modalGrossFlatExtraAllowanceAmt)||((this.modalGrossFlatExtraAllowanceAmt!= null)&&this.modalGrossFlatExtraAllowanceAmt.equals(rhs.modalGrossFlatExtraAllowanceAmt))))&&((this.livesWithPrimaryInsInd == rhs.livesWithPrimaryInsInd)||((this.livesWithPrimaryInsInd!= null)&&this.livesWithPrimaryInsInd.equals(rhs.livesWithPrimaryInsInd))))&&((this.dependentOnPrimaryInsInd == rhs.dependentOnPrimaryInsInd)||((this.dependentOnPrimaryInsInd!= null)&&this.dependentOnPrimaryInsInd.equals(rhs.dependentOnPrimaryInsInd))))&&((this.tempTableRating == rhs.tempTableRating)||((this.tempTableRating!= null)&&this.tempTableRating.equals(rhs.tempTableRating))))&&((this.tempRatingAmtPerThou == rhs.tempRatingAmtPerThou)||((this.tempRatingAmtPerThou!= null)&&this.tempRatingAmtPerThou.equals(rhs.tempRatingAmtPerThou))))&&((this.participantStatus == rhs.participantStatus)||((this.participantStatus!= null)&&this.participantStatus.equals(rhs.participantStatus))))&&((this.tempTableRatingStartDate == rhs.tempTableRatingStartDate)||((this.tempTableRatingStartDate!= null)&&this.tempTableRatingStartDate.equals(rhs.tempTableRatingStartDate))))&&((this.underwritingSubClass == rhs.underwritingSubClass)||((this.underwritingSubClass!= null)&&this.underwritingSubClass.equals(rhs.underwritingSubClass))))&&((this.deliveryInfo == rhs.deliveryInfo)||((this.deliveryInfo!= null)&&this.deliveryInfo.equals(rhs.deliveryInfo))))&&((this.tempTableRatingEndDate == rhs.tempTableRatingEndDate)||((this.tempTableRatingEndDate!= null)&&this.tempTableRatingEndDate.equals(rhs.tempTableRatingEndDate))))&&((this.ratingReason == rhs.ratingReason)||((this.ratingReason!= null)&&this.ratingReason.equals(rhs.ratingReason))))&&((this.beneficiaryRoleCode == rhs.beneficiaryRoleCode)||((this.beneficiaryRoleCode!= null)&&this.beneficiaryRoleCode.equals(rhs.beneficiaryRoleCode))))&&((this.tempFlatStartDate == rhs.tempFlatStartDate)||((this.tempFlatStartDate!= null)&&this.tempFlatStartDate.equals(rhs.tempFlatStartDate))))&&((this.preferredBeneficiaryInd == rhs.preferredBeneficiaryInd)||((this.preferredBeneficiaryInd!= null)&&this.preferredBeneficiaryInd.equals(rhs.preferredBeneficiaryInd))))&&((this.beneficiaryShareMethod == rhs.beneficiaryShareMethod)||((this.beneficiaryShareMethod!= null)&&this.beneficiaryShareMethod.equals(rhs.beneficiaryShareMethod))))&&((this.beneficiaryPercentDistribution == rhs.beneficiaryPercentDistribution)||((this.beneficiaryPercentDistribution!= null)&&this.beneficiaryPercentDistribution.equals(rhs.beneficiaryPercentDistribution))))&&((this.permRatingAmtPerThou == rhs.permRatingAmtPerThou)||((this.permRatingAmtPerThou!= null)&&this.permRatingAmtPerThou.equals(rhs.permRatingAmtPerThou))))&&((this.ageSetBackQuantity == rhs.ageSetBackQuantity)||((this.ageSetBackQuantity!= null)&&this.ageSetBackQuantity.equals(rhs.ageSetBackQuantity))))&&((this.participationPct == rhs.participationPct)||((this.participationPct!= null)&&this.participationPct.equals(rhs.participationPct))))&&((this.tempFlatExtraAmt == rhs.tempFlatExtraAmt)||((this.tempFlatExtraAmt!= null)&&this.tempFlatExtraAmt.equals(rhs.tempFlatExtraAmt))))&&((this.tempFlatExtraOverrideEffDate == rhs.tempFlatExtraOverrideEffDate)||((this.tempFlatExtraOverrideEffDate!= null)&&this.tempFlatExtraOverrideEffDate.equals(rhs.tempFlatExtraOverrideEffDate))))&&((this.flatExtraPremBasis == rhs.flatExtraPremBasis)||((this.flatExtraPremBasis!= null)&&this.flatExtraPremBasis.equals(rhs.flatExtraPremBasis))))&&((this.underwritingResult == rhs.underwritingResult)||((this.underwritingResult!= null)&&this.underwritingResult.equals(rhs.underwritingResult))))&&((this.participantName == rhs.participantName)||((this.participantName!= null)&&this.participantName.equals(rhs.participantName))))&&((this.beneficiaryAmountDistribution == rhs.beneficiaryAmountDistribution)||((this.beneficiaryAmountDistribution!= null)&&this.beneficiaryAmountDistribution.equals(rhs.beneficiaryAmountDistribution))));
    }

}
