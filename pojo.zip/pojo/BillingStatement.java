
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "BillingStatementKey",
    "BillingStatementSysKey",
    "PaymentRemitterName",
    "BillingPayPoint",
    "BranchOfService",
    "PaymentAmt",
    "PreviousBalanceAmt",
    "NewBalanceAmt",
    "PaymentMode",
    "PaymentDueDate",
    "PaymentForm",
    "PaymentMethod",
    "PaymentTermsDesc",
    "AccountNumber",
    "CustomerAccountNumber",
    "RoutingNumber",
    "AcctHolderName",
    "CreditCardExpDate",
    "CreditCardType",
    "BankAcctType",
    "BankBranchName",
    "PastDueBalanceAmt",
    "OCRLine",
    "BillingDetail",
    "ReconciliationSummary",
    "OLifEExtension",
    "id",
    "RemitterPartyID",
    "BankPartyID",
    "BankingHoldingID",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class BillingStatement {

    @JsonProperty("BillingStatementKey")
    private BillingStatementKey billingStatementKey;
    @JsonProperty("BillingStatementSysKey")
    private List<Object> billingStatementSysKey = new ArrayList<>();
    @JsonProperty("PaymentRemitterName")
    private String paymentRemitterName;
    @JsonProperty("BillingPayPoint")
    private String billingPayPoint;
    @JsonProperty("BranchOfService")
    private BranchOfService branchOfService;
    @JsonProperty("PaymentAmt")
    private Integer paymentAmt;
    @JsonProperty("PreviousBalanceAmt")
    private Integer previousBalanceAmt;
    @JsonProperty("NewBalanceAmt")
    private Integer newBalanceAmt;
    @JsonProperty("PaymentMode")
    private PaymentMode paymentMode;
    @JsonProperty("PaymentDueDate")
    private String paymentDueDate;
    @JsonProperty("PaymentForm")
    private PaymentForm paymentForm;
    @JsonProperty("PaymentMethod")
    private PaymentMethod paymentMethod;
    @JsonProperty("PaymentTermsDesc")
    private String paymentTermsDesc;
    @JsonProperty("AccountNumber")
    private String accountNumber;
    @JsonProperty("CustomerAccountNumber")
    private String customerAccountNumber;
    @JsonProperty("RoutingNumber")
    private String routingNumber;
    @JsonProperty("AcctHolderName")
    private String acctHolderName;
    @JsonProperty("CreditCardExpDate")
    private String creditCardExpDate;
    @JsonProperty("CreditCardType")
    private CreditCardType creditCardType;
    @JsonProperty("BankAcctType")
    private BankAcctType bankAcctType;
    @JsonProperty("BankBranchName")
    private String bankBranchName;
    @JsonProperty("PastDueBalanceAmt")
    private Integer pastDueBalanceAmt;
    @JsonProperty("OCRLine")
    private String oCRLine;
    @JsonProperty("BillingDetail")
    private List<Object> billingDetail = new ArrayList<>();
    @JsonProperty("ReconciliationSummary")
    private List<Object> reconciliationSummary = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("RemitterPartyID")
    private String remitterPartyID;
    @JsonProperty("BankPartyID")
    private String bankPartyID;
    @JsonProperty("BankingHoldingID")
    private String bankingHoldingID;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("BillingStatementKey")
    public BillingStatementKey getBillingStatementKey() {
        return billingStatementKey;
    }

    @JsonProperty("BillingStatementKey")
    public void setBillingStatementKey(BillingStatementKey billingStatementKey) {
        this.billingStatementKey = billingStatementKey;
    }

    public BillingStatement withBillingStatementKey(BillingStatementKey billingStatementKey) {
        this.billingStatementKey = billingStatementKey;
        return this;
    }

    @JsonProperty("BillingStatementSysKey")
    public List<Object> getBillingStatementSysKey() {
        return billingStatementSysKey;
    }

    @JsonProperty("BillingStatementSysKey")
    public void setBillingStatementSysKey(List<Object> billingStatementSysKey) {
        this.billingStatementSysKey = billingStatementSysKey;
    }

    public BillingStatement withBillingStatementSysKey(List<Object> billingStatementSysKey) {
        this.billingStatementSysKey = billingStatementSysKey;
        return this;
    }

    @JsonProperty("PaymentRemitterName")
    public String getPaymentRemitterName() {
        return paymentRemitterName;
    }

    @JsonProperty("PaymentRemitterName")
    public void setPaymentRemitterName(String paymentRemitterName) {
        this.paymentRemitterName = paymentRemitterName;
    }

    public BillingStatement withPaymentRemitterName(String paymentRemitterName) {
        this.paymentRemitterName = paymentRemitterName;
        return this;
    }

    @JsonProperty("BillingPayPoint")
    public String getBillingPayPoint() {
        return billingPayPoint;
    }

    @JsonProperty("BillingPayPoint")
    public void setBillingPayPoint(String billingPayPoint) {
        this.billingPayPoint = billingPayPoint;
    }

    public BillingStatement withBillingPayPoint(String billingPayPoint) {
        this.billingPayPoint = billingPayPoint;
        return this;
    }

    @JsonProperty("BranchOfService")
    public BranchOfService getBranchOfService() {
        return branchOfService;
    }

    @JsonProperty("BranchOfService")
    public void setBranchOfService(BranchOfService branchOfService) {
        this.branchOfService = branchOfService;
    }

    public BillingStatement withBranchOfService(BranchOfService branchOfService) {
        this.branchOfService = branchOfService;
        return this;
    }

    @JsonProperty("PaymentAmt")
    public Integer getPaymentAmt() {
        return paymentAmt;
    }

    @JsonProperty("PaymentAmt")
    public void setPaymentAmt(Integer paymentAmt) {
        this.paymentAmt = paymentAmt;
    }

    public BillingStatement withPaymentAmt(Integer paymentAmt) {
        this.paymentAmt = paymentAmt;
        return this;
    }

    @JsonProperty("PreviousBalanceAmt")
    public Integer getPreviousBalanceAmt() {
        return previousBalanceAmt;
    }

    @JsonProperty("PreviousBalanceAmt")
    public void setPreviousBalanceAmt(Integer previousBalanceAmt) {
        this.previousBalanceAmt = previousBalanceAmt;
    }

    public BillingStatement withPreviousBalanceAmt(Integer previousBalanceAmt) {
        this.previousBalanceAmt = previousBalanceAmt;
        return this;
    }

    @JsonProperty("NewBalanceAmt")
    public Integer getNewBalanceAmt() {
        return newBalanceAmt;
    }

    @JsonProperty("NewBalanceAmt")
    public void setNewBalanceAmt(Integer newBalanceAmt) {
        this.newBalanceAmt = newBalanceAmt;
    }

    public BillingStatement withNewBalanceAmt(Integer newBalanceAmt) {
        this.newBalanceAmt = newBalanceAmt;
        return this;
    }

    @JsonProperty("PaymentMode")
    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    @JsonProperty("PaymentMode")
    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public BillingStatement withPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
        return this;
    }

    @JsonProperty("PaymentDueDate")
    public String getPaymentDueDate() {
        return paymentDueDate;
    }

    @JsonProperty("PaymentDueDate")
    public void setPaymentDueDate(String paymentDueDate) {
        this.paymentDueDate = paymentDueDate;
    }

    public BillingStatement withPaymentDueDate(String paymentDueDate) {
        this.paymentDueDate = paymentDueDate;
        return this;
    }

    @JsonProperty("PaymentForm")
    public PaymentForm getPaymentForm() {
        return paymentForm;
    }

    @JsonProperty("PaymentForm")
    public void setPaymentForm(PaymentForm paymentForm) {
        this.paymentForm = paymentForm;
    }

    public BillingStatement withPaymentForm(PaymentForm paymentForm) {
        this.paymentForm = paymentForm;
        return this;
    }

    @JsonProperty("PaymentMethod")
    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    @JsonProperty("PaymentMethod")
    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public BillingStatement withPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
        return this;
    }

    @JsonProperty("PaymentTermsDesc")
    public String getPaymentTermsDesc() {
        return paymentTermsDesc;
    }

    @JsonProperty("PaymentTermsDesc")
    public void setPaymentTermsDesc(String paymentTermsDesc) {
        this.paymentTermsDesc = paymentTermsDesc;
    }

    public BillingStatement withPaymentTermsDesc(String paymentTermsDesc) {
        this.paymentTermsDesc = paymentTermsDesc;
        return this;
    }

    @JsonProperty("AccountNumber")
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("AccountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public BillingStatement withAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
        return this;
    }

    @JsonProperty("CustomerAccountNumber")
    public String getCustomerAccountNumber() {
        return customerAccountNumber;
    }

    @JsonProperty("CustomerAccountNumber")
    public void setCustomerAccountNumber(String customerAccountNumber) {
        this.customerAccountNumber = customerAccountNumber;
    }

    public BillingStatement withCustomerAccountNumber(String customerAccountNumber) {
        this.customerAccountNumber = customerAccountNumber;
        return this;
    }

    @JsonProperty("RoutingNumber")
    public String getRoutingNumber() {
        return routingNumber;
    }

    @JsonProperty("RoutingNumber")
    public void setRoutingNumber(String routingNumber) {
        this.routingNumber = routingNumber;
    }

    public BillingStatement withRoutingNumber(String routingNumber) {
        this.routingNumber = routingNumber;
        return this;
    }

    @JsonProperty("AcctHolderName")
    public String getAcctHolderName() {
        return acctHolderName;
    }

    @JsonProperty("AcctHolderName")
    public void setAcctHolderName(String acctHolderName) {
        this.acctHolderName = acctHolderName;
    }

    public BillingStatement withAcctHolderName(String acctHolderName) {
        this.acctHolderName = acctHolderName;
        return this;
    }

    @JsonProperty("CreditCardExpDate")
    public String getCreditCardExpDate() {
        return creditCardExpDate;
    }

    @JsonProperty("CreditCardExpDate")
    public void setCreditCardExpDate(String creditCardExpDate) {
        this.creditCardExpDate = creditCardExpDate;
    }

    public BillingStatement withCreditCardExpDate(String creditCardExpDate) {
        this.creditCardExpDate = creditCardExpDate;
        return this;
    }

    @JsonProperty("CreditCardType")
    public CreditCardType getCreditCardType() {
        return creditCardType;
    }

    @JsonProperty("CreditCardType")
    public void setCreditCardType(CreditCardType creditCardType) {
        this.creditCardType = creditCardType;
    }

    public BillingStatement withCreditCardType(CreditCardType creditCardType) {
        this.creditCardType = creditCardType;
        return this;
    }

    @JsonProperty("BankAcctType")
    public BankAcctType getBankAcctType() {
        return bankAcctType;
    }

    @JsonProperty("BankAcctType")
    public void setBankAcctType(BankAcctType bankAcctType) {
        this.bankAcctType = bankAcctType;
    }

    public BillingStatement withBankAcctType(BankAcctType bankAcctType) {
        this.bankAcctType = bankAcctType;
        return this;
    }

    @JsonProperty("BankBranchName")
    public String getBankBranchName() {
        return bankBranchName;
    }

    @JsonProperty("BankBranchName")
    public void setBankBranchName(String bankBranchName) {
        this.bankBranchName = bankBranchName;
    }

    public BillingStatement withBankBranchName(String bankBranchName) {
        this.bankBranchName = bankBranchName;
        return this;
    }

    @JsonProperty("PastDueBalanceAmt")
    public Integer getPastDueBalanceAmt() {
        return pastDueBalanceAmt;
    }

    @JsonProperty("PastDueBalanceAmt")
    public void setPastDueBalanceAmt(Integer pastDueBalanceAmt) {
        this.pastDueBalanceAmt = pastDueBalanceAmt;
    }

    public BillingStatement withPastDueBalanceAmt(Integer pastDueBalanceAmt) {
        this.pastDueBalanceAmt = pastDueBalanceAmt;
        return this;
    }

    @JsonProperty("OCRLine")
    public String getOCRLine() {
        return oCRLine;
    }

    @JsonProperty("OCRLine")
    public void setOCRLine(String oCRLine) {
        this.oCRLine = oCRLine;
    }

    public BillingStatement withOCRLine(String oCRLine) {
        this.oCRLine = oCRLine;
        return this;
    }

    @JsonProperty("BillingDetail")
    public List<Object> getBillingDetail() {
        return billingDetail;
    }

    @JsonProperty("BillingDetail")
    public void setBillingDetail(List<Object> billingDetail) {
        this.billingDetail = billingDetail;
    }

    public BillingStatement withBillingDetail(List<Object> billingDetail) {
        this.billingDetail = billingDetail;
        return this;
    }

    @JsonProperty("ReconciliationSummary")
    public List<Object> getReconciliationSummary() {
        return reconciliationSummary;
    }

    @JsonProperty("ReconciliationSummary")
    public void setReconciliationSummary(List<Object> reconciliationSummary) {
        this.reconciliationSummary = reconciliationSummary;
    }

    public BillingStatement withReconciliationSummary(List<Object> reconciliationSummary) {
        this.reconciliationSummary = reconciliationSummary;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public BillingStatement withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public BillingStatement withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("RemitterPartyID")
    public String getRemitterPartyID() {
        return remitterPartyID;
    }

    @JsonProperty("RemitterPartyID")
    public void setRemitterPartyID(String remitterPartyID) {
        this.remitterPartyID = remitterPartyID;
    }

    public BillingStatement withRemitterPartyID(String remitterPartyID) {
        this.remitterPartyID = remitterPartyID;
        return this;
    }

    @JsonProperty("BankPartyID")
    public String getBankPartyID() {
        return bankPartyID;
    }

    @JsonProperty("BankPartyID")
    public void setBankPartyID(String bankPartyID) {
        this.bankPartyID = bankPartyID;
    }

    public BillingStatement withBankPartyID(String bankPartyID) {
        this.bankPartyID = bankPartyID;
        return this;
    }

    @JsonProperty("BankingHoldingID")
    public String getBankingHoldingID() {
        return bankingHoldingID;
    }

    @JsonProperty("BankingHoldingID")
    public void setBankingHoldingID(String bankingHoldingID) {
        this.bankingHoldingID = bankingHoldingID;
    }

    public BillingStatement withBankingHoldingID(String bankingHoldingID) {
        this.bankingHoldingID = bankingHoldingID;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public BillingStatement withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public BillingStatement withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(BillingStatement.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("billingStatementKey");
        sb.append('=');
        sb.append(((this.billingStatementKey == null)?"<null>":this.billingStatementKey));
        sb.append(',');
        sb.append("billingStatementSysKey");
        sb.append('=');
        sb.append(((this.billingStatementSysKey == null)?"<null>":this.billingStatementSysKey));
        sb.append(',');
        sb.append("paymentRemitterName");
        sb.append('=');
        sb.append(((this.paymentRemitterName == null)?"<null>":this.paymentRemitterName));
        sb.append(',');
        sb.append("billingPayPoint");
        sb.append('=');
        sb.append(((this.billingPayPoint == null)?"<null>":this.billingPayPoint));
        sb.append(',');
        sb.append("branchOfService");
        sb.append('=');
        sb.append(((this.branchOfService == null)?"<null>":this.branchOfService));
        sb.append(',');
        sb.append("paymentAmt");
        sb.append('=');
        sb.append(((this.paymentAmt == null)?"<null>":this.paymentAmt));
        sb.append(',');
        sb.append("previousBalanceAmt");
        sb.append('=');
        sb.append(((this.previousBalanceAmt == null)?"<null>":this.previousBalanceAmt));
        sb.append(',');
        sb.append("newBalanceAmt");
        sb.append('=');
        sb.append(((this.newBalanceAmt == null)?"<null>":this.newBalanceAmt));
        sb.append(',');
        sb.append("paymentMode");
        sb.append('=');
        sb.append(((this.paymentMode == null)?"<null>":this.paymentMode));
        sb.append(',');
        sb.append("paymentDueDate");
        sb.append('=');
        sb.append(((this.paymentDueDate == null)?"<null>":this.paymentDueDate));
        sb.append(',');
        sb.append("paymentForm");
        sb.append('=');
        sb.append(((this.paymentForm == null)?"<null>":this.paymentForm));
        sb.append(',');
        sb.append("paymentMethod");
        sb.append('=');
        sb.append(((this.paymentMethod == null)?"<null>":this.paymentMethod));
        sb.append(',');
        sb.append("paymentTermsDesc");
        sb.append('=');
        sb.append(((this.paymentTermsDesc == null)?"<null>":this.paymentTermsDesc));
        sb.append(',');
        sb.append("accountNumber");
        sb.append('=');
        sb.append(((this.accountNumber == null)?"<null>":this.accountNumber));
        sb.append(',');
        sb.append("customerAccountNumber");
        sb.append('=');
        sb.append(((this.customerAccountNumber == null)?"<null>":this.customerAccountNumber));
        sb.append(',');
        sb.append("routingNumber");
        sb.append('=');
        sb.append(((this.routingNumber == null)?"<null>":this.routingNumber));
        sb.append(',');
        sb.append("acctHolderName");
        sb.append('=');
        sb.append(((this.acctHolderName == null)?"<null>":this.acctHolderName));
        sb.append(',');
        sb.append("creditCardExpDate");
        sb.append('=');
        sb.append(((this.creditCardExpDate == null)?"<null>":this.creditCardExpDate));
        sb.append(',');
        sb.append("creditCardType");
        sb.append('=');
        sb.append(((this.creditCardType == null)?"<null>":this.creditCardType));
        sb.append(',');
        sb.append("bankAcctType");
        sb.append('=');
        sb.append(((this.bankAcctType == null)?"<null>":this.bankAcctType));
        sb.append(',');
        sb.append("bankBranchName");
        sb.append('=');
        sb.append(((this.bankBranchName == null)?"<null>":this.bankBranchName));
        sb.append(',');
        sb.append("pastDueBalanceAmt");
        sb.append('=');
        sb.append(((this.pastDueBalanceAmt == null)?"<null>":this.pastDueBalanceAmt));
        sb.append(',');
        sb.append("oCRLine");
        sb.append('=');
        sb.append(((this.oCRLine == null)?"<null>":this.oCRLine));
        sb.append(',');
        sb.append("billingDetail");
        sb.append('=');
        sb.append(((this.billingDetail == null)?"<null>":this.billingDetail));
        sb.append(',');
        sb.append("reconciliationSummary");
        sb.append('=');
        sb.append(((this.reconciliationSummary == null)?"<null>":this.reconciliationSummary));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("remitterPartyID");
        sb.append('=');
        sb.append(((this.remitterPartyID == null)?"<null>":this.remitterPartyID));
        sb.append(',');
        sb.append("bankPartyID");
        sb.append('=');
        sb.append(((this.bankPartyID == null)?"<null>":this.bankPartyID));
        sb.append(',');
        sb.append("bankingHoldingID");
        sb.append('=');
        sb.append(((this.bankingHoldingID == null)?"<null>":this.bankingHoldingID));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.paymentAmt == null)? 0 :this.paymentAmt.hashCode()));
        result = ((result* 31)+((this.paymentForm == null)? 0 :this.paymentForm.hashCode()));
        result = ((result* 31)+((this.bankingHoldingID == null)? 0 :this.bankingHoldingID.hashCode()));
        result = ((result* 31)+((this.acctHolderName == null)? 0 :this.acctHolderName.hashCode()));
        result = ((result* 31)+((this.paymentRemitterName == null)? 0 :this.paymentRemitterName.hashCode()));
        result = ((result* 31)+((this.bankBranchName == null)? 0 :this.bankBranchName.hashCode()));
        result = ((result* 31)+((this.bankAcctType == null)? 0 :this.bankAcctType.hashCode()));
        result = ((result* 31)+((this.reconciliationSummary == null)? 0 :this.reconciliationSummary.hashCode()));
        result = ((result* 31)+((this.branchOfService == null)? 0 :this.branchOfService.hashCode()));
        result = ((result* 31)+((this.creditCardType == null)? 0 :this.creditCardType.hashCode()));
        result = ((result* 31)+((this.billingStatementSysKey == null)? 0 :this.billingStatementSysKey.hashCode()));
        result = ((result* 31)+((this.creditCardExpDate == null)? 0 :this.creditCardExpDate.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.billingStatementKey == null)? 0 :this.billingStatementKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.billingPayPoint == null)? 0 :this.billingPayPoint.hashCode()));
        result = ((result* 31)+((this.pastDueBalanceAmt == null)? 0 :this.pastDueBalanceAmt.hashCode()));
        result = ((result* 31)+((this.oCRLine == null)? 0 :this.oCRLine.hashCode()));
        result = ((result* 31)+((this.paymentMode == null)? 0 :this.paymentMode.hashCode()));
        result = ((result* 31)+((this.remitterPartyID == null)? 0 :this.remitterPartyID.hashCode()));
        result = ((result* 31)+((this.previousBalanceAmt == null)? 0 :this.previousBalanceAmt.hashCode()));
        result = ((result* 31)+((this.paymentTermsDesc == null)? 0 :this.paymentTermsDesc.hashCode()));
        result = ((result* 31)+((this.customerAccountNumber == null)? 0 :this.customerAccountNumber.hashCode()));
        result = ((result* 31)+((this.accountNumber == null)? 0 :this.accountNumber.hashCode()));
        result = ((result* 31)+((this.billingDetail == null)? 0 :this.billingDetail.hashCode()));
        result = ((result* 31)+((this.newBalanceAmt == null)? 0 :this.newBalanceAmt.hashCode()));
        result = ((result* 31)+((this.paymentDueDate == null)? 0 :this.paymentDueDate.hashCode()));
        result = ((result* 31)+((this.routingNumber == null)? 0 :this.routingNumber.hashCode()));
        result = ((result* 31)+((this.paymentMethod == null)? 0 :this.paymentMethod.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.bankPartyID == null)? 0 :this.bankPartyID.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BillingStatement) == false) {
            return false;
        }
        BillingStatement rhs = ((BillingStatement) other);
        return (((((((((((((((((((((((((((((((((this.paymentAmt == rhs.paymentAmt)||((this.paymentAmt!= null)&&this.paymentAmt.equals(rhs.paymentAmt)))&&((this.paymentForm == rhs.paymentForm)||((this.paymentForm!= null)&&this.paymentForm.equals(rhs.paymentForm))))&&((this.bankingHoldingID == rhs.bankingHoldingID)||((this.bankingHoldingID!= null)&&this.bankingHoldingID.equals(rhs.bankingHoldingID))))&&((this.acctHolderName == rhs.acctHolderName)||((this.acctHolderName!= null)&&this.acctHolderName.equals(rhs.acctHolderName))))&&((this.paymentRemitterName == rhs.paymentRemitterName)||((this.paymentRemitterName!= null)&&this.paymentRemitterName.equals(rhs.paymentRemitterName))))&&((this.bankBranchName == rhs.bankBranchName)||((this.bankBranchName!= null)&&this.bankBranchName.equals(rhs.bankBranchName))))&&((this.bankAcctType == rhs.bankAcctType)||((this.bankAcctType!= null)&&this.bankAcctType.equals(rhs.bankAcctType))))&&((this.reconciliationSummary == rhs.reconciliationSummary)||((this.reconciliationSummary!= null)&&this.reconciliationSummary.equals(rhs.reconciliationSummary))))&&((this.branchOfService == rhs.branchOfService)||((this.branchOfService!= null)&&this.branchOfService.equals(rhs.branchOfService))))&&((this.creditCardType == rhs.creditCardType)||((this.creditCardType!= null)&&this.creditCardType.equals(rhs.creditCardType))))&&((this.billingStatementSysKey == rhs.billingStatementSysKey)||((this.billingStatementSysKey!= null)&&this.billingStatementSysKey.equals(rhs.billingStatementSysKey))))&&((this.creditCardExpDate == rhs.creditCardExpDate)||((this.creditCardExpDate!= null)&&this.creditCardExpDate.equals(rhs.creditCardExpDate))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.billingStatementKey == rhs.billingStatementKey)||((this.billingStatementKey!= null)&&this.billingStatementKey.equals(rhs.billingStatementKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.billingPayPoint == rhs.billingPayPoint)||((this.billingPayPoint!= null)&&this.billingPayPoint.equals(rhs.billingPayPoint))))&&((this.pastDueBalanceAmt == rhs.pastDueBalanceAmt)||((this.pastDueBalanceAmt!= null)&&this.pastDueBalanceAmt.equals(rhs.pastDueBalanceAmt))))&&((this.oCRLine == rhs.oCRLine)||((this.oCRLine!= null)&&this.oCRLine.equals(rhs.oCRLine))))&&((this.paymentMode == rhs.paymentMode)||((this.paymentMode!= null)&&this.paymentMode.equals(rhs.paymentMode))))&&((this.remitterPartyID == rhs.remitterPartyID)||((this.remitterPartyID!= null)&&this.remitterPartyID.equals(rhs.remitterPartyID))))&&((this.previousBalanceAmt == rhs.previousBalanceAmt)||((this.previousBalanceAmt!= null)&&this.previousBalanceAmt.equals(rhs.previousBalanceAmt))))&&((this.paymentTermsDesc == rhs.paymentTermsDesc)||((this.paymentTermsDesc!= null)&&this.paymentTermsDesc.equals(rhs.paymentTermsDesc))))&&((this.customerAccountNumber == rhs.customerAccountNumber)||((this.customerAccountNumber!= null)&&this.customerAccountNumber.equals(rhs.customerAccountNumber))))&&((this.accountNumber == rhs.accountNumber)||((this.accountNumber!= null)&&this.accountNumber.equals(rhs.accountNumber))))&&((this.billingDetail == rhs.billingDetail)||((this.billingDetail!= null)&&this.billingDetail.equals(rhs.billingDetail))))&&((this.newBalanceAmt == rhs.newBalanceAmt)||((this.newBalanceAmt!= null)&&this.newBalanceAmt.equals(rhs.newBalanceAmt))))&&((this.paymentDueDate == rhs.paymentDueDate)||((this.paymentDueDate!= null)&&this.paymentDueDate.equals(rhs.paymentDueDate))))&&((this.routingNumber == rhs.routingNumber)||((this.routingNumber!= null)&&this.routingNumber.equals(rhs.routingNumber))))&&((this.paymentMethod == rhs.paymentMethod)||((this.paymentMethod!= null)&&this.paymentMethod.equals(rhs.paymentMethod))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.bankPartyID == rhs.bankPartyID)||((this.bankPartyID!= null)&&this.bankPartyID.equals(rhs.bankPartyID))));
    }

}
