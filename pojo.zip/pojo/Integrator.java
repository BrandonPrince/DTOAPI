
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "IntegratorKey",
    "IntegratorSysKey",
    "IntegratorType",
    "IntegratorAmt",
    "IntegratorPct",
    "OLifEExtension",
    "id",
    "DataRep",
    "AppliesToHoldingID"
})
@Generated("jsonschema2pojo")
public class Integrator {

    @JsonProperty("IntegratorKey")
    private IntegratorKey integratorKey;
    @JsonProperty("IntegratorSysKey")
    private List<Object> integratorSysKey = new ArrayList<>();
    @JsonProperty("IntegratorType")
    private IntegratorType integratorType;
    @JsonProperty("IntegratorAmt")
    private Integer integratorAmt;
    @JsonProperty("IntegratorPct")
    private Integer integratorPct;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonProperty("AppliesToHoldingID")
    private String appliesToHoldingID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("IntegratorKey")
    public IntegratorKey getIntegratorKey() {
        return integratorKey;
    }

    @JsonProperty("IntegratorKey")
    public void setIntegratorKey(IntegratorKey integratorKey) {
        this.integratorKey = integratorKey;
    }

    public Integrator withIntegratorKey(IntegratorKey integratorKey) {
        this.integratorKey = integratorKey;
        return this;
    }

    @JsonProperty("IntegratorSysKey")
    public List<Object> getIntegratorSysKey() {
        return integratorSysKey;
    }

    @JsonProperty("IntegratorSysKey")
    public void setIntegratorSysKey(List<Object> integratorSysKey) {
        this.integratorSysKey = integratorSysKey;
    }

    public Integrator withIntegratorSysKey(List<Object> integratorSysKey) {
        this.integratorSysKey = integratorSysKey;
        return this;
    }

    @JsonProperty("IntegratorType")
    public IntegratorType getIntegratorType() {
        return integratorType;
    }

    @JsonProperty("IntegratorType")
    public void setIntegratorType(IntegratorType integratorType) {
        this.integratorType = integratorType;
    }

    public Integrator withIntegratorType(IntegratorType integratorType) {
        this.integratorType = integratorType;
        return this;
    }

    @JsonProperty("IntegratorAmt")
    public Integer getIntegratorAmt() {
        return integratorAmt;
    }

    @JsonProperty("IntegratorAmt")
    public void setIntegratorAmt(Integer integratorAmt) {
        this.integratorAmt = integratorAmt;
    }

    public Integrator withIntegratorAmt(Integer integratorAmt) {
        this.integratorAmt = integratorAmt;
        return this;
    }

    @JsonProperty("IntegratorPct")
    public Integer getIntegratorPct() {
        return integratorPct;
    }

    @JsonProperty("IntegratorPct")
    public void setIntegratorPct(Integer integratorPct) {
        this.integratorPct = integratorPct;
    }

    public Integrator withIntegratorPct(Integer integratorPct) {
        this.integratorPct = integratorPct;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Integrator withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Integrator withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public Integrator withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonProperty("AppliesToHoldingID")
    public String getAppliesToHoldingID() {
        return appliesToHoldingID;
    }

    @JsonProperty("AppliesToHoldingID")
    public void setAppliesToHoldingID(String appliesToHoldingID) {
        this.appliesToHoldingID = appliesToHoldingID;
    }

    public Integrator withAppliesToHoldingID(String appliesToHoldingID) {
        this.appliesToHoldingID = appliesToHoldingID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Integrator withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Integrator.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("integratorKey");
        sb.append('=');
        sb.append(((this.integratorKey == null)?"<null>":this.integratorKey));
        sb.append(',');
        sb.append("integratorSysKey");
        sb.append('=');
        sb.append(((this.integratorSysKey == null)?"<null>":this.integratorSysKey));
        sb.append(',');
        sb.append("integratorType");
        sb.append('=');
        sb.append(((this.integratorType == null)?"<null>":this.integratorType));
        sb.append(',');
        sb.append("integratorAmt");
        sb.append('=');
        sb.append(((this.integratorAmt == null)?"<null>":this.integratorAmt));
        sb.append(',');
        sb.append("integratorPct");
        sb.append('=');
        sb.append(((this.integratorPct == null)?"<null>":this.integratorPct));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("appliesToHoldingID");
        sb.append('=');
        sb.append(((this.appliesToHoldingID == null)?"<null>":this.appliesToHoldingID));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.integratorType == null)? 0 :this.integratorType.hashCode()));
        result = ((result* 31)+((this.integratorPct == null)? 0 :this.integratorPct.hashCode()));
        result = ((result* 31)+((this.appliesToHoldingID == null)? 0 :this.appliesToHoldingID.hashCode()));
        result = ((result* 31)+((this.integratorKey == null)? 0 :this.integratorKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.integratorSysKey == null)? 0 :this.integratorSysKey.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.integratorAmt == null)? 0 :this.integratorAmt.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Integrator) == false) {
            return false;
        }
        Integrator rhs = ((Integrator) other);
        return (((((((((((this.integratorType == rhs.integratorType)||((this.integratorType!= null)&&this.integratorType.equals(rhs.integratorType)))&&((this.integratorPct == rhs.integratorPct)||((this.integratorPct!= null)&&this.integratorPct.equals(rhs.integratorPct))))&&((this.appliesToHoldingID == rhs.appliesToHoldingID)||((this.appliesToHoldingID!= null)&&this.appliesToHoldingID.equals(rhs.appliesToHoldingID))))&&((this.integratorKey == rhs.integratorKey)||((this.integratorKey!= null)&&this.integratorKey.equals(rhs.integratorKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.integratorSysKey == rhs.integratorSysKey)||((this.integratorSysKey!= null)&&this.integratorSysKey.equals(rhs.integratorSysKey))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.integratorAmt == rhs.integratorAmt)||((this.integratorAmt!= null)&&this.integratorAmt.equals(rhs.integratorAmt))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
