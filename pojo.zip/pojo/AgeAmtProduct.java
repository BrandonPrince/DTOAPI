
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AgeAmtProductKey",
    "AgeAmtProductSysKey",
    "AgeBasisType",
    "MinAge",
    "MaxAge",
    "MinAgeMeasureUnit",
    "MaxAgeMeasureUnit",
    "MinAmt",
    "MaxAmt",
    "MinPct",
    "MaxPct",
    "MinUnits",
    "MaxUnits",
    "MinRatioToBase",
    "MaxRatioToBase",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AgeAmtProduct {

    @JsonProperty("AgeAmtProductKey")
    private AgeAmtProductKey ageAmtProductKey;
    @JsonProperty("AgeAmtProductSysKey")
    private List<Object> ageAmtProductSysKey = new ArrayList<>();
    @JsonProperty("AgeBasisType")
    private AgeBasisType ageBasisType;
    @JsonProperty("MinAge")
    private Integer minAge;
    @JsonProperty("MaxAge")
    private Integer maxAge;
    @JsonProperty("MinAgeMeasureUnit")
    private MinAgeMeasureUnit minAgeMeasureUnit;
    @JsonProperty("MaxAgeMeasureUnit")
    private MaxAgeMeasureUnit maxAgeMeasureUnit;
    @JsonProperty("MinAmt")
    private Integer minAmt;
    @JsonProperty("MaxAmt")
    private Integer maxAmt;
    @JsonProperty("MinPct")
    private Integer minPct;
    @JsonProperty("MaxPct")
    private Integer maxPct;
    @JsonProperty("MinUnits")
    private Integer minUnits;
    @JsonProperty("MaxUnits")
    private Integer maxUnits;
    @JsonProperty("MinRatioToBase")
    private Integer minRatioToBase;
    @JsonProperty("MaxRatioToBase")
    private Integer maxRatioToBase;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AgeAmtProductKey")
    public AgeAmtProductKey getAgeAmtProductKey() {
        return ageAmtProductKey;
    }

    @JsonProperty("AgeAmtProductKey")
    public void setAgeAmtProductKey(AgeAmtProductKey ageAmtProductKey) {
        this.ageAmtProductKey = ageAmtProductKey;
    }

    public AgeAmtProduct withAgeAmtProductKey(AgeAmtProductKey ageAmtProductKey) {
        this.ageAmtProductKey = ageAmtProductKey;
        return this;
    }

    @JsonProperty("AgeAmtProductSysKey")
    public List<Object> getAgeAmtProductSysKey() {
        return ageAmtProductSysKey;
    }

    @JsonProperty("AgeAmtProductSysKey")
    public void setAgeAmtProductSysKey(List<Object> ageAmtProductSysKey) {
        this.ageAmtProductSysKey = ageAmtProductSysKey;
    }

    public AgeAmtProduct withAgeAmtProductSysKey(List<Object> ageAmtProductSysKey) {
        this.ageAmtProductSysKey = ageAmtProductSysKey;
        return this;
    }

    @JsonProperty("AgeBasisType")
    public AgeBasisType getAgeBasisType() {
        return ageBasisType;
    }

    @JsonProperty("AgeBasisType")
    public void setAgeBasisType(AgeBasisType ageBasisType) {
        this.ageBasisType = ageBasisType;
    }

    public AgeAmtProduct withAgeBasisType(AgeBasisType ageBasisType) {
        this.ageBasisType = ageBasisType;
        return this;
    }

    @JsonProperty("MinAge")
    public Integer getMinAge() {
        return minAge;
    }

    @JsonProperty("MinAge")
    public void setMinAge(Integer minAge) {
        this.minAge = minAge;
    }

    public AgeAmtProduct withMinAge(Integer minAge) {
        this.minAge = minAge;
        return this;
    }

    @JsonProperty("MaxAge")
    public Integer getMaxAge() {
        return maxAge;
    }

    @JsonProperty("MaxAge")
    public void setMaxAge(Integer maxAge) {
        this.maxAge = maxAge;
    }

    public AgeAmtProduct withMaxAge(Integer maxAge) {
        this.maxAge = maxAge;
        return this;
    }

    @JsonProperty("MinAgeMeasureUnit")
    public MinAgeMeasureUnit getMinAgeMeasureUnit() {
        return minAgeMeasureUnit;
    }

    @JsonProperty("MinAgeMeasureUnit")
    public void setMinAgeMeasureUnit(MinAgeMeasureUnit minAgeMeasureUnit) {
        this.minAgeMeasureUnit = minAgeMeasureUnit;
    }

    public AgeAmtProduct withMinAgeMeasureUnit(MinAgeMeasureUnit minAgeMeasureUnit) {
        this.minAgeMeasureUnit = minAgeMeasureUnit;
        return this;
    }

    @JsonProperty("MaxAgeMeasureUnit")
    public MaxAgeMeasureUnit getMaxAgeMeasureUnit() {
        return maxAgeMeasureUnit;
    }

    @JsonProperty("MaxAgeMeasureUnit")
    public void setMaxAgeMeasureUnit(MaxAgeMeasureUnit maxAgeMeasureUnit) {
        this.maxAgeMeasureUnit = maxAgeMeasureUnit;
    }

    public AgeAmtProduct withMaxAgeMeasureUnit(MaxAgeMeasureUnit maxAgeMeasureUnit) {
        this.maxAgeMeasureUnit = maxAgeMeasureUnit;
        return this;
    }

    @JsonProperty("MinAmt")
    public Integer getMinAmt() {
        return minAmt;
    }

    @JsonProperty("MinAmt")
    public void setMinAmt(Integer minAmt) {
        this.minAmt = minAmt;
    }

    public AgeAmtProduct withMinAmt(Integer minAmt) {
        this.minAmt = minAmt;
        return this;
    }

    @JsonProperty("MaxAmt")
    public Integer getMaxAmt() {
        return maxAmt;
    }

    @JsonProperty("MaxAmt")
    public void setMaxAmt(Integer maxAmt) {
        this.maxAmt = maxAmt;
    }

    public AgeAmtProduct withMaxAmt(Integer maxAmt) {
        this.maxAmt = maxAmt;
        return this;
    }

    @JsonProperty("MinPct")
    public Integer getMinPct() {
        return minPct;
    }

    @JsonProperty("MinPct")
    public void setMinPct(Integer minPct) {
        this.minPct = minPct;
    }

    public AgeAmtProduct withMinPct(Integer minPct) {
        this.minPct = minPct;
        return this;
    }

    @JsonProperty("MaxPct")
    public Integer getMaxPct() {
        return maxPct;
    }

    @JsonProperty("MaxPct")
    public void setMaxPct(Integer maxPct) {
        this.maxPct = maxPct;
    }

    public AgeAmtProduct withMaxPct(Integer maxPct) {
        this.maxPct = maxPct;
        return this;
    }

    @JsonProperty("MinUnits")
    public Integer getMinUnits() {
        return minUnits;
    }

    @JsonProperty("MinUnits")
    public void setMinUnits(Integer minUnits) {
        this.minUnits = minUnits;
    }

    public AgeAmtProduct withMinUnits(Integer minUnits) {
        this.minUnits = minUnits;
        return this;
    }

    @JsonProperty("MaxUnits")
    public Integer getMaxUnits() {
        return maxUnits;
    }

    @JsonProperty("MaxUnits")
    public void setMaxUnits(Integer maxUnits) {
        this.maxUnits = maxUnits;
    }

    public AgeAmtProduct withMaxUnits(Integer maxUnits) {
        this.maxUnits = maxUnits;
        return this;
    }

    @JsonProperty("MinRatioToBase")
    public Integer getMinRatioToBase() {
        return minRatioToBase;
    }

    @JsonProperty("MinRatioToBase")
    public void setMinRatioToBase(Integer minRatioToBase) {
        this.minRatioToBase = minRatioToBase;
    }

    public AgeAmtProduct withMinRatioToBase(Integer minRatioToBase) {
        this.minRatioToBase = minRatioToBase;
        return this;
    }

    @JsonProperty("MaxRatioToBase")
    public Integer getMaxRatioToBase() {
        return maxRatioToBase;
    }

    @JsonProperty("MaxRatioToBase")
    public void setMaxRatioToBase(Integer maxRatioToBase) {
        this.maxRatioToBase = maxRatioToBase;
    }

    public AgeAmtProduct withMaxRatioToBase(Integer maxRatioToBase) {
        this.maxRatioToBase = maxRatioToBase;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AgeAmtProduct withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AgeAmtProduct withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AgeAmtProduct withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AgeAmtProduct withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AgeAmtProduct.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("ageAmtProductKey");
        sb.append('=');
        sb.append(((this.ageAmtProductKey == null)?"<null>":this.ageAmtProductKey));
        sb.append(',');
        sb.append("ageAmtProductSysKey");
        sb.append('=');
        sb.append(((this.ageAmtProductSysKey == null)?"<null>":this.ageAmtProductSysKey));
        sb.append(',');
        sb.append("ageBasisType");
        sb.append('=');
        sb.append(((this.ageBasisType == null)?"<null>":this.ageBasisType));
        sb.append(',');
        sb.append("minAge");
        sb.append('=');
        sb.append(((this.minAge == null)?"<null>":this.minAge));
        sb.append(',');
        sb.append("maxAge");
        sb.append('=');
        sb.append(((this.maxAge == null)?"<null>":this.maxAge));
        sb.append(',');
        sb.append("minAgeMeasureUnit");
        sb.append('=');
        sb.append(((this.minAgeMeasureUnit == null)?"<null>":this.minAgeMeasureUnit));
        sb.append(',');
        sb.append("maxAgeMeasureUnit");
        sb.append('=');
        sb.append(((this.maxAgeMeasureUnit == null)?"<null>":this.maxAgeMeasureUnit));
        sb.append(',');
        sb.append("minAmt");
        sb.append('=');
        sb.append(((this.minAmt == null)?"<null>":this.minAmt));
        sb.append(',');
        sb.append("maxAmt");
        sb.append('=');
        sb.append(((this.maxAmt == null)?"<null>":this.maxAmt));
        sb.append(',');
        sb.append("minPct");
        sb.append('=');
        sb.append(((this.minPct == null)?"<null>":this.minPct));
        sb.append(',');
        sb.append("maxPct");
        sb.append('=');
        sb.append(((this.maxPct == null)?"<null>":this.maxPct));
        sb.append(',');
        sb.append("minUnits");
        sb.append('=');
        sb.append(((this.minUnits == null)?"<null>":this.minUnits));
        sb.append(',');
        sb.append("maxUnits");
        sb.append('=');
        sb.append(((this.maxUnits == null)?"<null>":this.maxUnits));
        sb.append(',');
        sb.append("minRatioToBase");
        sb.append('=');
        sb.append(((this.minRatioToBase == null)?"<null>":this.minRatioToBase));
        sb.append(',');
        sb.append("maxRatioToBase");
        sb.append('=');
        sb.append(((this.maxRatioToBase == null)?"<null>":this.maxRatioToBase));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.ageBasisType == null)? 0 :this.ageBasisType.hashCode()));
        result = ((result* 31)+((this.maxRatioToBase == null)? 0 :this.maxRatioToBase.hashCode()));
        result = ((result* 31)+((this.maxAgeMeasureUnit == null)? 0 :this.maxAgeMeasureUnit.hashCode()));
        result = ((result* 31)+((this.ageAmtProductSysKey == null)? 0 :this.ageAmtProductSysKey.hashCode()));
        result = ((result* 31)+((this.maxUnits == null)? 0 :this.maxUnits.hashCode()));
        result = ((result* 31)+((this.maxAmt == null)? 0 :this.maxAmt.hashCode()));
        result = ((result* 31)+((this.minAgeMeasureUnit == null)? 0 :this.minAgeMeasureUnit.hashCode()));
        result = ((result* 31)+((this.minAmt == null)? 0 :this.minAmt.hashCode()));
        result = ((result* 31)+((this.maxPct == null)? 0 :this.maxPct.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.minPct == null)? 0 :this.minPct.hashCode()));
        result = ((result* 31)+((this.maxAge == null)? 0 :this.maxAge.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.minAge == null)? 0 :this.minAge.hashCode()));
        result = ((result* 31)+((this.minUnits == null)? 0 :this.minUnits.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.ageAmtProductKey == null)? 0 :this.ageAmtProductKey.hashCode()));
        result = ((result* 31)+((this.minRatioToBase == null)? 0 :this.minRatioToBase.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AgeAmtProduct) == false) {
            return false;
        }
        AgeAmtProduct rhs = ((AgeAmtProduct) other);
        return ((((((((((((((((((((this.ageBasisType == rhs.ageBasisType)||((this.ageBasisType!= null)&&this.ageBasisType.equals(rhs.ageBasisType)))&&((this.maxRatioToBase == rhs.maxRatioToBase)||((this.maxRatioToBase!= null)&&this.maxRatioToBase.equals(rhs.maxRatioToBase))))&&((this.maxAgeMeasureUnit == rhs.maxAgeMeasureUnit)||((this.maxAgeMeasureUnit!= null)&&this.maxAgeMeasureUnit.equals(rhs.maxAgeMeasureUnit))))&&((this.ageAmtProductSysKey == rhs.ageAmtProductSysKey)||((this.ageAmtProductSysKey!= null)&&this.ageAmtProductSysKey.equals(rhs.ageAmtProductSysKey))))&&((this.maxUnits == rhs.maxUnits)||((this.maxUnits!= null)&&this.maxUnits.equals(rhs.maxUnits))))&&((this.maxAmt == rhs.maxAmt)||((this.maxAmt!= null)&&this.maxAmt.equals(rhs.maxAmt))))&&((this.minAgeMeasureUnit == rhs.minAgeMeasureUnit)||((this.minAgeMeasureUnit!= null)&&this.minAgeMeasureUnit.equals(rhs.minAgeMeasureUnit))))&&((this.minAmt == rhs.minAmt)||((this.minAmt!= null)&&this.minAmt.equals(rhs.minAmt))))&&((this.maxPct == rhs.maxPct)||((this.maxPct!= null)&&this.maxPct.equals(rhs.maxPct))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.minPct == rhs.minPct)||((this.minPct!= null)&&this.minPct.equals(rhs.minPct))))&&((this.maxAge == rhs.maxAge)||((this.maxAge!= null)&&this.maxAge.equals(rhs.maxAge))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.minAge == rhs.minAge)||((this.minAge!= null)&&this.minAge.equals(rhs.minAge))))&&((this.minUnits == rhs.minUnits)||((this.minUnits!= null)&&this.minUnits.equals(rhs.minUnits))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.ageAmtProductKey == rhs.ageAmtProductKey)||((this.ageAmtProductKey!= null)&&this.ageAmtProductKey.equals(rhs.ageAmtProductKey))))&&((this.minRatioToBase == rhs.minRatioToBase)||((this.minRatioToBase!= null)&&this.minRatioToBase.equals(rhs.minRatioToBase))));
    }

}
