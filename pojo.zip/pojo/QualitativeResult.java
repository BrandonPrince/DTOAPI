
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "QualitativeResultKey",
    "QualitativeResultSysKey",
    "ValueCode",
    "ValueString",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class QualitativeResult {

    @JsonProperty("QualitativeResultKey")
    private QualitativeResultKey qualitativeResultKey;
    @JsonProperty("QualitativeResultSysKey")
    private List<Object> qualitativeResultSysKey = new ArrayList<>();
    @JsonProperty("ValueCode")
    private ValueCode valueCode;
    @JsonProperty("ValueString")
    private String valueString;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("QualitativeResultKey")
    public QualitativeResultKey getQualitativeResultKey() {
        return qualitativeResultKey;
    }

    @JsonProperty("QualitativeResultKey")
    public void setQualitativeResultKey(QualitativeResultKey qualitativeResultKey) {
        this.qualitativeResultKey = qualitativeResultKey;
    }

    public QualitativeResult withQualitativeResultKey(QualitativeResultKey qualitativeResultKey) {
        this.qualitativeResultKey = qualitativeResultKey;
        return this;
    }

    @JsonProperty("QualitativeResultSysKey")
    public List<Object> getQualitativeResultSysKey() {
        return qualitativeResultSysKey;
    }

    @JsonProperty("QualitativeResultSysKey")
    public void setQualitativeResultSysKey(List<Object> qualitativeResultSysKey) {
        this.qualitativeResultSysKey = qualitativeResultSysKey;
    }

    public QualitativeResult withQualitativeResultSysKey(List<Object> qualitativeResultSysKey) {
        this.qualitativeResultSysKey = qualitativeResultSysKey;
        return this;
    }

    @JsonProperty("ValueCode")
    public ValueCode getValueCode() {
        return valueCode;
    }

    @JsonProperty("ValueCode")
    public void setValueCode(ValueCode valueCode) {
        this.valueCode = valueCode;
    }

    public QualitativeResult withValueCode(ValueCode valueCode) {
        this.valueCode = valueCode;
        return this;
    }

    @JsonProperty("ValueString")
    public String getValueString() {
        return valueString;
    }

    @JsonProperty("ValueString")
    public void setValueString(String valueString) {
        this.valueString = valueString;
    }

    public QualitativeResult withValueString(String valueString) {
        this.valueString = valueString;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public QualitativeResult withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public QualitativeResult withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public QualitativeResult withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public QualitativeResult withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(QualitativeResult.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("qualitativeResultKey");
        sb.append('=');
        sb.append(((this.qualitativeResultKey == null)?"<null>":this.qualitativeResultKey));
        sb.append(',');
        sb.append("qualitativeResultSysKey");
        sb.append('=');
        sb.append(((this.qualitativeResultSysKey == null)?"<null>":this.qualitativeResultSysKey));
        sb.append(',');
        sb.append("valueCode");
        sb.append('=');
        sb.append(((this.valueCode == null)?"<null>":this.valueCode));
        sb.append(',');
        sb.append("valueString");
        sb.append('=');
        sb.append(((this.valueString == null)?"<null>":this.valueString));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.qualitativeResultKey == null)? 0 :this.qualitativeResultKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.valueString == null)? 0 :this.valueString.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.valueCode == null)? 0 :this.valueCode.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.qualitativeResultSysKey == null)? 0 :this.qualitativeResultSysKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof QualitativeResult) == false) {
            return false;
        }
        QualitativeResult rhs = ((QualitativeResult) other);
        return (((((((((this.qualitativeResultKey == rhs.qualitativeResultKey)||((this.qualitativeResultKey!= null)&&this.qualitativeResultKey.equals(rhs.qualitativeResultKey)))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.valueString == rhs.valueString)||((this.valueString!= null)&&this.valueString.equals(rhs.valueString))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.valueCode == rhs.valueCode)||((this.valueCode!= null)&&this.valueCode.equals(rhs.valueCode))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.qualitativeResultSysKey == rhs.qualitativeResultSysKey)||((this.qualitativeResultSysKey!= null)&&this.qualitativeResultSysKey.equals(rhs.qualitativeResultSysKey))));
    }

}
