
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "PhoneKey",
    "PhoneSysKey",
    "PhoneTypeCode",
    "CountryCode",
    "AreaCode",
    "DialNumber",
    "AliasDialNumber",
    "Ext",
    "PrefPhone",
    "BestTimeToCallFrom",
    "BestTimeToCallTo",
    "InvalidInd",
    "SolicitationInd",
    "StartDate",
    "EndDate",
    "RecurringEndMoDay",
    "RecurringStartMoDay",
    "PhoneCountryTC",
    "TTYInd",
    "Sequence",
    "BestDayToCallCC",
    "SpeedDial",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class Phone {

    @JsonProperty("PhoneKey")
    private PhoneKey phoneKey;
    @JsonProperty("PhoneSysKey")
    private List<Object> phoneSysKey = new ArrayList<>();
    @JsonProperty("PhoneTypeCode")
    private PhoneTypeCode phoneTypeCode;
    @JsonProperty("CountryCode")
    private String countryCode;
    @JsonProperty("AreaCode")
    private String areaCode;
    @JsonProperty("DialNumber")
    private String dialNumber;
    @JsonProperty("AliasDialNumber")
    private String aliasDialNumber;
    @JsonProperty("Ext")
    private String ext;
    @JsonProperty("PrefPhone")
    private PrefPhone prefPhone;
    @JsonProperty("BestTimeToCallFrom")
    private String bestTimeToCallFrom;
    @JsonProperty("BestTimeToCallTo")
    private String bestTimeToCallTo;
    @JsonProperty("InvalidInd")
    private InvalidInd invalidInd;
    @JsonProperty("SolicitationInd")
    private SolicitationInd solicitationInd;
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("RecurringEndMoDay")
    private String recurringEndMoDay;
    @JsonProperty("RecurringStartMoDay")
    private String recurringStartMoDay;
    @JsonProperty("PhoneCountryTC")
    private PhoneCountryTC phoneCountryTC;
    @JsonProperty("TTYInd")
    private TTYInd tTYInd;
    @JsonProperty("Sequence")
    private Integer sequence;
    @JsonProperty("BestDayToCallCC")
    private BestDayToCallCC bestDayToCallCC;
    @JsonProperty("SpeedDial")
    private List<Object> speedDial = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("PhoneKey")
    public PhoneKey getPhoneKey() {
        return phoneKey;
    }

    @JsonProperty("PhoneKey")
    public void setPhoneKey(PhoneKey phoneKey) {
        this.phoneKey = phoneKey;
    }

    public Phone withPhoneKey(PhoneKey phoneKey) {
        this.phoneKey = phoneKey;
        return this;
    }

    @JsonProperty("PhoneSysKey")
    public List<Object> getPhoneSysKey() {
        return phoneSysKey;
    }

    @JsonProperty("PhoneSysKey")
    public void setPhoneSysKey(List<Object> phoneSysKey) {
        this.phoneSysKey = phoneSysKey;
    }

    public Phone withPhoneSysKey(List<Object> phoneSysKey) {
        this.phoneSysKey = phoneSysKey;
        return this;
    }

    @JsonProperty("PhoneTypeCode")
    public PhoneTypeCode getPhoneTypeCode() {
        return phoneTypeCode;
    }

    @JsonProperty("PhoneTypeCode")
    public void setPhoneTypeCode(PhoneTypeCode phoneTypeCode) {
        this.phoneTypeCode = phoneTypeCode;
    }

    public Phone withPhoneTypeCode(PhoneTypeCode phoneTypeCode) {
        this.phoneTypeCode = phoneTypeCode;
        return this;
    }

    @JsonProperty("CountryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("CountryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Phone withCountryCode(String countryCode) {
        this.countryCode = countryCode;
        return this;
    }

    @JsonProperty("AreaCode")
    public String getAreaCode() {
        return areaCode;
    }

    @JsonProperty("AreaCode")
    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public Phone withAreaCode(String areaCode) {
        this.areaCode = areaCode;
        return this;
    }

    @JsonProperty("DialNumber")
    public String getDialNumber() {
        return dialNumber;
    }

    @JsonProperty("DialNumber")
    public void setDialNumber(String dialNumber) {
        this.dialNumber = dialNumber;
    }

    public Phone withDialNumber(String dialNumber) {
        this.dialNumber = dialNumber;
        return this;
    }

    @JsonProperty("AliasDialNumber")
    public String getAliasDialNumber() {
        return aliasDialNumber;
    }

    @JsonProperty("AliasDialNumber")
    public void setAliasDialNumber(String aliasDialNumber) {
        this.aliasDialNumber = aliasDialNumber;
    }

    public Phone withAliasDialNumber(String aliasDialNumber) {
        this.aliasDialNumber = aliasDialNumber;
        return this;
    }

    @JsonProperty("Ext")
    public String getExt() {
        return ext;
    }

    @JsonProperty("Ext")
    public void setExt(String ext) {
        this.ext = ext;
    }

    public Phone withExt(String ext) {
        this.ext = ext;
        return this;
    }

    @JsonProperty("PrefPhone")
    public PrefPhone getPrefPhone() {
        return prefPhone;
    }

    @JsonProperty("PrefPhone")
    public void setPrefPhone(PrefPhone prefPhone) {
        this.prefPhone = prefPhone;
    }

    public Phone withPrefPhone(PrefPhone prefPhone) {
        this.prefPhone = prefPhone;
        return this;
    }

    @JsonProperty("BestTimeToCallFrom")
    public String getBestTimeToCallFrom() {
        return bestTimeToCallFrom;
    }

    @JsonProperty("BestTimeToCallFrom")
    public void setBestTimeToCallFrom(String bestTimeToCallFrom) {
        this.bestTimeToCallFrom = bestTimeToCallFrom;
    }

    public Phone withBestTimeToCallFrom(String bestTimeToCallFrom) {
        this.bestTimeToCallFrom = bestTimeToCallFrom;
        return this;
    }

    @JsonProperty("BestTimeToCallTo")
    public String getBestTimeToCallTo() {
        return bestTimeToCallTo;
    }

    @JsonProperty("BestTimeToCallTo")
    public void setBestTimeToCallTo(String bestTimeToCallTo) {
        this.bestTimeToCallTo = bestTimeToCallTo;
    }

    public Phone withBestTimeToCallTo(String bestTimeToCallTo) {
        this.bestTimeToCallTo = bestTimeToCallTo;
        return this;
    }

    @JsonProperty("InvalidInd")
    public InvalidInd getInvalidInd() {
        return invalidInd;
    }

    @JsonProperty("InvalidInd")
    public void setInvalidInd(InvalidInd invalidInd) {
        this.invalidInd = invalidInd;
    }

    public Phone withInvalidInd(InvalidInd invalidInd) {
        this.invalidInd = invalidInd;
        return this;
    }

    @JsonProperty("SolicitationInd")
    public SolicitationInd getSolicitationInd() {
        return solicitationInd;
    }

    @JsonProperty("SolicitationInd")
    public void setSolicitationInd(SolicitationInd solicitationInd) {
        this.solicitationInd = solicitationInd;
    }

    public Phone withSolicitationInd(SolicitationInd solicitationInd) {
        this.solicitationInd = solicitationInd;
        return this;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public Phone withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Phone withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("RecurringEndMoDay")
    public String getRecurringEndMoDay() {
        return recurringEndMoDay;
    }

    @JsonProperty("RecurringEndMoDay")
    public void setRecurringEndMoDay(String recurringEndMoDay) {
        this.recurringEndMoDay = recurringEndMoDay;
    }

    public Phone withRecurringEndMoDay(String recurringEndMoDay) {
        this.recurringEndMoDay = recurringEndMoDay;
        return this;
    }

    @JsonProperty("RecurringStartMoDay")
    public String getRecurringStartMoDay() {
        return recurringStartMoDay;
    }

    @JsonProperty("RecurringStartMoDay")
    public void setRecurringStartMoDay(String recurringStartMoDay) {
        this.recurringStartMoDay = recurringStartMoDay;
    }

    public Phone withRecurringStartMoDay(String recurringStartMoDay) {
        this.recurringStartMoDay = recurringStartMoDay;
        return this;
    }

    @JsonProperty("PhoneCountryTC")
    public PhoneCountryTC getPhoneCountryTC() {
        return phoneCountryTC;
    }

    @JsonProperty("PhoneCountryTC")
    public void setPhoneCountryTC(PhoneCountryTC phoneCountryTC) {
        this.phoneCountryTC = phoneCountryTC;
    }

    public Phone withPhoneCountryTC(PhoneCountryTC phoneCountryTC) {
        this.phoneCountryTC = phoneCountryTC;
        return this;
    }

    @JsonProperty("TTYInd")
    public TTYInd getTTYInd() {
        return tTYInd;
    }

    @JsonProperty("TTYInd")
    public void setTTYInd(TTYInd tTYInd) {
        this.tTYInd = tTYInd;
    }

    public Phone withTTYInd(TTYInd tTYInd) {
        this.tTYInd = tTYInd;
        return this;
    }

    @JsonProperty("Sequence")
    public Integer getSequence() {
        return sequence;
    }

    @JsonProperty("Sequence")
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public Phone withSequence(Integer sequence) {
        this.sequence = sequence;
        return this;
    }

    @JsonProperty("BestDayToCallCC")
    public BestDayToCallCC getBestDayToCallCC() {
        return bestDayToCallCC;
    }

    @JsonProperty("BestDayToCallCC")
    public void setBestDayToCallCC(BestDayToCallCC bestDayToCallCC) {
        this.bestDayToCallCC = bestDayToCallCC;
    }

    public Phone withBestDayToCallCC(BestDayToCallCC bestDayToCallCC) {
        this.bestDayToCallCC = bestDayToCallCC;
        return this;
    }

    @JsonProperty("SpeedDial")
    public List<Object> getSpeedDial() {
        return speedDial;
    }

    @JsonProperty("SpeedDial")
    public void setSpeedDial(List<Object> speedDial) {
        this.speedDial = speedDial;
    }

    public Phone withSpeedDial(List<Object> speedDial) {
        this.speedDial = speedDial;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Phone withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Phone withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public Phone withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Phone withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Phone.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("phoneKey");
        sb.append('=');
        sb.append(((this.phoneKey == null)?"<null>":this.phoneKey));
        sb.append(',');
        sb.append("phoneSysKey");
        sb.append('=');
        sb.append(((this.phoneSysKey == null)?"<null>":this.phoneSysKey));
        sb.append(',');
        sb.append("phoneTypeCode");
        sb.append('=');
        sb.append(((this.phoneTypeCode == null)?"<null>":this.phoneTypeCode));
        sb.append(',');
        sb.append("countryCode");
        sb.append('=');
        sb.append(((this.countryCode == null)?"<null>":this.countryCode));
        sb.append(',');
        sb.append("areaCode");
        sb.append('=');
        sb.append(((this.areaCode == null)?"<null>":this.areaCode));
        sb.append(',');
        sb.append("dialNumber");
        sb.append('=');
        sb.append(((this.dialNumber == null)?"<null>":this.dialNumber));
        sb.append(',');
        sb.append("aliasDialNumber");
        sb.append('=');
        sb.append(((this.aliasDialNumber == null)?"<null>":this.aliasDialNumber));
        sb.append(',');
        sb.append("ext");
        sb.append('=');
        sb.append(((this.ext == null)?"<null>":this.ext));
        sb.append(',');
        sb.append("prefPhone");
        sb.append('=');
        sb.append(((this.prefPhone == null)?"<null>":this.prefPhone));
        sb.append(',');
        sb.append("bestTimeToCallFrom");
        sb.append('=');
        sb.append(((this.bestTimeToCallFrom == null)?"<null>":this.bestTimeToCallFrom));
        sb.append(',');
        sb.append("bestTimeToCallTo");
        sb.append('=');
        sb.append(((this.bestTimeToCallTo == null)?"<null>":this.bestTimeToCallTo));
        sb.append(',');
        sb.append("invalidInd");
        sb.append('=');
        sb.append(((this.invalidInd == null)?"<null>":this.invalidInd));
        sb.append(',');
        sb.append("solicitationInd");
        sb.append('=');
        sb.append(((this.solicitationInd == null)?"<null>":this.solicitationInd));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("recurringEndMoDay");
        sb.append('=');
        sb.append(((this.recurringEndMoDay == null)?"<null>":this.recurringEndMoDay));
        sb.append(',');
        sb.append("recurringStartMoDay");
        sb.append('=');
        sb.append(((this.recurringStartMoDay == null)?"<null>":this.recurringStartMoDay));
        sb.append(',');
        sb.append("phoneCountryTC");
        sb.append('=');
        sb.append(((this.phoneCountryTC == null)?"<null>":this.phoneCountryTC));
        sb.append(',');
        sb.append("tTYInd");
        sb.append('=');
        sb.append(((this.tTYInd == null)?"<null>":this.tTYInd));
        sb.append(',');
        sb.append("sequence");
        sb.append('=');
        sb.append(((this.sequence == null)?"<null>":this.sequence));
        sb.append(',');
        sb.append("bestDayToCallCC");
        sb.append('=');
        sb.append(((this.bestDayToCallCC == null)?"<null>":this.bestDayToCallCC));
        sb.append(',');
        sb.append("speedDial");
        sb.append('=');
        sb.append(((this.speedDial == null)?"<null>":this.speedDial));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.speedDial == null)? 0 :this.speedDial.hashCode()));
        result = ((result* 31)+((this.phoneSysKey == null)? 0 :this.phoneSysKey.hashCode()));
        result = ((result* 31)+((this.recurringEndMoDay == null)? 0 :this.recurringEndMoDay.hashCode()));
        result = ((result* 31)+((this.aliasDialNumber == null)? 0 :this.aliasDialNumber.hashCode()));
        result = ((result* 31)+((this.bestDayToCallCC == null)? 0 :this.bestDayToCallCC.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.countryCode == null)? 0 :this.countryCode.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.bestTimeToCallTo == null)? 0 :this.bestTimeToCallTo.hashCode()));
        result = ((result* 31)+((this.tTYInd == null)? 0 :this.tTYInd.hashCode()));
        result = ((result* 31)+((this.ext == null)? 0 :this.ext.hashCode()));
        result = ((result* 31)+((this.phoneKey == null)? 0 :this.phoneKey.hashCode()));
        result = ((result* 31)+((this.invalidInd == null)? 0 :this.invalidInd.hashCode()));
        result = ((result* 31)+((this.dialNumber == null)? 0 :this.dialNumber.hashCode()));
        result = ((result* 31)+((this.phoneTypeCode == null)? 0 :this.phoneTypeCode.hashCode()));
        result = ((result* 31)+((this.solicitationInd == null)? 0 :this.solicitationInd.hashCode()));
        result = ((result* 31)+((this.phoneCountryTC == null)? 0 :this.phoneCountryTC.hashCode()));
        result = ((result* 31)+((this.recurringStartMoDay == null)? 0 :this.recurringStartMoDay.hashCode()));
        result = ((result* 31)+((this.sequence == null)? 0 :this.sequence.hashCode()));
        result = ((result* 31)+((this.areaCode == null)? 0 :this.areaCode.hashCode()));
        result = ((result* 31)+((this.bestTimeToCallFrom == null)? 0 :this.bestTimeToCallFrom.hashCode()));
        result = ((result* 31)+((this.prefPhone == null)? 0 :this.prefPhone.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Phone) == false) {
            return false;
        }
        Phone rhs = ((Phone) other);
        return (((((((((((((((((((((((((((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate)))&&((this.speedDial == rhs.speedDial)||((this.speedDial!= null)&&this.speedDial.equals(rhs.speedDial))))&&((this.phoneSysKey == rhs.phoneSysKey)||((this.phoneSysKey!= null)&&this.phoneSysKey.equals(rhs.phoneSysKey))))&&((this.recurringEndMoDay == rhs.recurringEndMoDay)||((this.recurringEndMoDay!= null)&&this.recurringEndMoDay.equals(rhs.recurringEndMoDay))))&&((this.aliasDialNumber == rhs.aliasDialNumber)||((this.aliasDialNumber!= null)&&this.aliasDialNumber.equals(rhs.aliasDialNumber))))&&((this.bestDayToCallCC == rhs.bestDayToCallCC)||((this.bestDayToCallCC!= null)&&this.bestDayToCallCC.equals(rhs.bestDayToCallCC))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.countryCode == rhs.countryCode)||((this.countryCode!= null)&&this.countryCode.equals(rhs.countryCode))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.bestTimeToCallTo == rhs.bestTimeToCallTo)||((this.bestTimeToCallTo!= null)&&this.bestTimeToCallTo.equals(rhs.bestTimeToCallTo))))&&((this.tTYInd == rhs.tTYInd)||((this.tTYInd!= null)&&this.tTYInd.equals(rhs.tTYInd))))&&((this.ext == rhs.ext)||((this.ext!= null)&&this.ext.equals(rhs.ext))))&&((this.phoneKey == rhs.phoneKey)||((this.phoneKey!= null)&&this.phoneKey.equals(rhs.phoneKey))))&&((this.invalidInd == rhs.invalidInd)||((this.invalidInd!= null)&&this.invalidInd.equals(rhs.invalidInd))))&&((this.dialNumber == rhs.dialNumber)||((this.dialNumber!= null)&&this.dialNumber.equals(rhs.dialNumber))))&&((this.phoneTypeCode == rhs.phoneTypeCode)||((this.phoneTypeCode!= null)&&this.phoneTypeCode.equals(rhs.phoneTypeCode))))&&((this.solicitationInd == rhs.solicitationInd)||((this.solicitationInd!= null)&&this.solicitationInd.equals(rhs.solicitationInd))))&&((this.phoneCountryTC == rhs.phoneCountryTC)||((this.phoneCountryTC!= null)&&this.phoneCountryTC.equals(rhs.phoneCountryTC))))&&((this.recurringStartMoDay == rhs.recurringStartMoDay)||((this.recurringStartMoDay!= null)&&this.recurringStartMoDay.equals(rhs.recurringStartMoDay))))&&((this.sequence == rhs.sequence)||((this.sequence!= null)&&this.sequence.equals(rhs.sequence))))&&((this.areaCode == rhs.areaCode)||((this.areaCode!= null)&&this.areaCode.equals(rhs.areaCode))))&&((this.bestTimeToCallFrom == rhs.bestTimeToCallFrom)||((this.bestTimeToCallFrom!= null)&&this.bestTimeToCallFrom.equals(rhs.bestTimeToCallFrom))))&&((this.prefPhone == rhs.prefPhone)||((this.prefPhone!= null)&&this.prefPhone.equals(rhs.prefPhone))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))));
    }

}
