
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CovOptionKey",
    "CovOptionSysKey",
    "ShortName",
    "MarketingName",
    "PlanName",
    "ProductCode",
    "ProductVersionCode",
    "FormNo",
    "ClassName",
    "CovOptionStatus",
    "IssueType",
    "IssueSubType",
    "LifeCovOptTypeCode",
    "ExpiryDate",
    "RatingReason",
    "RatingOverriddenInd",
    "RatingCommissionRule",
    "TobaccoPremiumBasis",
    "PermTableRating",
    "PermTableRatingEndDate",
    "TempTableRating",
    "TempTableRatingStartDate",
    "TempTableRatingEndDate",
    "QualAddBenefitInd",
    "LivesType",
    "IssuedAsAppliedInd",
    "UnderwritingClass",
    "UnderwritingSubClass",
    "PremSourceType",
    "AnnualPremAmt",
    "ModalPremAmt",
    "CovOptionPctInd",
    "OptionAmt",
    "OptionPct",
    "OptionPctType",
    "OptionNumberOfUnits",
    "ValuePerUnit",
    "DeathBenefitAmt",
    "TempFlatExtraAmt",
    "TempFlatEndDate",
    "PermFlatExtraAmt",
    "PermFlatExtraEndDate",
    "FlatExtraPremBasis",
    "ModalGrossFlatExtraPremAmt",
    "ModalGrossFlatExtraAllowanceAmt",
    "EffDate",
    "ExerciseDate",
    "TermDate",
    "GracePeriodStartDate",
    "TempPercentageLoading",
    "PermPercentageLoading",
    "FiledFormNumber",
    "EliminationPeriod",
    "BenefitPeriod",
    "BenefitMode",
    "PremiumPerUnit",
    "PremiumRatePerUnit",
    "RenewalPremiumPerUnit",
    "RenewalPremiumRatePerUnit",
    "MaxBenefitAmt",
    "CommissionLink",
    "AddedDate",
    "ModalGrossPermFlatAllowAmt",
    "PermTableRatingAlphaCode",
    "TempTableRatingCode",
    "ModalGrossTempFlatAllowAmt",
    "PaidUpDate",
    "TempFlatExtraDuration",
    "CovOptionNumber",
    "TempFlatStartDate",
    "GuidelineAnnPrem",
    "GuidelineAnnPremSum",
    "GuidelineSinglePrem",
    "Mec7DBLowest",
    "SECGuidelinePrem",
    "MinPremAmt",
    "TargetPremAmtATD",
    "TargetPremAmtITD",
    "TargetPremAmtMTD",
    "TargetPremAmtYTD",
    "GDBPrem",
    "Duration",
    "DurationDesign",
    "PreExistingConditionInd",
    "ChildMatureAge",
    "ChildAgeUse",
    "BenefitCoordinationInd",
    "TargetPremAmt",
    "AnnualIndexType",
    "PayToAge",
    "PayToYear",
    "PermRatingAmtPerThou",
    "TempRatingAmtPerThou",
    "TempFlatExtraOverrideEndDate",
    "TempFlatExtraOverrideEffDate",
    "Occupation",
    "OccupRating",
    "LastRatingDate",
    "TempRatingType",
    "PermRatingType",
    "LevelPremiumPeriod",
    "LevelPremiumPeriodUnits",
    "PaymentStructure",
    "CommissionRate",
    "Description",
    "ERContribAmt",
    "EEContribAmt",
    "ERContribPct",
    "EEContribPct",
    "UpgradeAvailableInd",
    "ModalPermRatingAmt",
    "ModalTempRatingAmt",
    "NetCurrentAmt",
    "ReinsuranceInfo",
    "SubstandardRating",
    "CovOptionXLat",
    "Participant",
    "BenefitLimit",
    "DeductionOption",
    "RestrictionInfo",
    "GroupCovOption",
    "Attachment",
    "ConditionTypeOption",
    "AltPremMode",
    "KeyedValue",
    "OLifEExtension",
    "id",
    "LifeParticipantRefID",
    "CarrierLicenseID",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class CovOption {

    @JsonProperty("CovOptionKey")
    private CovOptionKey covOptionKey;
    @JsonProperty("CovOptionSysKey")
    private List<Object> covOptionSysKey = new ArrayList<>();
    @JsonProperty("ShortName")
    private String shortName;
    @JsonProperty("MarketingName")
    private String marketingName;
    @JsonProperty("PlanName")
    private String planName;
    @JsonProperty("ProductCode")
    private String productCode;
    @JsonProperty("ProductVersionCode")
    private String productVersionCode;
    @JsonProperty("FormNo")
    private String formNo;
    @JsonProperty("ClassName")
    private String className;
    @JsonProperty("CovOptionStatus")
    private CovOptionStatus covOptionStatus;
    @JsonProperty("IssueType")
    private IssueType issueType;
    @JsonProperty("IssueSubType")
    private IssueSubType issueSubType;
    @JsonProperty("LifeCovOptTypeCode")
    private LifeCovOptTypeCode lifeCovOptTypeCode;
    @JsonProperty("ExpiryDate")
    private String expiryDate;
    @JsonProperty("RatingReason")
    private String ratingReason;
    @JsonProperty("RatingOverriddenInd")
    private RatingOverriddenInd ratingOverriddenInd;
    @JsonProperty("RatingCommissionRule")
    private RatingCommissionRule ratingCommissionRule;
    @JsonProperty("TobaccoPremiumBasis")
    private TobaccoPremiumBasis tobaccoPremiumBasis;
    @JsonProperty("PermTableRating")
    private PermTableRating permTableRating;
    @JsonProperty("PermTableRatingEndDate")
    private String permTableRatingEndDate;
    @JsonProperty("TempTableRating")
    private TempTableRating tempTableRating;
    @JsonProperty("TempTableRatingStartDate")
    private String tempTableRatingStartDate;
    @JsonProperty("TempTableRatingEndDate")
    private String tempTableRatingEndDate;
    @JsonProperty("QualAddBenefitInd")
    private QualAddBenefitInd qualAddBenefitInd;
    @JsonProperty("LivesType")
    private LivesType livesType;
    @JsonProperty("IssuedAsAppliedInd")
    private IssuedAsAppliedInd issuedAsAppliedInd;
    @JsonProperty("UnderwritingClass")
    private UnderwritingClass underwritingClass;
    @JsonProperty("UnderwritingSubClass")
    private UnderwritingSubClass underwritingSubClass;
    @JsonProperty("PremSourceType")
    private PremSourceType premSourceType;
    @JsonProperty("AnnualPremAmt")
    private Integer annualPremAmt;
    @JsonProperty("ModalPremAmt")
    private Integer modalPremAmt;
    @JsonProperty("CovOptionPctInd")
    private CovOptionPctInd covOptionPctInd;
    @JsonProperty("OptionAmt")
    private Integer optionAmt;
    @JsonProperty("OptionPct")
    private Integer optionPct;
    @JsonProperty("OptionPctType")
    private OptionPctType optionPctType;
    @JsonProperty("OptionNumberOfUnits")
    private Integer optionNumberOfUnits;
    @JsonProperty("ValuePerUnit")
    private Integer valuePerUnit;
    @JsonProperty("DeathBenefitAmt")
    private Integer deathBenefitAmt;
    @JsonProperty("TempFlatExtraAmt")
    private Integer tempFlatExtraAmt;
    @JsonProperty("TempFlatEndDate")
    private String tempFlatEndDate;
    @JsonProperty("PermFlatExtraAmt")
    private Integer permFlatExtraAmt;
    @JsonProperty("PermFlatExtraEndDate")
    private String permFlatExtraEndDate;
    @JsonProperty("FlatExtraPremBasis")
    private FlatExtraPremBasis flatExtraPremBasis;
    @JsonProperty("ModalGrossFlatExtraPremAmt")
    private Integer modalGrossFlatExtraPremAmt;
    @JsonProperty("ModalGrossFlatExtraAllowanceAmt")
    private Integer modalGrossFlatExtraAllowanceAmt;
    @JsonProperty("EffDate")
    private String effDate;
    @JsonProperty("ExerciseDate")
    private String exerciseDate;
    @JsonProperty("TermDate")
    private String termDate;
    @JsonProperty("GracePeriodStartDate")
    private String gracePeriodStartDate;
    @JsonProperty("TempPercentageLoading")
    private Integer tempPercentageLoading;
    @JsonProperty("PermPercentageLoading")
    private Integer permPercentageLoading;
    @JsonProperty("FiledFormNumber")
    private String filedFormNumber;
    @JsonProperty("EliminationPeriod")
    private EliminationPeriod eliminationPeriod;
    @JsonProperty("BenefitPeriod")
    private BenefitPeriod benefitPeriod;
    @JsonProperty("BenefitMode")
    private BenefitMode benefitMode;
    @JsonProperty("PremiumPerUnit")
    private Integer premiumPerUnit;
    @JsonProperty("PremiumRatePerUnit")
    private Integer premiumRatePerUnit;
    @JsonProperty("RenewalPremiumPerUnit")
    private Integer renewalPremiumPerUnit;
    @JsonProperty("RenewalPremiumRatePerUnit")
    private Integer renewalPremiumRatePerUnit;
    @JsonProperty("MaxBenefitAmt")
    private Integer maxBenefitAmt;
    @JsonProperty("CommissionLink")
    private String commissionLink;
    @JsonProperty("AddedDate")
    private String addedDate;
    @JsonProperty("ModalGrossPermFlatAllowAmt")
    private Integer modalGrossPermFlatAllowAmt;
    @JsonProperty("PermTableRatingAlphaCode")
    private String permTableRatingAlphaCode;
    @JsonProperty("TempTableRatingCode")
    private String tempTableRatingCode;
    @JsonProperty("ModalGrossTempFlatAllowAmt")
    private Integer modalGrossTempFlatAllowAmt;
    @JsonProperty("PaidUpDate")
    private String paidUpDate;
    @JsonProperty("TempFlatExtraDuration")
    private Integer tempFlatExtraDuration;
    @JsonProperty("CovOptionNumber")
    private String covOptionNumber;
    @JsonProperty("TempFlatStartDate")
    private String tempFlatStartDate;
    @JsonProperty("GuidelineAnnPrem")
    private Integer guidelineAnnPrem;
    @JsonProperty("GuidelineAnnPremSum")
    private Integer guidelineAnnPremSum;
    @JsonProperty("GuidelineSinglePrem")
    private Integer guidelineSinglePrem;
    @JsonProperty("Mec7DBLowest")
    private Integer mec7DBLowest;
    @JsonProperty("SECGuidelinePrem")
    private Integer sECGuidelinePrem;
    @JsonProperty("MinPremAmt")
    private Integer minPremAmt;
    @JsonProperty("TargetPremAmtATD")
    private Integer targetPremAmtATD;
    @JsonProperty("TargetPremAmtITD")
    private Integer targetPremAmtITD;
    @JsonProperty("TargetPremAmtMTD")
    private Integer targetPremAmtMTD;
    @JsonProperty("TargetPremAmtYTD")
    private Integer targetPremAmtYTD;
    @JsonProperty("GDBPrem")
    private Integer gDBPrem;
    @JsonProperty("Duration")
    private Integer duration;
    @JsonProperty("DurationDesign")
    private Integer durationDesign;
    @JsonProperty("PreExistingConditionInd")
    private PreExistingConditionInd preExistingConditionInd;
    @JsonProperty("ChildMatureAge")
    private Integer childMatureAge;
    @JsonProperty("ChildAgeUse")
    private ChildAgeUse childAgeUse;
    @JsonProperty("BenefitCoordinationInd")
    private BenefitCoordinationInd benefitCoordinationInd;
    @JsonProperty("TargetPremAmt")
    private Integer targetPremAmt;
    @JsonProperty("AnnualIndexType")
    private AnnualIndexType annualIndexType;
    @JsonProperty("PayToAge")
    private Integer payToAge;
    @JsonProperty("PayToYear")
    private Integer payToYear;
    @JsonProperty("PermRatingAmtPerThou")
    private Integer permRatingAmtPerThou;
    @JsonProperty("TempRatingAmtPerThou")
    private Integer tempRatingAmtPerThou;
    @JsonProperty("TempFlatExtraOverrideEndDate")
    private String tempFlatExtraOverrideEndDate;
    @JsonProperty("TempFlatExtraOverrideEffDate")
    private String tempFlatExtraOverrideEffDate;
    @JsonProperty("Occupation")
    private String occupation;
    @JsonProperty("OccupRating")
    private OccupRating occupRating;
    @JsonProperty("LastRatingDate")
    private String lastRatingDate;
    @JsonProperty("TempRatingType")
    private TempRatingType tempRatingType;
    @JsonProperty("PermRatingType")
    private PermRatingType permRatingType;
    @JsonProperty("LevelPremiumPeriod")
    private Integer levelPremiumPeriod;
    @JsonProperty("LevelPremiumPeriodUnits")
    private LevelPremiumPeriodUnits levelPremiumPeriodUnits;
    @JsonProperty("PaymentStructure")
    private PaymentStructure paymentStructure;
    @JsonProperty("CommissionRate")
    private Integer commissionRate;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("ERContribAmt")
    private Integer eRContribAmt;
    @JsonProperty("EEContribAmt")
    private Integer eEContribAmt;
    @JsonProperty("ERContribPct")
    private Integer eRContribPct;
    @JsonProperty("EEContribPct")
    private Integer eEContribPct;
    @JsonProperty("UpgradeAvailableInd")
    private UpgradeAvailableInd upgradeAvailableInd;
    @JsonProperty("ModalPermRatingAmt")
    private Integer modalPermRatingAmt;
    @JsonProperty("ModalTempRatingAmt")
    private Integer modalTempRatingAmt;
    @JsonProperty("NetCurrentAmt")
    private Integer netCurrentAmt;
    @JsonProperty("ReinsuranceInfo")
    private List<Object> reinsuranceInfo = new ArrayList<>();
    @JsonProperty("SubstandardRating")
    private List<Object> substandardRating = new ArrayList<>();
    @JsonProperty("CovOptionXLat")
    private List<Object> covOptionXLat = new ArrayList<>();
    @JsonProperty("Participant")
    private List<Object> participant = new ArrayList<>();
    @JsonProperty("BenefitLimit")
    private List<Object> benefitLimit = new ArrayList<>();
    @JsonProperty("DeductionOption")
    private List<Object> deductionOption = new ArrayList<>();
    @JsonProperty("RestrictionInfo")
    private List<Object> restrictionInfo = new ArrayList<>();
    @JsonProperty("GroupCovOption")
    private GroupCovOption groupCovOption;
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("ConditionTypeOption")
    private List<Object> conditionTypeOption = new ArrayList<>();
    @JsonProperty("AltPremMode")
    private List<Object> altPremMode = new ArrayList<>();
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("LifeParticipantRefID")
    private String lifeParticipantRefID;
    @JsonProperty("CarrierLicenseID")
    private String carrierLicenseID;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("CovOptionKey")
    public CovOptionKey getCovOptionKey() {
        return covOptionKey;
    }

    @JsonProperty("CovOptionKey")
    public void setCovOptionKey(CovOptionKey covOptionKey) {
        this.covOptionKey = covOptionKey;
    }

    public CovOption withCovOptionKey(CovOptionKey covOptionKey) {
        this.covOptionKey = covOptionKey;
        return this;
    }

    @JsonProperty("CovOptionSysKey")
    public List<Object> getCovOptionSysKey() {
        return covOptionSysKey;
    }

    @JsonProperty("CovOptionSysKey")
    public void setCovOptionSysKey(List<Object> covOptionSysKey) {
        this.covOptionSysKey = covOptionSysKey;
    }

    public CovOption withCovOptionSysKey(List<Object> covOptionSysKey) {
        this.covOptionSysKey = covOptionSysKey;
        return this;
    }

    @JsonProperty("ShortName")
    public String getShortName() {
        return shortName;
    }

    @JsonProperty("ShortName")
    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public CovOption withShortName(String shortName) {
        this.shortName = shortName;
        return this;
    }

    @JsonProperty("MarketingName")
    public String getMarketingName() {
        return marketingName;
    }

    @JsonProperty("MarketingName")
    public void setMarketingName(String marketingName) {
        this.marketingName = marketingName;
    }

    public CovOption withMarketingName(String marketingName) {
        this.marketingName = marketingName;
        return this;
    }

    @JsonProperty("PlanName")
    public String getPlanName() {
        return planName;
    }

    @JsonProperty("PlanName")
    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public CovOption withPlanName(String planName) {
        this.planName = planName;
        return this;
    }

    @JsonProperty("ProductCode")
    public String getProductCode() {
        return productCode;
    }

    @JsonProperty("ProductCode")
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public CovOption withProductCode(String productCode) {
        this.productCode = productCode;
        return this;
    }

    @JsonProperty("ProductVersionCode")
    public String getProductVersionCode() {
        return productVersionCode;
    }

    @JsonProperty("ProductVersionCode")
    public void setProductVersionCode(String productVersionCode) {
        this.productVersionCode = productVersionCode;
    }

    public CovOption withProductVersionCode(String productVersionCode) {
        this.productVersionCode = productVersionCode;
        return this;
    }

    @JsonProperty("FormNo")
    public String getFormNo() {
        return formNo;
    }

    @JsonProperty("FormNo")
    public void setFormNo(String formNo) {
        this.formNo = formNo;
    }

    public CovOption withFormNo(String formNo) {
        this.formNo = formNo;
        return this;
    }

    @JsonProperty("ClassName")
    public String getClassName() {
        return className;
    }

    @JsonProperty("ClassName")
    public void setClassName(String className) {
        this.className = className;
    }

    public CovOption withClassName(String className) {
        this.className = className;
        return this;
    }

    @JsonProperty("CovOptionStatus")
    public CovOptionStatus getCovOptionStatus() {
        return covOptionStatus;
    }

    @JsonProperty("CovOptionStatus")
    public void setCovOptionStatus(CovOptionStatus covOptionStatus) {
        this.covOptionStatus = covOptionStatus;
    }

    public CovOption withCovOptionStatus(CovOptionStatus covOptionStatus) {
        this.covOptionStatus = covOptionStatus;
        return this;
    }

    @JsonProperty("IssueType")
    public IssueType getIssueType() {
        return issueType;
    }

    @JsonProperty("IssueType")
    public void setIssueType(IssueType issueType) {
        this.issueType = issueType;
    }

    public CovOption withIssueType(IssueType issueType) {
        this.issueType = issueType;
        return this;
    }

    @JsonProperty("IssueSubType")
    public IssueSubType getIssueSubType() {
        return issueSubType;
    }

    @JsonProperty("IssueSubType")
    public void setIssueSubType(IssueSubType issueSubType) {
        this.issueSubType = issueSubType;
    }

    public CovOption withIssueSubType(IssueSubType issueSubType) {
        this.issueSubType = issueSubType;
        return this;
    }

    @JsonProperty("LifeCovOptTypeCode")
    public LifeCovOptTypeCode getLifeCovOptTypeCode() {
        return lifeCovOptTypeCode;
    }

    @JsonProperty("LifeCovOptTypeCode")
    public void setLifeCovOptTypeCode(LifeCovOptTypeCode lifeCovOptTypeCode) {
        this.lifeCovOptTypeCode = lifeCovOptTypeCode;
    }

    public CovOption withLifeCovOptTypeCode(LifeCovOptTypeCode lifeCovOptTypeCode) {
        this.lifeCovOptTypeCode = lifeCovOptTypeCode;
        return this;
    }

    @JsonProperty("ExpiryDate")
    public String getExpiryDate() {
        return expiryDate;
    }

    @JsonProperty("ExpiryDate")
    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public CovOption withExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
        return this;
    }

    @JsonProperty("RatingReason")
    public String getRatingReason() {
        return ratingReason;
    }

    @JsonProperty("RatingReason")
    public void setRatingReason(String ratingReason) {
        this.ratingReason = ratingReason;
    }

    public CovOption withRatingReason(String ratingReason) {
        this.ratingReason = ratingReason;
        return this;
    }

    @JsonProperty("RatingOverriddenInd")
    public RatingOverriddenInd getRatingOverriddenInd() {
        return ratingOverriddenInd;
    }

    @JsonProperty("RatingOverriddenInd")
    public void setRatingOverriddenInd(RatingOverriddenInd ratingOverriddenInd) {
        this.ratingOverriddenInd = ratingOverriddenInd;
    }

    public CovOption withRatingOverriddenInd(RatingOverriddenInd ratingOverriddenInd) {
        this.ratingOverriddenInd = ratingOverriddenInd;
        return this;
    }

    @JsonProperty("RatingCommissionRule")
    public RatingCommissionRule getRatingCommissionRule() {
        return ratingCommissionRule;
    }

    @JsonProperty("RatingCommissionRule")
    public void setRatingCommissionRule(RatingCommissionRule ratingCommissionRule) {
        this.ratingCommissionRule = ratingCommissionRule;
    }

    public CovOption withRatingCommissionRule(RatingCommissionRule ratingCommissionRule) {
        this.ratingCommissionRule = ratingCommissionRule;
        return this;
    }

    @JsonProperty("TobaccoPremiumBasis")
    public TobaccoPremiumBasis getTobaccoPremiumBasis() {
        return tobaccoPremiumBasis;
    }

    @JsonProperty("TobaccoPremiumBasis")
    public void setTobaccoPremiumBasis(TobaccoPremiumBasis tobaccoPremiumBasis) {
        this.tobaccoPremiumBasis = tobaccoPremiumBasis;
    }

    public CovOption withTobaccoPremiumBasis(TobaccoPremiumBasis tobaccoPremiumBasis) {
        this.tobaccoPremiumBasis = tobaccoPremiumBasis;
        return this;
    }

    @JsonProperty("PermTableRating")
    public PermTableRating getPermTableRating() {
        return permTableRating;
    }

    @JsonProperty("PermTableRating")
    public void setPermTableRating(PermTableRating permTableRating) {
        this.permTableRating = permTableRating;
    }

    public CovOption withPermTableRating(PermTableRating permTableRating) {
        this.permTableRating = permTableRating;
        return this;
    }

    @JsonProperty("PermTableRatingEndDate")
    public String getPermTableRatingEndDate() {
        return permTableRatingEndDate;
    }

    @JsonProperty("PermTableRatingEndDate")
    public void setPermTableRatingEndDate(String permTableRatingEndDate) {
        this.permTableRatingEndDate = permTableRatingEndDate;
    }

    public CovOption withPermTableRatingEndDate(String permTableRatingEndDate) {
        this.permTableRatingEndDate = permTableRatingEndDate;
        return this;
    }

    @JsonProperty("TempTableRating")
    public TempTableRating getTempTableRating() {
        return tempTableRating;
    }

    @JsonProperty("TempTableRating")
    public void setTempTableRating(TempTableRating tempTableRating) {
        this.tempTableRating = tempTableRating;
    }

    public CovOption withTempTableRating(TempTableRating tempTableRating) {
        this.tempTableRating = tempTableRating;
        return this;
    }

    @JsonProperty("TempTableRatingStartDate")
    public String getTempTableRatingStartDate() {
        return tempTableRatingStartDate;
    }

    @JsonProperty("TempTableRatingStartDate")
    public void setTempTableRatingStartDate(String tempTableRatingStartDate) {
        this.tempTableRatingStartDate = tempTableRatingStartDate;
    }

    public CovOption withTempTableRatingStartDate(String tempTableRatingStartDate) {
        this.tempTableRatingStartDate = tempTableRatingStartDate;
        return this;
    }

    @JsonProperty("TempTableRatingEndDate")
    public String getTempTableRatingEndDate() {
        return tempTableRatingEndDate;
    }

    @JsonProperty("TempTableRatingEndDate")
    public void setTempTableRatingEndDate(String tempTableRatingEndDate) {
        this.tempTableRatingEndDate = tempTableRatingEndDate;
    }

    public CovOption withTempTableRatingEndDate(String tempTableRatingEndDate) {
        this.tempTableRatingEndDate = tempTableRatingEndDate;
        return this;
    }

    @JsonProperty("QualAddBenefitInd")
    public QualAddBenefitInd getQualAddBenefitInd() {
        return qualAddBenefitInd;
    }

    @JsonProperty("QualAddBenefitInd")
    public void setQualAddBenefitInd(QualAddBenefitInd qualAddBenefitInd) {
        this.qualAddBenefitInd = qualAddBenefitInd;
    }

    public CovOption withQualAddBenefitInd(QualAddBenefitInd qualAddBenefitInd) {
        this.qualAddBenefitInd = qualAddBenefitInd;
        return this;
    }

    @JsonProperty("LivesType")
    public LivesType getLivesType() {
        return livesType;
    }

    @JsonProperty("LivesType")
    public void setLivesType(LivesType livesType) {
        this.livesType = livesType;
    }

    public CovOption withLivesType(LivesType livesType) {
        this.livesType = livesType;
        return this;
    }

    @JsonProperty("IssuedAsAppliedInd")
    public IssuedAsAppliedInd getIssuedAsAppliedInd() {
        return issuedAsAppliedInd;
    }

    @JsonProperty("IssuedAsAppliedInd")
    public void setIssuedAsAppliedInd(IssuedAsAppliedInd issuedAsAppliedInd) {
        this.issuedAsAppliedInd = issuedAsAppliedInd;
    }

    public CovOption withIssuedAsAppliedInd(IssuedAsAppliedInd issuedAsAppliedInd) {
        this.issuedAsAppliedInd = issuedAsAppliedInd;
        return this;
    }

    @JsonProperty("UnderwritingClass")
    public UnderwritingClass getUnderwritingClass() {
        return underwritingClass;
    }

    @JsonProperty("UnderwritingClass")
    public void setUnderwritingClass(UnderwritingClass underwritingClass) {
        this.underwritingClass = underwritingClass;
    }

    public CovOption withUnderwritingClass(UnderwritingClass underwritingClass) {
        this.underwritingClass = underwritingClass;
        return this;
    }

    @JsonProperty("UnderwritingSubClass")
    public UnderwritingSubClass getUnderwritingSubClass() {
        return underwritingSubClass;
    }

    @JsonProperty("UnderwritingSubClass")
    public void setUnderwritingSubClass(UnderwritingSubClass underwritingSubClass) {
        this.underwritingSubClass = underwritingSubClass;
    }

    public CovOption withUnderwritingSubClass(UnderwritingSubClass underwritingSubClass) {
        this.underwritingSubClass = underwritingSubClass;
        return this;
    }

    @JsonProperty("PremSourceType")
    public PremSourceType getPremSourceType() {
        return premSourceType;
    }

    @JsonProperty("PremSourceType")
    public void setPremSourceType(PremSourceType premSourceType) {
        this.premSourceType = premSourceType;
    }

    public CovOption withPremSourceType(PremSourceType premSourceType) {
        this.premSourceType = premSourceType;
        return this;
    }

    @JsonProperty("AnnualPremAmt")
    public Integer getAnnualPremAmt() {
        return annualPremAmt;
    }

    @JsonProperty("AnnualPremAmt")
    public void setAnnualPremAmt(Integer annualPremAmt) {
        this.annualPremAmt = annualPremAmt;
    }

    public CovOption withAnnualPremAmt(Integer annualPremAmt) {
        this.annualPremAmt = annualPremAmt;
        return this;
    }

    @JsonProperty("ModalPremAmt")
    public Integer getModalPremAmt() {
        return modalPremAmt;
    }

    @JsonProperty("ModalPremAmt")
    public void setModalPremAmt(Integer modalPremAmt) {
        this.modalPremAmt = modalPremAmt;
    }

    public CovOption withModalPremAmt(Integer modalPremAmt) {
        this.modalPremAmt = modalPremAmt;
        return this;
    }

    @JsonProperty("CovOptionPctInd")
    public CovOptionPctInd getCovOptionPctInd() {
        return covOptionPctInd;
    }

    @JsonProperty("CovOptionPctInd")
    public void setCovOptionPctInd(CovOptionPctInd covOptionPctInd) {
        this.covOptionPctInd = covOptionPctInd;
    }

    public CovOption withCovOptionPctInd(CovOptionPctInd covOptionPctInd) {
        this.covOptionPctInd = covOptionPctInd;
        return this;
    }

    @JsonProperty("OptionAmt")
    public Integer getOptionAmt() {
        return optionAmt;
    }

    @JsonProperty("OptionAmt")
    public void setOptionAmt(Integer optionAmt) {
        this.optionAmt = optionAmt;
    }

    public CovOption withOptionAmt(Integer optionAmt) {
        this.optionAmt = optionAmt;
        return this;
    }

    @JsonProperty("OptionPct")
    public Integer getOptionPct() {
        return optionPct;
    }

    @JsonProperty("OptionPct")
    public void setOptionPct(Integer optionPct) {
        this.optionPct = optionPct;
    }

    public CovOption withOptionPct(Integer optionPct) {
        this.optionPct = optionPct;
        return this;
    }

    @JsonProperty("OptionPctType")
    public OptionPctType getOptionPctType() {
        return optionPctType;
    }

    @JsonProperty("OptionPctType")
    public void setOptionPctType(OptionPctType optionPctType) {
        this.optionPctType = optionPctType;
    }

    public CovOption withOptionPctType(OptionPctType optionPctType) {
        this.optionPctType = optionPctType;
        return this;
    }

    @JsonProperty("OptionNumberOfUnits")
    public Integer getOptionNumberOfUnits() {
        return optionNumberOfUnits;
    }

    @JsonProperty("OptionNumberOfUnits")
    public void setOptionNumberOfUnits(Integer optionNumberOfUnits) {
        this.optionNumberOfUnits = optionNumberOfUnits;
    }

    public CovOption withOptionNumberOfUnits(Integer optionNumberOfUnits) {
        this.optionNumberOfUnits = optionNumberOfUnits;
        return this;
    }

    @JsonProperty("ValuePerUnit")
    public Integer getValuePerUnit() {
        return valuePerUnit;
    }

    @JsonProperty("ValuePerUnit")
    public void setValuePerUnit(Integer valuePerUnit) {
        this.valuePerUnit = valuePerUnit;
    }

    public CovOption withValuePerUnit(Integer valuePerUnit) {
        this.valuePerUnit = valuePerUnit;
        return this;
    }

    @JsonProperty("DeathBenefitAmt")
    public Integer getDeathBenefitAmt() {
        return deathBenefitAmt;
    }

    @JsonProperty("DeathBenefitAmt")
    public void setDeathBenefitAmt(Integer deathBenefitAmt) {
        this.deathBenefitAmt = deathBenefitAmt;
    }

    public CovOption withDeathBenefitAmt(Integer deathBenefitAmt) {
        this.deathBenefitAmt = deathBenefitAmt;
        return this;
    }

    @JsonProperty("TempFlatExtraAmt")
    public Integer getTempFlatExtraAmt() {
        return tempFlatExtraAmt;
    }

    @JsonProperty("TempFlatExtraAmt")
    public void setTempFlatExtraAmt(Integer tempFlatExtraAmt) {
        this.tempFlatExtraAmt = tempFlatExtraAmt;
    }

    public CovOption withTempFlatExtraAmt(Integer tempFlatExtraAmt) {
        this.tempFlatExtraAmt = tempFlatExtraAmt;
        return this;
    }

    @JsonProperty("TempFlatEndDate")
    public String getTempFlatEndDate() {
        return tempFlatEndDate;
    }

    @JsonProperty("TempFlatEndDate")
    public void setTempFlatEndDate(String tempFlatEndDate) {
        this.tempFlatEndDate = tempFlatEndDate;
    }

    public CovOption withTempFlatEndDate(String tempFlatEndDate) {
        this.tempFlatEndDate = tempFlatEndDate;
        return this;
    }

    @JsonProperty("PermFlatExtraAmt")
    public Integer getPermFlatExtraAmt() {
        return permFlatExtraAmt;
    }

    @JsonProperty("PermFlatExtraAmt")
    public void setPermFlatExtraAmt(Integer permFlatExtraAmt) {
        this.permFlatExtraAmt = permFlatExtraAmt;
    }

    public CovOption withPermFlatExtraAmt(Integer permFlatExtraAmt) {
        this.permFlatExtraAmt = permFlatExtraAmt;
        return this;
    }

    @JsonProperty("PermFlatExtraEndDate")
    public String getPermFlatExtraEndDate() {
        return permFlatExtraEndDate;
    }

    @JsonProperty("PermFlatExtraEndDate")
    public void setPermFlatExtraEndDate(String permFlatExtraEndDate) {
        this.permFlatExtraEndDate = permFlatExtraEndDate;
    }

    public CovOption withPermFlatExtraEndDate(String permFlatExtraEndDate) {
        this.permFlatExtraEndDate = permFlatExtraEndDate;
        return this;
    }

    @JsonProperty("FlatExtraPremBasis")
    public FlatExtraPremBasis getFlatExtraPremBasis() {
        return flatExtraPremBasis;
    }

    @JsonProperty("FlatExtraPremBasis")
    public void setFlatExtraPremBasis(FlatExtraPremBasis flatExtraPremBasis) {
        this.flatExtraPremBasis = flatExtraPremBasis;
    }

    public CovOption withFlatExtraPremBasis(FlatExtraPremBasis flatExtraPremBasis) {
        this.flatExtraPremBasis = flatExtraPremBasis;
        return this;
    }

    @JsonProperty("ModalGrossFlatExtraPremAmt")
    public Integer getModalGrossFlatExtraPremAmt() {
        return modalGrossFlatExtraPremAmt;
    }

    @JsonProperty("ModalGrossFlatExtraPremAmt")
    public void setModalGrossFlatExtraPremAmt(Integer modalGrossFlatExtraPremAmt) {
        this.modalGrossFlatExtraPremAmt = modalGrossFlatExtraPremAmt;
    }

    public CovOption withModalGrossFlatExtraPremAmt(Integer modalGrossFlatExtraPremAmt) {
        this.modalGrossFlatExtraPremAmt = modalGrossFlatExtraPremAmt;
        return this;
    }

    @JsonProperty("ModalGrossFlatExtraAllowanceAmt")
    public Integer getModalGrossFlatExtraAllowanceAmt() {
        return modalGrossFlatExtraAllowanceAmt;
    }

    @JsonProperty("ModalGrossFlatExtraAllowanceAmt")
    public void setModalGrossFlatExtraAllowanceAmt(Integer modalGrossFlatExtraAllowanceAmt) {
        this.modalGrossFlatExtraAllowanceAmt = modalGrossFlatExtraAllowanceAmt;
    }

    public CovOption withModalGrossFlatExtraAllowanceAmt(Integer modalGrossFlatExtraAllowanceAmt) {
        this.modalGrossFlatExtraAllowanceAmt = modalGrossFlatExtraAllowanceAmt;
        return this;
    }

    @JsonProperty("EffDate")
    public String getEffDate() {
        return effDate;
    }

    @JsonProperty("EffDate")
    public void setEffDate(String effDate) {
        this.effDate = effDate;
    }

    public CovOption withEffDate(String effDate) {
        this.effDate = effDate;
        return this;
    }

    @JsonProperty("ExerciseDate")
    public String getExerciseDate() {
        return exerciseDate;
    }

    @JsonProperty("ExerciseDate")
    public void setExerciseDate(String exerciseDate) {
        this.exerciseDate = exerciseDate;
    }

    public CovOption withExerciseDate(String exerciseDate) {
        this.exerciseDate = exerciseDate;
        return this;
    }

    @JsonProperty("TermDate")
    public String getTermDate() {
        return termDate;
    }

    @JsonProperty("TermDate")
    public void setTermDate(String termDate) {
        this.termDate = termDate;
    }

    public CovOption withTermDate(String termDate) {
        this.termDate = termDate;
        return this;
    }

    @JsonProperty("GracePeriodStartDate")
    public String getGracePeriodStartDate() {
        return gracePeriodStartDate;
    }

    @JsonProperty("GracePeriodStartDate")
    public void setGracePeriodStartDate(String gracePeriodStartDate) {
        this.gracePeriodStartDate = gracePeriodStartDate;
    }

    public CovOption withGracePeriodStartDate(String gracePeriodStartDate) {
        this.gracePeriodStartDate = gracePeriodStartDate;
        return this;
    }

    @JsonProperty("TempPercentageLoading")
    public Integer getTempPercentageLoading() {
        return tempPercentageLoading;
    }

    @JsonProperty("TempPercentageLoading")
    public void setTempPercentageLoading(Integer tempPercentageLoading) {
        this.tempPercentageLoading = tempPercentageLoading;
    }

    public CovOption withTempPercentageLoading(Integer tempPercentageLoading) {
        this.tempPercentageLoading = tempPercentageLoading;
        return this;
    }

    @JsonProperty("PermPercentageLoading")
    public Integer getPermPercentageLoading() {
        return permPercentageLoading;
    }

    @JsonProperty("PermPercentageLoading")
    public void setPermPercentageLoading(Integer permPercentageLoading) {
        this.permPercentageLoading = permPercentageLoading;
    }

    public CovOption withPermPercentageLoading(Integer permPercentageLoading) {
        this.permPercentageLoading = permPercentageLoading;
        return this;
    }

    @JsonProperty("FiledFormNumber")
    public String getFiledFormNumber() {
        return filedFormNumber;
    }

    @JsonProperty("FiledFormNumber")
    public void setFiledFormNumber(String filedFormNumber) {
        this.filedFormNumber = filedFormNumber;
    }

    public CovOption withFiledFormNumber(String filedFormNumber) {
        this.filedFormNumber = filedFormNumber;
        return this;
    }

    @JsonProperty("EliminationPeriod")
    public EliminationPeriod getEliminationPeriod() {
        return eliminationPeriod;
    }

    @JsonProperty("EliminationPeriod")
    public void setEliminationPeriod(EliminationPeriod eliminationPeriod) {
        this.eliminationPeriod = eliminationPeriod;
    }

    public CovOption withEliminationPeriod(EliminationPeriod eliminationPeriod) {
        this.eliminationPeriod = eliminationPeriod;
        return this;
    }

    @JsonProperty("BenefitPeriod")
    public BenefitPeriod getBenefitPeriod() {
        return benefitPeriod;
    }

    @JsonProperty("BenefitPeriod")
    public void setBenefitPeriod(BenefitPeriod benefitPeriod) {
        this.benefitPeriod = benefitPeriod;
    }

    public CovOption withBenefitPeriod(BenefitPeriod benefitPeriod) {
        this.benefitPeriod = benefitPeriod;
        return this;
    }

    @JsonProperty("BenefitMode")
    public BenefitMode getBenefitMode() {
        return benefitMode;
    }

    @JsonProperty("BenefitMode")
    public void setBenefitMode(BenefitMode benefitMode) {
        this.benefitMode = benefitMode;
    }

    public CovOption withBenefitMode(BenefitMode benefitMode) {
        this.benefitMode = benefitMode;
        return this;
    }

    @JsonProperty("PremiumPerUnit")
    public Integer getPremiumPerUnit() {
        return premiumPerUnit;
    }

    @JsonProperty("PremiumPerUnit")
    public void setPremiumPerUnit(Integer premiumPerUnit) {
        this.premiumPerUnit = premiumPerUnit;
    }

    public CovOption withPremiumPerUnit(Integer premiumPerUnit) {
        this.premiumPerUnit = premiumPerUnit;
        return this;
    }

    @JsonProperty("PremiumRatePerUnit")
    public Integer getPremiumRatePerUnit() {
        return premiumRatePerUnit;
    }

    @JsonProperty("PremiumRatePerUnit")
    public void setPremiumRatePerUnit(Integer premiumRatePerUnit) {
        this.premiumRatePerUnit = premiumRatePerUnit;
    }

    public CovOption withPremiumRatePerUnit(Integer premiumRatePerUnit) {
        this.premiumRatePerUnit = premiumRatePerUnit;
        return this;
    }

    @JsonProperty("RenewalPremiumPerUnit")
    public Integer getRenewalPremiumPerUnit() {
        return renewalPremiumPerUnit;
    }

    @JsonProperty("RenewalPremiumPerUnit")
    public void setRenewalPremiumPerUnit(Integer renewalPremiumPerUnit) {
        this.renewalPremiumPerUnit = renewalPremiumPerUnit;
    }

    public CovOption withRenewalPremiumPerUnit(Integer renewalPremiumPerUnit) {
        this.renewalPremiumPerUnit = renewalPremiumPerUnit;
        return this;
    }

    @JsonProperty("RenewalPremiumRatePerUnit")
    public Integer getRenewalPremiumRatePerUnit() {
        return renewalPremiumRatePerUnit;
    }

    @JsonProperty("RenewalPremiumRatePerUnit")
    public void setRenewalPremiumRatePerUnit(Integer renewalPremiumRatePerUnit) {
        this.renewalPremiumRatePerUnit = renewalPremiumRatePerUnit;
    }

    public CovOption withRenewalPremiumRatePerUnit(Integer renewalPremiumRatePerUnit) {
        this.renewalPremiumRatePerUnit = renewalPremiumRatePerUnit;
        return this;
    }

    @JsonProperty("MaxBenefitAmt")
    public Integer getMaxBenefitAmt() {
        return maxBenefitAmt;
    }

    @JsonProperty("MaxBenefitAmt")
    public void setMaxBenefitAmt(Integer maxBenefitAmt) {
        this.maxBenefitAmt = maxBenefitAmt;
    }

    public CovOption withMaxBenefitAmt(Integer maxBenefitAmt) {
        this.maxBenefitAmt = maxBenefitAmt;
        return this;
    }

    @JsonProperty("CommissionLink")
    public String getCommissionLink() {
        return commissionLink;
    }

    @JsonProperty("CommissionLink")
    public void setCommissionLink(String commissionLink) {
        this.commissionLink = commissionLink;
    }

    public CovOption withCommissionLink(String commissionLink) {
        this.commissionLink = commissionLink;
        return this;
    }

    @JsonProperty("AddedDate")
    public String getAddedDate() {
        return addedDate;
    }

    @JsonProperty("AddedDate")
    public void setAddedDate(String addedDate) {
        this.addedDate = addedDate;
    }

    public CovOption withAddedDate(String addedDate) {
        this.addedDate = addedDate;
        return this;
    }

    @JsonProperty("ModalGrossPermFlatAllowAmt")
    public Integer getModalGrossPermFlatAllowAmt() {
        return modalGrossPermFlatAllowAmt;
    }

    @JsonProperty("ModalGrossPermFlatAllowAmt")
    public void setModalGrossPermFlatAllowAmt(Integer modalGrossPermFlatAllowAmt) {
        this.modalGrossPermFlatAllowAmt = modalGrossPermFlatAllowAmt;
    }

    public CovOption withModalGrossPermFlatAllowAmt(Integer modalGrossPermFlatAllowAmt) {
        this.modalGrossPermFlatAllowAmt = modalGrossPermFlatAllowAmt;
        return this;
    }

    @JsonProperty("PermTableRatingAlphaCode")
    public String getPermTableRatingAlphaCode() {
        return permTableRatingAlphaCode;
    }

    @JsonProperty("PermTableRatingAlphaCode")
    public void setPermTableRatingAlphaCode(String permTableRatingAlphaCode) {
        this.permTableRatingAlphaCode = permTableRatingAlphaCode;
    }

    public CovOption withPermTableRatingAlphaCode(String permTableRatingAlphaCode) {
        this.permTableRatingAlphaCode = permTableRatingAlphaCode;
        return this;
    }

    @JsonProperty("TempTableRatingCode")
    public String getTempTableRatingCode() {
        return tempTableRatingCode;
    }

    @JsonProperty("TempTableRatingCode")
    public void setTempTableRatingCode(String tempTableRatingCode) {
        this.tempTableRatingCode = tempTableRatingCode;
    }

    public CovOption withTempTableRatingCode(String tempTableRatingCode) {
        this.tempTableRatingCode = tempTableRatingCode;
        return this;
    }

    @JsonProperty("ModalGrossTempFlatAllowAmt")
    public Integer getModalGrossTempFlatAllowAmt() {
        return modalGrossTempFlatAllowAmt;
    }

    @JsonProperty("ModalGrossTempFlatAllowAmt")
    public void setModalGrossTempFlatAllowAmt(Integer modalGrossTempFlatAllowAmt) {
        this.modalGrossTempFlatAllowAmt = modalGrossTempFlatAllowAmt;
    }

    public CovOption withModalGrossTempFlatAllowAmt(Integer modalGrossTempFlatAllowAmt) {
        this.modalGrossTempFlatAllowAmt = modalGrossTempFlatAllowAmt;
        return this;
    }

    @JsonProperty("PaidUpDate")
    public String getPaidUpDate() {
        return paidUpDate;
    }

    @JsonProperty("PaidUpDate")
    public void setPaidUpDate(String paidUpDate) {
        this.paidUpDate = paidUpDate;
    }

    public CovOption withPaidUpDate(String paidUpDate) {
        this.paidUpDate = paidUpDate;
        return this;
    }

    @JsonProperty("TempFlatExtraDuration")
    public Integer getTempFlatExtraDuration() {
        return tempFlatExtraDuration;
    }

    @JsonProperty("TempFlatExtraDuration")
    public void setTempFlatExtraDuration(Integer tempFlatExtraDuration) {
        this.tempFlatExtraDuration = tempFlatExtraDuration;
    }

    public CovOption withTempFlatExtraDuration(Integer tempFlatExtraDuration) {
        this.tempFlatExtraDuration = tempFlatExtraDuration;
        return this;
    }

    @JsonProperty("CovOptionNumber")
    public String getCovOptionNumber() {
        return covOptionNumber;
    }

    @JsonProperty("CovOptionNumber")
    public void setCovOptionNumber(String covOptionNumber) {
        this.covOptionNumber = covOptionNumber;
    }

    public CovOption withCovOptionNumber(String covOptionNumber) {
        this.covOptionNumber = covOptionNumber;
        return this;
    }

    @JsonProperty("TempFlatStartDate")
    public String getTempFlatStartDate() {
        return tempFlatStartDate;
    }

    @JsonProperty("TempFlatStartDate")
    public void setTempFlatStartDate(String tempFlatStartDate) {
        this.tempFlatStartDate = tempFlatStartDate;
    }

    public CovOption withTempFlatStartDate(String tempFlatStartDate) {
        this.tempFlatStartDate = tempFlatStartDate;
        return this;
    }

    @JsonProperty("GuidelineAnnPrem")
    public Integer getGuidelineAnnPrem() {
        return guidelineAnnPrem;
    }

    @JsonProperty("GuidelineAnnPrem")
    public void setGuidelineAnnPrem(Integer guidelineAnnPrem) {
        this.guidelineAnnPrem = guidelineAnnPrem;
    }

    public CovOption withGuidelineAnnPrem(Integer guidelineAnnPrem) {
        this.guidelineAnnPrem = guidelineAnnPrem;
        return this;
    }

    @JsonProperty("GuidelineAnnPremSum")
    public Integer getGuidelineAnnPremSum() {
        return guidelineAnnPremSum;
    }

    @JsonProperty("GuidelineAnnPremSum")
    public void setGuidelineAnnPremSum(Integer guidelineAnnPremSum) {
        this.guidelineAnnPremSum = guidelineAnnPremSum;
    }

    public CovOption withGuidelineAnnPremSum(Integer guidelineAnnPremSum) {
        this.guidelineAnnPremSum = guidelineAnnPremSum;
        return this;
    }

    @JsonProperty("GuidelineSinglePrem")
    public Integer getGuidelineSinglePrem() {
        return guidelineSinglePrem;
    }

    @JsonProperty("GuidelineSinglePrem")
    public void setGuidelineSinglePrem(Integer guidelineSinglePrem) {
        this.guidelineSinglePrem = guidelineSinglePrem;
    }

    public CovOption withGuidelineSinglePrem(Integer guidelineSinglePrem) {
        this.guidelineSinglePrem = guidelineSinglePrem;
        return this;
    }

    @JsonProperty("Mec7DBLowest")
    public Integer getMec7DBLowest() {
        return mec7DBLowest;
    }

    @JsonProperty("Mec7DBLowest")
    public void setMec7DBLowest(Integer mec7DBLowest) {
        this.mec7DBLowest = mec7DBLowest;
    }

    public CovOption withMec7DBLowest(Integer mec7DBLowest) {
        this.mec7DBLowest = mec7DBLowest;
        return this;
    }

    @JsonProperty("SECGuidelinePrem")
    public Integer getSECGuidelinePrem() {
        return sECGuidelinePrem;
    }

    @JsonProperty("SECGuidelinePrem")
    public void setSECGuidelinePrem(Integer sECGuidelinePrem) {
        this.sECGuidelinePrem = sECGuidelinePrem;
    }

    public CovOption withSECGuidelinePrem(Integer sECGuidelinePrem) {
        this.sECGuidelinePrem = sECGuidelinePrem;
        return this;
    }

    @JsonProperty("MinPremAmt")
    public Integer getMinPremAmt() {
        return minPremAmt;
    }

    @JsonProperty("MinPremAmt")
    public void setMinPremAmt(Integer minPremAmt) {
        this.minPremAmt = minPremAmt;
    }

    public CovOption withMinPremAmt(Integer minPremAmt) {
        this.minPremAmt = minPremAmt;
        return this;
    }

    @JsonProperty("TargetPremAmtATD")
    public Integer getTargetPremAmtATD() {
        return targetPremAmtATD;
    }

    @JsonProperty("TargetPremAmtATD")
    public void setTargetPremAmtATD(Integer targetPremAmtATD) {
        this.targetPremAmtATD = targetPremAmtATD;
    }

    public CovOption withTargetPremAmtATD(Integer targetPremAmtATD) {
        this.targetPremAmtATD = targetPremAmtATD;
        return this;
    }

    @JsonProperty("TargetPremAmtITD")
    public Integer getTargetPremAmtITD() {
        return targetPremAmtITD;
    }

    @JsonProperty("TargetPremAmtITD")
    public void setTargetPremAmtITD(Integer targetPremAmtITD) {
        this.targetPremAmtITD = targetPremAmtITD;
    }

    public CovOption withTargetPremAmtITD(Integer targetPremAmtITD) {
        this.targetPremAmtITD = targetPremAmtITD;
        return this;
    }

    @JsonProperty("TargetPremAmtMTD")
    public Integer getTargetPremAmtMTD() {
        return targetPremAmtMTD;
    }

    @JsonProperty("TargetPremAmtMTD")
    public void setTargetPremAmtMTD(Integer targetPremAmtMTD) {
        this.targetPremAmtMTD = targetPremAmtMTD;
    }

    public CovOption withTargetPremAmtMTD(Integer targetPremAmtMTD) {
        this.targetPremAmtMTD = targetPremAmtMTD;
        return this;
    }

    @JsonProperty("TargetPremAmtYTD")
    public Integer getTargetPremAmtYTD() {
        return targetPremAmtYTD;
    }

    @JsonProperty("TargetPremAmtYTD")
    public void setTargetPremAmtYTD(Integer targetPremAmtYTD) {
        this.targetPremAmtYTD = targetPremAmtYTD;
    }

    public CovOption withTargetPremAmtYTD(Integer targetPremAmtYTD) {
        this.targetPremAmtYTD = targetPremAmtYTD;
        return this;
    }

    @JsonProperty("GDBPrem")
    public Integer getGDBPrem() {
        return gDBPrem;
    }

    @JsonProperty("GDBPrem")
    public void setGDBPrem(Integer gDBPrem) {
        this.gDBPrem = gDBPrem;
    }

    public CovOption withGDBPrem(Integer gDBPrem) {
        this.gDBPrem = gDBPrem;
        return this;
    }

    @JsonProperty("Duration")
    public Integer getDuration() {
        return duration;
    }

    @JsonProperty("Duration")
    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public CovOption withDuration(Integer duration) {
        this.duration = duration;
        return this;
    }

    @JsonProperty("DurationDesign")
    public Integer getDurationDesign() {
        return durationDesign;
    }

    @JsonProperty("DurationDesign")
    public void setDurationDesign(Integer durationDesign) {
        this.durationDesign = durationDesign;
    }

    public CovOption withDurationDesign(Integer durationDesign) {
        this.durationDesign = durationDesign;
        return this;
    }

    @JsonProperty("PreExistingConditionInd")
    public PreExistingConditionInd getPreExistingConditionInd() {
        return preExistingConditionInd;
    }

    @JsonProperty("PreExistingConditionInd")
    public void setPreExistingConditionInd(PreExistingConditionInd preExistingConditionInd) {
        this.preExistingConditionInd = preExistingConditionInd;
    }

    public CovOption withPreExistingConditionInd(PreExistingConditionInd preExistingConditionInd) {
        this.preExistingConditionInd = preExistingConditionInd;
        return this;
    }

    @JsonProperty("ChildMatureAge")
    public Integer getChildMatureAge() {
        return childMatureAge;
    }

    @JsonProperty("ChildMatureAge")
    public void setChildMatureAge(Integer childMatureAge) {
        this.childMatureAge = childMatureAge;
    }

    public CovOption withChildMatureAge(Integer childMatureAge) {
        this.childMatureAge = childMatureAge;
        return this;
    }

    @JsonProperty("ChildAgeUse")
    public ChildAgeUse getChildAgeUse() {
        return childAgeUse;
    }

    @JsonProperty("ChildAgeUse")
    public void setChildAgeUse(ChildAgeUse childAgeUse) {
        this.childAgeUse = childAgeUse;
    }

    public CovOption withChildAgeUse(ChildAgeUse childAgeUse) {
        this.childAgeUse = childAgeUse;
        return this;
    }

    @JsonProperty("BenefitCoordinationInd")
    public BenefitCoordinationInd getBenefitCoordinationInd() {
        return benefitCoordinationInd;
    }

    @JsonProperty("BenefitCoordinationInd")
    public void setBenefitCoordinationInd(BenefitCoordinationInd benefitCoordinationInd) {
        this.benefitCoordinationInd = benefitCoordinationInd;
    }

    public CovOption withBenefitCoordinationInd(BenefitCoordinationInd benefitCoordinationInd) {
        this.benefitCoordinationInd = benefitCoordinationInd;
        return this;
    }

    @JsonProperty("TargetPremAmt")
    public Integer getTargetPremAmt() {
        return targetPremAmt;
    }

    @JsonProperty("TargetPremAmt")
    public void setTargetPremAmt(Integer targetPremAmt) {
        this.targetPremAmt = targetPremAmt;
    }

    public CovOption withTargetPremAmt(Integer targetPremAmt) {
        this.targetPremAmt = targetPremAmt;
        return this;
    }

    @JsonProperty("AnnualIndexType")
    public AnnualIndexType getAnnualIndexType() {
        return annualIndexType;
    }

    @JsonProperty("AnnualIndexType")
    public void setAnnualIndexType(AnnualIndexType annualIndexType) {
        this.annualIndexType = annualIndexType;
    }

    public CovOption withAnnualIndexType(AnnualIndexType annualIndexType) {
        this.annualIndexType = annualIndexType;
        return this;
    }

    @JsonProperty("PayToAge")
    public Integer getPayToAge() {
        return payToAge;
    }

    @JsonProperty("PayToAge")
    public void setPayToAge(Integer payToAge) {
        this.payToAge = payToAge;
    }

    public CovOption withPayToAge(Integer payToAge) {
        this.payToAge = payToAge;
        return this;
    }

    @JsonProperty("PayToYear")
    public Integer getPayToYear() {
        return payToYear;
    }

    @JsonProperty("PayToYear")
    public void setPayToYear(Integer payToYear) {
        this.payToYear = payToYear;
    }

    public CovOption withPayToYear(Integer payToYear) {
        this.payToYear = payToYear;
        return this;
    }

    @JsonProperty("PermRatingAmtPerThou")
    public Integer getPermRatingAmtPerThou() {
        return permRatingAmtPerThou;
    }

    @JsonProperty("PermRatingAmtPerThou")
    public void setPermRatingAmtPerThou(Integer permRatingAmtPerThou) {
        this.permRatingAmtPerThou = permRatingAmtPerThou;
    }

    public CovOption withPermRatingAmtPerThou(Integer permRatingAmtPerThou) {
        this.permRatingAmtPerThou = permRatingAmtPerThou;
        return this;
    }

    @JsonProperty("TempRatingAmtPerThou")
    public Integer getTempRatingAmtPerThou() {
        return tempRatingAmtPerThou;
    }

    @JsonProperty("TempRatingAmtPerThou")
    public void setTempRatingAmtPerThou(Integer tempRatingAmtPerThou) {
        this.tempRatingAmtPerThou = tempRatingAmtPerThou;
    }

    public CovOption withTempRatingAmtPerThou(Integer tempRatingAmtPerThou) {
        this.tempRatingAmtPerThou = tempRatingAmtPerThou;
        return this;
    }

    @JsonProperty("TempFlatExtraOverrideEndDate")
    public String getTempFlatExtraOverrideEndDate() {
        return tempFlatExtraOverrideEndDate;
    }

    @JsonProperty("TempFlatExtraOverrideEndDate")
    public void setTempFlatExtraOverrideEndDate(String tempFlatExtraOverrideEndDate) {
        this.tempFlatExtraOverrideEndDate = tempFlatExtraOverrideEndDate;
    }

    public CovOption withTempFlatExtraOverrideEndDate(String tempFlatExtraOverrideEndDate) {
        this.tempFlatExtraOverrideEndDate = tempFlatExtraOverrideEndDate;
        return this;
    }

    @JsonProperty("TempFlatExtraOverrideEffDate")
    public String getTempFlatExtraOverrideEffDate() {
        return tempFlatExtraOverrideEffDate;
    }

    @JsonProperty("TempFlatExtraOverrideEffDate")
    public void setTempFlatExtraOverrideEffDate(String tempFlatExtraOverrideEffDate) {
        this.tempFlatExtraOverrideEffDate = tempFlatExtraOverrideEffDate;
    }

    public CovOption withTempFlatExtraOverrideEffDate(String tempFlatExtraOverrideEffDate) {
        this.tempFlatExtraOverrideEffDate = tempFlatExtraOverrideEffDate;
        return this;
    }

    @JsonProperty("Occupation")
    public String getOccupation() {
        return occupation;
    }

    @JsonProperty("Occupation")
    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public CovOption withOccupation(String occupation) {
        this.occupation = occupation;
        return this;
    }

    @JsonProperty("OccupRating")
    public OccupRating getOccupRating() {
        return occupRating;
    }

    @JsonProperty("OccupRating")
    public void setOccupRating(OccupRating occupRating) {
        this.occupRating = occupRating;
    }

    public CovOption withOccupRating(OccupRating occupRating) {
        this.occupRating = occupRating;
        return this;
    }

    @JsonProperty("LastRatingDate")
    public String getLastRatingDate() {
        return lastRatingDate;
    }

    @JsonProperty("LastRatingDate")
    public void setLastRatingDate(String lastRatingDate) {
        this.lastRatingDate = lastRatingDate;
    }

    public CovOption withLastRatingDate(String lastRatingDate) {
        this.lastRatingDate = lastRatingDate;
        return this;
    }

    @JsonProperty("TempRatingType")
    public TempRatingType getTempRatingType() {
        return tempRatingType;
    }

    @JsonProperty("TempRatingType")
    public void setTempRatingType(TempRatingType tempRatingType) {
        this.tempRatingType = tempRatingType;
    }

    public CovOption withTempRatingType(TempRatingType tempRatingType) {
        this.tempRatingType = tempRatingType;
        return this;
    }

    @JsonProperty("PermRatingType")
    public PermRatingType getPermRatingType() {
        return permRatingType;
    }

    @JsonProperty("PermRatingType")
    public void setPermRatingType(PermRatingType permRatingType) {
        this.permRatingType = permRatingType;
    }

    public CovOption withPermRatingType(PermRatingType permRatingType) {
        this.permRatingType = permRatingType;
        return this;
    }

    @JsonProperty("LevelPremiumPeriod")
    public Integer getLevelPremiumPeriod() {
        return levelPremiumPeriod;
    }

    @JsonProperty("LevelPremiumPeriod")
    public void setLevelPremiumPeriod(Integer levelPremiumPeriod) {
        this.levelPremiumPeriod = levelPremiumPeriod;
    }

    public CovOption withLevelPremiumPeriod(Integer levelPremiumPeriod) {
        this.levelPremiumPeriod = levelPremiumPeriod;
        return this;
    }

    @JsonProperty("LevelPremiumPeriodUnits")
    public LevelPremiumPeriodUnits getLevelPremiumPeriodUnits() {
        return levelPremiumPeriodUnits;
    }

    @JsonProperty("LevelPremiumPeriodUnits")
    public void setLevelPremiumPeriodUnits(LevelPremiumPeriodUnits levelPremiumPeriodUnits) {
        this.levelPremiumPeriodUnits = levelPremiumPeriodUnits;
    }

    public CovOption withLevelPremiumPeriodUnits(LevelPremiumPeriodUnits levelPremiumPeriodUnits) {
        this.levelPremiumPeriodUnits = levelPremiumPeriodUnits;
        return this;
    }

    @JsonProperty("PaymentStructure")
    public PaymentStructure getPaymentStructure() {
        return paymentStructure;
    }

    @JsonProperty("PaymentStructure")
    public void setPaymentStructure(PaymentStructure paymentStructure) {
        this.paymentStructure = paymentStructure;
    }

    public CovOption withPaymentStructure(PaymentStructure paymentStructure) {
        this.paymentStructure = paymentStructure;
        return this;
    }

    @JsonProperty("CommissionRate")
    public Integer getCommissionRate() {
        return commissionRate;
    }

    @JsonProperty("CommissionRate")
    public void setCommissionRate(Integer commissionRate) {
        this.commissionRate = commissionRate;
    }

    public CovOption withCommissionRate(Integer commissionRate) {
        this.commissionRate = commissionRate;
        return this;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    public CovOption withDescription(String description) {
        this.description = description;
        return this;
    }

    @JsonProperty("ERContribAmt")
    public Integer getERContribAmt() {
        return eRContribAmt;
    }

    @JsonProperty("ERContribAmt")
    public void setERContribAmt(Integer eRContribAmt) {
        this.eRContribAmt = eRContribAmt;
    }

    public CovOption withERContribAmt(Integer eRContribAmt) {
        this.eRContribAmt = eRContribAmt;
        return this;
    }

    @JsonProperty("EEContribAmt")
    public Integer getEEContribAmt() {
        return eEContribAmt;
    }

    @JsonProperty("EEContribAmt")
    public void setEEContribAmt(Integer eEContribAmt) {
        this.eEContribAmt = eEContribAmt;
    }

    public CovOption withEEContribAmt(Integer eEContribAmt) {
        this.eEContribAmt = eEContribAmt;
        return this;
    }

    @JsonProperty("ERContribPct")
    public Integer getERContribPct() {
        return eRContribPct;
    }

    @JsonProperty("ERContribPct")
    public void setERContribPct(Integer eRContribPct) {
        this.eRContribPct = eRContribPct;
    }

    public CovOption withERContribPct(Integer eRContribPct) {
        this.eRContribPct = eRContribPct;
        return this;
    }

    @JsonProperty("EEContribPct")
    public Integer getEEContribPct() {
        return eEContribPct;
    }

    @JsonProperty("EEContribPct")
    public void setEEContribPct(Integer eEContribPct) {
        this.eEContribPct = eEContribPct;
    }

    public CovOption withEEContribPct(Integer eEContribPct) {
        this.eEContribPct = eEContribPct;
        return this;
    }

    @JsonProperty("UpgradeAvailableInd")
    public UpgradeAvailableInd getUpgradeAvailableInd() {
        return upgradeAvailableInd;
    }

    @JsonProperty("UpgradeAvailableInd")
    public void setUpgradeAvailableInd(UpgradeAvailableInd upgradeAvailableInd) {
        this.upgradeAvailableInd = upgradeAvailableInd;
    }

    public CovOption withUpgradeAvailableInd(UpgradeAvailableInd upgradeAvailableInd) {
        this.upgradeAvailableInd = upgradeAvailableInd;
        return this;
    }

    @JsonProperty("ModalPermRatingAmt")
    public Integer getModalPermRatingAmt() {
        return modalPermRatingAmt;
    }

    @JsonProperty("ModalPermRatingAmt")
    public void setModalPermRatingAmt(Integer modalPermRatingAmt) {
        this.modalPermRatingAmt = modalPermRatingAmt;
    }

    public CovOption withModalPermRatingAmt(Integer modalPermRatingAmt) {
        this.modalPermRatingAmt = modalPermRatingAmt;
        return this;
    }

    @JsonProperty("ModalTempRatingAmt")
    public Integer getModalTempRatingAmt() {
        return modalTempRatingAmt;
    }

    @JsonProperty("ModalTempRatingAmt")
    public void setModalTempRatingAmt(Integer modalTempRatingAmt) {
        this.modalTempRatingAmt = modalTempRatingAmt;
    }

    public CovOption withModalTempRatingAmt(Integer modalTempRatingAmt) {
        this.modalTempRatingAmt = modalTempRatingAmt;
        return this;
    }

    @JsonProperty("NetCurrentAmt")
    public Integer getNetCurrentAmt() {
        return netCurrentAmt;
    }

    @JsonProperty("NetCurrentAmt")
    public void setNetCurrentAmt(Integer netCurrentAmt) {
        this.netCurrentAmt = netCurrentAmt;
    }

    public CovOption withNetCurrentAmt(Integer netCurrentAmt) {
        this.netCurrentAmt = netCurrentAmt;
        return this;
    }

    @JsonProperty("ReinsuranceInfo")
    public List<Object> getReinsuranceInfo() {
        return reinsuranceInfo;
    }

    @JsonProperty("ReinsuranceInfo")
    public void setReinsuranceInfo(List<Object> reinsuranceInfo) {
        this.reinsuranceInfo = reinsuranceInfo;
    }

    public CovOption withReinsuranceInfo(List<Object> reinsuranceInfo) {
        this.reinsuranceInfo = reinsuranceInfo;
        return this;
    }

    @JsonProperty("SubstandardRating")
    public List<Object> getSubstandardRating() {
        return substandardRating;
    }

    @JsonProperty("SubstandardRating")
    public void setSubstandardRating(List<Object> substandardRating) {
        this.substandardRating = substandardRating;
    }

    public CovOption withSubstandardRating(List<Object> substandardRating) {
        this.substandardRating = substandardRating;
        return this;
    }

    @JsonProperty("CovOptionXLat")
    public List<Object> getCovOptionXLat() {
        return covOptionXLat;
    }

    @JsonProperty("CovOptionXLat")
    public void setCovOptionXLat(List<Object> covOptionXLat) {
        this.covOptionXLat = covOptionXLat;
    }

    public CovOption withCovOptionXLat(List<Object> covOptionXLat) {
        this.covOptionXLat = covOptionXLat;
        return this;
    }

    @JsonProperty("Participant")
    public List<Object> getParticipant() {
        return participant;
    }

    @JsonProperty("Participant")
    public void setParticipant(List<Object> participant) {
        this.participant = participant;
    }

    public CovOption withParticipant(List<Object> participant) {
        this.participant = participant;
        return this;
    }

    @JsonProperty("BenefitLimit")
    public List<Object> getBenefitLimit() {
        return benefitLimit;
    }

    @JsonProperty("BenefitLimit")
    public void setBenefitLimit(List<Object> benefitLimit) {
        this.benefitLimit = benefitLimit;
    }

    public CovOption withBenefitLimit(List<Object> benefitLimit) {
        this.benefitLimit = benefitLimit;
        return this;
    }

    @JsonProperty("DeductionOption")
    public List<Object> getDeductionOption() {
        return deductionOption;
    }

    @JsonProperty("DeductionOption")
    public void setDeductionOption(List<Object> deductionOption) {
        this.deductionOption = deductionOption;
    }

    public CovOption withDeductionOption(List<Object> deductionOption) {
        this.deductionOption = deductionOption;
        return this;
    }

    @JsonProperty("RestrictionInfo")
    public List<Object> getRestrictionInfo() {
        return restrictionInfo;
    }

    @JsonProperty("RestrictionInfo")
    public void setRestrictionInfo(List<Object> restrictionInfo) {
        this.restrictionInfo = restrictionInfo;
    }

    public CovOption withRestrictionInfo(List<Object> restrictionInfo) {
        this.restrictionInfo = restrictionInfo;
        return this;
    }

    @JsonProperty("GroupCovOption")
    public GroupCovOption getGroupCovOption() {
        return groupCovOption;
    }

    @JsonProperty("GroupCovOption")
    public void setGroupCovOption(GroupCovOption groupCovOption) {
        this.groupCovOption = groupCovOption;
    }

    public CovOption withGroupCovOption(GroupCovOption groupCovOption) {
        this.groupCovOption = groupCovOption;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public CovOption withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("ConditionTypeOption")
    public List<Object> getConditionTypeOption() {
        return conditionTypeOption;
    }

    @JsonProperty("ConditionTypeOption")
    public void setConditionTypeOption(List<Object> conditionTypeOption) {
        this.conditionTypeOption = conditionTypeOption;
    }

    public CovOption withConditionTypeOption(List<Object> conditionTypeOption) {
        this.conditionTypeOption = conditionTypeOption;
        return this;
    }

    @JsonProperty("AltPremMode")
    public List<Object> getAltPremMode() {
        return altPremMode;
    }

    @JsonProperty("AltPremMode")
    public void setAltPremMode(List<Object> altPremMode) {
        this.altPremMode = altPremMode;
    }

    public CovOption withAltPremMode(List<Object> altPremMode) {
        this.altPremMode = altPremMode;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public CovOption withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public CovOption withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public CovOption withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("LifeParticipantRefID")
    public String getLifeParticipantRefID() {
        return lifeParticipantRefID;
    }

    @JsonProperty("LifeParticipantRefID")
    public void setLifeParticipantRefID(String lifeParticipantRefID) {
        this.lifeParticipantRefID = lifeParticipantRefID;
    }

    public CovOption withLifeParticipantRefID(String lifeParticipantRefID) {
        this.lifeParticipantRefID = lifeParticipantRefID;
        return this;
    }

    @JsonProperty("CarrierLicenseID")
    public String getCarrierLicenseID() {
        return carrierLicenseID;
    }

    @JsonProperty("CarrierLicenseID")
    public void setCarrierLicenseID(String carrierLicenseID) {
        this.carrierLicenseID = carrierLicenseID;
    }

    public CovOption withCarrierLicenseID(String carrierLicenseID) {
        this.carrierLicenseID = carrierLicenseID;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public CovOption withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CovOption withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(CovOption.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("covOptionKey");
        sb.append('=');
        sb.append(((this.covOptionKey == null)?"<null>":this.covOptionKey));
        sb.append(',');
        sb.append("covOptionSysKey");
        sb.append('=');
        sb.append(((this.covOptionSysKey == null)?"<null>":this.covOptionSysKey));
        sb.append(',');
        sb.append("shortName");
        sb.append('=');
        sb.append(((this.shortName == null)?"<null>":this.shortName));
        sb.append(',');
        sb.append("marketingName");
        sb.append('=');
        sb.append(((this.marketingName == null)?"<null>":this.marketingName));
        sb.append(',');
        sb.append("planName");
        sb.append('=');
        sb.append(((this.planName == null)?"<null>":this.planName));
        sb.append(',');
        sb.append("productCode");
        sb.append('=');
        sb.append(((this.productCode == null)?"<null>":this.productCode));
        sb.append(',');
        sb.append("productVersionCode");
        sb.append('=');
        sb.append(((this.productVersionCode == null)?"<null>":this.productVersionCode));
        sb.append(',');
        sb.append("formNo");
        sb.append('=');
        sb.append(((this.formNo == null)?"<null>":this.formNo));
        sb.append(',');
        sb.append("className");
        sb.append('=');
        sb.append(((this.className == null)?"<null>":this.className));
        sb.append(',');
        sb.append("covOptionStatus");
        sb.append('=');
        sb.append(((this.covOptionStatus == null)?"<null>":this.covOptionStatus));
        sb.append(',');
        sb.append("issueType");
        sb.append('=');
        sb.append(((this.issueType == null)?"<null>":this.issueType));
        sb.append(',');
        sb.append("issueSubType");
        sb.append('=');
        sb.append(((this.issueSubType == null)?"<null>":this.issueSubType));
        sb.append(',');
        sb.append("lifeCovOptTypeCode");
        sb.append('=');
        sb.append(((this.lifeCovOptTypeCode == null)?"<null>":this.lifeCovOptTypeCode));
        sb.append(',');
        sb.append("expiryDate");
        sb.append('=');
        sb.append(((this.expiryDate == null)?"<null>":this.expiryDate));
        sb.append(',');
        sb.append("ratingReason");
        sb.append('=');
        sb.append(((this.ratingReason == null)?"<null>":this.ratingReason));
        sb.append(',');
        sb.append("ratingOverriddenInd");
        sb.append('=');
        sb.append(((this.ratingOverriddenInd == null)?"<null>":this.ratingOverriddenInd));
        sb.append(',');
        sb.append("ratingCommissionRule");
        sb.append('=');
        sb.append(((this.ratingCommissionRule == null)?"<null>":this.ratingCommissionRule));
        sb.append(',');
        sb.append("tobaccoPremiumBasis");
        sb.append('=');
        sb.append(((this.tobaccoPremiumBasis == null)?"<null>":this.tobaccoPremiumBasis));
        sb.append(',');
        sb.append("permTableRating");
        sb.append('=');
        sb.append(((this.permTableRating == null)?"<null>":this.permTableRating));
        sb.append(',');
        sb.append("permTableRatingEndDate");
        sb.append('=');
        sb.append(((this.permTableRatingEndDate == null)?"<null>":this.permTableRatingEndDate));
        sb.append(',');
        sb.append("tempTableRating");
        sb.append('=');
        sb.append(((this.tempTableRating == null)?"<null>":this.tempTableRating));
        sb.append(',');
        sb.append("tempTableRatingStartDate");
        sb.append('=');
        sb.append(((this.tempTableRatingStartDate == null)?"<null>":this.tempTableRatingStartDate));
        sb.append(',');
        sb.append("tempTableRatingEndDate");
        sb.append('=');
        sb.append(((this.tempTableRatingEndDate == null)?"<null>":this.tempTableRatingEndDate));
        sb.append(',');
        sb.append("qualAddBenefitInd");
        sb.append('=');
        sb.append(((this.qualAddBenefitInd == null)?"<null>":this.qualAddBenefitInd));
        sb.append(',');
        sb.append("livesType");
        sb.append('=');
        sb.append(((this.livesType == null)?"<null>":this.livesType));
        sb.append(',');
        sb.append("issuedAsAppliedInd");
        sb.append('=');
        sb.append(((this.issuedAsAppliedInd == null)?"<null>":this.issuedAsAppliedInd));
        sb.append(',');
        sb.append("underwritingClass");
        sb.append('=');
        sb.append(((this.underwritingClass == null)?"<null>":this.underwritingClass));
        sb.append(',');
        sb.append("underwritingSubClass");
        sb.append('=');
        sb.append(((this.underwritingSubClass == null)?"<null>":this.underwritingSubClass));
        sb.append(',');
        sb.append("premSourceType");
        sb.append('=');
        sb.append(((this.premSourceType == null)?"<null>":this.premSourceType));
        sb.append(',');
        sb.append("annualPremAmt");
        sb.append('=');
        sb.append(((this.annualPremAmt == null)?"<null>":this.annualPremAmt));
        sb.append(',');
        sb.append("modalPremAmt");
        sb.append('=');
        sb.append(((this.modalPremAmt == null)?"<null>":this.modalPremAmt));
        sb.append(',');
        sb.append("covOptionPctInd");
        sb.append('=');
        sb.append(((this.covOptionPctInd == null)?"<null>":this.covOptionPctInd));
        sb.append(',');
        sb.append("optionAmt");
        sb.append('=');
        sb.append(((this.optionAmt == null)?"<null>":this.optionAmt));
        sb.append(',');
        sb.append("optionPct");
        sb.append('=');
        sb.append(((this.optionPct == null)?"<null>":this.optionPct));
        sb.append(',');
        sb.append("optionPctType");
        sb.append('=');
        sb.append(((this.optionPctType == null)?"<null>":this.optionPctType));
        sb.append(',');
        sb.append("optionNumberOfUnits");
        sb.append('=');
        sb.append(((this.optionNumberOfUnits == null)?"<null>":this.optionNumberOfUnits));
        sb.append(',');
        sb.append("valuePerUnit");
        sb.append('=');
        sb.append(((this.valuePerUnit == null)?"<null>":this.valuePerUnit));
        sb.append(',');
        sb.append("deathBenefitAmt");
        sb.append('=');
        sb.append(((this.deathBenefitAmt == null)?"<null>":this.deathBenefitAmt));
        sb.append(',');
        sb.append("tempFlatExtraAmt");
        sb.append('=');
        sb.append(((this.tempFlatExtraAmt == null)?"<null>":this.tempFlatExtraAmt));
        sb.append(',');
        sb.append("tempFlatEndDate");
        sb.append('=');
        sb.append(((this.tempFlatEndDate == null)?"<null>":this.tempFlatEndDate));
        sb.append(',');
        sb.append("permFlatExtraAmt");
        sb.append('=');
        sb.append(((this.permFlatExtraAmt == null)?"<null>":this.permFlatExtraAmt));
        sb.append(',');
        sb.append("permFlatExtraEndDate");
        sb.append('=');
        sb.append(((this.permFlatExtraEndDate == null)?"<null>":this.permFlatExtraEndDate));
        sb.append(',');
        sb.append("flatExtraPremBasis");
        sb.append('=');
        sb.append(((this.flatExtraPremBasis == null)?"<null>":this.flatExtraPremBasis));
        sb.append(',');
        sb.append("modalGrossFlatExtraPremAmt");
        sb.append('=');
        sb.append(((this.modalGrossFlatExtraPremAmt == null)?"<null>":this.modalGrossFlatExtraPremAmt));
        sb.append(',');
        sb.append("modalGrossFlatExtraAllowanceAmt");
        sb.append('=');
        sb.append(((this.modalGrossFlatExtraAllowanceAmt == null)?"<null>":this.modalGrossFlatExtraAllowanceAmt));
        sb.append(',');
        sb.append("effDate");
        sb.append('=');
        sb.append(((this.effDate == null)?"<null>":this.effDate));
        sb.append(',');
        sb.append("exerciseDate");
        sb.append('=');
        sb.append(((this.exerciseDate == null)?"<null>":this.exerciseDate));
        sb.append(',');
        sb.append("termDate");
        sb.append('=');
        sb.append(((this.termDate == null)?"<null>":this.termDate));
        sb.append(',');
        sb.append("gracePeriodStartDate");
        sb.append('=');
        sb.append(((this.gracePeriodStartDate == null)?"<null>":this.gracePeriodStartDate));
        sb.append(',');
        sb.append("tempPercentageLoading");
        sb.append('=');
        sb.append(((this.tempPercentageLoading == null)?"<null>":this.tempPercentageLoading));
        sb.append(',');
        sb.append("permPercentageLoading");
        sb.append('=');
        sb.append(((this.permPercentageLoading == null)?"<null>":this.permPercentageLoading));
        sb.append(',');
        sb.append("filedFormNumber");
        sb.append('=');
        sb.append(((this.filedFormNumber == null)?"<null>":this.filedFormNumber));
        sb.append(',');
        sb.append("eliminationPeriod");
        sb.append('=');
        sb.append(((this.eliminationPeriod == null)?"<null>":this.eliminationPeriod));
        sb.append(',');
        sb.append("benefitPeriod");
        sb.append('=');
        sb.append(((this.benefitPeriod == null)?"<null>":this.benefitPeriod));
        sb.append(',');
        sb.append("benefitMode");
        sb.append('=');
        sb.append(((this.benefitMode == null)?"<null>":this.benefitMode));
        sb.append(',');
        sb.append("premiumPerUnit");
        sb.append('=');
        sb.append(((this.premiumPerUnit == null)?"<null>":this.premiumPerUnit));
        sb.append(',');
        sb.append("premiumRatePerUnit");
        sb.append('=');
        sb.append(((this.premiumRatePerUnit == null)?"<null>":this.premiumRatePerUnit));
        sb.append(',');
        sb.append("renewalPremiumPerUnit");
        sb.append('=');
        sb.append(((this.renewalPremiumPerUnit == null)?"<null>":this.renewalPremiumPerUnit));
        sb.append(',');
        sb.append("renewalPremiumRatePerUnit");
        sb.append('=');
        sb.append(((this.renewalPremiumRatePerUnit == null)?"<null>":this.renewalPremiumRatePerUnit));
        sb.append(',');
        sb.append("maxBenefitAmt");
        sb.append('=');
        sb.append(((this.maxBenefitAmt == null)?"<null>":this.maxBenefitAmt));
        sb.append(',');
        sb.append("commissionLink");
        sb.append('=');
        sb.append(((this.commissionLink == null)?"<null>":this.commissionLink));
        sb.append(',');
        sb.append("addedDate");
        sb.append('=');
        sb.append(((this.addedDate == null)?"<null>":this.addedDate));
        sb.append(',');
        sb.append("modalGrossPermFlatAllowAmt");
        sb.append('=');
        sb.append(((this.modalGrossPermFlatAllowAmt == null)?"<null>":this.modalGrossPermFlatAllowAmt));
        sb.append(',');
        sb.append("permTableRatingAlphaCode");
        sb.append('=');
        sb.append(((this.permTableRatingAlphaCode == null)?"<null>":this.permTableRatingAlphaCode));
        sb.append(',');
        sb.append("tempTableRatingCode");
        sb.append('=');
        sb.append(((this.tempTableRatingCode == null)?"<null>":this.tempTableRatingCode));
        sb.append(',');
        sb.append("modalGrossTempFlatAllowAmt");
        sb.append('=');
        sb.append(((this.modalGrossTempFlatAllowAmt == null)?"<null>":this.modalGrossTempFlatAllowAmt));
        sb.append(',');
        sb.append("paidUpDate");
        sb.append('=');
        sb.append(((this.paidUpDate == null)?"<null>":this.paidUpDate));
        sb.append(',');
        sb.append("tempFlatExtraDuration");
        sb.append('=');
        sb.append(((this.tempFlatExtraDuration == null)?"<null>":this.tempFlatExtraDuration));
        sb.append(',');
        sb.append("covOptionNumber");
        sb.append('=');
        sb.append(((this.covOptionNumber == null)?"<null>":this.covOptionNumber));
        sb.append(',');
        sb.append("tempFlatStartDate");
        sb.append('=');
        sb.append(((this.tempFlatStartDate == null)?"<null>":this.tempFlatStartDate));
        sb.append(',');
        sb.append("guidelineAnnPrem");
        sb.append('=');
        sb.append(((this.guidelineAnnPrem == null)?"<null>":this.guidelineAnnPrem));
        sb.append(',');
        sb.append("guidelineAnnPremSum");
        sb.append('=');
        sb.append(((this.guidelineAnnPremSum == null)?"<null>":this.guidelineAnnPremSum));
        sb.append(',');
        sb.append("guidelineSinglePrem");
        sb.append('=');
        sb.append(((this.guidelineSinglePrem == null)?"<null>":this.guidelineSinglePrem));
        sb.append(',');
        sb.append("mec7DBLowest");
        sb.append('=');
        sb.append(((this.mec7DBLowest == null)?"<null>":this.mec7DBLowest));
        sb.append(',');
        sb.append("sECGuidelinePrem");
        sb.append('=');
        sb.append(((this.sECGuidelinePrem == null)?"<null>":this.sECGuidelinePrem));
        sb.append(',');
        sb.append("minPremAmt");
        sb.append('=');
        sb.append(((this.minPremAmt == null)?"<null>":this.minPremAmt));
        sb.append(',');
        sb.append("targetPremAmtATD");
        sb.append('=');
        sb.append(((this.targetPremAmtATD == null)?"<null>":this.targetPremAmtATD));
        sb.append(',');
        sb.append("targetPremAmtITD");
        sb.append('=');
        sb.append(((this.targetPremAmtITD == null)?"<null>":this.targetPremAmtITD));
        sb.append(',');
        sb.append("targetPremAmtMTD");
        sb.append('=');
        sb.append(((this.targetPremAmtMTD == null)?"<null>":this.targetPremAmtMTD));
        sb.append(',');
        sb.append("targetPremAmtYTD");
        sb.append('=');
        sb.append(((this.targetPremAmtYTD == null)?"<null>":this.targetPremAmtYTD));
        sb.append(',');
        sb.append("gDBPrem");
        sb.append('=');
        sb.append(((this.gDBPrem == null)?"<null>":this.gDBPrem));
        sb.append(',');
        sb.append("duration");
        sb.append('=');
        sb.append(((this.duration == null)?"<null>":this.duration));
        sb.append(',');
        sb.append("durationDesign");
        sb.append('=');
        sb.append(((this.durationDesign == null)?"<null>":this.durationDesign));
        sb.append(',');
        sb.append("preExistingConditionInd");
        sb.append('=');
        sb.append(((this.preExistingConditionInd == null)?"<null>":this.preExistingConditionInd));
        sb.append(',');
        sb.append("childMatureAge");
        sb.append('=');
        sb.append(((this.childMatureAge == null)?"<null>":this.childMatureAge));
        sb.append(',');
        sb.append("childAgeUse");
        sb.append('=');
        sb.append(((this.childAgeUse == null)?"<null>":this.childAgeUse));
        sb.append(',');
        sb.append("benefitCoordinationInd");
        sb.append('=');
        sb.append(((this.benefitCoordinationInd == null)?"<null>":this.benefitCoordinationInd));
        sb.append(',');
        sb.append("targetPremAmt");
        sb.append('=');
        sb.append(((this.targetPremAmt == null)?"<null>":this.targetPremAmt));
        sb.append(',');
        sb.append("annualIndexType");
        sb.append('=');
        sb.append(((this.annualIndexType == null)?"<null>":this.annualIndexType));
        sb.append(',');
        sb.append("payToAge");
        sb.append('=');
        sb.append(((this.payToAge == null)?"<null>":this.payToAge));
        sb.append(',');
        sb.append("payToYear");
        sb.append('=');
        sb.append(((this.payToYear == null)?"<null>":this.payToYear));
        sb.append(',');
        sb.append("permRatingAmtPerThou");
        sb.append('=');
        sb.append(((this.permRatingAmtPerThou == null)?"<null>":this.permRatingAmtPerThou));
        sb.append(',');
        sb.append("tempRatingAmtPerThou");
        sb.append('=');
        sb.append(((this.tempRatingAmtPerThou == null)?"<null>":this.tempRatingAmtPerThou));
        sb.append(',');
        sb.append("tempFlatExtraOverrideEndDate");
        sb.append('=');
        sb.append(((this.tempFlatExtraOverrideEndDate == null)?"<null>":this.tempFlatExtraOverrideEndDate));
        sb.append(',');
        sb.append("tempFlatExtraOverrideEffDate");
        sb.append('=');
        sb.append(((this.tempFlatExtraOverrideEffDate == null)?"<null>":this.tempFlatExtraOverrideEffDate));
        sb.append(',');
        sb.append("occupation");
        sb.append('=');
        sb.append(((this.occupation == null)?"<null>":this.occupation));
        sb.append(',');
        sb.append("occupRating");
        sb.append('=');
        sb.append(((this.occupRating == null)?"<null>":this.occupRating));
        sb.append(',');
        sb.append("lastRatingDate");
        sb.append('=');
        sb.append(((this.lastRatingDate == null)?"<null>":this.lastRatingDate));
        sb.append(',');
        sb.append("tempRatingType");
        sb.append('=');
        sb.append(((this.tempRatingType == null)?"<null>":this.tempRatingType));
        sb.append(',');
        sb.append("permRatingType");
        sb.append('=');
        sb.append(((this.permRatingType == null)?"<null>":this.permRatingType));
        sb.append(',');
        sb.append("levelPremiumPeriod");
        sb.append('=');
        sb.append(((this.levelPremiumPeriod == null)?"<null>":this.levelPremiumPeriod));
        sb.append(',');
        sb.append("levelPremiumPeriodUnits");
        sb.append('=');
        sb.append(((this.levelPremiumPeriodUnits == null)?"<null>":this.levelPremiumPeriodUnits));
        sb.append(',');
        sb.append("paymentStructure");
        sb.append('=');
        sb.append(((this.paymentStructure == null)?"<null>":this.paymentStructure));
        sb.append(',');
        sb.append("commissionRate");
        sb.append('=');
        sb.append(((this.commissionRate == null)?"<null>":this.commissionRate));
        sb.append(',');
        sb.append("description");
        sb.append('=');
        sb.append(((this.description == null)?"<null>":this.description));
        sb.append(',');
        sb.append("eRContribAmt");
        sb.append('=');
        sb.append(((this.eRContribAmt == null)?"<null>":this.eRContribAmt));
        sb.append(',');
        sb.append("eEContribAmt");
        sb.append('=');
        sb.append(((this.eEContribAmt == null)?"<null>":this.eEContribAmt));
        sb.append(',');
        sb.append("eRContribPct");
        sb.append('=');
        sb.append(((this.eRContribPct == null)?"<null>":this.eRContribPct));
        sb.append(',');
        sb.append("eEContribPct");
        sb.append('=');
        sb.append(((this.eEContribPct == null)?"<null>":this.eEContribPct));
        sb.append(',');
        sb.append("upgradeAvailableInd");
        sb.append('=');
        sb.append(((this.upgradeAvailableInd == null)?"<null>":this.upgradeAvailableInd));
        sb.append(',');
        sb.append("modalPermRatingAmt");
        sb.append('=');
        sb.append(((this.modalPermRatingAmt == null)?"<null>":this.modalPermRatingAmt));
        sb.append(',');
        sb.append("modalTempRatingAmt");
        sb.append('=');
        sb.append(((this.modalTempRatingAmt == null)?"<null>":this.modalTempRatingAmt));
        sb.append(',');
        sb.append("netCurrentAmt");
        sb.append('=');
        sb.append(((this.netCurrentAmt == null)?"<null>":this.netCurrentAmt));
        sb.append(',');
        sb.append("reinsuranceInfo");
        sb.append('=');
        sb.append(((this.reinsuranceInfo == null)?"<null>":this.reinsuranceInfo));
        sb.append(',');
        sb.append("substandardRating");
        sb.append('=');
        sb.append(((this.substandardRating == null)?"<null>":this.substandardRating));
        sb.append(',');
        sb.append("covOptionXLat");
        sb.append('=');
        sb.append(((this.covOptionXLat == null)?"<null>":this.covOptionXLat));
        sb.append(',');
        sb.append("participant");
        sb.append('=');
        sb.append(((this.participant == null)?"<null>":this.participant));
        sb.append(',');
        sb.append("benefitLimit");
        sb.append('=');
        sb.append(((this.benefitLimit == null)?"<null>":this.benefitLimit));
        sb.append(',');
        sb.append("deductionOption");
        sb.append('=');
        sb.append(((this.deductionOption == null)?"<null>":this.deductionOption));
        sb.append(',');
        sb.append("restrictionInfo");
        sb.append('=');
        sb.append(((this.restrictionInfo == null)?"<null>":this.restrictionInfo));
        sb.append(',');
        sb.append("groupCovOption");
        sb.append('=');
        sb.append(((this.groupCovOption == null)?"<null>":this.groupCovOption));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("conditionTypeOption");
        sb.append('=');
        sb.append(((this.conditionTypeOption == null)?"<null>":this.conditionTypeOption));
        sb.append(',');
        sb.append("altPremMode");
        sb.append('=');
        sb.append(((this.altPremMode == null)?"<null>":this.altPremMode));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("lifeParticipantRefID");
        sb.append('=');
        sb.append(((this.lifeParticipantRefID == null)?"<null>":this.lifeParticipantRefID));
        sb.append(',');
        sb.append("carrierLicenseID");
        sb.append('=');
        sb.append(((this.carrierLicenseID == null)?"<null>":this.carrierLicenseID));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.occupRating == null)? 0 :this.occupRating.hashCode()));
        result = ((result* 31)+((this.addedDate == null)? 0 :this.addedDate.hashCode()));
        result = ((result* 31)+((this.occupation == null)? 0 :this.occupation.hashCode()));
        result = ((result* 31)+((this.planName == null)? 0 :this.planName.hashCode()));
        result = ((result* 31)+((this.tempPercentageLoading == null)? 0 :this.tempPercentageLoading.hashCode()));
        result = ((result* 31)+((this.issueSubType == null)? 0 :this.issueSubType.hashCode()));
        result = ((result* 31)+((this.ratingOverriddenInd == null)? 0 :this.ratingOverriddenInd.hashCode()));
        result = ((result* 31)+((this.optionNumberOfUnits == null)? 0 :this.optionNumberOfUnits.hashCode()));
        result = ((result* 31)+((this.levelPremiumPeriod == null)? 0 :this.levelPremiumPeriod.hashCode()));
        result = ((result* 31)+((this.eRContribAmt == null)? 0 :this.eRContribAmt.hashCode()));
        result = ((result* 31)+((this.covOptionStatus == null)? 0 :this.covOptionStatus.hashCode()));
        result = ((result* 31)+((this.eEContribPct == null)? 0 :this.eEContribPct.hashCode()));
        result = ((result* 31)+((this.modalGrossPermFlatAllowAmt == null)? 0 :this.modalGrossPermFlatAllowAmt.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.productVersionCode == null)? 0 :this.productVersionCode.hashCode()));
        result = ((result* 31)+((this.modalGrossFlatExtraPremAmt == null)? 0 :this.modalGrossFlatExtraPremAmt.hashCode()));
        result = ((result* 31)+((this.permTableRating == null)? 0 :this.permTableRating.hashCode()));
        result = ((result* 31)+((this.substandardRating == null)? 0 :this.substandardRating.hashCode()));
        result = ((result* 31)+((this.commissionLink == null)? 0 :this.commissionLink.hashCode()));
        result = ((result* 31)+((this.renewalPremiumPerUnit == null)? 0 :this.renewalPremiumPerUnit.hashCode()));
        result = ((result* 31)+((this.deductionOption == null)? 0 :this.deductionOption.hashCode()));
        result = ((result* 31)+((this.targetPremAmtYTD == null)? 0 :this.targetPremAmtYTD.hashCode()));
        result = ((result* 31)+((this.benefitLimit == null)? 0 :this.benefitLimit.hashCode()));
        result = ((result* 31)+((this.targetPremAmtMTD == null)? 0 :this.targetPremAmtMTD.hashCode()));
        result = ((result* 31)+((this.permRatingType == null)? 0 :this.permRatingType.hashCode()));
        result = ((result* 31)+((this.permPercentageLoading == null)? 0 :this.permPercentageLoading.hashCode()));
        result = ((result* 31)+((this.lastRatingDate == null)? 0 :this.lastRatingDate.hashCode()));
        result = ((result* 31)+((this.premiumPerUnit == null)? 0 :this.premiumPerUnit.hashCode()));
        result = ((result* 31)+((this.guidelineSinglePrem == null)? 0 :this.guidelineSinglePrem.hashCode()));
        result = ((result* 31)+((this.targetPremAmtITD == null)? 0 :this.targetPremAmtITD.hashCode()));
        result = ((result* 31)+((this.covOptionNumber == null)? 0 :this.covOptionNumber.hashCode()));
        result = ((result* 31)+((this.targetPremAmt == null)? 0 :this.targetPremAmt.hashCode()));
        result = ((result* 31)+((this.eRContribPct == null)? 0 :this.eRContribPct.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.shortName == null)? 0 :this.shortName.hashCode()));
        result = ((result* 31)+((this.targetPremAmtATD == null)? 0 :this.targetPremAmtATD.hashCode()));
        result = ((result* 31)+((this.tempRatingType == null)? 0 :this.tempRatingType.hashCode()));
        result = ((result* 31)+((this.eEContribAmt == null)? 0 :this.eEContribAmt.hashCode()));
        result = ((result* 31)+((this.eliminationPeriod == null)? 0 :this.eliminationPeriod.hashCode()));
        result = ((result* 31)+((this.preExistingConditionInd == null)? 0 :this.preExistingConditionInd.hashCode()));
        result = ((result* 31)+((this.tempFlatExtraOverrideEndDate == null)? 0 :this.tempFlatExtraOverrideEndDate.hashCode()));
        result = ((result* 31)+((this.childMatureAge == null)? 0 :this.childMatureAge.hashCode()));
        result = ((result* 31)+((this.childAgeUse == null)? 0 :this.childAgeUse.hashCode()));
        result = ((result* 31)+((this.tempFlatExtraDuration == null)? 0 :this.tempFlatExtraDuration.hashCode()));
        result = ((result* 31)+((this.paymentStructure == null)? 0 :this.paymentStructure.hashCode()));
        result = ((result* 31)+((this.className == null)? 0 :this.className.hashCode()));
        result = ((result* 31)+((this.marketingName == null)? 0 :this.marketingName.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.conditionTypeOption == null)? 0 :this.conditionTypeOption.hashCode()));
        result = ((result* 31)+((this.modalGrossFlatExtraAllowanceAmt == null)? 0 :this.modalGrossFlatExtraAllowanceAmt.hashCode()));
        result = ((result* 31)+((this.filedFormNumber == null)? 0 :this.filedFormNumber.hashCode()));
        result = ((result* 31)+((this.tempTableRating == null)? 0 :this.tempTableRating.hashCode()));
        result = ((result* 31)+((this.tempRatingAmtPerThou == null)? 0 :this.tempRatingAmtPerThou.hashCode()));
        result = ((result* 31)+((this.benefitCoordinationInd == null)? 0 :this.benefitCoordinationInd.hashCode()));
        result = ((result* 31)+((this.covOptionSysKey == null)? 0 :this.covOptionSysKey.hashCode()));
        result = ((result* 31)+((this.underwritingSubClass == null)? 0 :this.underwritingSubClass.hashCode()));
        result = ((result* 31)+((this.paidUpDate == null)? 0 :this.paidUpDate.hashCode()));
        result = ((result* 31)+((this.covOptionKey == null)? 0 :this.covOptionKey.hashCode()));
        result = ((result* 31)+((this.tempTableRatingEndDate == null)? 0 :this.tempTableRatingEndDate.hashCode()));
        result = ((result* 31)+((this.ratingReason == null)? 0 :this.ratingReason.hashCode()));
        result = ((result* 31)+((this.tempFlatStartDate == null)? 0 :this.tempFlatStartDate.hashCode()));
        result = ((result* 31)+((this.productCode == null)? 0 :this.productCode.hashCode()));
        result = ((result* 31)+((this.modalPremAmt == null)? 0 :this.modalPremAmt.hashCode()));
        result = ((result* 31)+((this.tempFlatExtraAmt == null)? 0 :this.tempFlatExtraAmt.hashCode()));
        result = ((result* 31)+((this.benefitPeriod == null)? 0 :this.benefitPeriod.hashCode()));
        result = ((result* 31)+((this.modalGrossTempFlatAllowAmt == null)? 0 :this.modalGrossTempFlatAllowAmt.hashCode()));
        result = ((result* 31)+((this.covOptionXLat == null)? 0 :this.covOptionXLat.hashCode()));
        result = ((result* 31)+((this.exerciseDate == null)? 0 :this.exerciseDate.hashCode()));
        result = ((result* 31)+((this.restrictionInfo == null)? 0 :this.restrictionInfo.hashCode()));
        result = ((result* 31)+((this.tempTableRatingCode == null)? 0 :this.tempTableRatingCode.hashCode()));
        result = ((result* 31)+((this.durationDesign == null)? 0 :this.durationDesign.hashCode()));
        result = ((result* 31)+((this.underwritingClass == null)? 0 :this.underwritingClass.hashCode()));
        result = ((result* 31)+((this.participant == null)? 0 :this.participant.hashCode()));
        result = ((result* 31)+((this.tobaccoPremiumBasis == null)? 0 :this.tobaccoPremiumBasis.hashCode()));
        result = ((result* 31)+((this.deathBenefitAmt == null)? 0 :this.deathBenefitAmt.hashCode()));
        result = ((result* 31)+((this.payToYear == null)? 0 :this.payToYear.hashCode()));
        result = ((result* 31)+((this.lifeCovOptTypeCode == null)? 0 :this.lifeCovOptTypeCode.hashCode()));
        result = ((result* 31)+((this.effDate == null)? 0 :this.effDate.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.permFlatExtraAmt == null)? 0 :this.permFlatExtraAmt.hashCode()));
        result = ((result* 31)+((this.permFlatExtraEndDate == null)? 0 :this.permFlatExtraEndDate.hashCode()));
        result = ((result* 31)+((this.gDBPrem == null)? 0 :this.gDBPrem.hashCode()));
        result = ((result* 31)+((this.issuedAsAppliedInd == null)? 0 :this.issuedAsAppliedInd.hashCode()));
        result = ((result* 31)+((this.optionPctType == null)? 0 :this.optionPctType.hashCode()));
        result = ((result* 31)+((this.reinsuranceInfo == null)? 0 :this.reinsuranceInfo.hashCode()));
        result = ((result* 31)+((this.permTableRatingEndDate == null)? 0 :this.permTableRatingEndDate.hashCode()));
        result = ((result* 31)+((this.annualPremAmt == null)? 0 :this.annualPremAmt.hashCode()));
        result = ((result* 31)+((this.issueType == null)? 0 :this.issueType.hashCode()));
        result = ((result* 31)+((this.payToAge == null)? 0 :this.payToAge.hashCode()));
        result = ((result* 31)+((this.tempFlatEndDate == null)? 0 :this.tempFlatEndDate.hashCode()));
        result = ((result* 31)+((this.gracePeriodStartDate == null)? 0 :this.gracePeriodStartDate.hashCode()));
        result = ((result* 31)+((this.mec7DBLowest == null)? 0 :this.mec7DBLowest.hashCode()));
        result = ((result* 31)+((this.termDate == null)? 0 :this.termDate.hashCode()));
        result = ((result* 31)+((this.permTableRatingAlphaCode == null)? 0 :this.permTableRatingAlphaCode.hashCode()));
        result = ((result* 31)+((this.modalPermRatingAmt == null)? 0 :this.modalPermRatingAmt.hashCode()));
        result = ((result* 31)+((this.altPremMode == null)? 0 :this.altPremMode.hashCode()));
        result = ((result* 31)+((this.commissionRate == null)? 0 :this.commissionRate.hashCode()));
        result = ((result* 31)+((this.carrierLicenseID == null)? 0 :this.carrierLicenseID.hashCode()));
        result = ((result* 31)+((this.levelPremiumPeriodUnits == null)? 0 :this.levelPremiumPeriodUnits.hashCode()));
        result = ((result* 31)+((this.ratingCommissionRule == null)? 0 :this.ratingCommissionRule.hashCode()));
        result = ((result* 31)+((this.description == null)? 0 :this.description.hashCode()));
        result = ((result* 31)+((this.valuePerUnit == null)? 0 :this.valuePerUnit.hashCode()));
        result = ((result* 31)+((this.livesType == null)? 0 :this.livesType.hashCode()));
        result = ((result* 31)+((this.modalTempRatingAmt == null)? 0 :this.modalTempRatingAmt.hashCode()));
        result = ((result* 31)+((this.expiryDate == null)? 0 :this.expiryDate.hashCode()));
        result = ((result* 31)+((this.qualAddBenefitInd == null)? 0 :this.qualAddBenefitInd.hashCode()));
        result = ((result* 31)+((this.duration == null)? 0 :this.duration.hashCode()));
        result = ((result* 31)+((this.optionPct == null)? 0 :this.optionPct.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        result = ((result* 31)+((this.premSourceType == null)? 0 :this.premSourceType.hashCode()));
        result = ((result* 31)+((this.minPremAmt == null)? 0 :this.minPremAmt.hashCode()));
        result = ((result* 31)+((this.renewalPremiumRatePerUnit == null)? 0 :this.renewalPremiumRatePerUnit.hashCode()));
        result = ((result* 31)+((this.tempTableRatingStartDate == null)? 0 :this.tempTableRatingStartDate.hashCode()));
        result = ((result* 31)+((this.netCurrentAmt == null)? 0 :this.netCurrentAmt.hashCode()));
        result = ((result* 31)+((this.covOptionPctInd == null)? 0 :this.covOptionPctInd.hashCode()));
        result = ((result* 31)+((this.upgradeAvailableInd == null)? 0 :this.upgradeAvailableInd.hashCode()));
        result = ((result* 31)+((this.maxBenefitAmt == null)? 0 :this.maxBenefitAmt.hashCode()));
        result = ((result* 31)+((this.guidelineAnnPremSum == null)? 0 :this.guidelineAnnPremSum.hashCode()));
        result = ((result* 31)+((this.annualIndexType == null)? 0 :this.annualIndexType.hashCode()));
        result = ((result* 31)+((this.optionAmt == null)? 0 :this.optionAmt.hashCode()));
        result = ((result* 31)+((this.benefitMode == null)? 0 :this.benefitMode.hashCode()));
        result = ((result* 31)+((this.guidelineAnnPrem == null)? 0 :this.guidelineAnnPrem.hashCode()));
        result = ((result* 31)+((this.permRatingAmtPerThou == null)? 0 :this.permRatingAmtPerThou.hashCode()));
        result = ((result* 31)+((this.tempFlatExtraOverrideEffDate == null)? 0 :this.tempFlatExtraOverrideEffDate.hashCode()));
        result = ((result* 31)+((this.flatExtraPremBasis == null)? 0 :this.flatExtraPremBasis.hashCode()));
        result = ((result* 31)+((this.formNo == null)? 0 :this.formNo.hashCode()));
        result = ((result* 31)+((this.sECGuidelinePrem == null)? 0 :this.sECGuidelinePrem.hashCode()));
        result = ((result* 31)+((this.premiumRatePerUnit == null)? 0 :this.premiumRatePerUnit.hashCode()));
        result = ((result* 31)+((this.lifeParticipantRefID == null)? 0 :this.lifeParticipantRefID.hashCode()));
        result = ((result* 31)+((this.groupCovOption == null)? 0 :this.groupCovOption.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CovOption) == false) {
            return false;
        }
        CovOption rhs = ((CovOption) other);
        return ((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((this.occupRating == rhs.occupRating)||((this.occupRating!= null)&&this.occupRating.equals(rhs.occupRating)))&&((this.addedDate == rhs.addedDate)||((this.addedDate!= null)&&this.addedDate.equals(rhs.addedDate))))&&((this.occupation == rhs.occupation)||((this.occupation!= null)&&this.occupation.equals(rhs.occupation))))&&((this.planName == rhs.planName)||((this.planName!= null)&&this.planName.equals(rhs.planName))))&&((this.tempPercentageLoading == rhs.tempPercentageLoading)||((this.tempPercentageLoading!= null)&&this.tempPercentageLoading.equals(rhs.tempPercentageLoading))))&&((this.issueSubType == rhs.issueSubType)||((this.issueSubType!= null)&&this.issueSubType.equals(rhs.issueSubType))))&&((this.ratingOverriddenInd == rhs.ratingOverriddenInd)||((this.ratingOverriddenInd!= null)&&this.ratingOverriddenInd.equals(rhs.ratingOverriddenInd))))&&((this.optionNumberOfUnits == rhs.optionNumberOfUnits)||((this.optionNumberOfUnits!= null)&&this.optionNumberOfUnits.equals(rhs.optionNumberOfUnits))))&&((this.levelPremiumPeriod == rhs.levelPremiumPeriod)||((this.levelPremiumPeriod!= null)&&this.levelPremiumPeriod.equals(rhs.levelPremiumPeriod))))&&((this.eRContribAmt == rhs.eRContribAmt)||((this.eRContribAmt!= null)&&this.eRContribAmt.equals(rhs.eRContribAmt))))&&((this.covOptionStatus == rhs.covOptionStatus)||((this.covOptionStatus!= null)&&this.covOptionStatus.equals(rhs.covOptionStatus))))&&((this.eEContribPct == rhs.eEContribPct)||((this.eEContribPct!= null)&&this.eEContribPct.equals(rhs.eEContribPct))))&&((this.modalGrossPermFlatAllowAmt == rhs.modalGrossPermFlatAllowAmt)||((this.modalGrossPermFlatAllowAmt!= null)&&this.modalGrossPermFlatAllowAmt.equals(rhs.modalGrossPermFlatAllowAmt))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.productVersionCode == rhs.productVersionCode)||((this.productVersionCode!= null)&&this.productVersionCode.equals(rhs.productVersionCode))))&&((this.modalGrossFlatExtraPremAmt == rhs.modalGrossFlatExtraPremAmt)||((this.modalGrossFlatExtraPremAmt!= null)&&this.modalGrossFlatExtraPremAmt.equals(rhs.modalGrossFlatExtraPremAmt))))&&((this.permTableRating == rhs.permTableRating)||((this.permTableRating!= null)&&this.permTableRating.equals(rhs.permTableRating))))&&((this.substandardRating == rhs.substandardRating)||((this.substandardRating!= null)&&this.substandardRating.equals(rhs.substandardRating))))&&((this.commissionLink == rhs.commissionLink)||((this.commissionLink!= null)&&this.commissionLink.equals(rhs.commissionLink))))&&((this.renewalPremiumPerUnit == rhs.renewalPremiumPerUnit)||((this.renewalPremiumPerUnit!= null)&&this.renewalPremiumPerUnit.equals(rhs.renewalPremiumPerUnit))))&&((this.deductionOption == rhs.deductionOption)||((this.deductionOption!= null)&&this.deductionOption.equals(rhs.deductionOption))))&&((this.targetPremAmtYTD == rhs.targetPremAmtYTD)||((this.targetPremAmtYTD!= null)&&this.targetPremAmtYTD.equals(rhs.targetPremAmtYTD))))&&((this.benefitLimit == rhs.benefitLimit)||((this.benefitLimit!= null)&&this.benefitLimit.equals(rhs.benefitLimit))))&&((this.targetPremAmtMTD == rhs.targetPremAmtMTD)||((this.targetPremAmtMTD!= null)&&this.targetPremAmtMTD.equals(rhs.targetPremAmtMTD))))&&((this.permRatingType == rhs.permRatingType)||((this.permRatingType!= null)&&this.permRatingType.equals(rhs.permRatingType))))&&((this.permPercentageLoading == rhs.permPercentageLoading)||((this.permPercentageLoading!= null)&&this.permPercentageLoading.equals(rhs.permPercentageLoading))))&&((this.lastRatingDate == rhs.lastRatingDate)||((this.lastRatingDate!= null)&&this.lastRatingDate.equals(rhs.lastRatingDate))))&&((this.premiumPerUnit == rhs.premiumPerUnit)||((this.premiumPerUnit!= null)&&this.premiumPerUnit.equals(rhs.premiumPerUnit))))&&((this.guidelineSinglePrem == rhs.guidelineSinglePrem)||((this.guidelineSinglePrem!= null)&&this.guidelineSinglePrem.equals(rhs.guidelineSinglePrem))))&&((this.targetPremAmtITD == rhs.targetPremAmtITD)||((this.targetPremAmtITD!= null)&&this.targetPremAmtITD.equals(rhs.targetPremAmtITD))))&&((this.covOptionNumber == rhs.covOptionNumber)||((this.covOptionNumber!= null)&&this.covOptionNumber.equals(rhs.covOptionNumber))))&&((this.targetPremAmt == rhs.targetPremAmt)||((this.targetPremAmt!= null)&&this.targetPremAmt.equals(rhs.targetPremAmt))))&&((this.eRContribPct == rhs.eRContribPct)||((this.eRContribPct!= null)&&this.eRContribPct.equals(rhs.eRContribPct))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.shortName == rhs.shortName)||((this.shortName!= null)&&this.shortName.equals(rhs.shortName))))&&((this.targetPremAmtATD == rhs.targetPremAmtATD)||((this.targetPremAmtATD!= null)&&this.targetPremAmtATD.equals(rhs.targetPremAmtATD))))&&((this.tempRatingType == rhs.tempRatingType)||((this.tempRatingType!= null)&&this.tempRatingType.equals(rhs.tempRatingType))))&&((this.eEContribAmt == rhs.eEContribAmt)||((this.eEContribAmt!= null)&&this.eEContribAmt.equals(rhs.eEContribAmt))))&&((this.eliminationPeriod == rhs.eliminationPeriod)||((this.eliminationPeriod!= null)&&this.eliminationPeriod.equals(rhs.eliminationPeriod))))&&((this.preExistingConditionInd == rhs.preExistingConditionInd)||((this.preExistingConditionInd!= null)&&this.preExistingConditionInd.equals(rhs.preExistingConditionInd))))&&((this.tempFlatExtraOverrideEndDate == rhs.tempFlatExtraOverrideEndDate)||((this.tempFlatExtraOverrideEndDate!= null)&&this.tempFlatExtraOverrideEndDate.equals(rhs.tempFlatExtraOverrideEndDate))))&&((this.childMatureAge == rhs.childMatureAge)||((this.childMatureAge!= null)&&this.childMatureAge.equals(rhs.childMatureAge))))&&((this.childAgeUse == rhs.childAgeUse)||((this.childAgeUse!= null)&&this.childAgeUse.equals(rhs.childAgeUse))))&&((this.tempFlatExtraDuration == rhs.tempFlatExtraDuration)||((this.tempFlatExtraDuration!= null)&&this.tempFlatExtraDuration.equals(rhs.tempFlatExtraDuration))))&&((this.paymentStructure == rhs.paymentStructure)||((this.paymentStructure!= null)&&this.paymentStructure.equals(rhs.paymentStructure))))&&((this.className == rhs.className)||((this.className!= null)&&this.className.equals(rhs.className))))&&((this.marketingName == rhs.marketingName)||((this.marketingName!= null)&&this.marketingName.equals(rhs.marketingName))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.conditionTypeOption == rhs.conditionTypeOption)||((this.conditionTypeOption!= null)&&this.conditionTypeOption.equals(rhs.conditionTypeOption))))&&((this.modalGrossFlatExtraAllowanceAmt == rhs.modalGrossFlatExtraAllowanceAmt)||((this.modalGrossFlatExtraAllowanceAmt!= null)&&this.modalGrossFlatExtraAllowanceAmt.equals(rhs.modalGrossFlatExtraAllowanceAmt))))&&((this.filedFormNumber == rhs.filedFormNumber)||((this.filedFormNumber!= null)&&this.filedFormNumber.equals(rhs.filedFormNumber))))&&((this.tempTableRating == rhs.tempTableRating)||((this.tempTableRating!= null)&&this.tempTableRating.equals(rhs.tempTableRating))))&&((this.tempRatingAmtPerThou == rhs.tempRatingAmtPerThou)||((this.tempRatingAmtPerThou!= null)&&this.tempRatingAmtPerThou.equals(rhs.tempRatingAmtPerThou))))&&((this.benefitCoordinationInd == rhs.benefitCoordinationInd)||((this.benefitCoordinationInd!= null)&&this.benefitCoordinationInd.equals(rhs.benefitCoordinationInd))))&&((this.covOptionSysKey == rhs.covOptionSysKey)||((this.covOptionSysKey!= null)&&this.covOptionSysKey.equals(rhs.covOptionSysKey))))&&((this.underwritingSubClass == rhs.underwritingSubClass)||((this.underwritingSubClass!= null)&&this.underwritingSubClass.equals(rhs.underwritingSubClass))))&&((this.paidUpDate == rhs.paidUpDate)||((this.paidUpDate!= null)&&this.paidUpDate.equals(rhs.paidUpDate))))&&((this.covOptionKey == rhs.covOptionKey)||((this.covOptionKey!= null)&&this.covOptionKey.equals(rhs.covOptionKey))))&&((this.tempTableRatingEndDate == rhs.tempTableRatingEndDate)||((this.tempTableRatingEndDate!= null)&&this.tempTableRatingEndDate.equals(rhs.tempTableRatingEndDate))))&&((this.ratingReason == rhs.ratingReason)||((this.ratingReason!= null)&&this.ratingReason.equals(rhs.ratingReason))))&&((this.tempFlatStartDate == rhs.tempFlatStartDate)||((this.tempFlatStartDate!= null)&&this.tempFlatStartDate.equals(rhs.tempFlatStartDate))))&&((this.productCode == rhs.productCode)||((this.productCode!= null)&&this.productCode.equals(rhs.productCode))))&&((this.modalPremAmt == rhs.modalPremAmt)||((this.modalPremAmt!= null)&&this.modalPremAmt.equals(rhs.modalPremAmt))))&&((this.tempFlatExtraAmt == rhs.tempFlatExtraAmt)||((this.tempFlatExtraAmt!= null)&&this.tempFlatExtraAmt.equals(rhs.tempFlatExtraAmt))))&&((this.benefitPeriod == rhs.benefitPeriod)||((this.benefitPeriod!= null)&&this.benefitPeriod.equals(rhs.benefitPeriod))))&&((this.modalGrossTempFlatAllowAmt == rhs.modalGrossTempFlatAllowAmt)||((this.modalGrossTempFlatAllowAmt!= null)&&this.modalGrossTempFlatAllowAmt.equals(rhs.modalGrossTempFlatAllowAmt))))&&((this.covOptionXLat == rhs.covOptionXLat)||((this.covOptionXLat!= null)&&this.covOptionXLat.equals(rhs.covOptionXLat))))&&((this.exerciseDate == rhs.exerciseDate)||((this.exerciseDate!= null)&&this.exerciseDate.equals(rhs.exerciseDate))))&&((this.restrictionInfo == rhs.restrictionInfo)||((this.restrictionInfo!= null)&&this.restrictionInfo.equals(rhs.restrictionInfo))))&&((this.tempTableRatingCode == rhs.tempTableRatingCode)||((this.tempTableRatingCode!= null)&&this.tempTableRatingCode.equals(rhs.tempTableRatingCode))))&&((this.durationDesign == rhs.durationDesign)||((this.durationDesign!= null)&&this.durationDesign.equals(rhs.durationDesign))))&&((this.underwritingClass == rhs.underwritingClass)||((this.underwritingClass!= null)&&this.underwritingClass.equals(rhs.underwritingClass))))&&((this.participant == rhs.participant)||((this.participant!= null)&&this.participant.equals(rhs.participant))))&&((this.tobaccoPremiumBasis == rhs.tobaccoPremiumBasis)||((this.tobaccoPremiumBasis!= null)&&this.tobaccoPremiumBasis.equals(rhs.tobaccoPremiumBasis))))&&((this.deathBenefitAmt == rhs.deathBenefitAmt)||((this.deathBenefitAmt!= null)&&this.deathBenefitAmt.equals(rhs.deathBenefitAmt))))&&((this.payToYear == rhs.payToYear)||((this.payToYear!= null)&&this.payToYear.equals(rhs.payToYear))))&&((this.lifeCovOptTypeCode == rhs.lifeCovOptTypeCode)||((this.lifeCovOptTypeCode!= null)&&this.lifeCovOptTypeCode.equals(rhs.lifeCovOptTypeCode))))&&((this.effDate == rhs.effDate)||((this.effDate!= null)&&this.effDate.equals(rhs.effDate))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.permFlatExtraAmt == rhs.permFlatExtraAmt)||((this.permFlatExtraAmt!= null)&&this.permFlatExtraAmt.equals(rhs.permFlatExtraAmt))))&&((this.permFlatExtraEndDate == rhs.permFlatExtraEndDate)||((this.permFlatExtraEndDate!= null)&&this.permFlatExtraEndDate.equals(rhs.permFlatExtraEndDate))))&&((this.gDBPrem == rhs.gDBPrem)||((this.gDBPrem!= null)&&this.gDBPrem.equals(rhs.gDBPrem))))&&((this.issuedAsAppliedInd == rhs.issuedAsAppliedInd)||((this.issuedAsAppliedInd!= null)&&this.issuedAsAppliedInd.equals(rhs.issuedAsAppliedInd))))&&((this.optionPctType == rhs.optionPctType)||((this.optionPctType!= null)&&this.optionPctType.equals(rhs.optionPctType))))&&((this.reinsuranceInfo == rhs.reinsuranceInfo)||((this.reinsuranceInfo!= null)&&this.reinsuranceInfo.equals(rhs.reinsuranceInfo))))&&((this.permTableRatingEndDate == rhs.permTableRatingEndDate)||((this.permTableRatingEndDate!= null)&&this.permTableRatingEndDate.equals(rhs.permTableRatingEndDate))))&&((this.annualPremAmt == rhs.annualPremAmt)||((this.annualPremAmt!= null)&&this.annualPremAmt.equals(rhs.annualPremAmt))))&&((this.issueType == rhs.issueType)||((this.issueType!= null)&&this.issueType.equals(rhs.issueType))))&&((this.payToAge == rhs.payToAge)||((this.payToAge!= null)&&this.payToAge.equals(rhs.payToAge))))&&((this.tempFlatEndDate == rhs.tempFlatEndDate)||((this.tempFlatEndDate!= null)&&this.tempFlatEndDate.equals(rhs.tempFlatEndDate))))&&((this.gracePeriodStartDate == rhs.gracePeriodStartDate)||((this.gracePeriodStartDate!= null)&&this.gracePeriodStartDate.equals(rhs.gracePeriodStartDate))))&&((this.mec7DBLowest == rhs.mec7DBLowest)||((this.mec7DBLowest!= null)&&this.mec7DBLowest.equals(rhs.mec7DBLowest))))&&((this.termDate == rhs.termDate)||((this.termDate!= null)&&this.termDate.equals(rhs.termDate))))&&((this.permTableRatingAlphaCode == rhs.permTableRatingAlphaCode)||((this.permTableRatingAlphaCode!= null)&&this.permTableRatingAlphaCode.equals(rhs.permTableRatingAlphaCode))))&&((this.modalPermRatingAmt == rhs.modalPermRatingAmt)||((this.modalPermRatingAmt!= null)&&this.modalPermRatingAmt.equals(rhs.modalPermRatingAmt))))&&((this.altPremMode == rhs.altPremMode)||((this.altPremMode!= null)&&this.altPremMode.equals(rhs.altPremMode))))&&((this.commissionRate == rhs.commissionRate)||((this.commissionRate!= null)&&this.commissionRate.equals(rhs.commissionRate))))&&((this.carrierLicenseID == rhs.carrierLicenseID)||((this.carrierLicenseID!= null)&&this.carrierLicenseID.equals(rhs.carrierLicenseID))))&&((this.levelPremiumPeriodUnits == rhs.levelPremiumPeriodUnits)||((this.levelPremiumPeriodUnits!= null)&&this.levelPremiumPeriodUnits.equals(rhs.levelPremiumPeriodUnits))))&&((this.ratingCommissionRule == rhs.ratingCommissionRule)||((this.ratingCommissionRule!= null)&&this.ratingCommissionRule.equals(rhs.ratingCommissionRule))))&&((this.description == rhs.description)||((this.description!= null)&&this.description.equals(rhs.description))))&&((this.valuePerUnit == rhs.valuePerUnit)||((this.valuePerUnit!= null)&&this.valuePerUnit.equals(rhs.valuePerUnit))))&&((this.livesType == rhs.livesType)||((this.livesType!= null)&&this.livesType.equals(rhs.livesType))))&&((this.modalTempRatingAmt == rhs.modalTempRatingAmt)||((this.modalTempRatingAmt!= null)&&this.modalTempRatingAmt.equals(rhs.modalTempRatingAmt))))&&((this.expiryDate == rhs.expiryDate)||((this.expiryDate!= null)&&this.expiryDate.equals(rhs.expiryDate))))&&((this.qualAddBenefitInd == rhs.qualAddBenefitInd)||((this.qualAddBenefitInd!= null)&&this.qualAddBenefitInd.equals(rhs.qualAddBenefitInd))))&&((this.duration == rhs.duration)||((this.duration!= null)&&this.duration.equals(rhs.duration))))&&((this.optionPct == rhs.optionPct)||((this.optionPct!= null)&&this.optionPct.equals(rhs.optionPct))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))))&&((this.premSourceType == rhs.premSourceType)||((this.premSourceType!= null)&&this.premSourceType.equals(rhs.premSourceType))))&&((this.minPremAmt == rhs.minPremAmt)||((this.minPremAmt!= null)&&this.minPremAmt.equals(rhs.minPremAmt))))&&((this.renewalPremiumRatePerUnit == rhs.renewalPremiumRatePerUnit)||((this.renewalPremiumRatePerUnit!= null)&&this.renewalPremiumRatePerUnit.equals(rhs.renewalPremiumRatePerUnit))))&&((this.tempTableRatingStartDate == rhs.tempTableRatingStartDate)||((this.tempTableRatingStartDate!= null)&&this.tempTableRatingStartDate.equals(rhs.tempTableRatingStartDate))))&&((this.netCurrentAmt == rhs.netCurrentAmt)||((this.netCurrentAmt!= null)&&this.netCurrentAmt.equals(rhs.netCurrentAmt))))&&((this.covOptionPctInd == rhs.covOptionPctInd)||((this.covOptionPctInd!= null)&&this.covOptionPctInd.equals(rhs.covOptionPctInd))))&&((this.upgradeAvailableInd == rhs.upgradeAvailableInd)||((this.upgradeAvailableInd!= null)&&this.upgradeAvailableInd.equals(rhs.upgradeAvailableInd))))&&((this.maxBenefitAmt == rhs.maxBenefitAmt)||((this.maxBenefitAmt!= null)&&this.maxBenefitAmt.equals(rhs.maxBenefitAmt))))&&((this.guidelineAnnPremSum == rhs.guidelineAnnPremSum)||((this.guidelineAnnPremSum!= null)&&this.guidelineAnnPremSum.equals(rhs.guidelineAnnPremSum))))&&((this.annualIndexType == rhs.annualIndexType)||((this.annualIndexType!= null)&&this.annualIndexType.equals(rhs.annualIndexType))))&&((this.optionAmt == rhs.optionAmt)||((this.optionAmt!= null)&&this.optionAmt.equals(rhs.optionAmt))))&&((this.benefitMode == rhs.benefitMode)||((this.benefitMode!= null)&&this.benefitMode.equals(rhs.benefitMode))))&&((this.guidelineAnnPrem == rhs.guidelineAnnPrem)||((this.guidelineAnnPrem!= null)&&this.guidelineAnnPrem.equals(rhs.guidelineAnnPrem))))&&((this.permRatingAmtPerThou == rhs.permRatingAmtPerThou)||((this.permRatingAmtPerThou!= null)&&this.permRatingAmtPerThou.equals(rhs.permRatingAmtPerThou))))&&((this.tempFlatExtraOverrideEffDate == rhs.tempFlatExtraOverrideEffDate)||((this.tempFlatExtraOverrideEffDate!= null)&&this.tempFlatExtraOverrideEffDate.equals(rhs.tempFlatExtraOverrideEffDate))))&&((this.flatExtraPremBasis == rhs.flatExtraPremBasis)||((this.flatExtraPremBasis!= null)&&this.flatExtraPremBasis.equals(rhs.flatExtraPremBasis))))&&((this.formNo == rhs.formNo)||((this.formNo!= null)&&this.formNo.equals(rhs.formNo))))&&((this.sECGuidelinePrem == rhs.sECGuidelinePrem)||((this.sECGuidelinePrem!= null)&&this.sECGuidelinePrem.equals(rhs.sECGuidelinePrem))))&&((this.premiumRatePerUnit == rhs.premiumRatePerUnit)||((this.premiumRatePerUnit!= null)&&this.premiumRatePerUnit.equals(rhs.premiumRatePerUnit))))&&((this.lifeParticipantRefID == rhs.lifeParticipantRefID)||((this.lifeParticipantRefID!= null)&&this.lifeParticipantRefID.equals(rhs.lifeParticipantRefID))))&&((this.groupCovOption == rhs.groupCovOption)||((this.groupCovOption!= null)&&this.groupCovOption.equals(rhs.groupCovOption))));
    }

}
