
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SubstandardRatingKey",
    "SubstandardRatingSysKey",
    "RatingReason",
    "RatingCommissionRule",
    "PermTableRating",
    "PermTableRatingEndDate",
    "TempTableRating",
    "TempTableRatingStartDate",
    "TempTableRatingEndDate",
    "TempFlatEndDate",
    "TempFlatExtraAmt",
    "FlatExtraPremBasis",
    "AmtPerThou",
    "ModalGrossPermFlatExtraAllowanceAmt",
    "ModalGrossTempFlatExtraAllowanceAmt",
    "TempFlatExtraDuration",
    "TempPercentageLoading",
    "PermPercentageLoading",
    "EndDate",
    "EffDate",
    "PermFlatExtraAmt",
    "PermFlatExtraEndDate",
    "PermTableRatingAlphaCode",
    "TempTableRatingCode",
    "LastRatingDate",
    "TempRatingType",
    "PermRatingType",
    "TempFlatStartDate",
    "Occupation",
    "OccupRating",
    "RatingOverriddenInd",
    "PermRatingAmtPerThou",
    "TempRatingAmtPerThou",
    "ModalPermRatingAmt",
    "ModalTempRatingAmt",
    "KeyedValue",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class SubstandardRating {

    @JsonProperty("SubstandardRatingKey")
    private SubstandardRatingKey substandardRatingKey;
    @JsonProperty("SubstandardRatingSysKey")
    private List<Object> substandardRatingSysKey = new ArrayList<>();
    @JsonProperty("RatingReason")
    private String ratingReason;
    @JsonProperty("RatingCommissionRule")
    private RatingCommissionRule ratingCommissionRule;
    @JsonProperty("PermTableRating")
    private PermTableRating permTableRating;
    @JsonProperty("PermTableRatingEndDate")
    private String permTableRatingEndDate;
    @JsonProperty("TempTableRating")
    private TempTableRating tempTableRating;
    @JsonProperty("TempTableRatingStartDate")
    private String tempTableRatingStartDate;
    @JsonProperty("TempTableRatingEndDate")
    private String tempTableRatingEndDate;
    @JsonProperty("TempFlatEndDate")
    private String tempFlatEndDate;
    @JsonProperty("TempFlatExtraAmt")
    private Integer tempFlatExtraAmt;
    @JsonProperty("FlatExtraPremBasis")
    private FlatExtraPremBasis flatExtraPremBasis;
    @JsonProperty("AmtPerThou")
    private Integer amtPerThou;
    @JsonProperty("ModalGrossPermFlatExtraAllowanceAmt")
    private Integer modalGrossPermFlatExtraAllowanceAmt;
    @JsonProperty("ModalGrossTempFlatExtraAllowanceAmt")
    private Integer modalGrossTempFlatExtraAllowanceAmt;
    @JsonProperty("TempFlatExtraDuration")
    private Integer tempFlatExtraDuration;
    @JsonProperty("TempPercentageLoading")
    private Integer tempPercentageLoading;
    @JsonProperty("PermPercentageLoading")
    private Integer permPercentageLoading;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("EffDate")
    private String effDate;
    @JsonProperty("PermFlatExtraAmt")
    private Integer permFlatExtraAmt;
    @JsonProperty("PermFlatExtraEndDate")
    private String permFlatExtraEndDate;
    @JsonProperty("PermTableRatingAlphaCode")
    private String permTableRatingAlphaCode;
    @JsonProperty("TempTableRatingCode")
    private String tempTableRatingCode;
    @JsonProperty("LastRatingDate")
    private String lastRatingDate;
    @JsonProperty("TempRatingType")
    private TempRatingType tempRatingType;
    @JsonProperty("PermRatingType")
    private PermRatingType permRatingType;
    @JsonProperty("TempFlatStartDate")
    private String tempFlatStartDate;
    @JsonProperty("Occupation")
    private String occupation;
    @JsonProperty("OccupRating")
    private OccupRating occupRating;
    @JsonProperty("RatingOverriddenInd")
    private RatingOverriddenInd ratingOverriddenInd;
    @JsonProperty("PermRatingAmtPerThou")
    private Integer permRatingAmtPerThou;
    @JsonProperty("TempRatingAmtPerThou")
    private Integer tempRatingAmtPerThou;
    @JsonProperty("ModalPermRatingAmt")
    private Integer modalPermRatingAmt;
    @JsonProperty("ModalTempRatingAmt")
    private Integer modalTempRatingAmt;
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("SubstandardRatingKey")
    public SubstandardRatingKey getSubstandardRatingKey() {
        return substandardRatingKey;
    }

    @JsonProperty("SubstandardRatingKey")
    public void setSubstandardRatingKey(SubstandardRatingKey substandardRatingKey) {
        this.substandardRatingKey = substandardRatingKey;
    }

    public SubstandardRating withSubstandardRatingKey(SubstandardRatingKey substandardRatingKey) {
        this.substandardRatingKey = substandardRatingKey;
        return this;
    }

    @JsonProperty("SubstandardRatingSysKey")
    public List<Object> getSubstandardRatingSysKey() {
        return substandardRatingSysKey;
    }

    @JsonProperty("SubstandardRatingSysKey")
    public void setSubstandardRatingSysKey(List<Object> substandardRatingSysKey) {
        this.substandardRatingSysKey = substandardRatingSysKey;
    }

    public SubstandardRating withSubstandardRatingSysKey(List<Object> substandardRatingSysKey) {
        this.substandardRatingSysKey = substandardRatingSysKey;
        return this;
    }

    @JsonProperty("RatingReason")
    public String getRatingReason() {
        return ratingReason;
    }

    @JsonProperty("RatingReason")
    public void setRatingReason(String ratingReason) {
        this.ratingReason = ratingReason;
    }

    public SubstandardRating withRatingReason(String ratingReason) {
        this.ratingReason = ratingReason;
        return this;
    }

    @JsonProperty("RatingCommissionRule")
    public RatingCommissionRule getRatingCommissionRule() {
        return ratingCommissionRule;
    }

    @JsonProperty("RatingCommissionRule")
    public void setRatingCommissionRule(RatingCommissionRule ratingCommissionRule) {
        this.ratingCommissionRule = ratingCommissionRule;
    }

    public SubstandardRating withRatingCommissionRule(RatingCommissionRule ratingCommissionRule) {
        this.ratingCommissionRule = ratingCommissionRule;
        return this;
    }

    @JsonProperty("PermTableRating")
    public PermTableRating getPermTableRating() {
        return permTableRating;
    }

    @JsonProperty("PermTableRating")
    public void setPermTableRating(PermTableRating permTableRating) {
        this.permTableRating = permTableRating;
    }

    public SubstandardRating withPermTableRating(PermTableRating permTableRating) {
        this.permTableRating = permTableRating;
        return this;
    }

    @JsonProperty("PermTableRatingEndDate")
    public String getPermTableRatingEndDate() {
        return permTableRatingEndDate;
    }

    @JsonProperty("PermTableRatingEndDate")
    public void setPermTableRatingEndDate(String permTableRatingEndDate) {
        this.permTableRatingEndDate = permTableRatingEndDate;
    }

    public SubstandardRating withPermTableRatingEndDate(String permTableRatingEndDate) {
        this.permTableRatingEndDate = permTableRatingEndDate;
        return this;
    }

    @JsonProperty("TempTableRating")
    public TempTableRating getTempTableRating() {
        return tempTableRating;
    }

    @JsonProperty("TempTableRating")
    public void setTempTableRating(TempTableRating tempTableRating) {
        this.tempTableRating = tempTableRating;
    }

    public SubstandardRating withTempTableRating(TempTableRating tempTableRating) {
        this.tempTableRating = tempTableRating;
        return this;
    }

    @JsonProperty("TempTableRatingStartDate")
    public String getTempTableRatingStartDate() {
        return tempTableRatingStartDate;
    }

    @JsonProperty("TempTableRatingStartDate")
    public void setTempTableRatingStartDate(String tempTableRatingStartDate) {
        this.tempTableRatingStartDate = tempTableRatingStartDate;
    }

    public SubstandardRating withTempTableRatingStartDate(String tempTableRatingStartDate) {
        this.tempTableRatingStartDate = tempTableRatingStartDate;
        return this;
    }

    @JsonProperty("TempTableRatingEndDate")
    public String getTempTableRatingEndDate() {
        return tempTableRatingEndDate;
    }

    @JsonProperty("TempTableRatingEndDate")
    public void setTempTableRatingEndDate(String tempTableRatingEndDate) {
        this.tempTableRatingEndDate = tempTableRatingEndDate;
    }

    public SubstandardRating withTempTableRatingEndDate(String tempTableRatingEndDate) {
        this.tempTableRatingEndDate = tempTableRatingEndDate;
        return this;
    }

    @JsonProperty("TempFlatEndDate")
    public String getTempFlatEndDate() {
        return tempFlatEndDate;
    }

    @JsonProperty("TempFlatEndDate")
    public void setTempFlatEndDate(String tempFlatEndDate) {
        this.tempFlatEndDate = tempFlatEndDate;
    }

    public SubstandardRating withTempFlatEndDate(String tempFlatEndDate) {
        this.tempFlatEndDate = tempFlatEndDate;
        return this;
    }

    @JsonProperty("TempFlatExtraAmt")
    public Integer getTempFlatExtraAmt() {
        return tempFlatExtraAmt;
    }

    @JsonProperty("TempFlatExtraAmt")
    public void setTempFlatExtraAmt(Integer tempFlatExtraAmt) {
        this.tempFlatExtraAmt = tempFlatExtraAmt;
    }

    public SubstandardRating withTempFlatExtraAmt(Integer tempFlatExtraAmt) {
        this.tempFlatExtraAmt = tempFlatExtraAmt;
        return this;
    }

    @JsonProperty("FlatExtraPremBasis")
    public FlatExtraPremBasis getFlatExtraPremBasis() {
        return flatExtraPremBasis;
    }

    @JsonProperty("FlatExtraPremBasis")
    public void setFlatExtraPremBasis(FlatExtraPremBasis flatExtraPremBasis) {
        this.flatExtraPremBasis = flatExtraPremBasis;
    }

    public SubstandardRating withFlatExtraPremBasis(FlatExtraPremBasis flatExtraPremBasis) {
        this.flatExtraPremBasis = flatExtraPremBasis;
        return this;
    }

    @JsonProperty("AmtPerThou")
    public Integer getAmtPerThou() {
        return amtPerThou;
    }

    @JsonProperty("AmtPerThou")
    public void setAmtPerThou(Integer amtPerThou) {
        this.amtPerThou = amtPerThou;
    }

    public SubstandardRating withAmtPerThou(Integer amtPerThou) {
        this.amtPerThou = amtPerThou;
        return this;
    }

    @JsonProperty("ModalGrossPermFlatExtraAllowanceAmt")
    public Integer getModalGrossPermFlatExtraAllowanceAmt() {
        return modalGrossPermFlatExtraAllowanceAmt;
    }

    @JsonProperty("ModalGrossPermFlatExtraAllowanceAmt")
    public void setModalGrossPermFlatExtraAllowanceAmt(Integer modalGrossPermFlatExtraAllowanceAmt) {
        this.modalGrossPermFlatExtraAllowanceAmt = modalGrossPermFlatExtraAllowanceAmt;
    }

    public SubstandardRating withModalGrossPermFlatExtraAllowanceAmt(Integer modalGrossPermFlatExtraAllowanceAmt) {
        this.modalGrossPermFlatExtraAllowanceAmt = modalGrossPermFlatExtraAllowanceAmt;
        return this;
    }

    @JsonProperty("ModalGrossTempFlatExtraAllowanceAmt")
    public Integer getModalGrossTempFlatExtraAllowanceAmt() {
        return modalGrossTempFlatExtraAllowanceAmt;
    }

    @JsonProperty("ModalGrossTempFlatExtraAllowanceAmt")
    public void setModalGrossTempFlatExtraAllowanceAmt(Integer modalGrossTempFlatExtraAllowanceAmt) {
        this.modalGrossTempFlatExtraAllowanceAmt = modalGrossTempFlatExtraAllowanceAmt;
    }

    public SubstandardRating withModalGrossTempFlatExtraAllowanceAmt(Integer modalGrossTempFlatExtraAllowanceAmt) {
        this.modalGrossTempFlatExtraAllowanceAmt = modalGrossTempFlatExtraAllowanceAmt;
        return this;
    }

    @JsonProperty("TempFlatExtraDuration")
    public Integer getTempFlatExtraDuration() {
        return tempFlatExtraDuration;
    }

    @JsonProperty("TempFlatExtraDuration")
    public void setTempFlatExtraDuration(Integer tempFlatExtraDuration) {
        this.tempFlatExtraDuration = tempFlatExtraDuration;
    }

    public SubstandardRating withTempFlatExtraDuration(Integer tempFlatExtraDuration) {
        this.tempFlatExtraDuration = tempFlatExtraDuration;
        return this;
    }

    @JsonProperty("TempPercentageLoading")
    public Integer getTempPercentageLoading() {
        return tempPercentageLoading;
    }

    @JsonProperty("TempPercentageLoading")
    public void setTempPercentageLoading(Integer tempPercentageLoading) {
        this.tempPercentageLoading = tempPercentageLoading;
    }

    public SubstandardRating withTempPercentageLoading(Integer tempPercentageLoading) {
        this.tempPercentageLoading = tempPercentageLoading;
        return this;
    }

    @JsonProperty("PermPercentageLoading")
    public Integer getPermPercentageLoading() {
        return permPercentageLoading;
    }

    @JsonProperty("PermPercentageLoading")
    public void setPermPercentageLoading(Integer permPercentageLoading) {
        this.permPercentageLoading = permPercentageLoading;
    }

    public SubstandardRating withPermPercentageLoading(Integer permPercentageLoading) {
        this.permPercentageLoading = permPercentageLoading;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public SubstandardRating withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("EffDate")
    public String getEffDate() {
        return effDate;
    }

    @JsonProperty("EffDate")
    public void setEffDate(String effDate) {
        this.effDate = effDate;
    }

    public SubstandardRating withEffDate(String effDate) {
        this.effDate = effDate;
        return this;
    }

    @JsonProperty("PermFlatExtraAmt")
    public Integer getPermFlatExtraAmt() {
        return permFlatExtraAmt;
    }

    @JsonProperty("PermFlatExtraAmt")
    public void setPermFlatExtraAmt(Integer permFlatExtraAmt) {
        this.permFlatExtraAmt = permFlatExtraAmt;
    }

    public SubstandardRating withPermFlatExtraAmt(Integer permFlatExtraAmt) {
        this.permFlatExtraAmt = permFlatExtraAmt;
        return this;
    }

    @JsonProperty("PermFlatExtraEndDate")
    public String getPermFlatExtraEndDate() {
        return permFlatExtraEndDate;
    }

    @JsonProperty("PermFlatExtraEndDate")
    public void setPermFlatExtraEndDate(String permFlatExtraEndDate) {
        this.permFlatExtraEndDate = permFlatExtraEndDate;
    }

    public SubstandardRating withPermFlatExtraEndDate(String permFlatExtraEndDate) {
        this.permFlatExtraEndDate = permFlatExtraEndDate;
        return this;
    }

    @JsonProperty("PermTableRatingAlphaCode")
    public String getPermTableRatingAlphaCode() {
        return permTableRatingAlphaCode;
    }

    @JsonProperty("PermTableRatingAlphaCode")
    public void setPermTableRatingAlphaCode(String permTableRatingAlphaCode) {
        this.permTableRatingAlphaCode = permTableRatingAlphaCode;
    }

    public SubstandardRating withPermTableRatingAlphaCode(String permTableRatingAlphaCode) {
        this.permTableRatingAlphaCode = permTableRatingAlphaCode;
        return this;
    }

    @JsonProperty("TempTableRatingCode")
    public String getTempTableRatingCode() {
        return tempTableRatingCode;
    }

    @JsonProperty("TempTableRatingCode")
    public void setTempTableRatingCode(String tempTableRatingCode) {
        this.tempTableRatingCode = tempTableRatingCode;
    }

    public SubstandardRating withTempTableRatingCode(String tempTableRatingCode) {
        this.tempTableRatingCode = tempTableRatingCode;
        return this;
    }

    @JsonProperty("LastRatingDate")
    public String getLastRatingDate() {
        return lastRatingDate;
    }

    @JsonProperty("LastRatingDate")
    public void setLastRatingDate(String lastRatingDate) {
        this.lastRatingDate = lastRatingDate;
    }

    public SubstandardRating withLastRatingDate(String lastRatingDate) {
        this.lastRatingDate = lastRatingDate;
        return this;
    }

    @JsonProperty("TempRatingType")
    public TempRatingType getTempRatingType() {
        return tempRatingType;
    }

    @JsonProperty("TempRatingType")
    public void setTempRatingType(TempRatingType tempRatingType) {
        this.tempRatingType = tempRatingType;
    }

    public SubstandardRating withTempRatingType(TempRatingType tempRatingType) {
        this.tempRatingType = tempRatingType;
        return this;
    }

    @JsonProperty("PermRatingType")
    public PermRatingType getPermRatingType() {
        return permRatingType;
    }

    @JsonProperty("PermRatingType")
    public void setPermRatingType(PermRatingType permRatingType) {
        this.permRatingType = permRatingType;
    }

    public SubstandardRating withPermRatingType(PermRatingType permRatingType) {
        this.permRatingType = permRatingType;
        return this;
    }

    @JsonProperty("TempFlatStartDate")
    public String getTempFlatStartDate() {
        return tempFlatStartDate;
    }

    @JsonProperty("TempFlatStartDate")
    public void setTempFlatStartDate(String tempFlatStartDate) {
        this.tempFlatStartDate = tempFlatStartDate;
    }

    public SubstandardRating withTempFlatStartDate(String tempFlatStartDate) {
        this.tempFlatStartDate = tempFlatStartDate;
        return this;
    }

    @JsonProperty("Occupation")
    public String getOccupation() {
        return occupation;
    }

    @JsonProperty("Occupation")
    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public SubstandardRating withOccupation(String occupation) {
        this.occupation = occupation;
        return this;
    }

    @JsonProperty("OccupRating")
    public OccupRating getOccupRating() {
        return occupRating;
    }

    @JsonProperty("OccupRating")
    public void setOccupRating(OccupRating occupRating) {
        this.occupRating = occupRating;
    }

    public SubstandardRating withOccupRating(OccupRating occupRating) {
        this.occupRating = occupRating;
        return this;
    }

    @JsonProperty("RatingOverriddenInd")
    public RatingOverriddenInd getRatingOverriddenInd() {
        return ratingOverriddenInd;
    }

    @JsonProperty("RatingOverriddenInd")
    public void setRatingOverriddenInd(RatingOverriddenInd ratingOverriddenInd) {
        this.ratingOverriddenInd = ratingOverriddenInd;
    }

    public SubstandardRating withRatingOverriddenInd(RatingOverriddenInd ratingOverriddenInd) {
        this.ratingOverriddenInd = ratingOverriddenInd;
        return this;
    }

    @JsonProperty("PermRatingAmtPerThou")
    public Integer getPermRatingAmtPerThou() {
        return permRatingAmtPerThou;
    }

    @JsonProperty("PermRatingAmtPerThou")
    public void setPermRatingAmtPerThou(Integer permRatingAmtPerThou) {
        this.permRatingAmtPerThou = permRatingAmtPerThou;
    }

    public SubstandardRating withPermRatingAmtPerThou(Integer permRatingAmtPerThou) {
        this.permRatingAmtPerThou = permRatingAmtPerThou;
        return this;
    }

    @JsonProperty("TempRatingAmtPerThou")
    public Integer getTempRatingAmtPerThou() {
        return tempRatingAmtPerThou;
    }

    @JsonProperty("TempRatingAmtPerThou")
    public void setTempRatingAmtPerThou(Integer tempRatingAmtPerThou) {
        this.tempRatingAmtPerThou = tempRatingAmtPerThou;
    }

    public SubstandardRating withTempRatingAmtPerThou(Integer tempRatingAmtPerThou) {
        this.tempRatingAmtPerThou = tempRatingAmtPerThou;
        return this;
    }

    @JsonProperty("ModalPermRatingAmt")
    public Integer getModalPermRatingAmt() {
        return modalPermRatingAmt;
    }

    @JsonProperty("ModalPermRatingAmt")
    public void setModalPermRatingAmt(Integer modalPermRatingAmt) {
        this.modalPermRatingAmt = modalPermRatingAmt;
    }

    public SubstandardRating withModalPermRatingAmt(Integer modalPermRatingAmt) {
        this.modalPermRatingAmt = modalPermRatingAmt;
        return this;
    }

    @JsonProperty("ModalTempRatingAmt")
    public Integer getModalTempRatingAmt() {
        return modalTempRatingAmt;
    }

    @JsonProperty("ModalTempRatingAmt")
    public void setModalTempRatingAmt(Integer modalTempRatingAmt) {
        this.modalTempRatingAmt = modalTempRatingAmt;
    }

    public SubstandardRating withModalTempRatingAmt(Integer modalTempRatingAmt) {
        this.modalTempRatingAmt = modalTempRatingAmt;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public SubstandardRating withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public SubstandardRating withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public SubstandardRating withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public SubstandardRating withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SubstandardRating withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(SubstandardRating.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("substandardRatingKey");
        sb.append('=');
        sb.append(((this.substandardRatingKey == null)?"<null>":this.substandardRatingKey));
        sb.append(',');
        sb.append("substandardRatingSysKey");
        sb.append('=');
        sb.append(((this.substandardRatingSysKey == null)?"<null>":this.substandardRatingSysKey));
        sb.append(',');
        sb.append("ratingReason");
        sb.append('=');
        sb.append(((this.ratingReason == null)?"<null>":this.ratingReason));
        sb.append(',');
        sb.append("ratingCommissionRule");
        sb.append('=');
        sb.append(((this.ratingCommissionRule == null)?"<null>":this.ratingCommissionRule));
        sb.append(',');
        sb.append("permTableRating");
        sb.append('=');
        sb.append(((this.permTableRating == null)?"<null>":this.permTableRating));
        sb.append(',');
        sb.append("permTableRatingEndDate");
        sb.append('=');
        sb.append(((this.permTableRatingEndDate == null)?"<null>":this.permTableRatingEndDate));
        sb.append(',');
        sb.append("tempTableRating");
        sb.append('=');
        sb.append(((this.tempTableRating == null)?"<null>":this.tempTableRating));
        sb.append(',');
        sb.append("tempTableRatingStartDate");
        sb.append('=');
        sb.append(((this.tempTableRatingStartDate == null)?"<null>":this.tempTableRatingStartDate));
        sb.append(',');
        sb.append("tempTableRatingEndDate");
        sb.append('=');
        sb.append(((this.tempTableRatingEndDate == null)?"<null>":this.tempTableRatingEndDate));
        sb.append(',');
        sb.append("tempFlatEndDate");
        sb.append('=');
        sb.append(((this.tempFlatEndDate == null)?"<null>":this.tempFlatEndDate));
        sb.append(',');
        sb.append("tempFlatExtraAmt");
        sb.append('=');
        sb.append(((this.tempFlatExtraAmt == null)?"<null>":this.tempFlatExtraAmt));
        sb.append(',');
        sb.append("flatExtraPremBasis");
        sb.append('=');
        sb.append(((this.flatExtraPremBasis == null)?"<null>":this.flatExtraPremBasis));
        sb.append(',');
        sb.append("amtPerThou");
        sb.append('=');
        sb.append(((this.amtPerThou == null)?"<null>":this.amtPerThou));
        sb.append(',');
        sb.append("modalGrossPermFlatExtraAllowanceAmt");
        sb.append('=');
        sb.append(((this.modalGrossPermFlatExtraAllowanceAmt == null)?"<null>":this.modalGrossPermFlatExtraAllowanceAmt));
        sb.append(',');
        sb.append("modalGrossTempFlatExtraAllowanceAmt");
        sb.append('=');
        sb.append(((this.modalGrossTempFlatExtraAllowanceAmt == null)?"<null>":this.modalGrossTempFlatExtraAllowanceAmt));
        sb.append(',');
        sb.append("tempFlatExtraDuration");
        sb.append('=');
        sb.append(((this.tempFlatExtraDuration == null)?"<null>":this.tempFlatExtraDuration));
        sb.append(',');
        sb.append("tempPercentageLoading");
        sb.append('=');
        sb.append(((this.tempPercentageLoading == null)?"<null>":this.tempPercentageLoading));
        sb.append(',');
        sb.append("permPercentageLoading");
        sb.append('=');
        sb.append(((this.permPercentageLoading == null)?"<null>":this.permPercentageLoading));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("effDate");
        sb.append('=');
        sb.append(((this.effDate == null)?"<null>":this.effDate));
        sb.append(',');
        sb.append("permFlatExtraAmt");
        sb.append('=');
        sb.append(((this.permFlatExtraAmt == null)?"<null>":this.permFlatExtraAmt));
        sb.append(',');
        sb.append("permFlatExtraEndDate");
        sb.append('=');
        sb.append(((this.permFlatExtraEndDate == null)?"<null>":this.permFlatExtraEndDate));
        sb.append(',');
        sb.append("permTableRatingAlphaCode");
        sb.append('=');
        sb.append(((this.permTableRatingAlphaCode == null)?"<null>":this.permTableRatingAlphaCode));
        sb.append(',');
        sb.append("tempTableRatingCode");
        sb.append('=');
        sb.append(((this.tempTableRatingCode == null)?"<null>":this.tempTableRatingCode));
        sb.append(',');
        sb.append("lastRatingDate");
        sb.append('=');
        sb.append(((this.lastRatingDate == null)?"<null>":this.lastRatingDate));
        sb.append(',');
        sb.append("tempRatingType");
        sb.append('=');
        sb.append(((this.tempRatingType == null)?"<null>":this.tempRatingType));
        sb.append(',');
        sb.append("permRatingType");
        sb.append('=');
        sb.append(((this.permRatingType == null)?"<null>":this.permRatingType));
        sb.append(',');
        sb.append("tempFlatStartDate");
        sb.append('=');
        sb.append(((this.tempFlatStartDate == null)?"<null>":this.tempFlatStartDate));
        sb.append(',');
        sb.append("occupation");
        sb.append('=');
        sb.append(((this.occupation == null)?"<null>":this.occupation));
        sb.append(',');
        sb.append("occupRating");
        sb.append('=');
        sb.append(((this.occupRating == null)?"<null>":this.occupRating));
        sb.append(',');
        sb.append("ratingOverriddenInd");
        sb.append('=');
        sb.append(((this.ratingOverriddenInd == null)?"<null>":this.ratingOverriddenInd));
        sb.append(',');
        sb.append("permRatingAmtPerThou");
        sb.append('=');
        sb.append(((this.permRatingAmtPerThou == null)?"<null>":this.permRatingAmtPerThou));
        sb.append(',');
        sb.append("tempRatingAmtPerThou");
        sb.append('=');
        sb.append(((this.tempRatingAmtPerThou == null)?"<null>":this.tempRatingAmtPerThou));
        sb.append(',');
        sb.append("modalPermRatingAmt");
        sb.append('=');
        sb.append(((this.modalPermRatingAmt == null)?"<null>":this.modalPermRatingAmt));
        sb.append(',');
        sb.append("modalTempRatingAmt");
        sb.append('=');
        sb.append(((this.modalTempRatingAmt == null)?"<null>":this.modalTempRatingAmt));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.occupRating == null)? 0 :this.occupRating.hashCode()));
        result = ((result* 31)+((this.occupation == null)? 0 :this.occupation.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.substandardRatingKey == null)? 0 :this.substandardRatingKey.hashCode()));
        result = ((result* 31)+((this.ratingCommissionRule == null)? 0 :this.ratingCommissionRule.hashCode()));
        result = ((result* 31)+((this.tempFlatExtraDuration == null)? 0 :this.tempFlatExtraDuration.hashCode()));
        result = ((result* 31)+((this.tempPercentageLoading == null)? 0 :this.tempPercentageLoading.hashCode()));
        result = ((result* 31)+((this.tempTableRatingCode == null)? 0 :this.tempTableRatingCode.hashCode()));
        result = ((result* 31)+((this.modalTempRatingAmt == null)? 0 :this.modalTempRatingAmt.hashCode()));
        result = ((result* 31)+((this.ratingOverriddenInd == null)? 0 :this.ratingOverriddenInd.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.modalGrossPermFlatExtraAllowanceAmt == null)? 0 :this.modalGrossPermFlatExtraAllowanceAmt.hashCode()));
        result = ((result* 31)+((this.effDate == null)? 0 :this.effDate.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.amtPerThou == null)? 0 :this.amtPerThou.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.substandardRatingSysKey == null)? 0 :this.substandardRatingSysKey.hashCode()));
        result = ((result* 31)+((this.permFlatExtraAmt == null)? 0 :this.permFlatExtraAmt.hashCode()));
        result = ((result* 31)+((this.tempTableRating == null)? 0 :this.tempTableRating.hashCode()));
        result = ((result* 31)+((this.tempRatingAmtPerThou == null)? 0 :this.tempRatingAmtPerThou.hashCode()));
        result = ((result* 31)+((this.permFlatExtraEndDate == null)? 0 :this.permFlatExtraEndDate.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.permTableRating == null)? 0 :this.permTableRating.hashCode()));
        result = ((result* 31)+((this.tempTableRatingStartDate == null)? 0 :this.tempTableRatingStartDate.hashCode()));
        result = ((result* 31)+((this.permTableRatingEndDate == null)? 0 :this.permTableRatingEndDate.hashCode()));
        result = ((result* 31)+((this.tempTableRatingEndDate == null)? 0 :this.tempTableRatingEndDate.hashCode()));
        result = ((result* 31)+((this.ratingReason == null)? 0 :this.ratingReason.hashCode()));
        result = ((result* 31)+((this.tempFlatStartDate == null)? 0 :this.tempFlatStartDate.hashCode()));
        result = ((result* 31)+((this.permRatingType == null)? 0 :this.permRatingType.hashCode()));
        result = ((result* 31)+((this.permPercentageLoading == null)? 0 :this.permPercentageLoading.hashCode()));
        result = ((result* 31)+((this.lastRatingDate == null)? 0 :this.lastRatingDate.hashCode()));
        result = ((result* 31)+((this.tempFlatEndDate == null)? 0 :this.tempFlatEndDate.hashCode()));
        result = ((result* 31)+((this.permRatingAmtPerThou == null)? 0 :this.permRatingAmtPerThou.hashCode()));
        result = ((result* 31)+((this.tempFlatExtraAmt == null)? 0 :this.tempFlatExtraAmt.hashCode()));
        result = ((result* 31)+((this.modalGrossTempFlatExtraAllowanceAmt == null)? 0 :this.modalGrossTempFlatExtraAllowanceAmt.hashCode()));
        result = ((result* 31)+((this.flatExtraPremBasis == null)? 0 :this.flatExtraPremBasis.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.permTableRatingAlphaCode == null)? 0 :this.permTableRatingAlphaCode.hashCode()));
        result = ((result* 31)+((this.tempRatingType == null)? 0 :this.tempRatingType.hashCode()));
        result = ((result* 31)+((this.modalPermRatingAmt == null)? 0 :this.modalPermRatingAmt.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SubstandardRating) == false) {
            return false;
        }
        SubstandardRating rhs = ((SubstandardRating) other);
        return (((((((((((((((((((((((((((((((((((((((((this.occupRating == rhs.occupRating)||((this.occupRating!= null)&&this.occupRating.equals(rhs.occupRating)))&&((this.occupation == rhs.occupation)||((this.occupation!= null)&&this.occupation.equals(rhs.occupation))))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.substandardRatingKey == rhs.substandardRatingKey)||((this.substandardRatingKey!= null)&&this.substandardRatingKey.equals(rhs.substandardRatingKey))))&&((this.ratingCommissionRule == rhs.ratingCommissionRule)||((this.ratingCommissionRule!= null)&&this.ratingCommissionRule.equals(rhs.ratingCommissionRule))))&&((this.tempFlatExtraDuration == rhs.tempFlatExtraDuration)||((this.tempFlatExtraDuration!= null)&&this.tempFlatExtraDuration.equals(rhs.tempFlatExtraDuration))))&&((this.tempPercentageLoading == rhs.tempPercentageLoading)||((this.tempPercentageLoading!= null)&&this.tempPercentageLoading.equals(rhs.tempPercentageLoading))))&&((this.tempTableRatingCode == rhs.tempTableRatingCode)||((this.tempTableRatingCode!= null)&&this.tempTableRatingCode.equals(rhs.tempTableRatingCode))))&&((this.modalTempRatingAmt == rhs.modalTempRatingAmt)||((this.modalTempRatingAmt!= null)&&this.modalTempRatingAmt.equals(rhs.modalTempRatingAmt))))&&((this.ratingOverriddenInd == rhs.ratingOverriddenInd)||((this.ratingOverriddenInd!= null)&&this.ratingOverriddenInd.equals(rhs.ratingOverriddenInd))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.modalGrossPermFlatExtraAllowanceAmt == rhs.modalGrossPermFlatExtraAllowanceAmt)||((this.modalGrossPermFlatExtraAllowanceAmt!= null)&&this.modalGrossPermFlatExtraAllowanceAmt.equals(rhs.modalGrossPermFlatExtraAllowanceAmt))))&&((this.effDate == rhs.effDate)||((this.effDate!= null)&&this.effDate.equals(rhs.effDate))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.amtPerThou == rhs.amtPerThou)||((this.amtPerThou!= null)&&this.amtPerThou.equals(rhs.amtPerThou))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.substandardRatingSysKey == rhs.substandardRatingSysKey)||((this.substandardRatingSysKey!= null)&&this.substandardRatingSysKey.equals(rhs.substandardRatingSysKey))))&&((this.permFlatExtraAmt == rhs.permFlatExtraAmt)||((this.permFlatExtraAmt!= null)&&this.permFlatExtraAmt.equals(rhs.permFlatExtraAmt))))&&((this.tempTableRating == rhs.tempTableRating)||((this.tempTableRating!= null)&&this.tempTableRating.equals(rhs.tempTableRating))))&&((this.tempRatingAmtPerThou == rhs.tempRatingAmtPerThou)||((this.tempRatingAmtPerThou!= null)&&this.tempRatingAmtPerThou.equals(rhs.tempRatingAmtPerThou))))&&((this.permFlatExtraEndDate == rhs.permFlatExtraEndDate)||((this.permFlatExtraEndDate!= null)&&this.permFlatExtraEndDate.equals(rhs.permFlatExtraEndDate))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.permTableRating == rhs.permTableRating)||((this.permTableRating!= null)&&this.permTableRating.equals(rhs.permTableRating))))&&((this.tempTableRatingStartDate == rhs.tempTableRatingStartDate)||((this.tempTableRatingStartDate!= null)&&this.tempTableRatingStartDate.equals(rhs.tempTableRatingStartDate))))&&((this.permTableRatingEndDate == rhs.permTableRatingEndDate)||((this.permTableRatingEndDate!= null)&&this.permTableRatingEndDate.equals(rhs.permTableRatingEndDate))))&&((this.tempTableRatingEndDate == rhs.tempTableRatingEndDate)||((this.tempTableRatingEndDate!= null)&&this.tempTableRatingEndDate.equals(rhs.tempTableRatingEndDate))))&&((this.ratingReason == rhs.ratingReason)||((this.ratingReason!= null)&&this.ratingReason.equals(rhs.ratingReason))))&&((this.tempFlatStartDate == rhs.tempFlatStartDate)||((this.tempFlatStartDate!= null)&&this.tempFlatStartDate.equals(rhs.tempFlatStartDate))))&&((this.permRatingType == rhs.permRatingType)||((this.permRatingType!= null)&&this.permRatingType.equals(rhs.permRatingType))))&&((this.permPercentageLoading == rhs.permPercentageLoading)||((this.permPercentageLoading!= null)&&this.permPercentageLoading.equals(rhs.permPercentageLoading))))&&((this.lastRatingDate == rhs.lastRatingDate)||((this.lastRatingDate!= null)&&this.lastRatingDate.equals(rhs.lastRatingDate))))&&((this.tempFlatEndDate == rhs.tempFlatEndDate)||((this.tempFlatEndDate!= null)&&this.tempFlatEndDate.equals(rhs.tempFlatEndDate))))&&((this.permRatingAmtPerThou == rhs.permRatingAmtPerThou)||((this.permRatingAmtPerThou!= null)&&this.permRatingAmtPerThou.equals(rhs.permRatingAmtPerThou))))&&((this.tempFlatExtraAmt == rhs.tempFlatExtraAmt)||((this.tempFlatExtraAmt!= null)&&this.tempFlatExtraAmt.equals(rhs.tempFlatExtraAmt))))&&((this.modalGrossTempFlatExtraAllowanceAmt == rhs.modalGrossTempFlatExtraAllowanceAmt)||((this.modalGrossTempFlatExtraAllowanceAmt!= null)&&this.modalGrossTempFlatExtraAllowanceAmt.equals(rhs.modalGrossTempFlatExtraAllowanceAmt))))&&((this.flatExtraPremBasis == rhs.flatExtraPremBasis)||((this.flatExtraPremBasis!= null)&&this.flatExtraPremBasis.equals(rhs.flatExtraPremBasis))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.permTableRatingAlphaCode == rhs.permTableRatingAlphaCode)||((this.permTableRatingAlphaCode!= null)&&this.permTableRatingAlphaCode.equals(rhs.permTableRatingAlphaCode))))&&((this.tempRatingType == rhs.tempRatingType)||((this.tempRatingType!= null)&&this.tempRatingType.equals(rhs.tempRatingType))))&&((this.modalPermRatingAmt == rhs.modalPermRatingAmt)||((this.modalPermRatingAmt!= null)&&this.modalPermRatingAmt.equals(rhs.modalPermRatingAmt))));
    }

}
