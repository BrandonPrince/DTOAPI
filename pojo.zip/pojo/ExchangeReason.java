
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ExchangeReasonKey",
    "ExchangeReasonSysKey",
    "ExchangeReasonCode",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class ExchangeReason {

    @JsonProperty("ExchangeReasonKey")
    private ExchangeReasonKey exchangeReasonKey;
    @JsonProperty("ExchangeReasonSysKey")
    private List<Object> exchangeReasonSysKey = new ArrayList<>();
    @JsonProperty("ExchangeReasonCode")
    private ExchangeReasonCode exchangeReasonCode;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ExchangeReasonKey")
    public ExchangeReasonKey getExchangeReasonKey() {
        return exchangeReasonKey;
    }

    @JsonProperty("ExchangeReasonKey")
    public void setExchangeReasonKey(ExchangeReasonKey exchangeReasonKey) {
        this.exchangeReasonKey = exchangeReasonKey;
    }

    public ExchangeReason withExchangeReasonKey(ExchangeReasonKey exchangeReasonKey) {
        this.exchangeReasonKey = exchangeReasonKey;
        return this;
    }

    @JsonProperty("ExchangeReasonSysKey")
    public List<Object> getExchangeReasonSysKey() {
        return exchangeReasonSysKey;
    }

    @JsonProperty("ExchangeReasonSysKey")
    public void setExchangeReasonSysKey(List<Object> exchangeReasonSysKey) {
        this.exchangeReasonSysKey = exchangeReasonSysKey;
    }

    public ExchangeReason withExchangeReasonSysKey(List<Object> exchangeReasonSysKey) {
        this.exchangeReasonSysKey = exchangeReasonSysKey;
        return this;
    }

    @JsonProperty("ExchangeReasonCode")
    public ExchangeReasonCode getExchangeReasonCode() {
        return exchangeReasonCode;
    }

    @JsonProperty("ExchangeReasonCode")
    public void setExchangeReasonCode(ExchangeReasonCode exchangeReasonCode) {
        this.exchangeReasonCode = exchangeReasonCode;
    }

    public ExchangeReason withExchangeReasonCode(ExchangeReasonCode exchangeReasonCode) {
        this.exchangeReasonCode = exchangeReasonCode;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public ExchangeReason withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public ExchangeReason withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public ExchangeReason withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ExchangeReason withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ExchangeReason.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("exchangeReasonKey");
        sb.append('=');
        sb.append(((this.exchangeReasonKey == null)?"<null>":this.exchangeReasonKey));
        sb.append(',');
        sb.append("exchangeReasonSysKey");
        sb.append('=');
        sb.append(((this.exchangeReasonSysKey == null)?"<null>":this.exchangeReasonSysKey));
        sb.append(',');
        sb.append("exchangeReasonCode");
        sb.append('=');
        sb.append(((this.exchangeReasonCode == null)?"<null>":this.exchangeReasonCode));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.exchangeReasonKey == null)? 0 :this.exchangeReasonKey.hashCode()));
        result = ((result* 31)+((this.exchangeReasonCode == null)? 0 :this.exchangeReasonCode.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.exchangeReasonSysKey == null)? 0 :this.exchangeReasonSysKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ExchangeReason) == false) {
            return false;
        }
        ExchangeReason rhs = ((ExchangeReason) other);
        return ((((((((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension)))&&((this.exchangeReasonKey == rhs.exchangeReasonKey)||((this.exchangeReasonKey!= null)&&this.exchangeReasonKey.equals(rhs.exchangeReasonKey))))&&((this.exchangeReasonCode == rhs.exchangeReasonCode)||((this.exchangeReasonCode!= null)&&this.exchangeReasonCode.equals(rhs.exchangeReasonCode))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.exchangeReasonSysKey == rhs.exchangeReasonSysKey)||((this.exchangeReasonSysKey!= null)&&this.exchangeReasonSysKey.equals(rhs.exchangeReasonSysKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
