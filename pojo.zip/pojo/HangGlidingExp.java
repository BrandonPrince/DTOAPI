
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "HangGlidingExpKey",
    "HangGlidingExpSysKey",
    "CertifiedCraftInd",
    "ExperimentalEquipmentInd",
    "GliderAssembly",
    "JumpLocationType",
    "CraftAssembly",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class HangGlidingExp {

    @JsonProperty("HangGlidingExpKey")
    private HangGlidingExpKey hangGlidingExpKey;
    @JsonProperty("HangGlidingExpSysKey")
    private List<Object> hangGlidingExpSysKey = new ArrayList<>();
    @JsonProperty("CertifiedCraftInd")
    private CertifiedCraftInd certifiedCraftInd;
    @JsonProperty("ExperimentalEquipmentInd")
    private ExperimentalEquipmentInd experimentalEquipmentInd;
    @JsonProperty("GliderAssembly")
    private GliderAssembly gliderAssembly;
    @JsonProperty("JumpLocationType")
    private String jumpLocationType;
    @JsonProperty("CraftAssembly")
    private CraftAssembly craftAssembly;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("HangGlidingExpKey")
    public HangGlidingExpKey getHangGlidingExpKey() {
        return hangGlidingExpKey;
    }

    @JsonProperty("HangGlidingExpKey")
    public void setHangGlidingExpKey(HangGlidingExpKey hangGlidingExpKey) {
        this.hangGlidingExpKey = hangGlidingExpKey;
    }

    public HangGlidingExp withHangGlidingExpKey(HangGlidingExpKey hangGlidingExpKey) {
        this.hangGlidingExpKey = hangGlidingExpKey;
        return this;
    }

    @JsonProperty("HangGlidingExpSysKey")
    public List<Object> getHangGlidingExpSysKey() {
        return hangGlidingExpSysKey;
    }

    @JsonProperty("HangGlidingExpSysKey")
    public void setHangGlidingExpSysKey(List<Object> hangGlidingExpSysKey) {
        this.hangGlidingExpSysKey = hangGlidingExpSysKey;
    }

    public HangGlidingExp withHangGlidingExpSysKey(List<Object> hangGlidingExpSysKey) {
        this.hangGlidingExpSysKey = hangGlidingExpSysKey;
        return this;
    }

    @JsonProperty("CertifiedCraftInd")
    public CertifiedCraftInd getCertifiedCraftInd() {
        return certifiedCraftInd;
    }

    @JsonProperty("CertifiedCraftInd")
    public void setCertifiedCraftInd(CertifiedCraftInd certifiedCraftInd) {
        this.certifiedCraftInd = certifiedCraftInd;
    }

    public HangGlidingExp withCertifiedCraftInd(CertifiedCraftInd certifiedCraftInd) {
        this.certifiedCraftInd = certifiedCraftInd;
        return this;
    }

    @JsonProperty("ExperimentalEquipmentInd")
    public ExperimentalEquipmentInd getExperimentalEquipmentInd() {
        return experimentalEquipmentInd;
    }

    @JsonProperty("ExperimentalEquipmentInd")
    public void setExperimentalEquipmentInd(ExperimentalEquipmentInd experimentalEquipmentInd) {
        this.experimentalEquipmentInd = experimentalEquipmentInd;
    }

    public HangGlidingExp withExperimentalEquipmentInd(ExperimentalEquipmentInd experimentalEquipmentInd) {
        this.experimentalEquipmentInd = experimentalEquipmentInd;
        return this;
    }

    @JsonProperty("GliderAssembly")
    public GliderAssembly getGliderAssembly() {
        return gliderAssembly;
    }

    @JsonProperty("GliderAssembly")
    public void setGliderAssembly(GliderAssembly gliderAssembly) {
        this.gliderAssembly = gliderAssembly;
    }

    public HangGlidingExp withGliderAssembly(GliderAssembly gliderAssembly) {
        this.gliderAssembly = gliderAssembly;
        return this;
    }

    @JsonProperty("JumpLocationType")
    public String getJumpLocationType() {
        return jumpLocationType;
    }

    @JsonProperty("JumpLocationType")
    public void setJumpLocationType(String jumpLocationType) {
        this.jumpLocationType = jumpLocationType;
    }

    public HangGlidingExp withJumpLocationType(String jumpLocationType) {
        this.jumpLocationType = jumpLocationType;
        return this;
    }

    @JsonProperty("CraftAssembly")
    public CraftAssembly getCraftAssembly() {
        return craftAssembly;
    }

    @JsonProperty("CraftAssembly")
    public void setCraftAssembly(CraftAssembly craftAssembly) {
        this.craftAssembly = craftAssembly;
    }

    public HangGlidingExp withCraftAssembly(CraftAssembly craftAssembly) {
        this.craftAssembly = craftAssembly;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public HangGlidingExp withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public HangGlidingExp withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public HangGlidingExp withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public HangGlidingExp withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(HangGlidingExp.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("hangGlidingExpKey");
        sb.append('=');
        sb.append(((this.hangGlidingExpKey == null)?"<null>":this.hangGlidingExpKey));
        sb.append(',');
        sb.append("hangGlidingExpSysKey");
        sb.append('=');
        sb.append(((this.hangGlidingExpSysKey == null)?"<null>":this.hangGlidingExpSysKey));
        sb.append(',');
        sb.append("certifiedCraftInd");
        sb.append('=');
        sb.append(((this.certifiedCraftInd == null)?"<null>":this.certifiedCraftInd));
        sb.append(',');
        sb.append("experimentalEquipmentInd");
        sb.append('=');
        sb.append(((this.experimentalEquipmentInd == null)?"<null>":this.experimentalEquipmentInd));
        sb.append(',');
        sb.append("gliderAssembly");
        sb.append('=');
        sb.append(((this.gliderAssembly == null)?"<null>":this.gliderAssembly));
        sb.append(',');
        sb.append("jumpLocationType");
        sb.append('=');
        sb.append(((this.jumpLocationType == null)?"<null>":this.jumpLocationType));
        sb.append(',');
        sb.append("craftAssembly");
        sb.append('=');
        sb.append(((this.craftAssembly == null)?"<null>":this.craftAssembly));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.hangGlidingExpKey == null)? 0 :this.hangGlidingExpKey.hashCode()));
        result = ((result* 31)+((this.gliderAssembly == null)? 0 :this.gliderAssembly.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.hangGlidingExpSysKey == null)? 0 :this.hangGlidingExpSysKey.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.craftAssembly == null)? 0 :this.craftAssembly.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.experimentalEquipmentInd == null)? 0 :this.experimentalEquipmentInd.hashCode()));
        result = ((result* 31)+((this.jumpLocationType == null)? 0 :this.jumpLocationType.hashCode()));
        result = ((result* 31)+((this.certifiedCraftInd == null)? 0 :this.certifiedCraftInd.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof HangGlidingExp) == false) {
            return false;
        }
        HangGlidingExp rhs = ((HangGlidingExp) other);
        return ((((((((((((this.hangGlidingExpKey == rhs.hangGlidingExpKey)||((this.hangGlidingExpKey!= null)&&this.hangGlidingExpKey.equals(rhs.hangGlidingExpKey)))&&((this.gliderAssembly == rhs.gliderAssembly)||((this.gliderAssembly!= null)&&this.gliderAssembly.equals(rhs.gliderAssembly))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.hangGlidingExpSysKey == rhs.hangGlidingExpSysKey)||((this.hangGlidingExpSysKey!= null)&&this.hangGlidingExpSysKey.equals(rhs.hangGlidingExpSysKey))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.craftAssembly == rhs.craftAssembly)||((this.craftAssembly!= null)&&this.craftAssembly.equals(rhs.craftAssembly))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.experimentalEquipmentInd == rhs.experimentalEquipmentInd)||((this.experimentalEquipmentInd!= null)&&this.experimentalEquipmentInd.equals(rhs.experimentalEquipmentInd))))&&((this.jumpLocationType == rhs.jumpLocationType)||((this.jumpLocationType!= null)&&this.jumpLocationType.equals(rhs.jumpLocationType))))&&((this.certifiedCraftInd == rhs.certifiedCraftInd)||((this.certifiedCraftInd!= null)&&this.certifiedCraftInd.equals(rhs.certifiedCraftInd))));
    }

}
