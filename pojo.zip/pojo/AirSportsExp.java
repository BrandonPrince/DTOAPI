
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AirsportsExpKey",
    "AirsportsExpSysKey",
    "ProfessionalInd",
    "CompeteInd",
    "CompetitionDetail",
    "SafetyStandardsInd",
    "AvgAerialHeight",
    "MaxAerialHeight",
    "AerialHeightUnitMeasure",
    "AvgAerialDuration",
    "MaxAerialDuration",
    "AerialDurationUnitMeasure",
    "BallooningExp",
    "HangGlidingExp",
    "ParachutingExp",
    "UltraliteExp",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AirSportsExp {

    @JsonProperty("AirsportsExpKey")
    private AirsportsExpKey airsportsExpKey;
    @JsonProperty("AirsportsExpSysKey")
    private List<Object> airsportsExpSysKey = new ArrayList<>();
    @JsonProperty("ProfessionalInd")
    private ProfessionalInd professionalInd;
    @JsonProperty("CompeteInd")
    private CompeteInd competeInd;
    @JsonProperty("CompetitionDetail")
    private List<Object> competitionDetail = new ArrayList<>();
    @JsonProperty("SafetyStandardsInd")
    private SafetyStandardsInd safetyStandardsInd;
    @JsonProperty("AvgAerialHeight")
    private Integer avgAerialHeight;
    @JsonProperty("MaxAerialHeight")
    private Integer maxAerialHeight;
    @JsonProperty("AerialHeightUnitMeasure")
    private AerialHeightUnitMeasure aerialHeightUnitMeasure;
    @JsonProperty("AvgAerialDuration")
    private Integer avgAerialDuration;
    @JsonProperty("MaxAerialDuration")
    private Integer maxAerialDuration;
    @JsonProperty("AerialDurationUnitMeasure")
    private AerialDurationUnitMeasure aerialDurationUnitMeasure;
    @JsonProperty("BallooningExp")
    private BallooningExp ballooningExp;
    @JsonProperty("HangGlidingExp")
    private HangGlidingExp hangGlidingExp;
    @JsonProperty("ParachutingExp")
    private ParachutingExp parachutingExp;
    @JsonProperty("UltraliteExp")
    private UltraliteExp ultraliteExp;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AirsportsExpKey")
    public AirsportsExpKey getAirsportsExpKey() {
        return airsportsExpKey;
    }

    @JsonProperty("AirsportsExpKey")
    public void setAirsportsExpKey(AirsportsExpKey airsportsExpKey) {
        this.airsportsExpKey = airsportsExpKey;
    }

    public AirSportsExp withAirsportsExpKey(AirsportsExpKey airsportsExpKey) {
        this.airsportsExpKey = airsportsExpKey;
        return this;
    }

    @JsonProperty("AirsportsExpSysKey")
    public List<Object> getAirsportsExpSysKey() {
        return airsportsExpSysKey;
    }

    @JsonProperty("AirsportsExpSysKey")
    public void setAirsportsExpSysKey(List<Object> airsportsExpSysKey) {
        this.airsportsExpSysKey = airsportsExpSysKey;
    }

    public AirSportsExp withAirsportsExpSysKey(List<Object> airsportsExpSysKey) {
        this.airsportsExpSysKey = airsportsExpSysKey;
        return this;
    }

    @JsonProperty("ProfessionalInd")
    public ProfessionalInd getProfessionalInd() {
        return professionalInd;
    }

    @JsonProperty("ProfessionalInd")
    public void setProfessionalInd(ProfessionalInd professionalInd) {
        this.professionalInd = professionalInd;
    }

    public AirSportsExp withProfessionalInd(ProfessionalInd professionalInd) {
        this.professionalInd = professionalInd;
        return this;
    }

    @JsonProperty("CompeteInd")
    public CompeteInd getCompeteInd() {
        return competeInd;
    }

    @JsonProperty("CompeteInd")
    public void setCompeteInd(CompeteInd competeInd) {
        this.competeInd = competeInd;
    }

    public AirSportsExp withCompeteInd(CompeteInd competeInd) {
        this.competeInd = competeInd;
        return this;
    }

    @JsonProperty("CompetitionDetail")
    public List<Object> getCompetitionDetail() {
        return competitionDetail;
    }

    @JsonProperty("CompetitionDetail")
    public void setCompetitionDetail(List<Object> competitionDetail) {
        this.competitionDetail = competitionDetail;
    }

    public AirSportsExp withCompetitionDetail(List<Object> competitionDetail) {
        this.competitionDetail = competitionDetail;
        return this;
    }

    @JsonProperty("SafetyStandardsInd")
    public SafetyStandardsInd getSafetyStandardsInd() {
        return safetyStandardsInd;
    }

    @JsonProperty("SafetyStandardsInd")
    public void setSafetyStandardsInd(SafetyStandardsInd safetyStandardsInd) {
        this.safetyStandardsInd = safetyStandardsInd;
    }

    public AirSportsExp withSafetyStandardsInd(SafetyStandardsInd safetyStandardsInd) {
        this.safetyStandardsInd = safetyStandardsInd;
        return this;
    }

    @JsonProperty("AvgAerialHeight")
    public Integer getAvgAerialHeight() {
        return avgAerialHeight;
    }

    @JsonProperty("AvgAerialHeight")
    public void setAvgAerialHeight(Integer avgAerialHeight) {
        this.avgAerialHeight = avgAerialHeight;
    }

    public AirSportsExp withAvgAerialHeight(Integer avgAerialHeight) {
        this.avgAerialHeight = avgAerialHeight;
        return this;
    }

    @JsonProperty("MaxAerialHeight")
    public Integer getMaxAerialHeight() {
        return maxAerialHeight;
    }

    @JsonProperty("MaxAerialHeight")
    public void setMaxAerialHeight(Integer maxAerialHeight) {
        this.maxAerialHeight = maxAerialHeight;
    }

    public AirSportsExp withMaxAerialHeight(Integer maxAerialHeight) {
        this.maxAerialHeight = maxAerialHeight;
        return this;
    }

    @JsonProperty("AerialHeightUnitMeasure")
    public AerialHeightUnitMeasure getAerialHeightUnitMeasure() {
        return aerialHeightUnitMeasure;
    }

    @JsonProperty("AerialHeightUnitMeasure")
    public void setAerialHeightUnitMeasure(AerialHeightUnitMeasure aerialHeightUnitMeasure) {
        this.aerialHeightUnitMeasure = aerialHeightUnitMeasure;
    }

    public AirSportsExp withAerialHeightUnitMeasure(AerialHeightUnitMeasure aerialHeightUnitMeasure) {
        this.aerialHeightUnitMeasure = aerialHeightUnitMeasure;
        return this;
    }

    @JsonProperty("AvgAerialDuration")
    public Integer getAvgAerialDuration() {
        return avgAerialDuration;
    }

    @JsonProperty("AvgAerialDuration")
    public void setAvgAerialDuration(Integer avgAerialDuration) {
        this.avgAerialDuration = avgAerialDuration;
    }

    public AirSportsExp withAvgAerialDuration(Integer avgAerialDuration) {
        this.avgAerialDuration = avgAerialDuration;
        return this;
    }

    @JsonProperty("MaxAerialDuration")
    public Integer getMaxAerialDuration() {
        return maxAerialDuration;
    }

    @JsonProperty("MaxAerialDuration")
    public void setMaxAerialDuration(Integer maxAerialDuration) {
        this.maxAerialDuration = maxAerialDuration;
    }

    public AirSportsExp withMaxAerialDuration(Integer maxAerialDuration) {
        this.maxAerialDuration = maxAerialDuration;
        return this;
    }

    @JsonProperty("AerialDurationUnitMeasure")
    public AerialDurationUnitMeasure getAerialDurationUnitMeasure() {
        return aerialDurationUnitMeasure;
    }

    @JsonProperty("AerialDurationUnitMeasure")
    public void setAerialDurationUnitMeasure(AerialDurationUnitMeasure aerialDurationUnitMeasure) {
        this.aerialDurationUnitMeasure = aerialDurationUnitMeasure;
    }

    public AirSportsExp withAerialDurationUnitMeasure(AerialDurationUnitMeasure aerialDurationUnitMeasure) {
        this.aerialDurationUnitMeasure = aerialDurationUnitMeasure;
        return this;
    }

    @JsonProperty("BallooningExp")
    public BallooningExp getBallooningExp() {
        return ballooningExp;
    }

    @JsonProperty("BallooningExp")
    public void setBallooningExp(BallooningExp ballooningExp) {
        this.ballooningExp = ballooningExp;
    }

    public AirSportsExp withBallooningExp(BallooningExp ballooningExp) {
        this.ballooningExp = ballooningExp;
        return this;
    }

    @JsonProperty("HangGlidingExp")
    public HangGlidingExp getHangGlidingExp() {
        return hangGlidingExp;
    }

    @JsonProperty("HangGlidingExp")
    public void setHangGlidingExp(HangGlidingExp hangGlidingExp) {
        this.hangGlidingExp = hangGlidingExp;
    }

    public AirSportsExp withHangGlidingExp(HangGlidingExp hangGlidingExp) {
        this.hangGlidingExp = hangGlidingExp;
        return this;
    }

    @JsonProperty("ParachutingExp")
    public ParachutingExp getParachutingExp() {
        return parachutingExp;
    }

    @JsonProperty("ParachutingExp")
    public void setParachutingExp(ParachutingExp parachutingExp) {
        this.parachutingExp = parachutingExp;
    }

    public AirSportsExp withParachutingExp(ParachutingExp parachutingExp) {
        this.parachutingExp = parachutingExp;
        return this;
    }

    @JsonProperty("UltraliteExp")
    public UltraliteExp getUltraliteExp() {
        return ultraliteExp;
    }

    @JsonProperty("UltraliteExp")
    public void setUltraliteExp(UltraliteExp ultraliteExp) {
        this.ultraliteExp = ultraliteExp;
    }

    public AirSportsExp withUltraliteExp(UltraliteExp ultraliteExp) {
        this.ultraliteExp = ultraliteExp;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AirSportsExp withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AirSportsExp withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AirSportsExp withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AirSportsExp withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AirSportsExp.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("airsportsExpKey");
        sb.append('=');
        sb.append(((this.airsportsExpKey == null)?"<null>":this.airsportsExpKey));
        sb.append(',');
        sb.append("airsportsExpSysKey");
        sb.append('=');
        sb.append(((this.airsportsExpSysKey == null)?"<null>":this.airsportsExpSysKey));
        sb.append(',');
        sb.append("professionalInd");
        sb.append('=');
        sb.append(((this.professionalInd == null)?"<null>":this.professionalInd));
        sb.append(',');
        sb.append("competeInd");
        sb.append('=');
        sb.append(((this.competeInd == null)?"<null>":this.competeInd));
        sb.append(',');
        sb.append("competitionDetail");
        sb.append('=');
        sb.append(((this.competitionDetail == null)?"<null>":this.competitionDetail));
        sb.append(',');
        sb.append("safetyStandardsInd");
        sb.append('=');
        sb.append(((this.safetyStandardsInd == null)?"<null>":this.safetyStandardsInd));
        sb.append(',');
        sb.append("avgAerialHeight");
        sb.append('=');
        sb.append(((this.avgAerialHeight == null)?"<null>":this.avgAerialHeight));
        sb.append(',');
        sb.append("maxAerialHeight");
        sb.append('=');
        sb.append(((this.maxAerialHeight == null)?"<null>":this.maxAerialHeight));
        sb.append(',');
        sb.append("aerialHeightUnitMeasure");
        sb.append('=');
        sb.append(((this.aerialHeightUnitMeasure == null)?"<null>":this.aerialHeightUnitMeasure));
        sb.append(',');
        sb.append("avgAerialDuration");
        sb.append('=');
        sb.append(((this.avgAerialDuration == null)?"<null>":this.avgAerialDuration));
        sb.append(',');
        sb.append("maxAerialDuration");
        sb.append('=');
        sb.append(((this.maxAerialDuration == null)?"<null>":this.maxAerialDuration));
        sb.append(',');
        sb.append("aerialDurationUnitMeasure");
        sb.append('=');
        sb.append(((this.aerialDurationUnitMeasure == null)?"<null>":this.aerialDurationUnitMeasure));
        sb.append(',');
        sb.append("ballooningExp");
        sb.append('=');
        sb.append(((this.ballooningExp == null)?"<null>":this.ballooningExp));
        sb.append(',');
        sb.append("hangGlidingExp");
        sb.append('=');
        sb.append(((this.hangGlidingExp == null)?"<null>":this.hangGlidingExp));
        sb.append(',');
        sb.append("parachutingExp");
        sb.append('=');
        sb.append(((this.parachutingExp == null)?"<null>":this.parachutingExp));
        sb.append(',');
        sb.append("ultraliteExp");
        sb.append('=');
        sb.append(((this.ultraliteExp == null)?"<null>":this.ultraliteExp));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.competeInd == null)? 0 :this.competeInd.hashCode()));
        result = ((result* 31)+((this.airsportsExpSysKey == null)? 0 :this.airsportsExpSysKey.hashCode()));
        result = ((result* 31)+((this.professionalInd == null)? 0 :this.professionalInd.hashCode()));
        result = ((result* 31)+((this.aerialHeightUnitMeasure == null)? 0 :this.aerialHeightUnitMeasure.hashCode()));
        result = ((result* 31)+((this.hangGlidingExp == null)? 0 :this.hangGlidingExp.hashCode()));
        result = ((result* 31)+((this.airsportsExpKey == null)? 0 :this.airsportsExpKey.hashCode()));
        result = ((result* 31)+((this.competitionDetail == null)? 0 :this.competitionDetail.hashCode()));
        result = ((result* 31)+((this.maxAerialDuration == null)? 0 :this.maxAerialDuration.hashCode()));
        result = ((result* 31)+((this.avgAerialDuration == null)? 0 :this.avgAerialDuration.hashCode()));
        result = ((result* 31)+((this.safetyStandardsInd == null)? 0 :this.safetyStandardsInd.hashCode()));
        result = ((result* 31)+((this.parachutingExp == null)? 0 :this.parachutingExp.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.aerialDurationUnitMeasure == null)? 0 :this.aerialDurationUnitMeasure.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.ballooningExp == null)? 0 :this.ballooningExp.hashCode()));
        result = ((result* 31)+((this.maxAerialHeight == null)? 0 :this.maxAerialHeight.hashCode()));
        result = ((result* 31)+((this.ultraliteExp == null)? 0 :this.ultraliteExp.hashCode()));
        result = ((result* 31)+((this.avgAerialHeight == null)? 0 :this.avgAerialHeight.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AirSportsExp) == false) {
            return false;
        }
        AirSportsExp rhs = ((AirSportsExp) other);
        return (((((((((((((((((((((this.competeInd == rhs.competeInd)||((this.competeInd!= null)&&this.competeInd.equals(rhs.competeInd)))&&((this.airsportsExpSysKey == rhs.airsportsExpSysKey)||((this.airsportsExpSysKey!= null)&&this.airsportsExpSysKey.equals(rhs.airsportsExpSysKey))))&&((this.professionalInd == rhs.professionalInd)||((this.professionalInd!= null)&&this.professionalInd.equals(rhs.professionalInd))))&&((this.aerialHeightUnitMeasure == rhs.aerialHeightUnitMeasure)||((this.aerialHeightUnitMeasure!= null)&&this.aerialHeightUnitMeasure.equals(rhs.aerialHeightUnitMeasure))))&&((this.hangGlidingExp == rhs.hangGlidingExp)||((this.hangGlidingExp!= null)&&this.hangGlidingExp.equals(rhs.hangGlidingExp))))&&((this.airsportsExpKey == rhs.airsportsExpKey)||((this.airsportsExpKey!= null)&&this.airsportsExpKey.equals(rhs.airsportsExpKey))))&&((this.competitionDetail == rhs.competitionDetail)||((this.competitionDetail!= null)&&this.competitionDetail.equals(rhs.competitionDetail))))&&((this.maxAerialDuration == rhs.maxAerialDuration)||((this.maxAerialDuration!= null)&&this.maxAerialDuration.equals(rhs.maxAerialDuration))))&&((this.avgAerialDuration == rhs.avgAerialDuration)||((this.avgAerialDuration!= null)&&this.avgAerialDuration.equals(rhs.avgAerialDuration))))&&((this.safetyStandardsInd == rhs.safetyStandardsInd)||((this.safetyStandardsInd!= null)&&this.safetyStandardsInd.equals(rhs.safetyStandardsInd))))&&((this.parachutingExp == rhs.parachutingExp)||((this.parachutingExp!= null)&&this.parachutingExp.equals(rhs.parachutingExp))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.aerialDurationUnitMeasure == rhs.aerialDurationUnitMeasure)||((this.aerialDurationUnitMeasure!= null)&&this.aerialDurationUnitMeasure.equals(rhs.aerialDurationUnitMeasure))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.ballooningExp == rhs.ballooningExp)||((this.ballooningExp!= null)&&this.ballooningExp.equals(rhs.ballooningExp))))&&((this.maxAerialHeight == rhs.maxAerialHeight)||((this.maxAerialHeight!= null)&&this.maxAerialHeight.equals(rhs.maxAerialHeight))))&&((this.ultraliteExp == rhs.ultraliteExp)||((this.ultraliteExp!= null)&&this.ultraliteExp.equals(rhs.ultraliteExp))))&&((this.avgAerialHeight == rhs.avgAerialHeight)||((this.avgAerialHeight!= null)&&this.avgAerialHeight.equals(rhs.avgAerialHeight))));
    }

}
