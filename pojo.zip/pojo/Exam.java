
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ExamKey",
    "ExamSysKey",
    "ExamType",
    "StatusDate",
    "ExamName",
    "InstitutionName",
    "ExamDate",
    "CompletedInd",
    "RequiredInd",
    "ExemptionInd",
    "EducationalCreditEquivalent",
    "ProducerExamStatus",
    "ExamNumber",
    "ExamApprovalNumber",
    "ExamWindowStartDate",
    "ExamWindowEndDate",
    "ApprovedHours",
    "OLifEExtension",
    "ExaminingInstitutionID"
})
@Generated("jsonschema2pojo")
public class Exam {

    @JsonProperty("ExamKey")
    private ExamKey examKey;
    @JsonProperty("ExamSysKey")
    private List<Object> examSysKey = new ArrayList<>();
    @JsonProperty("ExamType")
    private ExamType examType;
    @JsonProperty("StatusDate")
    private String statusDate;
    @JsonProperty("ExamName")
    private String examName;
    @JsonProperty("InstitutionName")
    private String institutionName;
    @JsonProperty("ExamDate")
    private String examDate;
    @JsonProperty("CompletedInd")
    private CompletedInd completedInd;
    @JsonProperty("RequiredInd")
    private RequiredInd requiredInd;
    @JsonProperty("ExemptionInd")
    private ExemptionInd exemptionInd;
    @JsonProperty("EducationalCreditEquivalent")
    private String educationalCreditEquivalent;
    @JsonProperty("ProducerExamStatus")
    private ProducerExamStatus producerExamStatus;
    @JsonProperty("ExamNumber")
    private String examNumber;
    @JsonProperty("ExamApprovalNumber")
    private String examApprovalNumber;
    @JsonProperty("ExamWindowStartDate")
    private String examWindowStartDate;
    @JsonProperty("ExamWindowEndDate")
    private String examWindowEndDate;
    @JsonProperty("ApprovedHours")
    private Integer approvedHours;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("ExaminingInstitutionID")
    private String examiningInstitutionID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ExamKey")
    public ExamKey getExamKey() {
        return examKey;
    }

    @JsonProperty("ExamKey")
    public void setExamKey(ExamKey examKey) {
        this.examKey = examKey;
    }

    public Exam withExamKey(ExamKey examKey) {
        this.examKey = examKey;
        return this;
    }

    @JsonProperty("ExamSysKey")
    public List<Object> getExamSysKey() {
        return examSysKey;
    }

    @JsonProperty("ExamSysKey")
    public void setExamSysKey(List<Object> examSysKey) {
        this.examSysKey = examSysKey;
    }

    public Exam withExamSysKey(List<Object> examSysKey) {
        this.examSysKey = examSysKey;
        return this;
    }

    @JsonProperty("ExamType")
    public ExamType getExamType() {
        return examType;
    }

    @JsonProperty("ExamType")
    public void setExamType(ExamType examType) {
        this.examType = examType;
    }

    public Exam withExamType(ExamType examType) {
        this.examType = examType;
        return this;
    }

    @JsonProperty("StatusDate")
    public String getStatusDate() {
        return statusDate;
    }

    @JsonProperty("StatusDate")
    public void setStatusDate(String statusDate) {
        this.statusDate = statusDate;
    }

    public Exam withStatusDate(String statusDate) {
        this.statusDate = statusDate;
        return this;
    }

    @JsonProperty("ExamName")
    public String getExamName() {
        return examName;
    }

    @JsonProperty("ExamName")
    public void setExamName(String examName) {
        this.examName = examName;
    }

    public Exam withExamName(String examName) {
        this.examName = examName;
        return this;
    }

    @JsonProperty("InstitutionName")
    public String getInstitutionName() {
        return institutionName;
    }

    @JsonProperty("InstitutionName")
    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public Exam withInstitutionName(String institutionName) {
        this.institutionName = institutionName;
        return this;
    }

    @JsonProperty("ExamDate")
    public String getExamDate() {
        return examDate;
    }

    @JsonProperty("ExamDate")
    public void setExamDate(String examDate) {
        this.examDate = examDate;
    }

    public Exam withExamDate(String examDate) {
        this.examDate = examDate;
        return this;
    }

    @JsonProperty("CompletedInd")
    public CompletedInd getCompletedInd() {
        return completedInd;
    }

    @JsonProperty("CompletedInd")
    public void setCompletedInd(CompletedInd completedInd) {
        this.completedInd = completedInd;
    }

    public Exam withCompletedInd(CompletedInd completedInd) {
        this.completedInd = completedInd;
        return this;
    }

    @JsonProperty("RequiredInd")
    public RequiredInd getRequiredInd() {
        return requiredInd;
    }

    @JsonProperty("RequiredInd")
    public void setRequiredInd(RequiredInd requiredInd) {
        this.requiredInd = requiredInd;
    }

    public Exam withRequiredInd(RequiredInd requiredInd) {
        this.requiredInd = requiredInd;
        return this;
    }

    @JsonProperty("ExemptionInd")
    public ExemptionInd getExemptionInd() {
        return exemptionInd;
    }

    @JsonProperty("ExemptionInd")
    public void setExemptionInd(ExemptionInd exemptionInd) {
        this.exemptionInd = exemptionInd;
    }

    public Exam withExemptionInd(ExemptionInd exemptionInd) {
        this.exemptionInd = exemptionInd;
        return this;
    }

    @JsonProperty("EducationalCreditEquivalent")
    public String getEducationalCreditEquivalent() {
        return educationalCreditEquivalent;
    }

    @JsonProperty("EducationalCreditEquivalent")
    public void setEducationalCreditEquivalent(String educationalCreditEquivalent) {
        this.educationalCreditEquivalent = educationalCreditEquivalent;
    }

    public Exam withEducationalCreditEquivalent(String educationalCreditEquivalent) {
        this.educationalCreditEquivalent = educationalCreditEquivalent;
        return this;
    }

    @JsonProperty("ProducerExamStatus")
    public ProducerExamStatus getProducerExamStatus() {
        return producerExamStatus;
    }

    @JsonProperty("ProducerExamStatus")
    public void setProducerExamStatus(ProducerExamStatus producerExamStatus) {
        this.producerExamStatus = producerExamStatus;
    }

    public Exam withProducerExamStatus(ProducerExamStatus producerExamStatus) {
        this.producerExamStatus = producerExamStatus;
        return this;
    }

    @JsonProperty("ExamNumber")
    public String getExamNumber() {
        return examNumber;
    }

    @JsonProperty("ExamNumber")
    public void setExamNumber(String examNumber) {
        this.examNumber = examNumber;
    }

    public Exam withExamNumber(String examNumber) {
        this.examNumber = examNumber;
        return this;
    }

    @JsonProperty("ExamApprovalNumber")
    public String getExamApprovalNumber() {
        return examApprovalNumber;
    }

    @JsonProperty("ExamApprovalNumber")
    public void setExamApprovalNumber(String examApprovalNumber) {
        this.examApprovalNumber = examApprovalNumber;
    }

    public Exam withExamApprovalNumber(String examApprovalNumber) {
        this.examApprovalNumber = examApprovalNumber;
        return this;
    }

    @JsonProperty("ExamWindowStartDate")
    public String getExamWindowStartDate() {
        return examWindowStartDate;
    }

    @JsonProperty("ExamWindowStartDate")
    public void setExamWindowStartDate(String examWindowStartDate) {
        this.examWindowStartDate = examWindowStartDate;
    }

    public Exam withExamWindowStartDate(String examWindowStartDate) {
        this.examWindowStartDate = examWindowStartDate;
        return this;
    }

    @JsonProperty("ExamWindowEndDate")
    public String getExamWindowEndDate() {
        return examWindowEndDate;
    }

    @JsonProperty("ExamWindowEndDate")
    public void setExamWindowEndDate(String examWindowEndDate) {
        this.examWindowEndDate = examWindowEndDate;
    }

    public Exam withExamWindowEndDate(String examWindowEndDate) {
        this.examWindowEndDate = examWindowEndDate;
        return this;
    }

    @JsonProperty("ApprovedHours")
    public Integer getApprovedHours() {
        return approvedHours;
    }

    @JsonProperty("ApprovedHours")
    public void setApprovedHours(Integer approvedHours) {
        this.approvedHours = approvedHours;
    }

    public Exam withApprovedHours(Integer approvedHours) {
        this.approvedHours = approvedHours;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Exam withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("ExaminingInstitutionID")
    public String getExaminingInstitutionID() {
        return examiningInstitutionID;
    }

    @JsonProperty("ExaminingInstitutionID")
    public void setExaminingInstitutionID(String examiningInstitutionID) {
        this.examiningInstitutionID = examiningInstitutionID;
    }

    public Exam withExaminingInstitutionID(String examiningInstitutionID) {
        this.examiningInstitutionID = examiningInstitutionID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Exam withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Exam.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("examKey");
        sb.append('=');
        sb.append(((this.examKey == null)?"<null>":this.examKey));
        sb.append(',');
        sb.append("examSysKey");
        sb.append('=');
        sb.append(((this.examSysKey == null)?"<null>":this.examSysKey));
        sb.append(',');
        sb.append("examType");
        sb.append('=');
        sb.append(((this.examType == null)?"<null>":this.examType));
        sb.append(',');
        sb.append("statusDate");
        sb.append('=');
        sb.append(((this.statusDate == null)?"<null>":this.statusDate));
        sb.append(',');
        sb.append("examName");
        sb.append('=');
        sb.append(((this.examName == null)?"<null>":this.examName));
        sb.append(',');
        sb.append("institutionName");
        sb.append('=');
        sb.append(((this.institutionName == null)?"<null>":this.institutionName));
        sb.append(',');
        sb.append("examDate");
        sb.append('=');
        sb.append(((this.examDate == null)?"<null>":this.examDate));
        sb.append(',');
        sb.append("completedInd");
        sb.append('=');
        sb.append(((this.completedInd == null)?"<null>":this.completedInd));
        sb.append(',');
        sb.append("requiredInd");
        sb.append('=');
        sb.append(((this.requiredInd == null)?"<null>":this.requiredInd));
        sb.append(',');
        sb.append("exemptionInd");
        sb.append('=');
        sb.append(((this.exemptionInd == null)?"<null>":this.exemptionInd));
        sb.append(',');
        sb.append("educationalCreditEquivalent");
        sb.append('=');
        sb.append(((this.educationalCreditEquivalent == null)?"<null>":this.educationalCreditEquivalent));
        sb.append(',');
        sb.append("producerExamStatus");
        sb.append('=');
        sb.append(((this.producerExamStatus == null)?"<null>":this.producerExamStatus));
        sb.append(',');
        sb.append("examNumber");
        sb.append('=');
        sb.append(((this.examNumber == null)?"<null>":this.examNumber));
        sb.append(',');
        sb.append("examApprovalNumber");
        sb.append('=');
        sb.append(((this.examApprovalNumber == null)?"<null>":this.examApprovalNumber));
        sb.append(',');
        sb.append("examWindowStartDate");
        sb.append('=');
        sb.append(((this.examWindowStartDate == null)?"<null>":this.examWindowStartDate));
        sb.append(',');
        sb.append("examWindowEndDate");
        sb.append('=');
        sb.append(((this.examWindowEndDate == null)?"<null>":this.examWindowEndDate));
        sb.append(',');
        sb.append("approvedHours");
        sb.append('=');
        sb.append(((this.approvedHours == null)?"<null>":this.approvedHours));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("examiningInstitutionID");
        sb.append('=');
        sb.append(((this.examiningInstitutionID == null)?"<null>":this.examiningInstitutionID));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.statusDate == null)? 0 :this.statusDate.hashCode()));
        result = ((result* 31)+((this.examiningInstitutionID == null)? 0 :this.examiningInstitutionID.hashCode()));
        result = ((result* 31)+((this.completedInd == null)? 0 :this.completedInd.hashCode()));
        result = ((result* 31)+((this.examKey == null)? 0 :this.examKey.hashCode()));
        result = ((result* 31)+((this.requiredInd == null)? 0 :this.requiredInd.hashCode()));
        result = ((result* 31)+((this.approvedHours == null)? 0 :this.approvedHours.hashCode()));
        result = ((result* 31)+((this.examDate == null)? 0 :this.examDate.hashCode()));
        result = ((result* 31)+((this.examName == null)? 0 :this.examName.hashCode()));
        result = ((result* 31)+((this.examType == null)? 0 :this.examType.hashCode()));
        result = ((result* 31)+((this.examNumber == null)? 0 :this.examNumber.hashCode()));
        result = ((result* 31)+((this.producerExamStatus == null)? 0 :this.producerExamStatus.hashCode()));
        result = ((result* 31)+((this.examApprovalNumber == null)? 0 :this.examApprovalNumber.hashCode()));
        result = ((result* 31)+((this.exemptionInd == null)? 0 :this.exemptionInd.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.examSysKey == null)? 0 :this.examSysKey.hashCode()));
        result = ((result* 31)+((this.examWindowEndDate == null)? 0 :this.examWindowEndDate.hashCode()));
        result = ((result* 31)+((this.institutionName == null)? 0 :this.institutionName.hashCode()));
        result = ((result* 31)+((this.educationalCreditEquivalent == null)? 0 :this.educationalCreditEquivalent.hashCode()));
        result = ((result* 31)+((this.examWindowStartDate == null)? 0 :this.examWindowStartDate.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Exam) == false) {
            return false;
        }
        Exam rhs = ((Exam) other);
        return (((((((((((((((((((((this.statusDate == rhs.statusDate)||((this.statusDate!= null)&&this.statusDate.equals(rhs.statusDate)))&&((this.examiningInstitutionID == rhs.examiningInstitutionID)||((this.examiningInstitutionID!= null)&&this.examiningInstitutionID.equals(rhs.examiningInstitutionID))))&&((this.completedInd == rhs.completedInd)||((this.completedInd!= null)&&this.completedInd.equals(rhs.completedInd))))&&((this.examKey == rhs.examKey)||((this.examKey!= null)&&this.examKey.equals(rhs.examKey))))&&((this.requiredInd == rhs.requiredInd)||((this.requiredInd!= null)&&this.requiredInd.equals(rhs.requiredInd))))&&((this.approvedHours == rhs.approvedHours)||((this.approvedHours!= null)&&this.approvedHours.equals(rhs.approvedHours))))&&((this.examDate == rhs.examDate)||((this.examDate!= null)&&this.examDate.equals(rhs.examDate))))&&((this.examName == rhs.examName)||((this.examName!= null)&&this.examName.equals(rhs.examName))))&&((this.examType == rhs.examType)||((this.examType!= null)&&this.examType.equals(rhs.examType))))&&((this.examNumber == rhs.examNumber)||((this.examNumber!= null)&&this.examNumber.equals(rhs.examNumber))))&&((this.producerExamStatus == rhs.producerExamStatus)||((this.producerExamStatus!= null)&&this.producerExamStatus.equals(rhs.producerExamStatus))))&&((this.examApprovalNumber == rhs.examApprovalNumber)||((this.examApprovalNumber!= null)&&this.examApprovalNumber.equals(rhs.examApprovalNumber))))&&((this.exemptionInd == rhs.exemptionInd)||((this.exemptionInd!= null)&&this.exemptionInd.equals(rhs.exemptionInd))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.examSysKey == rhs.examSysKey)||((this.examSysKey!= null)&&this.examSysKey.equals(rhs.examSysKey))))&&((this.examWindowEndDate == rhs.examWindowEndDate)||((this.examWindowEndDate!= null)&&this.examWindowEndDate.equals(rhs.examWindowEndDate))))&&((this.institutionName == rhs.institutionName)||((this.institutionName!= null)&&this.institutionName.equals(rhs.institutionName))))&&((this.educationalCreditEquivalent == rhs.educationalCreditEquivalent)||((this.educationalCreditEquivalent!= null)&&this.educationalCreditEquivalent.equals(rhs.educationalCreditEquivalent))))&&((this.examWindowStartDate == rhs.examWindowStartDate)||((this.examWindowStartDate!= null)&&this.examWindowStartDate.equals(rhs.examWindowStartDate))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
