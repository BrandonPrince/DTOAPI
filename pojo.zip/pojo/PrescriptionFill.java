
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "PrescriptionFillKey",
    "PrescriptionFillSysKey",
    "PrescriptionNumber",
    "PrescriptionFillNumber",
    "PrescriptionFillDate",
    "PrescriptionFillPartialDate",
    "PrescriptionTotalRefillsAllowed",
    "PrescriptionDaysSupply",
    "PrescriptionQuantityDispensed",
    "KeyedValue",
    "OLifEExtension",
    "id",
    "PharmacyID",
    "PhysicianID",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class PrescriptionFill {

    @JsonProperty("PrescriptionFillKey")
    private PrescriptionFillKey prescriptionFillKey;
    @JsonProperty("PrescriptionFillSysKey")
    private List<Object> prescriptionFillSysKey = new ArrayList<>();
    @JsonProperty("PrescriptionNumber")
    private String prescriptionNumber;
    @JsonProperty("PrescriptionFillNumber")
    private Integer prescriptionFillNumber;
    @JsonProperty("PrescriptionFillDate")
    private String prescriptionFillDate;
    @JsonProperty("PrescriptionFillPartialDate")
    private String prescriptionFillPartialDate;
    @JsonProperty("PrescriptionTotalRefillsAllowed")
    private Integer prescriptionTotalRefillsAllowed;
    @JsonProperty("PrescriptionDaysSupply")
    private Integer prescriptionDaysSupply;
    @JsonProperty("PrescriptionQuantityDispensed")
    private Integer prescriptionQuantityDispensed;
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("PharmacyID")
    private String pharmacyID;
    @JsonProperty("PhysicianID")
    private String physicianID;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("PrescriptionFillKey")
    public PrescriptionFillKey getPrescriptionFillKey() {
        return prescriptionFillKey;
    }

    @JsonProperty("PrescriptionFillKey")
    public void setPrescriptionFillKey(PrescriptionFillKey prescriptionFillKey) {
        this.prescriptionFillKey = prescriptionFillKey;
    }

    public PrescriptionFill withPrescriptionFillKey(PrescriptionFillKey prescriptionFillKey) {
        this.prescriptionFillKey = prescriptionFillKey;
        return this;
    }

    @JsonProperty("PrescriptionFillSysKey")
    public List<Object> getPrescriptionFillSysKey() {
        return prescriptionFillSysKey;
    }

    @JsonProperty("PrescriptionFillSysKey")
    public void setPrescriptionFillSysKey(List<Object> prescriptionFillSysKey) {
        this.prescriptionFillSysKey = prescriptionFillSysKey;
    }

    public PrescriptionFill withPrescriptionFillSysKey(List<Object> prescriptionFillSysKey) {
        this.prescriptionFillSysKey = prescriptionFillSysKey;
        return this;
    }

    @JsonProperty("PrescriptionNumber")
    public String getPrescriptionNumber() {
        return prescriptionNumber;
    }

    @JsonProperty("PrescriptionNumber")
    public void setPrescriptionNumber(String prescriptionNumber) {
        this.prescriptionNumber = prescriptionNumber;
    }

    public PrescriptionFill withPrescriptionNumber(String prescriptionNumber) {
        this.prescriptionNumber = prescriptionNumber;
        return this;
    }

    @JsonProperty("PrescriptionFillNumber")
    public Integer getPrescriptionFillNumber() {
        return prescriptionFillNumber;
    }

    @JsonProperty("PrescriptionFillNumber")
    public void setPrescriptionFillNumber(Integer prescriptionFillNumber) {
        this.prescriptionFillNumber = prescriptionFillNumber;
    }

    public PrescriptionFill withPrescriptionFillNumber(Integer prescriptionFillNumber) {
        this.prescriptionFillNumber = prescriptionFillNumber;
        return this;
    }

    @JsonProperty("PrescriptionFillDate")
    public String getPrescriptionFillDate() {
        return prescriptionFillDate;
    }

    @JsonProperty("PrescriptionFillDate")
    public void setPrescriptionFillDate(String prescriptionFillDate) {
        this.prescriptionFillDate = prescriptionFillDate;
    }

    public PrescriptionFill withPrescriptionFillDate(String prescriptionFillDate) {
        this.prescriptionFillDate = prescriptionFillDate;
        return this;
    }

    @JsonProperty("PrescriptionFillPartialDate")
    public String getPrescriptionFillPartialDate() {
        return prescriptionFillPartialDate;
    }

    @JsonProperty("PrescriptionFillPartialDate")
    public void setPrescriptionFillPartialDate(String prescriptionFillPartialDate) {
        this.prescriptionFillPartialDate = prescriptionFillPartialDate;
    }

    public PrescriptionFill withPrescriptionFillPartialDate(String prescriptionFillPartialDate) {
        this.prescriptionFillPartialDate = prescriptionFillPartialDate;
        return this;
    }

    @JsonProperty("PrescriptionTotalRefillsAllowed")
    public Integer getPrescriptionTotalRefillsAllowed() {
        return prescriptionTotalRefillsAllowed;
    }

    @JsonProperty("PrescriptionTotalRefillsAllowed")
    public void setPrescriptionTotalRefillsAllowed(Integer prescriptionTotalRefillsAllowed) {
        this.prescriptionTotalRefillsAllowed = prescriptionTotalRefillsAllowed;
    }

    public PrescriptionFill withPrescriptionTotalRefillsAllowed(Integer prescriptionTotalRefillsAllowed) {
        this.prescriptionTotalRefillsAllowed = prescriptionTotalRefillsAllowed;
        return this;
    }

    @JsonProperty("PrescriptionDaysSupply")
    public Integer getPrescriptionDaysSupply() {
        return prescriptionDaysSupply;
    }

    @JsonProperty("PrescriptionDaysSupply")
    public void setPrescriptionDaysSupply(Integer prescriptionDaysSupply) {
        this.prescriptionDaysSupply = prescriptionDaysSupply;
    }

    public PrescriptionFill withPrescriptionDaysSupply(Integer prescriptionDaysSupply) {
        this.prescriptionDaysSupply = prescriptionDaysSupply;
        return this;
    }

    @JsonProperty("PrescriptionQuantityDispensed")
    public Integer getPrescriptionQuantityDispensed() {
        return prescriptionQuantityDispensed;
    }

    @JsonProperty("PrescriptionQuantityDispensed")
    public void setPrescriptionQuantityDispensed(Integer prescriptionQuantityDispensed) {
        this.prescriptionQuantityDispensed = prescriptionQuantityDispensed;
    }

    public PrescriptionFill withPrescriptionQuantityDispensed(Integer prescriptionQuantityDispensed) {
        this.prescriptionQuantityDispensed = prescriptionQuantityDispensed;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public PrescriptionFill withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public PrescriptionFill withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public PrescriptionFill withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("PharmacyID")
    public String getPharmacyID() {
        return pharmacyID;
    }

    @JsonProperty("PharmacyID")
    public void setPharmacyID(String pharmacyID) {
        this.pharmacyID = pharmacyID;
    }

    public PrescriptionFill withPharmacyID(String pharmacyID) {
        this.pharmacyID = pharmacyID;
        return this;
    }

    @JsonProperty("PhysicianID")
    public String getPhysicianID() {
        return physicianID;
    }

    @JsonProperty("PhysicianID")
    public void setPhysicianID(String physicianID) {
        this.physicianID = physicianID;
    }

    public PrescriptionFill withPhysicianID(String physicianID) {
        this.physicianID = physicianID;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public PrescriptionFill withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public PrescriptionFill withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(PrescriptionFill.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("prescriptionFillKey");
        sb.append('=');
        sb.append(((this.prescriptionFillKey == null)?"<null>":this.prescriptionFillKey));
        sb.append(',');
        sb.append("prescriptionFillSysKey");
        sb.append('=');
        sb.append(((this.prescriptionFillSysKey == null)?"<null>":this.prescriptionFillSysKey));
        sb.append(',');
        sb.append("prescriptionNumber");
        sb.append('=');
        sb.append(((this.prescriptionNumber == null)?"<null>":this.prescriptionNumber));
        sb.append(',');
        sb.append("prescriptionFillNumber");
        sb.append('=');
        sb.append(((this.prescriptionFillNumber == null)?"<null>":this.prescriptionFillNumber));
        sb.append(',');
        sb.append("prescriptionFillDate");
        sb.append('=');
        sb.append(((this.prescriptionFillDate == null)?"<null>":this.prescriptionFillDate));
        sb.append(',');
        sb.append("prescriptionFillPartialDate");
        sb.append('=');
        sb.append(((this.prescriptionFillPartialDate == null)?"<null>":this.prescriptionFillPartialDate));
        sb.append(',');
        sb.append("prescriptionTotalRefillsAllowed");
        sb.append('=');
        sb.append(((this.prescriptionTotalRefillsAllowed == null)?"<null>":this.prescriptionTotalRefillsAllowed));
        sb.append(',');
        sb.append("prescriptionDaysSupply");
        sb.append('=');
        sb.append(((this.prescriptionDaysSupply == null)?"<null>":this.prescriptionDaysSupply));
        sb.append(',');
        sb.append("prescriptionQuantityDispensed");
        sb.append('=');
        sb.append(((this.prescriptionQuantityDispensed == null)?"<null>":this.prescriptionQuantityDispensed));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("pharmacyID");
        sb.append('=');
        sb.append(((this.pharmacyID == null)?"<null>":this.pharmacyID));
        sb.append(',');
        sb.append("physicianID");
        sb.append('=');
        sb.append(((this.physicianID == null)?"<null>":this.physicianID));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.pharmacyID == null)? 0 :this.pharmacyID.hashCode()));
        result = ((result* 31)+((this.prescriptionQuantityDispensed == null)? 0 :this.prescriptionQuantityDispensed.hashCode()));
        result = ((result* 31)+((this.prescriptionNumber == null)? 0 :this.prescriptionNumber.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.prescriptionFillKey == null)? 0 :this.prescriptionFillKey.hashCode()));
        result = ((result* 31)+((this.physicianID == null)? 0 :this.physicianID.hashCode()));
        result = ((result* 31)+((this.prescriptionTotalRefillsAllowed == null)? 0 :this.prescriptionTotalRefillsAllowed.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.prescriptionFillPartialDate == null)? 0 :this.prescriptionFillPartialDate.hashCode()));
        result = ((result* 31)+((this.prescriptionFillNumber == null)? 0 :this.prescriptionFillNumber.hashCode()));
        result = ((result* 31)+((this.prescriptionFillDate == null)? 0 :this.prescriptionFillDate.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.prescriptionFillSysKey == null)? 0 :this.prescriptionFillSysKey.hashCode()));
        result = ((result* 31)+((this.prescriptionDaysSupply == null)? 0 :this.prescriptionDaysSupply.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PrescriptionFill) == false) {
            return false;
        }
        PrescriptionFill rhs = ((PrescriptionFill) other);
        return (((((((((((((((((this.pharmacyID == rhs.pharmacyID)||((this.pharmacyID!= null)&&this.pharmacyID.equals(rhs.pharmacyID)))&&((this.prescriptionQuantityDispensed == rhs.prescriptionQuantityDispensed)||((this.prescriptionQuantityDispensed!= null)&&this.prescriptionQuantityDispensed.equals(rhs.prescriptionQuantityDispensed))))&&((this.prescriptionNumber == rhs.prescriptionNumber)||((this.prescriptionNumber!= null)&&this.prescriptionNumber.equals(rhs.prescriptionNumber))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.prescriptionFillKey == rhs.prescriptionFillKey)||((this.prescriptionFillKey!= null)&&this.prescriptionFillKey.equals(rhs.prescriptionFillKey))))&&((this.physicianID == rhs.physicianID)||((this.physicianID!= null)&&this.physicianID.equals(rhs.physicianID))))&&((this.prescriptionTotalRefillsAllowed == rhs.prescriptionTotalRefillsAllowed)||((this.prescriptionTotalRefillsAllowed!= null)&&this.prescriptionTotalRefillsAllowed.equals(rhs.prescriptionTotalRefillsAllowed))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.prescriptionFillPartialDate == rhs.prescriptionFillPartialDate)||((this.prescriptionFillPartialDate!= null)&&this.prescriptionFillPartialDate.equals(rhs.prescriptionFillPartialDate))))&&((this.prescriptionFillNumber == rhs.prescriptionFillNumber)||((this.prescriptionFillNumber!= null)&&this.prescriptionFillNumber.equals(rhs.prescriptionFillNumber))))&&((this.prescriptionFillDate == rhs.prescriptionFillDate)||((this.prescriptionFillDate!= null)&&this.prescriptionFillDate.equals(rhs.prescriptionFillDate))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.prescriptionFillSysKey == rhs.prescriptionFillSysKey)||((this.prescriptionFillSysKey!= null)&&this.prescriptionFillSysKey.equals(rhs.prescriptionFillSysKey))))&&((this.prescriptionDaysSupply == rhs.prescriptionDaysSupply)||((this.prescriptionDaysSupply!= null)&&this.prescriptionDaysSupply.equals(rhs.prescriptionDaysSupply))));
    }

}
