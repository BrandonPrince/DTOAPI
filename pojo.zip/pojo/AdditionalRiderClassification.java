
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AdditionalRiderClassificationKey",
    "AdditionalRiderClassificationSysKey",
    "RiderTypeCode",
    "RiderSubTypeCode",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AdditionalRiderClassification {

    @JsonProperty("AdditionalRiderClassificationKey")
    private AdditionalRiderClassificationKey additionalRiderClassificationKey;
    @JsonProperty("AdditionalRiderClassificationSysKey")
    private List<Object> additionalRiderClassificationSysKey = new ArrayList<>();
    @JsonProperty("RiderTypeCode")
    private RiderTypeCode riderTypeCode;
    @JsonProperty("RiderSubTypeCode")
    private RiderSubTypeCode riderSubTypeCode;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AdditionalRiderClassificationKey")
    public AdditionalRiderClassificationKey getAdditionalRiderClassificationKey() {
        return additionalRiderClassificationKey;
    }

    @JsonProperty("AdditionalRiderClassificationKey")
    public void setAdditionalRiderClassificationKey(AdditionalRiderClassificationKey additionalRiderClassificationKey) {
        this.additionalRiderClassificationKey = additionalRiderClassificationKey;
    }

    public AdditionalRiderClassification withAdditionalRiderClassificationKey(AdditionalRiderClassificationKey additionalRiderClassificationKey) {
        this.additionalRiderClassificationKey = additionalRiderClassificationKey;
        return this;
    }

    @JsonProperty("AdditionalRiderClassificationSysKey")
    public List<Object> getAdditionalRiderClassificationSysKey() {
        return additionalRiderClassificationSysKey;
    }

    @JsonProperty("AdditionalRiderClassificationSysKey")
    public void setAdditionalRiderClassificationSysKey(List<Object> additionalRiderClassificationSysKey) {
        this.additionalRiderClassificationSysKey = additionalRiderClassificationSysKey;
    }

    public AdditionalRiderClassification withAdditionalRiderClassificationSysKey(List<Object> additionalRiderClassificationSysKey) {
        this.additionalRiderClassificationSysKey = additionalRiderClassificationSysKey;
        return this;
    }

    @JsonProperty("RiderTypeCode")
    public RiderTypeCode getRiderTypeCode() {
        return riderTypeCode;
    }

    @JsonProperty("RiderTypeCode")
    public void setRiderTypeCode(RiderTypeCode riderTypeCode) {
        this.riderTypeCode = riderTypeCode;
    }

    public AdditionalRiderClassification withRiderTypeCode(RiderTypeCode riderTypeCode) {
        this.riderTypeCode = riderTypeCode;
        return this;
    }

    @JsonProperty("RiderSubTypeCode")
    public RiderSubTypeCode getRiderSubTypeCode() {
        return riderSubTypeCode;
    }

    @JsonProperty("RiderSubTypeCode")
    public void setRiderSubTypeCode(RiderSubTypeCode riderSubTypeCode) {
        this.riderSubTypeCode = riderSubTypeCode;
    }

    public AdditionalRiderClassification withRiderSubTypeCode(RiderSubTypeCode riderSubTypeCode) {
        this.riderSubTypeCode = riderSubTypeCode;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AdditionalRiderClassification withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AdditionalRiderClassification withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AdditionalRiderClassification withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AdditionalRiderClassification withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AdditionalRiderClassification.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("additionalRiderClassificationKey");
        sb.append('=');
        sb.append(((this.additionalRiderClassificationKey == null)?"<null>":this.additionalRiderClassificationKey));
        sb.append(',');
        sb.append("additionalRiderClassificationSysKey");
        sb.append('=');
        sb.append(((this.additionalRiderClassificationSysKey == null)?"<null>":this.additionalRiderClassificationSysKey));
        sb.append(',');
        sb.append("riderTypeCode");
        sb.append('=');
        sb.append(((this.riderTypeCode == null)?"<null>":this.riderTypeCode));
        sb.append(',');
        sb.append("riderSubTypeCode");
        sb.append('=');
        sb.append(((this.riderSubTypeCode == null)?"<null>":this.riderSubTypeCode));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.riderTypeCode == null)? 0 :this.riderTypeCode.hashCode()));
        result = ((result* 31)+((this.riderSubTypeCode == null)? 0 :this.riderSubTypeCode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.additionalRiderClassificationKey == null)? 0 :this.additionalRiderClassificationKey.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.additionalRiderClassificationSysKey == null)? 0 :this.additionalRiderClassificationSysKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AdditionalRiderClassification) == false) {
            return false;
        }
        AdditionalRiderClassification rhs = ((AdditionalRiderClassification) other);
        return (((((((((this.riderTypeCode == rhs.riderTypeCode)||((this.riderTypeCode!= null)&&this.riderTypeCode.equals(rhs.riderTypeCode)))&&((this.riderSubTypeCode == rhs.riderSubTypeCode)||((this.riderSubTypeCode!= null)&&this.riderSubTypeCode.equals(rhs.riderSubTypeCode))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.additionalRiderClassificationKey == rhs.additionalRiderClassificationKey)||((this.additionalRiderClassificationKey!= null)&&this.additionalRiderClassificationKey.equals(rhs.additionalRiderClassificationKey))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.additionalRiderClassificationSysKey == rhs.additionalRiderClassificationSysKey)||((this.additionalRiderClassificationSysKey!= null)&&this.additionalRiderClassificationSysKey.equals(rhs.additionalRiderClassificationSysKey))));
    }

}
