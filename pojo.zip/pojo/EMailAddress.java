
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "EMailAddressKey",
    "EMailAddressSysKey",
    "EMailType",
    "AddrLine",
    "PrefEMailAddr",
    "AttachmentInd",
    "UndeliverableInd",
    "SolicitationInd",
    "StartDate",
    "EndDate",
    "Language",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class EMailAddress {

    @JsonProperty("EMailAddressKey")
    private EMailAddressKey eMailAddressKey;
    @JsonProperty("EMailAddressSysKey")
    private List<Object> eMailAddressSysKey = new ArrayList<>();
    @JsonProperty("EMailType")
    private EMailType eMailType;
    @JsonProperty("AddrLine")
    private String addrLine;
    @JsonProperty("PrefEMailAddr")
    private PrefEMailAddr prefEMailAddr;
    @JsonProperty("AttachmentInd")
    private AttachmentInd attachmentInd;
    @JsonProperty("UndeliverableInd")
    private UndeliverableInd undeliverableInd;
    @JsonProperty("SolicitationInd")
    private SolicitationInd solicitationInd;
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("Language")
    private Language language;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("EMailAddressKey")
    public EMailAddressKey getEMailAddressKey() {
        return eMailAddressKey;
    }

    @JsonProperty("EMailAddressKey")
    public void setEMailAddressKey(EMailAddressKey eMailAddressKey) {
        this.eMailAddressKey = eMailAddressKey;
    }

    public EMailAddress withEMailAddressKey(EMailAddressKey eMailAddressKey) {
        this.eMailAddressKey = eMailAddressKey;
        return this;
    }

    @JsonProperty("EMailAddressSysKey")
    public List<Object> getEMailAddressSysKey() {
        return eMailAddressSysKey;
    }

    @JsonProperty("EMailAddressSysKey")
    public void setEMailAddressSysKey(List<Object> eMailAddressSysKey) {
        this.eMailAddressSysKey = eMailAddressSysKey;
    }

    public EMailAddress withEMailAddressSysKey(List<Object> eMailAddressSysKey) {
        this.eMailAddressSysKey = eMailAddressSysKey;
        return this;
    }

    @JsonProperty("EMailType")
    public EMailType getEMailType() {
        return eMailType;
    }

    @JsonProperty("EMailType")
    public void setEMailType(EMailType eMailType) {
        this.eMailType = eMailType;
    }

    public EMailAddress withEMailType(EMailType eMailType) {
        this.eMailType = eMailType;
        return this;
    }

    @JsonProperty("AddrLine")
    public String getAddrLine() {
        return addrLine;
    }

    @JsonProperty("AddrLine")
    public void setAddrLine(String addrLine) {
        this.addrLine = addrLine;
    }

    public EMailAddress withAddrLine(String addrLine) {
        this.addrLine = addrLine;
        return this;
    }

    @JsonProperty("PrefEMailAddr")
    public PrefEMailAddr getPrefEMailAddr() {
        return prefEMailAddr;
    }

    @JsonProperty("PrefEMailAddr")
    public void setPrefEMailAddr(PrefEMailAddr prefEMailAddr) {
        this.prefEMailAddr = prefEMailAddr;
    }

    public EMailAddress withPrefEMailAddr(PrefEMailAddr prefEMailAddr) {
        this.prefEMailAddr = prefEMailAddr;
        return this;
    }

    @JsonProperty("AttachmentInd")
    public AttachmentInd getAttachmentInd() {
        return attachmentInd;
    }

    @JsonProperty("AttachmentInd")
    public void setAttachmentInd(AttachmentInd attachmentInd) {
        this.attachmentInd = attachmentInd;
    }

    public EMailAddress withAttachmentInd(AttachmentInd attachmentInd) {
        this.attachmentInd = attachmentInd;
        return this;
    }

    @JsonProperty("UndeliverableInd")
    public UndeliverableInd getUndeliverableInd() {
        return undeliverableInd;
    }

    @JsonProperty("UndeliverableInd")
    public void setUndeliverableInd(UndeliverableInd undeliverableInd) {
        this.undeliverableInd = undeliverableInd;
    }

    public EMailAddress withUndeliverableInd(UndeliverableInd undeliverableInd) {
        this.undeliverableInd = undeliverableInd;
        return this;
    }

    @JsonProperty("SolicitationInd")
    public SolicitationInd getSolicitationInd() {
        return solicitationInd;
    }

    @JsonProperty("SolicitationInd")
    public void setSolicitationInd(SolicitationInd solicitationInd) {
        this.solicitationInd = solicitationInd;
    }

    public EMailAddress withSolicitationInd(SolicitationInd solicitationInd) {
        this.solicitationInd = solicitationInd;
        return this;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public EMailAddress withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public EMailAddress withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("Language")
    public Language getLanguage() {
        return language;
    }

    @JsonProperty("Language")
    public void setLanguage(Language language) {
        this.language = language;
    }

    public EMailAddress withLanguage(Language language) {
        this.language = language;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public EMailAddress withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public EMailAddress withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public EMailAddress withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public EMailAddress withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(EMailAddress.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("eMailAddressKey");
        sb.append('=');
        sb.append(((this.eMailAddressKey == null)?"<null>":this.eMailAddressKey));
        sb.append(',');
        sb.append("eMailAddressSysKey");
        sb.append('=');
        sb.append(((this.eMailAddressSysKey == null)?"<null>":this.eMailAddressSysKey));
        sb.append(',');
        sb.append("eMailType");
        sb.append('=');
        sb.append(((this.eMailType == null)?"<null>":this.eMailType));
        sb.append(',');
        sb.append("addrLine");
        sb.append('=');
        sb.append(((this.addrLine == null)?"<null>":this.addrLine));
        sb.append(',');
        sb.append("prefEMailAddr");
        sb.append('=');
        sb.append(((this.prefEMailAddr == null)?"<null>":this.prefEMailAddr));
        sb.append(',');
        sb.append("attachmentInd");
        sb.append('=');
        sb.append(((this.attachmentInd == null)?"<null>":this.attachmentInd));
        sb.append(',');
        sb.append("undeliverableInd");
        sb.append('=');
        sb.append(((this.undeliverableInd == null)?"<null>":this.undeliverableInd));
        sb.append(',');
        sb.append("solicitationInd");
        sb.append('=');
        sb.append(((this.solicitationInd == null)?"<null>":this.solicitationInd));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("language");
        sb.append('=');
        sb.append(((this.language == null)?"<null>":this.language));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.eMailAddressKey == null)? 0 :this.eMailAddressKey.hashCode()));
        result = ((result* 31)+((this.undeliverableInd == null)? 0 :this.undeliverableInd.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.eMailAddressSysKey == null)? 0 :this.eMailAddressSysKey.hashCode()));
        result = ((result* 31)+((this.language == null)? 0 :this.language.hashCode()));
        result = ((result* 31)+((this.eMailType == null)? 0 :this.eMailType.hashCode()));
        result = ((result* 31)+((this.solicitationInd == null)? 0 :this.solicitationInd.hashCode()));
        result = ((result* 31)+((this.attachmentInd == null)? 0 :this.attachmentInd.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.addrLine == null)? 0 :this.addrLine.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.prefEMailAddr == null)? 0 :this.prefEMailAddr.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof EMailAddress) == false) {
            return false;
        }
        EMailAddress rhs = ((EMailAddress) other);
        return ((((((((((((((((this.eMailAddressKey == rhs.eMailAddressKey)||((this.eMailAddressKey!= null)&&this.eMailAddressKey.equals(rhs.eMailAddressKey)))&&((this.undeliverableInd == rhs.undeliverableInd)||((this.undeliverableInd!= null)&&this.undeliverableInd.equals(rhs.undeliverableInd))))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.eMailAddressSysKey == rhs.eMailAddressSysKey)||((this.eMailAddressSysKey!= null)&&this.eMailAddressSysKey.equals(rhs.eMailAddressSysKey))))&&((this.language == rhs.language)||((this.language!= null)&&this.language.equals(rhs.language))))&&((this.eMailType == rhs.eMailType)||((this.eMailType!= null)&&this.eMailType.equals(rhs.eMailType))))&&((this.solicitationInd == rhs.solicitationInd)||((this.solicitationInd!= null)&&this.solicitationInd.equals(rhs.solicitationInd))))&&((this.attachmentInd == rhs.attachmentInd)||((this.attachmentInd!= null)&&this.attachmentInd.equals(rhs.attachmentInd))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.addrLine == rhs.addrLine)||((this.addrLine!= null)&&this.addrLine.equals(rhs.addrLine))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.prefEMailAddr == rhs.prefEMailAddr)||((this.prefEMailAddr!= null)&&this.prefEMailAddr.equals(rhs.prefEMailAddr))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))));
    }

}
