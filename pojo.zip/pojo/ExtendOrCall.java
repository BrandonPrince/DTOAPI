
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ExtendOrCallKey",
    "ExtendOrCallSysKey",
    "ExtendOrCallType",
    "ExtendOrCallDate",
    "NumDaysNotice",
    "NewRate",
    "StartDate",
    "EndDate",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class ExtendOrCall {

    @JsonProperty("ExtendOrCallKey")
    private ExtendOrCallKey extendOrCallKey;
    @JsonProperty("ExtendOrCallSysKey")
    private List<Object> extendOrCallSysKey = new ArrayList<>();
    @JsonProperty("ExtendOrCallType")
    private ExtendOrCallType extendOrCallType;
    @JsonProperty("ExtendOrCallDate")
    private String extendOrCallDate;
    @JsonProperty("NumDaysNotice")
    private Integer numDaysNotice;
    @JsonProperty("NewRate")
    private Integer newRate;
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ExtendOrCallKey")
    public ExtendOrCallKey getExtendOrCallKey() {
        return extendOrCallKey;
    }

    @JsonProperty("ExtendOrCallKey")
    public void setExtendOrCallKey(ExtendOrCallKey extendOrCallKey) {
        this.extendOrCallKey = extendOrCallKey;
    }

    public ExtendOrCall withExtendOrCallKey(ExtendOrCallKey extendOrCallKey) {
        this.extendOrCallKey = extendOrCallKey;
        return this;
    }

    @JsonProperty("ExtendOrCallSysKey")
    public List<Object> getExtendOrCallSysKey() {
        return extendOrCallSysKey;
    }

    @JsonProperty("ExtendOrCallSysKey")
    public void setExtendOrCallSysKey(List<Object> extendOrCallSysKey) {
        this.extendOrCallSysKey = extendOrCallSysKey;
    }

    public ExtendOrCall withExtendOrCallSysKey(List<Object> extendOrCallSysKey) {
        this.extendOrCallSysKey = extendOrCallSysKey;
        return this;
    }

    @JsonProperty("ExtendOrCallType")
    public ExtendOrCallType getExtendOrCallType() {
        return extendOrCallType;
    }

    @JsonProperty("ExtendOrCallType")
    public void setExtendOrCallType(ExtendOrCallType extendOrCallType) {
        this.extendOrCallType = extendOrCallType;
    }

    public ExtendOrCall withExtendOrCallType(ExtendOrCallType extendOrCallType) {
        this.extendOrCallType = extendOrCallType;
        return this;
    }

    @JsonProperty("ExtendOrCallDate")
    public String getExtendOrCallDate() {
        return extendOrCallDate;
    }

    @JsonProperty("ExtendOrCallDate")
    public void setExtendOrCallDate(String extendOrCallDate) {
        this.extendOrCallDate = extendOrCallDate;
    }

    public ExtendOrCall withExtendOrCallDate(String extendOrCallDate) {
        this.extendOrCallDate = extendOrCallDate;
        return this;
    }

    @JsonProperty("NumDaysNotice")
    public Integer getNumDaysNotice() {
        return numDaysNotice;
    }

    @JsonProperty("NumDaysNotice")
    public void setNumDaysNotice(Integer numDaysNotice) {
        this.numDaysNotice = numDaysNotice;
    }

    public ExtendOrCall withNumDaysNotice(Integer numDaysNotice) {
        this.numDaysNotice = numDaysNotice;
        return this;
    }

    @JsonProperty("NewRate")
    public Integer getNewRate() {
        return newRate;
    }

    @JsonProperty("NewRate")
    public void setNewRate(Integer newRate) {
        this.newRate = newRate;
    }

    public ExtendOrCall withNewRate(Integer newRate) {
        this.newRate = newRate;
        return this;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public ExtendOrCall withStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public ExtendOrCall withEndDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public ExtendOrCall withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public ExtendOrCall withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public ExtendOrCall withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ExtendOrCall withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ExtendOrCall.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("extendOrCallKey");
        sb.append('=');
        sb.append(((this.extendOrCallKey == null)?"<null>":this.extendOrCallKey));
        sb.append(',');
        sb.append("extendOrCallSysKey");
        sb.append('=');
        sb.append(((this.extendOrCallSysKey == null)?"<null>":this.extendOrCallSysKey));
        sb.append(',');
        sb.append("extendOrCallType");
        sb.append('=');
        sb.append(((this.extendOrCallType == null)?"<null>":this.extendOrCallType));
        sb.append(',');
        sb.append("extendOrCallDate");
        sb.append('=');
        sb.append(((this.extendOrCallDate == null)?"<null>":this.extendOrCallDate));
        sb.append(',');
        sb.append("numDaysNotice");
        sb.append('=');
        sb.append(((this.numDaysNotice == null)?"<null>":this.numDaysNotice));
        sb.append(',');
        sb.append("newRate");
        sb.append('=');
        sb.append(((this.newRate == null)?"<null>":this.newRate));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.numDaysNotice == null)? 0 :this.numDaysNotice.hashCode()));
        result = ((result* 31)+((this.extendOrCallType == null)? 0 :this.extendOrCallType.hashCode()));
        result = ((result* 31)+((this.extendOrCallKey == null)? 0 :this.extendOrCallKey.hashCode()));
        result = ((result* 31)+((this.endDate == null)? 0 :this.endDate.hashCode()));
        result = ((result* 31)+((this.extendOrCallDate == null)? 0 :this.extendOrCallDate.hashCode()));
        result = ((result* 31)+((this.extendOrCallSysKey == null)? 0 :this.extendOrCallSysKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.newRate == null)? 0 :this.newRate.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.startDate == null)? 0 :this.startDate.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ExtendOrCall) == false) {
            return false;
        }
        ExtendOrCall rhs = ((ExtendOrCall) other);
        return (((((((((((((this.numDaysNotice == rhs.numDaysNotice)||((this.numDaysNotice!= null)&&this.numDaysNotice.equals(rhs.numDaysNotice)))&&((this.extendOrCallType == rhs.extendOrCallType)||((this.extendOrCallType!= null)&&this.extendOrCallType.equals(rhs.extendOrCallType))))&&((this.extendOrCallKey == rhs.extendOrCallKey)||((this.extendOrCallKey!= null)&&this.extendOrCallKey.equals(rhs.extendOrCallKey))))&&((this.endDate == rhs.endDate)||((this.endDate!= null)&&this.endDate.equals(rhs.endDate))))&&((this.extendOrCallDate == rhs.extendOrCallDate)||((this.extendOrCallDate!= null)&&this.extendOrCallDate.equals(rhs.extendOrCallDate))))&&((this.extendOrCallSysKey == rhs.extendOrCallSysKey)||((this.extendOrCallSysKey!= null)&&this.extendOrCallSysKey.equals(rhs.extendOrCallSysKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.newRate == rhs.newRate)||((this.newRate!= null)&&this.newRate.equals(rhs.newRate))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.startDate == rhs.startDate)||((this.startDate!= null)&&this.startDate.equals(rhs.startDate))));
    }

}
