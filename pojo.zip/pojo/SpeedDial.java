
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SpeedDialKey",
    "SpeedDialSysKey",
    "SpeedDialNumber",
    "SpeedDialType",
    "OrgCode",
    "Description",
    "OLifEExtension",
    "id",
    "OwnerPartyID",
    "OwnerPhoneID",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class SpeedDial {

    @JsonProperty("SpeedDialKey")
    private SpeedDialKey speedDialKey;
    @JsonProperty("SpeedDialSysKey")
    private List<Object> speedDialSysKey = new ArrayList<>();
    @JsonProperty("SpeedDialNumber")
    private String speedDialNumber;
    @JsonProperty("SpeedDialType")
    private SpeedDialType speedDialType;
    @JsonProperty("OrgCode")
    private String orgCode;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("OwnerPartyID")
    private String ownerPartyID;
    @JsonProperty("OwnerPhoneID")
    private String ownerPhoneID;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("SpeedDialKey")
    public SpeedDialKey getSpeedDialKey() {
        return speedDialKey;
    }

    @JsonProperty("SpeedDialKey")
    public void setSpeedDialKey(SpeedDialKey speedDialKey) {
        this.speedDialKey = speedDialKey;
    }

    public SpeedDial withSpeedDialKey(SpeedDialKey speedDialKey) {
        this.speedDialKey = speedDialKey;
        return this;
    }

    @JsonProperty("SpeedDialSysKey")
    public List<Object> getSpeedDialSysKey() {
        return speedDialSysKey;
    }

    @JsonProperty("SpeedDialSysKey")
    public void setSpeedDialSysKey(List<Object> speedDialSysKey) {
        this.speedDialSysKey = speedDialSysKey;
    }

    public SpeedDial withSpeedDialSysKey(List<Object> speedDialSysKey) {
        this.speedDialSysKey = speedDialSysKey;
        return this;
    }

    @JsonProperty("SpeedDialNumber")
    public String getSpeedDialNumber() {
        return speedDialNumber;
    }

    @JsonProperty("SpeedDialNumber")
    public void setSpeedDialNumber(String speedDialNumber) {
        this.speedDialNumber = speedDialNumber;
    }

    public SpeedDial withSpeedDialNumber(String speedDialNumber) {
        this.speedDialNumber = speedDialNumber;
        return this;
    }

    @JsonProperty("SpeedDialType")
    public SpeedDialType getSpeedDialType() {
        return speedDialType;
    }

    @JsonProperty("SpeedDialType")
    public void setSpeedDialType(SpeedDialType speedDialType) {
        this.speedDialType = speedDialType;
    }

    public SpeedDial withSpeedDialType(SpeedDialType speedDialType) {
        this.speedDialType = speedDialType;
        return this;
    }

    @JsonProperty("OrgCode")
    public String getOrgCode() {
        return orgCode;
    }

    @JsonProperty("OrgCode")
    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public SpeedDial withOrgCode(String orgCode) {
        this.orgCode = orgCode;
        return this;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    public SpeedDial withDescription(String description) {
        this.description = description;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public SpeedDial withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public SpeedDial withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("OwnerPartyID")
    public String getOwnerPartyID() {
        return ownerPartyID;
    }

    @JsonProperty("OwnerPartyID")
    public void setOwnerPartyID(String ownerPartyID) {
        this.ownerPartyID = ownerPartyID;
    }

    public SpeedDial withOwnerPartyID(String ownerPartyID) {
        this.ownerPartyID = ownerPartyID;
        return this;
    }

    @JsonProperty("OwnerPhoneID")
    public String getOwnerPhoneID() {
        return ownerPhoneID;
    }

    @JsonProperty("OwnerPhoneID")
    public void setOwnerPhoneID(String ownerPhoneID) {
        this.ownerPhoneID = ownerPhoneID;
    }

    public SpeedDial withOwnerPhoneID(String ownerPhoneID) {
        this.ownerPhoneID = ownerPhoneID;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public SpeedDial withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SpeedDial withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(SpeedDial.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("speedDialKey");
        sb.append('=');
        sb.append(((this.speedDialKey == null)?"<null>":this.speedDialKey));
        sb.append(',');
        sb.append("speedDialSysKey");
        sb.append('=');
        sb.append(((this.speedDialSysKey == null)?"<null>":this.speedDialSysKey));
        sb.append(',');
        sb.append("speedDialNumber");
        sb.append('=');
        sb.append(((this.speedDialNumber == null)?"<null>":this.speedDialNumber));
        sb.append(',');
        sb.append("speedDialType");
        sb.append('=');
        sb.append(((this.speedDialType == null)?"<null>":this.speedDialType));
        sb.append(',');
        sb.append("orgCode");
        sb.append('=');
        sb.append(((this.orgCode == null)?"<null>":this.orgCode));
        sb.append(',');
        sb.append("description");
        sb.append('=');
        sb.append(((this.description == null)?"<null>":this.description));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("ownerPartyID");
        sb.append('=');
        sb.append(((this.ownerPartyID == null)?"<null>":this.ownerPartyID));
        sb.append(',');
        sb.append("ownerPhoneID");
        sb.append('=');
        sb.append(((this.ownerPhoneID == null)?"<null>":this.ownerPhoneID));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.speedDialKey == null)? 0 :this.speedDialKey.hashCode()));
        result = ((result* 31)+((this.description == null)? 0 :this.description.hashCode()));
        result = ((result* 31)+((this.ownerPartyID == null)? 0 :this.ownerPartyID.hashCode()));
        result = ((result* 31)+((this.ownerPhoneID == null)? 0 :this.ownerPhoneID.hashCode()));
        result = ((result* 31)+((this.speedDialType == null)? 0 :this.speedDialType.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.speedDialSysKey == null)? 0 :this.speedDialSysKey.hashCode()));
        result = ((result* 31)+((this.orgCode == null)? 0 :this.orgCode.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.speedDialNumber == null)? 0 :this.speedDialNumber.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SpeedDial) == false) {
            return false;
        }
        SpeedDial rhs = ((SpeedDial) other);
        return (((((((((((((this.speedDialKey == rhs.speedDialKey)||((this.speedDialKey!= null)&&this.speedDialKey.equals(rhs.speedDialKey)))&&((this.description == rhs.description)||((this.description!= null)&&this.description.equals(rhs.description))))&&((this.ownerPartyID == rhs.ownerPartyID)||((this.ownerPartyID!= null)&&this.ownerPartyID.equals(rhs.ownerPartyID))))&&((this.ownerPhoneID == rhs.ownerPhoneID)||((this.ownerPhoneID!= null)&&this.ownerPhoneID.equals(rhs.ownerPhoneID))))&&((this.speedDialType == rhs.speedDialType)||((this.speedDialType!= null)&&this.speedDialType.equals(rhs.speedDialType))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.speedDialSysKey == rhs.speedDialSysKey)||((this.speedDialSysKey!= null)&&this.speedDialSysKey.equals(rhs.speedDialSysKey))))&&((this.orgCode == rhs.orgCode)||((this.orgCode!= null)&&this.orgCode.equals(rhs.orgCode))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.speedDialNumber == rhs.speedDialNumber)||((this.speedDialNumber!= null)&&this.speedDialNumber.equals(rhs.speedDialNumber))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
