
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AvocationGuidelineKey",
    "AvocationGuidelineSysKey",
    "GuidelineFailInstructionType",
    "GuidelineDescription",
    "MaxNumberOccurrences",
    "HistoryDuration",
    "HistoryDurationQualifier",
    "AvocationInfo",
    "Attachment",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class AvocationGuideline {

    @JsonProperty("AvocationGuidelineKey")
    private AvocationGuidelineKey avocationGuidelineKey;
    @JsonProperty("AvocationGuidelineSysKey")
    private List<Object> avocationGuidelineSysKey = new ArrayList<>();
    @JsonProperty("GuidelineFailInstructionType")
    private GuidelineFailInstructionType guidelineFailInstructionType;
    @JsonProperty("GuidelineDescription")
    private String guidelineDescription;
    @JsonProperty("MaxNumberOccurrences")
    private Integer maxNumberOccurrences;
    @JsonProperty("HistoryDuration")
    private Integer historyDuration;
    @JsonProperty("HistoryDurationQualifier")
    private HistoryDurationQualifier historyDurationQualifier;
    @JsonProperty("AvocationInfo")
    private List<Object> avocationInfo = new ArrayList<>();
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("AvocationGuidelineKey")
    public AvocationGuidelineKey getAvocationGuidelineKey() {
        return avocationGuidelineKey;
    }

    @JsonProperty("AvocationGuidelineKey")
    public void setAvocationGuidelineKey(AvocationGuidelineKey avocationGuidelineKey) {
        this.avocationGuidelineKey = avocationGuidelineKey;
    }

    public AvocationGuideline withAvocationGuidelineKey(AvocationGuidelineKey avocationGuidelineKey) {
        this.avocationGuidelineKey = avocationGuidelineKey;
        return this;
    }

    @JsonProperty("AvocationGuidelineSysKey")
    public List<Object> getAvocationGuidelineSysKey() {
        return avocationGuidelineSysKey;
    }

    @JsonProperty("AvocationGuidelineSysKey")
    public void setAvocationGuidelineSysKey(List<Object> avocationGuidelineSysKey) {
        this.avocationGuidelineSysKey = avocationGuidelineSysKey;
    }

    public AvocationGuideline withAvocationGuidelineSysKey(List<Object> avocationGuidelineSysKey) {
        this.avocationGuidelineSysKey = avocationGuidelineSysKey;
        return this;
    }

    @JsonProperty("GuidelineFailInstructionType")
    public GuidelineFailInstructionType getGuidelineFailInstructionType() {
        return guidelineFailInstructionType;
    }

    @JsonProperty("GuidelineFailInstructionType")
    public void setGuidelineFailInstructionType(GuidelineFailInstructionType guidelineFailInstructionType) {
        this.guidelineFailInstructionType = guidelineFailInstructionType;
    }

    public AvocationGuideline withGuidelineFailInstructionType(GuidelineFailInstructionType guidelineFailInstructionType) {
        this.guidelineFailInstructionType = guidelineFailInstructionType;
        return this;
    }

    @JsonProperty("GuidelineDescription")
    public String getGuidelineDescription() {
        return guidelineDescription;
    }

    @JsonProperty("GuidelineDescription")
    public void setGuidelineDescription(String guidelineDescription) {
        this.guidelineDescription = guidelineDescription;
    }

    public AvocationGuideline withGuidelineDescription(String guidelineDescription) {
        this.guidelineDescription = guidelineDescription;
        return this;
    }

    @JsonProperty("MaxNumberOccurrences")
    public Integer getMaxNumberOccurrences() {
        return maxNumberOccurrences;
    }

    @JsonProperty("MaxNumberOccurrences")
    public void setMaxNumberOccurrences(Integer maxNumberOccurrences) {
        this.maxNumberOccurrences = maxNumberOccurrences;
    }

    public AvocationGuideline withMaxNumberOccurrences(Integer maxNumberOccurrences) {
        this.maxNumberOccurrences = maxNumberOccurrences;
        return this;
    }

    @JsonProperty("HistoryDuration")
    public Integer getHistoryDuration() {
        return historyDuration;
    }

    @JsonProperty("HistoryDuration")
    public void setHistoryDuration(Integer historyDuration) {
        this.historyDuration = historyDuration;
    }

    public AvocationGuideline withHistoryDuration(Integer historyDuration) {
        this.historyDuration = historyDuration;
        return this;
    }

    @JsonProperty("HistoryDurationQualifier")
    public HistoryDurationQualifier getHistoryDurationQualifier() {
        return historyDurationQualifier;
    }

    @JsonProperty("HistoryDurationQualifier")
    public void setHistoryDurationQualifier(HistoryDurationQualifier historyDurationQualifier) {
        this.historyDurationQualifier = historyDurationQualifier;
    }

    public AvocationGuideline withHistoryDurationQualifier(HistoryDurationQualifier historyDurationQualifier) {
        this.historyDurationQualifier = historyDurationQualifier;
        return this;
    }

    @JsonProperty("AvocationInfo")
    public List<Object> getAvocationInfo() {
        return avocationInfo;
    }

    @JsonProperty("AvocationInfo")
    public void setAvocationInfo(List<Object> avocationInfo) {
        this.avocationInfo = avocationInfo;
    }

    public AvocationGuideline withAvocationInfo(List<Object> avocationInfo) {
        this.avocationInfo = avocationInfo;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public AvocationGuideline withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public AvocationGuideline withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public AvocationGuideline withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public AvocationGuideline withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AvocationGuideline withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(AvocationGuideline.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("avocationGuidelineKey");
        sb.append('=');
        sb.append(((this.avocationGuidelineKey == null)?"<null>":this.avocationGuidelineKey));
        sb.append(',');
        sb.append("avocationGuidelineSysKey");
        sb.append('=');
        sb.append(((this.avocationGuidelineSysKey == null)?"<null>":this.avocationGuidelineSysKey));
        sb.append(',');
        sb.append("guidelineFailInstructionType");
        sb.append('=');
        sb.append(((this.guidelineFailInstructionType == null)?"<null>":this.guidelineFailInstructionType));
        sb.append(',');
        sb.append("guidelineDescription");
        sb.append('=');
        sb.append(((this.guidelineDescription == null)?"<null>":this.guidelineDescription));
        sb.append(',');
        sb.append("maxNumberOccurrences");
        sb.append('=');
        sb.append(((this.maxNumberOccurrences == null)?"<null>":this.maxNumberOccurrences));
        sb.append(',');
        sb.append("historyDuration");
        sb.append('=');
        sb.append(((this.historyDuration == null)?"<null>":this.historyDuration));
        sb.append(',');
        sb.append("historyDurationQualifier");
        sb.append('=');
        sb.append(((this.historyDurationQualifier == null)?"<null>":this.historyDurationQualifier));
        sb.append(',');
        sb.append("avocationInfo");
        sb.append('=');
        sb.append(((this.avocationInfo == null)?"<null>":this.avocationInfo));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.historyDuration == null)? 0 :this.historyDuration.hashCode()));
        result = ((result* 31)+((this.maxNumberOccurrences == null)? 0 :this.maxNumberOccurrences.hashCode()));
        result = ((result* 31)+((this.historyDurationQualifier == null)? 0 :this.historyDurationQualifier.hashCode()));
        result = ((result* 31)+((this.avocationInfo == null)? 0 :this.avocationInfo.hashCode()));
        result = ((result* 31)+((this.guidelineDescription == null)? 0 :this.guidelineDescription.hashCode()));
        result = ((result* 31)+((this.avocationGuidelineKey == null)? 0 :this.avocationGuidelineKey.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        result = ((result* 31)+((this.avocationGuidelineSysKey == null)? 0 :this.avocationGuidelineSysKey.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.guidelineFailInstructionType == null)? 0 :this.guidelineFailInstructionType.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AvocationGuideline) == false) {
            return false;
        }
        AvocationGuideline rhs = ((AvocationGuideline) other);
        return ((((((((((((((this.historyDuration == rhs.historyDuration)||((this.historyDuration!= null)&&this.historyDuration.equals(rhs.historyDuration)))&&((this.maxNumberOccurrences == rhs.maxNumberOccurrences)||((this.maxNumberOccurrences!= null)&&this.maxNumberOccurrences.equals(rhs.maxNumberOccurrences))))&&((this.historyDurationQualifier == rhs.historyDurationQualifier)||((this.historyDurationQualifier!= null)&&this.historyDurationQualifier.equals(rhs.historyDurationQualifier))))&&((this.avocationInfo == rhs.avocationInfo)||((this.avocationInfo!= null)&&this.avocationInfo.equals(rhs.avocationInfo))))&&((this.guidelineDescription == rhs.guidelineDescription)||((this.guidelineDescription!= null)&&this.guidelineDescription.equals(rhs.guidelineDescription))))&&((this.avocationGuidelineKey == rhs.avocationGuidelineKey)||((this.avocationGuidelineKey!= null)&&this.avocationGuidelineKey.equals(rhs.avocationGuidelineKey))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))))&&((this.avocationGuidelineSysKey == rhs.avocationGuidelineSysKey)||((this.avocationGuidelineSysKey!= null)&&this.avocationGuidelineSysKey.equals(rhs.avocationGuidelineSysKey))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.guidelineFailInstructionType == rhs.guidelineFailInstructionType)||((this.guidelineFailInstructionType!= null)&&this.guidelineFailInstructionType.equals(rhs.guidelineFailInstructionType))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
