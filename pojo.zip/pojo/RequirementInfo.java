
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ReqCode",
    "RequirementInfoKey",
    "RequirementInfoSysKey",
    "HORequirementRefID",
    "RequirementInfoUniqueID",
    "Sequence",
    "FormNo",
    "FormVersion",
    "RequirementDetails",
    "RestrictIssueCode",
    "ReqStatus",
    "RequestedDate",
    "RequestedTime",
    "ReRequestedDate",
    "FulfilledDate",
    "FulfilledTime",
    "ReceivedDate",
    "ScheduledDate",
    "ReceivedAtLocationDate",
    "RequestedScheduleDate",
    "RequestedScheduleTimeStart",
    "RequestedScheduleTimeEnd",
    "UserCode",
    "FormRecievedWithAppInd",
    "ReferredDate",
    "StatusDate",
    "StatusTime",
    "HistoryStartDate",
    "HistoryEndDate",
    "RequirementStatusReason",
    "ResponsiblePartyType",
    "ReceivedPartyOrgCode",
    "ReferredPartyOrgCode",
    "ReleasePartyOrgCode",
    "MIBInquiryReason",
    "AppliesToPartyType",
    "RequirementAcctNum",
    "ProviderOrderNum",
    "CarrierOrderNum",
    "ReqCategory",
    "ProviderServiceCode",
    "ReqSubStatus",
    "DueDate",
    "DueTime",
    "OrderReceivedDate",
    "HistoryDuration",
    "HistoryDurationQualifier",
    "IntendedUseOfInformationType",
    "SubmissionType",
    "ReqSubmissionType",
    "Priority",
    "FollowUpCount",
    "LanguageInterpreterNeeded",
    "InterpretedLanguage",
    "StatusReceiverParty",
    "ResultsReceiverParty",
    "StatusEvent",
    "Attachment",
    "PreferredReqFulfiller",
    "TrackingInfo",
    "EvaluationFaceAmt",
    "KeyedValue",
    "OLifEExtension",
    "id",
    "AppliesToPartyID",
    "RequesterPartyID",
    "FulfillerPartyID",
    "ReceivedPartyID",
    "ReferredPartyID",
    "RequestedAddressId",
    "DataRep",
    "RequestorContactPartyID",
    "AppliesToParticipantID",
    "PhysicianPartyID",
    "FacilityPartyID"
})
@Generated("jsonschema2pojo")
public class RequirementInfo {

    @JsonProperty("ReqCode")
    private ReqCode reqCode;
    @JsonProperty("RequirementInfoKey")
    private RequirementInfoKey requirementInfoKey;
    @JsonProperty("RequirementInfoSysKey")
    private List<Object> requirementInfoSysKey = new ArrayList<>();
    @JsonProperty("HORequirementRefID")
    private String hORequirementRefID;
    @JsonProperty("RequirementInfoUniqueID")
    private String requirementInfoUniqueID;
    @JsonProperty("Sequence")
    private Integer sequence;
    @JsonProperty("FormNo")
    private String formNo;
    @JsonProperty("FormVersion")
    private String formVersion;
    @JsonProperty("RequirementDetails")
    private String requirementDetails;
    @JsonProperty("RestrictIssueCode")
    private RestrictIssueCode restrictIssueCode;
    @JsonProperty("ReqStatus")
    private ReqStatus reqStatus;
    @JsonProperty("RequestedDate")
    private String requestedDate;
    @JsonProperty("RequestedTime")
    private String requestedTime;
    @JsonProperty("ReRequestedDate")
    private String reRequestedDate;
    @JsonProperty("FulfilledDate")
    private String fulfilledDate;
    @JsonProperty("FulfilledTime")
    private String fulfilledTime;
    @JsonProperty("ReceivedDate")
    private String receivedDate;
    @JsonProperty("ScheduledDate")
    private String scheduledDate;
    @JsonProperty("ReceivedAtLocationDate")
    private String receivedAtLocationDate;
    @JsonProperty("RequestedScheduleDate")
    private String requestedScheduleDate;
    @JsonProperty("RequestedScheduleTimeStart")
    private String requestedScheduleTimeStart;
    @JsonProperty("RequestedScheduleTimeEnd")
    private String requestedScheduleTimeEnd;
    @JsonProperty("UserCode")
    private String userCode;
    @JsonProperty("FormRecievedWithAppInd")
    private FormRecievedWithAppInd formRecievedWithAppInd;
    @JsonProperty("ReferredDate")
    private String referredDate;
    @JsonProperty("StatusDate")
    private String statusDate;
    @JsonProperty("StatusTime")
    private String statusTime;
    @JsonProperty("HistoryStartDate")
    private String historyStartDate;
    @JsonProperty("HistoryEndDate")
    private String historyEndDate;
    @JsonProperty("RequirementStatusReason")
    private String requirementStatusReason;
    @JsonProperty("ResponsiblePartyType")
    private ResponsiblePartyType responsiblePartyType;
    @JsonProperty("ReceivedPartyOrgCode")
    private String receivedPartyOrgCode;
    @JsonProperty("ReferredPartyOrgCode")
    private String referredPartyOrgCode;
    @JsonProperty("ReleasePartyOrgCode")
    private String releasePartyOrgCode;
    @JsonProperty("MIBInquiryReason")
    private MIBInquiryReason mIBInquiryReason;
    @JsonProperty("AppliesToPartyType")
    private AppliesToPartyType appliesToPartyType;
    @JsonProperty("RequirementAcctNum")
    private String requirementAcctNum;
    @JsonProperty("ProviderOrderNum")
    private String providerOrderNum;
    @JsonProperty("CarrierOrderNum")
    private String carrierOrderNum;
    @JsonProperty("ReqCategory")
    private ReqCategory reqCategory;
    @JsonProperty("ProviderServiceCode")
    private String providerServiceCode;
    @JsonProperty("ReqSubStatus")
    private ReqSubStatus reqSubStatus;
    @JsonProperty("DueDate")
    private String dueDate;
    @JsonProperty("DueTime")
    private String dueTime;
    @JsonProperty("OrderReceivedDate")
    private String orderReceivedDate;
    @JsonProperty("HistoryDuration")
    private Integer historyDuration;
    @JsonProperty("HistoryDurationQualifier")
    private HistoryDurationQualifier historyDurationQualifier;
    @JsonProperty("IntendedUseOfInformationType")
    private IntendedUseOfInformationType intendedUseOfInformationType;
    @JsonProperty("SubmissionType")
    private SubmissionType submissionType;
    @JsonProperty("ReqSubmissionType")
    private ReqSubmissionType reqSubmissionType;
    @JsonProperty("Priority")
    private Priority priority;
    @JsonProperty("FollowUpCount")
    private Integer followUpCount;
    @JsonProperty("LanguageInterpreterNeeded")
    private LanguageInterpreterNeeded languageInterpreterNeeded;
    @JsonProperty("InterpretedLanguage")
    private InterpretedLanguage interpretedLanguage;
    @JsonProperty("StatusReceiverParty")
    private List<Object> statusReceiverParty = new ArrayList<>();
    @JsonProperty("ResultsReceiverParty")
    private List<Object> resultsReceiverParty = new ArrayList<>();
    @JsonProperty("StatusEvent")
    private List<Object> statusEvent = new ArrayList<>();
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("PreferredReqFulfiller")
    private List<Object> preferredReqFulfiller = new ArrayList<>();
    @JsonProperty("TrackingInfo")
    private List<Object> trackingInfo = new ArrayList<>();
    @JsonProperty("EvaluationFaceAmt")
    private Integer evaluationFaceAmt;
    @JsonProperty("KeyedValue")
    private List<Object> keyedValue = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("AppliesToPartyID")
    private String appliesToPartyID;
    @JsonProperty("RequesterPartyID")
    private String requesterPartyID;
    @JsonProperty("FulfillerPartyID")
    private String fulfillerPartyID;
    @JsonProperty("ReceivedPartyID")
    private String receivedPartyID;
    @JsonProperty("ReferredPartyID")
    private String referredPartyID;
    @JsonProperty("RequestedAddressId")
    private String requestedAddressId;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonProperty("RequestorContactPartyID")
    private String requestorContactPartyID;
    @JsonProperty("AppliesToParticipantID")
    private String appliesToParticipantID;
    @JsonProperty("PhysicianPartyID")
    private String physicianPartyID;
    @JsonProperty("FacilityPartyID")
    private String facilityPartyID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ReqCode")
    public ReqCode getReqCode() {
        return reqCode;
    }

    @JsonProperty("ReqCode")
    public void setReqCode(ReqCode reqCode) {
        this.reqCode = reqCode;
    }

    public RequirementInfo withReqCode(ReqCode reqCode) {
        this.reqCode = reqCode;
        return this;
    }

    @JsonProperty("RequirementInfoKey")
    public RequirementInfoKey getRequirementInfoKey() {
        return requirementInfoKey;
    }

    @JsonProperty("RequirementInfoKey")
    public void setRequirementInfoKey(RequirementInfoKey requirementInfoKey) {
        this.requirementInfoKey = requirementInfoKey;
    }

    public RequirementInfo withRequirementInfoKey(RequirementInfoKey requirementInfoKey) {
        this.requirementInfoKey = requirementInfoKey;
        return this;
    }

    @JsonProperty("RequirementInfoSysKey")
    public List<Object> getRequirementInfoSysKey() {
        return requirementInfoSysKey;
    }

    @JsonProperty("RequirementInfoSysKey")
    public void setRequirementInfoSysKey(List<Object> requirementInfoSysKey) {
        this.requirementInfoSysKey = requirementInfoSysKey;
    }

    public RequirementInfo withRequirementInfoSysKey(List<Object> requirementInfoSysKey) {
        this.requirementInfoSysKey = requirementInfoSysKey;
        return this;
    }

    @JsonProperty("HORequirementRefID")
    public String getHORequirementRefID() {
        return hORequirementRefID;
    }

    @JsonProperty("HORequirementRefID")
    public void setHORequirementRefID(String hORequirementRefID) {
        this.hORequirementRefID = hORequirementRefID;
    }

    public RequirementInfo withHORequirementRefID(String hORequirementRefID) {
        this.hORequirementRefID = hORequirementRefID;
        return this;
    }

    @JsonProperty("RequirementInfoUniqueID")
    public String getRequirementInfoUniqueID() {
        return requirementInfoUniqueID;
    }

    @JsonProperty("RequirementInfoUniqueID")
    public void setRequirementInfoUniqueID(String requirementInfoUniqueID) {
        this.requirementInfoUniqueID = requirementInfoUniqueID;
    }

    public RequirementInfo withRequirementInfoUniqueID(String requirementInfoUniqueID) {
        this.requirementInfoUniqueID = requirementInfoUniqueID;
        return this;
    }

    @JsonProperty("Sequence")
    public Integer getSequence() {
        return sequence;
    }

    @JsonProperty("Sequence")
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public RequirementInfo withSequence(Integer sequence) {
        this.sequence = sequence;
        return this;
    }

    @JsonProperty("FormNo")
    public String getFormNo() {
        return formNo;
    }

    @JsonProperty("FormNo")
    public void setFormNo(String formNo) {
        this.formNo = formNo;
    }

    public RequirementInfo withFormNo(String formNo) {
        this.formNo = formNo;
        return this;
    }

    @JsonProperty("FormVersion")
    public String getFormVersion() {
        return formVersion;
    }

    @JsonProperty("FormVersion")
    public void setFormVersion(String formVersion) {
        this.formVersion = formVersion;
    }

    public RequirementInfo withFormVersion(String formVersion) {
        this.formVersion = formVersion;
        return this;
    }

    @JsonProperty("RequirementDetails")
    public String getRequirementDetails() {
        return requirementDetails;
    }

    @JsonProperty("RequirementDetails")
    public void setRequirementDetails(String requirementDetails) {
        this.requirementDetails = requirementDetails;
    }

    public RequirementInfo withRequirementDetails(String requirementDetails) {
        this.requirementDetails = requirementDetails;
        return this;
    }

    @JsonProperty("RestrictIssueCode")
    public RestrictIssueCode getRestrictIssueCode() {
        return restrictIssueCode;
    }

    @JsonProperty("RestrictIssueCode")
    public void setRestrictIssueCode(RestrictIssueCode restrictIssueCode) {
        this.restrictIssueCode = restrictIssueCode;
    }

    public RequirementInfo withRestrictIssueCode(RestrictIssueCode restrictIssueCode) {
        this.restrictIssueCode = restrictIssueCode;
        return this;
    }

    @JsonProperty("ReqStatus")
    public ReqStatus getReqStatus() {
        return reqStatus;
    }

    @JsonProperty("ReqStatus")
    public void setReqStatus(ReqStatus reqStatus) {
        this.reqStatus = reqStatus;
    }

    public RequirementInfo withReqStatus(ReqStatus reqStatus) {
        this.reqStatus = reqStatus;
        return this;
    }

    @JsonProperty("RequestedDate")
    public String getRequestedDate() {
        return requestedDate;
    }

    @JsonProperty("RequestedDate")
    public void setRequestedDate(String requestedDate) {
        this.requestedDate = requestedDate;
    }

    public RequirementInfo withRequestedDate(String requestedDate) {
        this.requestedDate = requestedDate;
        return this;
    }

    @JsonProperty("RequestedTime")
    public String getRequestedTime() {
        return requestedTime;
    }

    @JsonProperty("RequestedTime")
    public void setRequestedTime(String requestedTime) {
        this.requestedTime = requestedTime;
    }

    public RequirementInfo withRequestedTime(String requestedTime) {
        this.requestedTime = requestedTime;
        return this;
    }

    @JsonProperty("ReRequestedDate")
    public String getReRequestedDate() {
        return reRequestedDate;
    }

    @JsonProperty("ReRequestedDate")
    public void setReRequestedDate(String reRequestedDate) {
        this.reRequestedDate = reRequestedDate;
    }

    public RequirementInfo withReRequestedDate(String reRequestedDate) {
        this.reRequestedDate = reRequestedDate;
        return this;
    }

    @JsonProperty("FulfilledDate")
    public String getFulfilledDate() {
        return fulfilledDate;
    }

    @JsonProperty("FulfilledDate")
    public void setFulfilledDate(String fulfilledDate) {
        this.fulfilledDate = fulfilledDate;
    }

    public RequirementInfo withFulfilledDate(String fulfilledDate) {
        this.fulfilledDate = fulfilledDate;
        return this;
    }

    @JsonProperty("FulfilledTime")
    public String getFulfilledTime() {
        return fulfilledTime;
    }

    @JsonProperty("FulfilledTime")
    public void setFulfilledTime(String fulfilledTime) {
        this.fulfilledTime = fulfilledTime;
    }

    public RequirementInfo withFulfilledTime(String fulfilledTime) {
        this.fulfilledTime = fulfilledTime;
        return this;
    }

    @JsonProperty("ReceivedDate")
    public String getReceivedDate() {
        return receivedDate;
    }

    @JsonProperty("ReceivedDate")
    public void setReceivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
    }

    public RequirementInfo withReceivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
        return this;
    }

    @JsonProperty("ScheduledDate")
    public String getScheduledDate() {
        return scheduledDate;
    }

    @JsonProperty("ScheduledDate")
    public void setScheduledDate(String scheduledDate) {
        this.scheduledDate = scheduledDate;
    }

    public RequirementInfo withScheduledDate(String scheduledDate) {
        this.scheduledDate = scheduledDate;
        return this;
    }

    @JsonProperty("ReceivedAtLocationDate")
    public String getReceivedAtLocationDate() {
        return receivedAtLocationDate;
    }

    @JsonProperty("ReceivedAtLocationDate")
    public void setReceivedAtLocationDate(String receivedAtLocationDate) {
        this.receivedAtLocationDate = receivedAtLocationDate;
    }

    public RequirementInfo withReceivedAtLocationDate(String receivedAtLocationDate) {
        this.receivedAtLocationDate = receivedAtLocationDate;
        return this;
    }

    @JsonProperty("RequestedScheduleDate")
    public String getRequestedScheduleDate() {
        return requestedScheduleDate;
    }

    @JsonProperty("RequestedScheduleDate")
    public void setRequestedScheduleDate(String requestedScheduleDate) {
        this.requestedScheduleDate = requestedScheduleDate;
    }

    public RequirementInfo withRequestedScheduleDate(String requestedScheduleDate) {
        this.requestedScheduleDate = requestedScheduleDate;
        return this;
    }

    @JsonProperty("RequestedScheduleTimeStart")
    public String getRequestedScheduleTimeStart() {
        return requestedScheduleTimeStart;
    }

    @JsonProperty("RequestedScheduleTimeStart")
    public void setRequestedScheduleTimeStart(String requestedScheduleTimeStart) {
        this.requestedScheduleTimeStart = requestedScheduleTimeStart;
    }

    public RequirementInfo withRequestedScheduleTimeStart(String requestedScheduleTimeStart) {
        this.requestedScheduleTimeStart = requestedScheduleTimeStart;
        return this;
    }

    @JsonProperty("RequestedScheduleTimeEnd")
    public String getRequestedScheduleTimeEnd() {
        return requestedScheduleTimeEnd;
    }

    @JsonProperty("RequestedScheduleTimeEnd")
    public void setRequestedScheduleTimeEnd(String requestedScheduleTimeEnd) {
        this.requestedScheduleTimeEnd = requestedScheduleTimeEnd;
    }

    public RequirementInfo withRequestedScheduleTimeEnd(String requestedScheduleTimeEnd) {
        this.requestedScheduleTimeEnd = requestedScheduleTimeEnd;
        return this;
    }

    @JsonProperty("UserCode")
    public String getUserCode() {
        return userCode;
    }

    @JsonProperty("UserCode")
    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public RequirementInfo withUserCode(String userCode) {
        this.userCode = userCode;
        return this;
    }

    @JsonProperty("FormRecievedWithAppInd")
    public FormRecievedWithAppInd getFormRecievedWithAppInd() {
        return formRecievedWithAppInd;
    }

    @JsonProperty("FormRecievedWithAppInd")
    public void setFormRecievedWithAppInd(FormRecievedWithAppInd formRecievedWithAppInd) {
        this.formRecievedWithAppInd = formRecievedWithAppInd;
    }

    public RequirementInfo withFormRecievedWithAppInd(FormRecievedWithAppInd formRecievedWithAppInd) {
        this.formRecievedWithAppInd = formRecievedWithAppInd;
        return this;
    }

    @JsonProperty("ReferredDate")
    public String getReferredDate() {
        return referredDate;
    }

    @JsonProperty("ReferredDate")
    public void setReferredDate(String referredDate) {
        this.referredDate = referredDate;
    }

    public RequirementInfo withReferredDate(String referredDate) {
        this.referredDate = referredDate;
        return this;
    }

    @JsonProperty("StatusDate")
    public String getStatusDate() {
        return statusDate;
    }

    @JsonProperty("StatusDate")
    public void setStatusDate(String statusDate) {
        this.statusDate = statusDate;
    }

    public RequirementInfo withStatusDate(String statusDate) {
        this.statusDate = statusDate;
        return this;
    }

    @JsonProperty("StatusTime")
    public String getStatusTime() {
        return statusTime;
    }

    @JsonProperty("StatusTime")
    public void setStatusTime(String statusTime) {
        this.statusTime = statusTime;
    }

    public RequirementInfo withStatusTime(String statusTime) {
        this.statusTime = statusTime;
        return this;
    }

    @JsonProperty("HistoryStartDate")
    public String getHistoryStartDate() {
        return historyStartDate;
    }

    @JsonProperty("HistoryStartDate")
    public void setHistoryStartDate(String historyStartDate) {
        this.historyStartDate = historyStartDate;
    }

    public RequirementInfo withHistoryStartDate(String historyStartDate) {
        this.historyStartDate = historyStartDate;
        return this;
    }

    @JsonProperty("HistoryEndDate")
    public String getHistoryEndDate() {
        return historyEndDate;
    }

    @JsonProperty("HistoryEndDate")
    public void setHistoryEndDate(String historyEndDate) {
        this.historyEndDate = historyEndDate;
    }

    public RequirementInfo withHistoryEndDate(String historyEndDate) {
        this.historyEndDate = historyEndDate;
        return this;
    }

    @JsonProperty("RequirementStatusReason")
    public String getRequirementStatusReason() {
        return requirementStatusReason;
    }

    @JsonProperty("RequirementStatusReason")
    public void setRequirementStatusReason(String requirementStatusReason) {
        this.requirementStatusReason = requirementStatusReason;
    }

    public RequirementInfo withRequirementStatusReason(String requirementStatusReason) {
        this.requirementStatusReason = requirementStatusReason;
        return this;
    }

    @JsonProperty("ResponsiblePartyType")
    public ResponsiblePartyType getResponsiblePartyType() {
        return responsiblePartyType;
    }

    @JsonProperty("ResponsiblePartyType")
    public void setResponsiblePartyType(ResponsiblePartyType responsiblePartyType) {
        this.responsiblePartyType = responsiblePartyType;
    }

    public RequirementInfo withResponsiblePartyType(ResponsiblePartyType responsiblePartyType) {
        this.responsiblePartyType = responsiblePartyType;
        return this;
    }

    @JsonProperty("ReceivedPartyOrgCode")
    public String getReceivedPartyOrgCode() {
        return receivedPartyOrgCode;
    }

    @JsonProperty("ReceivedPartyOrgCode")
    public void setReceivedPartyOrgCode(String receivedPartyOrgCode) {
        this.receivedPartyOrgCode = receivedPartyOrgCode;
    }

    public RequirementInfo withReceivedPartyOrgCode(String receivedPartyOrgCode) {
        this.receivedPartyOrgCode = receivedPartyOrgCode;
        return this;
    }

    @JsonProperty("ReferredPartyOrgCode")
    public String getReferredPartyOrgCode() {
        return referredPartyOrgCode;
    }

    @JsonProperty("ReferredPartyOrgCode")
    public void setReferredPartyOrgCode(String referredPartyOrgCode) {
        this.referredPartyOrgCode = referredPartyOrgCode;
    }

    public RequirementInfo withReferredPartyOrgCode(String referredPartyOrgCode) {
        this.referredPartyOrgCode = referredPartyOrgCode;
        return this;
    }

    @JsonProperty("ReleasePartyOrgCode")
    public String getReleasePartyOrgCode() {
        return releasePartyOrgCode;
    }

    @JsonProperty("ReleasePartyOrgCode")
    public void setReleasePartyOrgCode(String releasePartyOrgCode) {
        this.releasePartyOrgCode = releasePartyOrgCode;
    }

    public RequirementInfo withReleasePartyOrgCode(String releasePartyOrgCode) {
        this.releasePartyOrgCode = releasePartyOrgCode;
        return this;
    }

    @JsonProperty("MIBInquiryReason")
    public MIBInquiryReason getMIBInquiryReason() {
        return mIBInquiryReason;
    }

    @JsonProperty("MIBInquiryReason")
    public void setMIBInquiryReason(MIBInquiryReason mIBInquiryReason) {
        this.mIBInquiryReason = mIBInquiryReason;
    }

    public RequirementInfo withMIBInquiryReason(MIBInquiryReason mIBInquiryReason) {
        this.mIBInquiryReason = mIBInquiryReason;
        return this;
    }

    @JsonProperty("AppliesToPartyType")
    public AppliesToPartyType getAppliesToPartyType() {
        return appliesToPartyType;
    }

    @JsonProperty("AppliesToPartyType")
    public void setAppliesToPartyType(AppliesToPartyType appliesToPartyType) {
        this.appliesToPartyType = appliesToPartyType;
    }

    public RequirementInfo withAppliesToPartyType(AppliesToPartyType appliesToPartyType) {
        this.appliesToPartyType = appliesToPartyType;
        return this;
    }

    @JsonProperty("RequirementAcctNum")
    public String getRequirementAcctNum() {
        return requirementAcctNum;
    }

    @JsonProperty("RequirementAcctNum")
    public void setRequirementAcctNum(String requirementAcctNum) {
        this.requirementAcctNum = requirementAcctNum;
    }

    public RequirementInfo withRequirementAcctNum(String requirementAcctNum) {
        this.requirementAcctNum = requirementAcctNum;
        return this;
    }

    @JsonProperty("ProviderOrderNum")
    public String getProviderOrderNum() {
        return providerOrderNum;
    }

    @JsonProperty("ProviderOrderNum")
    public void setProviderOrderNum(String providerOrderNum) {
        this.providerOrderNum = providerOrderNum;
    }

    public RequirementInfo withProviderOrderNum(String providerOrderNum) {
        this.providerOrderNum = providerOrderNum;
        return this;
    }

    @JsonProperty("CarrierOrderNum")
    public String getCarrierOrderNum() {
        return carrierOrderNum;
    }

    @JsonProperty("CarrierOrderNum")
    public void setCarrierOrderNum(String carrierOrderNum) {
        this.carrierOrderNum = carrierOrderNum;
    }

    public RequirementInfo withCarrierOrderNum(String carrierOrderNum) {
        this.carrierOrderNum = carrierOrderNum;
        return this;
    }

    @JsonProperty("ReqCategory")
    public ReqCategory getReqCategory() {
        return reqCategory;
    }

    @JsonProperty("ReqCategory")
    public void setReqCategory(ReqCategory reqCategory) {
        this.reqCategory = reqCategory;
    }

    public RequirementInfo withReqCategory(ReqCategory reqCategory) {
        this.reqCategory = reqCategory;
        return this;
    }

    @JsonProperty("ProviderServiceCode")
    public String getProviderServiceCode() {
        return providerServiceCode;
    }

    @JsonProperty("ProviderServiceCode")
    public void setProviderServiceCode(String providerServiceCode) {
        this.providerServiceCode = providerServiceCode;
    }

    public RequirementInfo withProviderServiceCode(String providerServiceCode) {
        this.providerServiceCode = providerServiceCode;
        return this;
    }

    @JsonProperty("ReqSubStatus")
    public ReqSubStatus getReqSubStatus() {
        return reqSubStatus;
    }

    @JsonProperty("ReqSubStatus")
    public void setReqSubStatus(ReqSubStatus reqSubStatus) {
        this.reqSubStatus = reqSubStatus;
    }

    public RequirementInfo withReqSubStatus(ReqSubStatus reqSubStatus) {
        this.reqSubStatus = reqSubStatus;
        return this;
    }

    @JsonProperty("DueDate")
    public String getDueDate() {
        return dueDate;
    }

    @JsonProperty("DueDate")
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public RequirementInfo withDueDate(String dueDate) {
        this.dueDate = dueDate;
        return this;
    }

    @JsonProperty("DueTime")
    public String getDueTime() {
        return dueTime;
    }

    @JsonProperty("DueTime")
    public void setDueTime(String dueTime) {
        this.dueTime = dueTime;
    }

    public RequirementInfo withDueTime(String dueTime) {
        this.dueTime = dueTime;
        return this;
    }

    @JsonProperty("OrderReceivedDate")
    public String getOrderReceivedDate() {
        return orderReceivedDate;
    }

    @JsonProperty("OrderReceivedDate")
    public void setOrderReceivedDate(String orderReceivedDate) {
        this.orderReceivedDate = orderReceivedDate;
    }

    public RequirementInfo withOrderReceivedDate(String orderReceivedDate) {
        this.orderReceivedDate = orderReceivedDate;
        return this;
    }

    @JsonProperty("HistoryDuration")
    public Integer getHistoryDuration() {
        return historyDuration;
    }

    @JsonProperty("HistoryDuration")
    public void setHistoryDuration(Integer historyDuration) {
        this.historyDuration = historyDuration;
    }

    public RequirementInfo withHistoryDuration(Integer historyDuration) {
        this.historyDuration = historyDuration;
        return this;
    }

    @JsonProperty("HistoryDurationQualifier")
    public HistoryDurationQualifier getHistoryDurationQualifier() {
        return historyDurationQualifier;
    }

    @JsonProperty("HistoryDurationQualifier")
    public void setHistoryDurationQualifier(HistoryDurationQualifier historyDurationQualifier) {
        this.historyDurationQualifier = historyDurationQualifier;
    }

    public RequirementInfo withHistoryDurationQualifier(HistoryDurationQualifier historyDurationQualifier) {
        this.historyDurationQualifier = historyDurationQualifier;
        return this;
    }

    @JsonProperty("IntendedUseOfInformationType")
    public IntendedUseOfInformationType getIntendedUseOfInformationType() {
        return intendedUseOfInformationType;
    }

    @JsonProperty("IntendedUseOfInformationType")
    public void setIntendedUseOfInformationType(IntendedUseOfInformationType intendedUseOfInformationType) {
        this.intendedUseOfInformationType = intendedUseOfInformationType;
    }

    public RequirementInfo withIntendedUseOfInformationType(IntendedUseOfInformationType intendedUseOfInformationType) {
        this.intendedUseOfInformationType = intendedUseOfInformationType;
        return this;
    }

    @JsonProperty("SubmissionType")
    public SubmissionType getSubmissionType() {
        return submissionType;
    }

    @JsonProperty("SubmissionType")
    public void setSubmissionType(SubmissionType submissionType) {
        this.submissionType = submissionType;
    }

    public RequirementInfo withSubmissionType(SubmissionType submissionType) {
        this.submissionType = submissionType;
        return this;
    }

    @JsonProperty("ReqSubmissionType")
    public ReqSubmissionType getReqSubmissionType() {
        return reqSubmissionType;
    }

    @JsonProperty("ReqSubmissionType")
    public void setReqSubmissionType(ReqSubmissionType reqSubmissionType) {
        this.reqSubmissionType = reqSubmissionType;
    }

    public RequirementInfo withReqSubmissionType(ReqSubmissionType reqSubmissionType) {
        this.reqSubmissionType = reqSubmissionType;
        return this;
    }

    @JsonProperty("Priority")
    public Priority getPriority() {
        return priority;
    }

    @JsonProperty("Priority")
    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public RequirementInfo withPriority(Priority priority) {
        this.priority = priority;
        return this;
    }

    @JsonProperty("FollowUpCount")
    public Integer getFollowUpCount() {
        return followUpCount;
    }

    @JsonProperty("FollowUpCount")
    public void setFollowUpCount(Integer followUpCount) {
        this.followUpCount = followUpCount;
    }

    public RequirementInfo withFollowUpCount(Integer followUpCount) {
        this.followUpCount = followUpCount;
        return this;
    }

    @JsonProperty("LanguageInterpreterNeeded")
    public LanguageInterpreterNeeded getLanguageInterpreterNeeded() {
        return languageInterpreterNeeded;
    }

    @JsonProperty("LanguageInterpreterNeeded")
    public void setLanguageInterpreterNeeded(LanguageInterpreterNeeded languageInterpreterNeeded) {
        this.languageInterpreterNeeded = languageInterpreterNeeded;
    }

    public RequirementInfo withLanguageInterpreterNeeded(LanguageInterpreterNeeded languageInterpreterNeeded) {
        this.languageInterpreterNeeded = languageInterpreterNeeded;
        return this;
    }

    @JsonProperty("InterpretedLanguage")
    public InterpretedLanguage getInterpretedLanguage() {
        return interpretedLanguage;
    }

    @JsonProperty("InterpretedLanguage")
    public void setInterpretedLanguage(InterpretedLanguage interpretedLanguage) {
        this.interpretedLanguage = interpretedLanguage;
    }

    public RequirementInfo withInterpretedLanguage(InterpretedLanguage interpretedLanguage) {
        this.interpretedLanguage = interpretedLanguage;
        return this;
    }

    @JsonProperty("StatusReceiverParty")
    public List<Object> getStatusReceiverParty() {
        return statusReceiverParty;
    }

    @JsonProperty("StatusReceiverParty")
    public void setStatusReceiverParty(List<Object> statusReceiverParty) {
        this.statusReceiverParty = statusReceiverParty;
    }

    public RequirementInfo withStatusReceiverParty(List<Object> statusReceiverParty) {
        this.statusReceiverParty = statusReceiverParty;
        return this;
    }

    @JsonProperty("ResultsReceiverParty")
    public List<Object> getResultsReceiverParty() {
        return resultsReceiverParty;
    }

    @JsonProperty("ResultsReceiverParty")
    public void setResultsReceiverParty(List<Object> resultsReceiverParty) {
        this.resultsReceiverParty = resultsReceiverParty;
    }

    public RequirementInfo withResultsReceiverParty(List<Object> resultsReceiverParty) {
        this.resultsReceiverParty = resultsReceiverParty;
        return this;
    }

    @JsonProperty("StatusEvent")
    public List<Object> getStatusEvent() {
        return statusEvent;
    }

    @JsonProperty("StatusEvent")
    public void setStatusEvent(List<Object> statusEvent) {
        this.statusEvent = statusEvent;
    }

    public RequirementInfo withStatusEvent(List<Object> statusEvent) {
        this.statusEvent = statusEvent;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public RequirementInfo withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("PreferredReqFulfiller")
    public List<Object> getPreferredReqFulfiller() {
        return preferredReqFulfiller;
    }

    @JsonProperty("PreferredReqFulfiller")
    public void setPreferredReqFulfiller(List<Object> preferredReqFulfiller) {
        this.preferredReqFulfiller = preferredReqFulfiller;
    }

    public RequirementInfo withPreferredReqFulfiller(List<Object> preferredReqFulfiller) {
        this.preferredReqFulfiller = preferredReqFulfiller;
        return this;
    }

    @JsonProperty("TrackingInfo")
    public List<Object> getTrackingInfo() {
        return trackingInfo;
    }

    @JsonProperty("TrackingInfo")
    public void setTrackingInfo(List<Object> trackingInfo) {
        this.trackingInfo = trackingInfo;
    }

    public RequirementInfo withTrackingInfo(List<Object> trackingInfo) {
        this.trackingInfo = trackingInfo;
        return this;
    }

    @JsonProperty("EvaluationFaceAmt")
    public Integer getEvaluationFaceAmt() {
        return evaluationFaceAmt;
    }

    @JsonProperty("EvaluationFaceAmt")
    public void setEvaluationFaceAmt(Integer evaluationFaceAmt) {
        this.evaluationFaceAmt = evaluationFaceAmt;
    }

    public RequirementInfo withEvaluationFaceAmt(Integer evaluationFaceAmt) {
        this.evaluationFaceAmt = evaluationFaceAmt;
        return this;
    }

    @JsonProperty("KeyedValue")
    public List<Object> getKeyedValue() {
        return keyedValue;
    }

    @JsonProperty("KeyedValue")
    public void setKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
    }

    public RequirementInfo withKeyedValue(List<Object> keyedValue) {
        this.keyedValue = keyedValue;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public RequirementInfo withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public RequirementInfo withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("AppliesToPartyID")
    public String getAppliesToPartyID() {
        return appliesToPartyID;
    }

    @JsonProperty("AppliesToPartyID")
    public void setAppliesToPartyID(String appliesToPartyID) {
        this.appliesToPartyID = appliesToPartyID;
    }

    public RequirementInfo withAppliesToPartyID(String appliesToPartyID) {
        this.appliesToPartyID = appliesToPartyID;
        return this;
    }

    @JsonProperty("RequesterPartyID")
    public String getRequesterPartyID() {
        return requesterPartyID;
    }

    @JsonProperty("RequesterPartyID")
    public void setRequesterPartyID(String requesterPartyID) {
        this.requesterPartyID = requesterPartyID;
    }

    public RequirementInfo withRequesterPartyID(String requesterPartyID) {
        this.requesterPartyID = requesterPartyID;
        return this;
    }

    @JsonProperty("FulfillerPartyID")
    public String getFulfillerPartyID() {
        return fulfillerPartyID;
    }

    @JsonProperty("FulfillerPartyID")
    public void setFulfillerPartyID(String fulfillerPartyID) {
        this.fulfillerPartyID = fulfillerPartyID;
    }

    public RequirementInfo withFulfillerPartyID(String fulfillerPartyID) {
        this.fulfillerPartyID = fulfillerPartyID;
        return this;
    }

    @JsonProperty("ReceivedPartyID")
    public String getReceivedPartyID() {
        return receivedPartyID;
    }

    @JsonProperty("ReceivedPartyID")
    public void setReceivedPartyID(String receivedPartyID) {
        this.receivedPartyID = receivedPartyID;
    }

    public RequirementInfo withReceivedPartyID(String receivedPartyID) {
        this.receivedPartyID = receivedPartyID;
        return this;
    }

    @JsonProperty("ReferredPartyID")
    public String getReferredPartyID() {
        return referredPartyID;
    }

    @JsonProperty("ReferredPartyID")
    public void setReferredPartyID(String referredPartyID) {
        this.referredPartyID = referredPartyID;
    }

    public RequirementInfo withReferredPartyID(String referredPartyID) {
        this.referredPartyID = referredPartyID;
        return this;
    }

    @JsonProperty("RequestedAddressId")
    public String getRequestedAddressId() {
        return requestedAddressId;
    }

    @JsonProperty("RequestedAddressId")
    public void setRequestedAddressId(String requestedAddressId) {
        this.requestedAddressId = requestedAddressId;
    }

    public RequirementInfo withRequestedAddressId(String requestedAddressId) {
        this.requestedAddressId = requestedAddressId;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public RequirementInfo withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonProperty("RequestorContactPartyID")
    public String getRequestorContactPartyID() {
        return requestorContactPartyID;
    }

    @JsonProperty("RequestorContactPartyID")
    public void setRequestorContactPartyID(String requestorContactPartyID) {
        this.requestorContactPartyID = requestorContactPartyID;
    }

    public RequirementInfo withRequestorContactPartyID(String requestorContactPartyID) {
        this.requestorContactPartyID = requestorContactPartyID;
        return this;
    }

    @JsonProperty("AppliesToParticipantID")
    public String getAppliesToParticipantID() {
        return appliesToParticipantID;
    }

    @JsonProperty("AppliesToParticipantID")
    public void setAppliesToParticipantID(String appliesToParticipantID) {
        this.appliesToParticipantID = appliesToParticipantID;
    }

    public RequirementInfo withAppliesToParticipantID(String appliesToParticipantID) {
        this.appliesToParticipantID = appliesToParticipantID;
        return this;
    }

    @JsonProperty("PhysicianPartyID")
    public String getPhysicianPartyID() {
        return physicianPartyID;
    }

    @JsonProperty("PhysicianPartyID")
    public void setPhysicianPartyID(String physicianPartyID) {
        this.physicianPartyID = physicianPartyID;
    }

    public RequirementInfo withPhysicianPartyID(String physicianPartyID) {
        this.physicianPartyID = physicianPartyID;
        return this;
    }

    @JsonProperty("FacilityPartyID")
    public String getFacilityPartyID() {
        return facilityPartyID;
    }

    @JsonProperty("FacilityPartyID")
    public void setFacilityPartyID(String facilityPartyID) {
        this.facilityPartyID = facilityPartyID;
    }

    public RequirementInfo withFacilityPartyID(String facilityPartyID) {
        this.facilityPartyID = facilityPartyID;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public RequirementInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(RequirementInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("reqCode");
        sb.append('=');
        sb.append(((this.reqCode == null)?"<null>":this.reqCode));
        sb.append(',');
        sb.append("requirementInfoKey");
        sb.append('=');
        sb.append(((this.requirementInfoKey == null)?"<null>":this.requirementInfoKey));
        sb.append(',');
        sb.append("requirementInfoSysKey");
        sb.append('=');
        sb.append(((this.requirementInfoSysKey == null)?"<null>":this.requirementInfoSysKey));
        sb.append(',');
        sb.append("hORequirementRefID");
        sb.append('=');
        sb.append(((this.hORequirementRefID == null)?"<null>":this.hORequirementRefID));
        sb.append(',');
        sb.append("requirementInfoUniqueID");
        sb.append('=');
        sb.append(((this.requirementInfoUniqueID == null)?"<null>":this.requirementInfoUniqueID));
        sb.append(',');
        sb.append("sequence");
        sb.append('=');
        sb.append(((this.sequence == null)?"<null>":this.sequence));
        sb.append(',');
        sb.append("formNo");
        sb.append('=');
        sb.append(((this.formNo == null)?"<null>":this.formNo));
        sb.append(',');
        sb.append("formVersion");
        sb.append('=');
        sb.append(((this.formVersion == null)?"<null>":this.formVersion));
        sb.append(',');
        sb.append("requirementDetails");
        sb.append('=');
        sb.append(((this.requirementDetails == null)?"<null>":this.requirementDetails));
        sb.append(',');
        sb.append("restrictIssueCode");
        sb.append('=');
        sb.append(((this.restrictIssueCode == null)?"<null>":this.restrictIssueCode));
        sb.append(',');
        sb.append("reqStatus");
        sb.append('=');
        sb.append(((this.reqStatus == null)?"<null>":this.reqStatus));
        sb.append(',');
        sb.append("requestedDate");
        sb.append('=');
        sb.append(((this.requestedDate == null)?"<null>":this.requestedDate));
        sb.append(',');
        sb.append("requestedTime");
        sb.append('=');
        sb.append(((this.requestedTime == null)?"<null>":this.requestedTime));
        sb.append(',');
        sb.append("reRequestedDate");
        sb.append('=');
        sb.append(((this.reRequestedDate == null)?"<null>":this.reRequestedDate));
        sb.append(',');
        sb.append("fulfilledDate");
        sb.append('=');
        sb.append(((this.fulfilledDate == null)?"<null>":this.fulfilledDate));
        sb.append(',');
        sb.append("fulfilledTime");
        sb.append('=');
        sb.append(((this.fulfilledTime == null)?"<null>":this.fulfilledTime));
        sb.append(',');
        sb.append("receivedDate");
        sb.append('=');
        sb.append(((this.receivedDate == null)?"<null>":this.receivedDate));
        sb.append(',');
        sb.append("scheduledDate");
        sb.append('=');
        sb.append(((this.scheduledDate == null)?"<null>":this.scheduledDate));
        sb.append(',');
        sb.append("receivedAtLocationDate");
        sb.append('=');
        sb.append(((this.receivedAtLocationDate == null)?"<null>":this.receivedAtLocationDate));
        sb.append(',');
        sb.append("requestedScheduleDate");
        sb.append('=');
        sb.append(((this.requestedScheduleDate == null)?"<null>":this.requestedScheduleDate));
        sb.append(',');
        sb.append("requestedScheduleTimeStart");
        sb.append('=');
        sb.append(((this.requestedScheduleTimeStart == null)?"<null>":this.requestedScheduleTimeStart));
        sb.append(',');
        sb.append("requestedScheduleTimeEnd");
        sb.append('=');
        sb.append(((this.requestedScheduleTimeEnd == null)?"<null>":this.requestedScheduleTimeEnd));
        sb.append(',');
        sb.append("userCode");
        sb.append('=');
        sb.append(((this.userCode == null)?"<null>":this.userCode));
        sb.append(',');
        sb.append("formRecievedWithAppInd");
        sb.append('=');
        sb.append(((this.formRecievedWithAppInd == null)?"<null>":this.formRecievedWithAppInd));
        sb.append(',');
        sb.append("referredDate");
        sb.append('=');
        sb.append(((this.referredDate == null)?"<null>":this.referredDate));
        sb.append(',');
        sb.append("statusDate");
        sb.append('=');
        sb.append(((this.statusDate == null)?"<null>":this.statusDate));
        sb.append(',');
        sb.append("statusTime");
        sb.append('=');
        sb.append(((this.statusTime == null)?"<null>":this.statusTime));
        sb.append(',');
        sb.append("historyStartDate");
        sb.append('=');
        sb.append(((this.historyStartDate == null)?"<null>":this.historyStartDate));
        sb.append(',');
        sb.append("historyEndDate");
        sb.append('=');
        sb.append(((this.historyEndDate == null)?"<null>":this.historyEndDate));
        sb.append(',');
        sb.append("requirementStatusReason");
        sb.append('=');
        sb.append(((this.requirementStatusReason == null)?"<null>":this.requirementStatusReason));
        sb.append(',');
        sb.append("responsiblePartyType");
        sb.append('=');
        sb.append(((this.responsiblePartyType == null)?"<null>":this.responsiblePartyType));
        sb.append(',');
        sb.append("receivedPartyOrgCode");
        sb.append('=');
        sb.append(((this.receivedPartyOrgCode == null)?"<null>":this.receivedPartyOrgCode));
        sb.append(',');
        sb.append("referredPartyOrgCode");
        sb.append('=');
        sb.append(((this.referredPartyOrgCode == null)?"<null>":this.referredPartyOrgCode));
        sb.append(',');
        sb.append("releasePartyOrgCode");
        sb.append('=');
        sb.append(((this.releasePartyOrgCode == null)?"<null>":this.releasePartyOrgCode));
        sb.append(',');
        sb.append("mIBInquiryReason");
        sb.append('=');
        sb.append(((this.mIBInquiryReason == null)?"<null>":this.mIBInquiryReason));
        sb.append(',');
        sb.append("appliesToPartyType");
        sb.append('=');
        sb.append(((this.appliesToPartyType == null)?"<null>":this.appliesToPartyType));
        sb.append(',');
        sb.append("requirementAcctNum");
        sb.append('=');
        sb.append(((this.requirementAcctNum == null)?"<null>":this.requirementAcctNum));
        sb.append(',');
        sb.append("providerOrderNum");
        sb.append('=');
        sb.append(((this.providerOrderNum == null)?"<null>":this.providerOrderNum));
        sb.append(',');
        sb.append("carrierOrderNum");
        sb.append('=');
        sb.append(((this.carrierOrderNum == null)?"<null>":this.carrierOrderNum));
        sb.append(',');
        sb.append("reqCategory");
        sb.append('=');
        sb.append(((this.reqCategory == null)?"<null>":this.reqCategory));
        sb.append(',');
        sb.append("providerServiceCode");
        sb.append('=');
        sb.append(((this.providerServiceCode == null)?"<null>":this.providerServiceCode));
        sb.append(',');
        sb.append("reqSubStatus");
        sb.append('=');
        sb.append(((this.reqSubStatus == null)?"<null>":this.reqSubStatus));
        sb.append(',');
        sb.append("dueDate");
        sb.append('=');
        sb.append(((this.dueDate == null)?"<null>":this.dueDate));
        sb.append(',');
        sb.append("dueTime");
        sb.append('=');
        sb.append(((this.dueTime == null)?"<null>":this.dueTime));
        sb.append(',');
        sb.append("orderReceivedDate");
        sb.append('=');
        sb.append(((this.orderReceivedDate == null)?"<null>":this.orderReceivedDate));
        sb.append(',');
        sb.append("historyDuration");
        sb.append('=');
        sb.append(((this.historyDuration == null)?"<null>":this.historyDuration));
        sb.append(',');
        sb.append("historyDurationQualifier");
        sb.append('=');
        sb.append(((this.historyDurationQualifier == null)?"<null>":this.historyDurationQualifier));
        sb.append(',');
        sb.append("intendedUseOfInformationType");
        sb.append('=');
        sb.append(((this.intendedUseOfInformationType == null)?"<null>":this.intendedUseOfInformationType));
        sb.append(',');
        sb.append("submissionType");
        sb.append('=');
        sb.append(((this.submissionType == null)?"<null>":this.submissionType));
        sb.append(',');
        sb.append("reqSubmissionType");
        sb.append('=');
        sb.append(((this.reqSubmissionType == null)?"<null>":this.reqSubmissionType));
        sb.append(',');
        sb.append("priority");
        sb.append('=');
        sb.append(((this.priority == null)?"<null>":this.priority));
        sb.append(',');
        sb.append("followUpCount");
        sb.append('=');
        sb.append(((this.followUpCount == null)?"<null>":this.followUpCount));
        sb.append(',');
        sb.append("languageInterpreterNeeded");
        sb.append('=');
        sb.append(((this.languageInterpreterNeeded == null)?"<null>":this.languageInterpreterNeeded));
        sb.append(',');
        sb.append("interpretedLanguage");
        sb.append('=');
        sb.append(((this.interpretedLanguage == null)?"<null>":this.interpretedLanguage));
        sb.append(',');
        sb.append("statusReceiverParty");
        sb.append('=');
        sb.append(((this.statusReceiverParty == null)?"<null>":this.statusReceiverParty));
        sb.append(',');
        sb.append("resultsReceiverParty");
        sb.append('=');
        sb.append(((this.resultsReceiverParty == null)?"<null>":this.resultsReceiverParty));
        sb.append(',');
        sb.append("statusEvent");
        sb.append('=');
        sb.append(((this.statusEvent == null)?"<null>":this.statusEvent));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("preferredReqFulfiller");
        sb.append('=');
        sb.append(((this.preferredReqFulfiller == null)?"<null>":this.preferredReqFulfiller));
        sb.append(',');
        sb.append("trackingInfo");
        sb.append('=');
        sb.append(((this.trackingInfo == null)?"<null>":this.trackingInfo));
        sb.append(',');
        sb.append("evaluationFaceAmt");
        sb.append('=');
        sb.append(((this.evaluationFaceAmt == null)?"<null>":this.evaluationFaceAmt));
        sb.append(',');
        sb.append("keyedValue");
        sb.append('=');
        sb.append(((this.keyedValue == null)?"<null>":this.keyedValue));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("appliesToPartyID");
        sb.append('=');
        sb.append(((this.appliesToPartyID == null)?"<null>":this.appliesToPartyID));
        sb.append(',');
        sb.append("requesterPartyID");
        sb.append('=');
        sb.append(((this.requesterPartyID == null)?"<null>":this.requesterPartyID));
        sb.append(',');
        sb.append("fulfillerPartyID");
        sb.append('=');
        sb.append(((this.fulfillerPartyID == null)?"<null>":this.fulfillerPartyID));
        sb.append(',');
        sb.append("receivedPartyID");
        sb.append('=');
        sb.append(((this.receivedPartyID == null)?"<null>":this.receivedPartyID));
        sb.append(',');
        sb.append("referredPartyID");
        sb.append('=');
        sb.append(((this.referredPartyID == null)?"<null>":this.referredPartyID));
        sb.append(',');
        sb.append("requestedAddressId");
        sb.append('=');
        sb.append(((this.requestedAddressId == null)?"<null>":this.requestedAddressId));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("requestorContactPartyID");
        sb.append('=');
        sb.append(((this.requestorContactPartyID == null)?"<null>":this.requestorContactPartyID));
        sb.append(',');
        sb.append("appliesToParticipantID");
        sb.append('=');
        sb.append(((this.appliesToParticipantID == null)?"<null>":this.appliesToParticipantID));
        sb.append(',');
        sb.append("physicianPartyID");
        sb.append('=');
        sb.append(((this.physicianPartyID == null)?"<null>":this.physicianPartyID));
        sb.append(',');
        sb.append("facilityPartyID");
        sb.append('=');
        sb.append(((this.facilityPartyID == null)?"<null>":this.facilityPartyID));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.statusDate == null)? 0 :this.statusDate.hashCode()));
        result = ((result* 31)+((this.formRecievedWithAppInd == null)? 0 :this.formRecievedWithAppInd.hashCode()));
        result = ((result* 31)+((this.historyDuration == null)? 0 :this.historyDuration.hashCode()));
        result = ((result* 31)+((this.receivedAtLocationDate == null)? 0 :this.receivedAtLocationDate.hashCode()));
        result = ((result* 31)+((this.requestedScheduleTimeEnd == null)? 0 :this.requestedScheduleTimeEnd.hashCode()));
        result = ((result* 31)+((this.dueDate == null)? 0 :this.dueDate.hashCode()));
        result = ((result* 31)+((this.appliesToPartyType == null)? 0 :this.appliesToPartyType.hashCode()));
        result = ((result* 31)+((this.hORequirementRefID == null)? 0 :this.hORequirementRefID.hashCode()));
        result = ((result* 31)+((this.formVersion == null)? 0 :this.formVersion.hashCode()));
        result = ((result* 31)+((this.intendedUseOfInformationType == null)? 0 :this.intendedUseOfInformationType.hashCode()));
        result = ((result* 31)+((this.requirementInfoKey == null)? 0 :this.requirementInfoKey.hashCode()));
        result = ((result* 31)+((this.requestorContactPartyID == null)? 0 :this.requestorContactPartyID.hashCode()));
        result = ((result* 31)+((this.reqCode == null)? 0 :this.reqCode.hashCode()));
        result = ((result* 31)+((this.reqStatus == null)? 0 :this.reqStatus.hashCode()));
        result = ((result* 31)+((this.responsiblePartyType == null)? 0 :this.responsiblePartyType.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.restrictIssueCode == null)? 0 :this.restrictIssueCode.hashCode()));
        result = ((result* 31)+((this.statusTime == null)? 0 :this.statusTime.hashCode()));
        result = ((result* 31)+((this.requirementDetails == null)? 0 :this.requirementDetails.hashCode()));
        result = ((result* 31)+((this.releasePartyOrgCode == null)? 0 :this.releasePartyOrgCode.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.receivedDate == null)? 0 :this.receivedDate.hashCode()));
        result = ((result* 31)+((this.historyEndDate == null)? 0 :this.historyEndDate.hashCode()));
        result = ((result* 31)+((this.requestedAddressId == null)? 0 :this.requestedAddressId.hashCode()));
        result = ((result* 31)+((this.requirementStatusReason == null)? 0 :this.requirementStatusReason.hashCode()));
        result = ((result* 31)+((this.facilityPartyID == null)? 0 :this.facilityPartyID.hashCode()));
        result = ((result* 31)+((this.mIBInquiryReason == null)? 0 :this.mIBInquiryReason.hashCode()));
        result = ((result* 31)+((this.interpretedLanguage == null)? 0 :this.interpretedLanguage.hashCode()));
        result = ((result* 31)+((this.receivedPartyOrgCode == null)? 0 :this.receivedPartyOrgCode.hashCode()));
        result = ((result* 31)+((this.referredPartyOrgCode == null)? 0 :this.referredPartyOrgCode.hashCode()));
        result = ((result* 31)+((this.historyDurationQualifier == null)? 0 :this.historyDurationQualifier.hashCode()));
        result = ((result* 31)+((this.historyStartDate == null)? 0 :this.historyStartDate.hashCode()));
        result = ((result* 31)+((this.dueTime == null)? 0 :this.dueTime.hashCode()));
        result = ((result* 31)+((this.priority == null)? 0 :this.priority.hashCode()));
        result = ((result* 31)+((this.reqSubmissionType == null)? 0 :this.reqSubmissionType.hashCode()));
        result = ((result* 31)+((this.statusReceiverParty == null)? 0 :this.statusReceiverParty.hashCode()));
        result = ((result* 31)+((this.fulfillerPartyID == null)? 0 :this.fulfillerPartyID.hashCode()));
        result = ((result* 31)+((this.sequence == null)? 0 :this.sequence.hashCode()));
        result = ((result* 31)+((this.requestedTime == null)? 0 :this.requestedTime.hashCode()));
        result = ((result* 31)+((this.orderReceivedDate == null)? 0 :this.orderReceivedDate.hashCode()));
        result = ((result* 31)+((this.resultsReceiverParty == null)? 0 :this.resultsReceiverParty.hashCode()));
        result = ((result* 31)+((this.trackingInfo == null)? 0 :this.trackingInfo.hashCode()));
        result = ((result* 31)+((this.statusEvent == null)? 0 :this.statusEvent.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.followUpCount == null)? 0 :this.followUpCount.hashCode()));
        result = ((result* 31)+((this.fulfilledDate == null)? 0 :this.fulfilledDate.hashCode()));
        result = ((result* 31)+((this.referredDate == null)? 0 :this.referredDate.hashCode()));
        result = ((result* 31)+((this.evaluationFaceAmt == null)? 0 :this.evaluationFaceAmt.hashCode()));
        result = ((result* 31)+((this.physicianPartyID == null)? 0 :this.physicianPartyID.hashCode()));
        result = ((result* 31)+((this.requirementInfoSysKey == null)? 0 :this.requirementInfoSysKey.hashCode()));
        result = ((result* 31)+((this.languageInterpreterNeeded == null)? 0 :this.languageInterpreterNeeded.hashCode()));
        result = ((result* 31)+((this.requesterPartyID == null)? 0 :this.requesterPartyID.hashCode()));
        result = ((result* 31)+((this.referredPartyID == null)? 0 :this.referredPartyID.hashCode()));
        result = ((result* 31)+((this.scheduledDate == null)? 0 :this.scheduledDate.hashCode()));
        result = ((result* 31)+((this.appliesToParticipantID == null)? 0 :this.appliesToParticipantID.hashCode()));
        result = ((result* 31)+((this.userCode == null)? 0 :this.userCode.hashCode()));
        result = ((result* 31)+((this.providerOrderNum == null)? 0 :this.providerOrderNum.hashCode()));
        result = ((result* 31)+((this.keyedValue == null)? 0 :this.keyedValue.hashCode()));
        result = ((result* 31)+((this.submissionType == null)? 0 :this.submissionType.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.requirementAcctNum == null)? 0 :this.requirementAcctNum.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        result = ((result* 31)+((this.providerServiceCode == null)? 0 :this.providerServiceCode.hashCode()));
        result = ((result* 31)+((this.preferredReqFulfiller == null)? 0 :this.preferredReqFulfiller.hashCode()));
        result = ((result* 31)+((this.requestedDate == null)? 0 :this.requestedDate.hashCode()));
        result = ((result* 31)+((this.fulfilledTime == null)? 0 :this.fulfilledTime.hashCode()));
        result = ((result* 31)+((this.reqCategory == null)? 0 :this.reqCategory.hashCode()));
        result = ((result* 31)+((this.reqSubStatus == null)? 0 :this.reqSubStatus.hashCode()));
        result = ((result* 31)+((this.receivedPartyID == null)? 0 :this.receivedPartyID.hashCode()));
        result = ((result* 31)+((this.requirementInfoUniqueID == null)? 0 :this.requirementInfoUniqueID.hashCode()));
        result = ((result* 31)+((this.appliesToPartyID == null)? 0 :this.appliesToPartyID.hashCode()));
        result = ((result* 31)+((this.requestedScheduleTimeStart == null)? 0 :this.requestedScheduleTimeStart.hashCode()));
        result = ((result* 31)+((this.carrierOrderNum == null)? 0 :this.carrierOrderNum.hashCode()));
        result = ((result* 31)+((this.reRequestedDate == null)? 0 :this.reRequestedDate.hashCode()));
        result = ((result* 31)+((this.formNo == null)? 0 :this.formNo.hashCode()));
        result = ((result* 31)+((this.requestedScheduleDate == null)? 0 :this.requestedScheduleDate.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RequirementInfo) == false) {
            return false;
        }
        RequirementInfo rhs = ((RequirementInfo) other);
        return (((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((this.statusDate == rhs.statusDate)||((this.statusDate!= null)&&this.statusDate.equals(rhs.statusDate)))&&((this.formRecievedWithAppInd == rhs.formRecievedWithAppInd)||((this.formRecievedWithAppInd!= null)&&this.formRecievedWithAppInd.equals(rhs.formRecievedWithAppInd))))&&((this.historyDuration == rhs.historyDuration)||((this.historyDuration!= null)&&this.historyDuration.equals(rhs.historyDuration))))&&((this.receivedAtLocationDate == rhs.receivedAtLocationDate)||((this.receivedAtLocationDate!= null)&&this.receivedAtLocationDate.equals(rhs.receivedAtLocationDate))))&&((this.requestedScheduleTimeEnd == rhs.requestedScheduleTimeEnd)||((this.requestedScheduleTimeEnd!= null)&&this.requestedScheduleTimeEnd.equals(rhs.requestedScheduleTimeEnd))))&&((this.dueDate == rhs.dueDate)||((this.dueDate!= null)&&this.dueDate.equals(rhs.dueDate))))&&((this.appliesToPartyType == rhs.appliesToPartyType)||((this.appliesToPartyType!= null)&&this.appliesToPartyType.equals(rhs.appliesToPartyType))))&&((this.hORequirementRefID == rhs.hORequirementRefID)||((this.hORequirementRefID!= null)&&this.hORequirementRefID.equals(rhs.hORequirementRefID))))&&((this.formVersion == rhs.formVersion)||((this.formVersion!= null)&&this.formVersion.equals(rhs.formVersion))))&&((this.intendedUseOfInformationType == rhs.intendedUseOfInformationType)||((this.intendedUseOfInformationType!= null)&&this.intendedUseOfInformationType.equals(rhs.intendedUseOfInformationType))))&&((this.requirementInfoKey == rhs.requirementInfoKey)||((this.requirementInfoKey!= null)&&this.requirementInfoKey.equals(rhs.requirementInfoKey))))&&((this.requestorContactPartyID == rhs.requestorContactPartyID)||((this.requestorContactPartyID!= null)&&this.requestorContactPartyID.equals(rhs.requestorContactPartyID))))&&((this.reqCode == rhs.reqCode)||((this.reqCode!= null)&&this.reqCode.equals(rhs.reqCode))))&&((this.reqStatus == rhs.reqStatus)||((this.reqStatus!= null)&&this.reqStatus.equals(rhs.reqStatus))))&&((this.responsiblePartyType == rhs.responsiblePartyType)||((this.responsiblePartyType!= null)&&this.responsiblePartyType.equals(rhs.responsiblePartyType))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.restrictIssueCode == rhs.restrictIssueCode)||((this.restrictIssueCode!= null)&&this.restrictIssueCode.equals(rhs.restrictIssueCode))))&&((this.statusTime == rhs.statusTime)||((this.statusTime!= null)&&this.statusTime.equals(rhs.statusTime))))&&((this.requirementDetails == rhs.requirementDetails)||((this.requirementDetails!= null)&&this.requirementDetails.equals(rhs.requirementDetails))))&&((this.releasePartyOrgCode == rhs.releasePartyOrgCode)||((this.releasePartyOrgCode!= null)&&this.releasePartyOrgCode.equals(rhs.releasePartyOrgCode))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.receivedDate == rhs.receivedDate)||((this.receivedDate!= null)&&this.receivedDate.equals(rhs.receivedDate))))&&((this.historyEndDate == rhs.historyEndDate)||((this.historyEndDate!= null)&&this.historyEndDate.equals(rhs.historyEndDate))))&&((this.requestedAddressId == rhs.requestedAddressId)||((this.requestedAddressId!= null)&&this.requestedAddressId.equals(rhs.requestedAddressId))))&&((this.requirementStatusReason == rhs.requirementStatusReason)||((this.requirementStatusReason!= null)&&this.requirementStatusReason.equals(rhs.requirementStatusReason))))&&((this.facilityPartyID == rhs.facilityPartyID)||((this.facilityPartyID!= null)&&this.facilityPartyID.equals(rhs.facilityPartyID))))&&((this.mIBInquiryReason == rhs.mIBInquiryReason)||((this.mIBInquiryReason!= null)&&this.mIBInquiryReason.equals(rhs.mIBInquiryReason))))&&((this.interpretedLanguage == rhs.interpretedLanguage)||((this.interpretedLanguage!= null)&&this.interpretedLanguage.equals(rhs.interpretedLanguage))))&&((this.receivedPartyOrgCode == rhs.receivedPartyOrgCode)||((this.receivedPartyOrgCode!= null)&&this.receivedPartyOrgCode.equals(rhs.receivedPartyOrgCode))))&&((this.referredPartyOrgCode == rhs.referredPartyOrgCode)||((this.referredPartyOrgCode!= null)&&this.referredPartyOrgCode.equals(rhs.referredPartyOrgCode))))&&((this.historyDurationQualifier == rhs.historyDurationQualifier)||((this.historyDurationQualifier!= null)&&this.historyDurationQualifier.equals(rhs.historyDurationQualifier))))&&((this.historyStartDate == rhs.historyStartDate)||((this.historyStartDate!= null)&&this.historyStartDate.equals(rhs.historyStartDate))))&&((this.dueTime == rhs.dueTime)||((this.dueTime!= null)&&this.dueTime.equals(rhs.dueTime))))&&((this.priority == rhs.priority)||((this.priority!= null)&&this.priority.equals(rhs.priority))))&&((this.reqSubmissionType == rhs.reqSubmissionType)||((this.reqSubmissionType!= null)&&this.reqSubmissionType.equals(rhs.reqSubmissionType))))&&((this.statusReceiverParty == rhs.statusReceiverParty)||((this.statusReceiverParty!= null)&&this.statusReceiverParty.equals(rhs.statusReceiverParty))))&&((this.fulfillerPartyID == rhs.fulfillerPartyID)||((this.fulfillerPartyID!= null)&&this.fulfillerPartyID.equals(rhs.fulfillerPartyID))))&&((this.sequence == rhs.sequence)||((this.sequence!= null)&&this.sequence.equals(rhs.sequence))))&&((this.requestedTime == rhs.requestedTime)||((this.requestedTime!= null)&&this.requestedTime.equals(rhs.requestedTime))))&&((this.orderReceivedDate == rhs.orderReceivedDate)||((this.orderReceivedDate!= null)&&this.orderReceivedDate.equals(rhs.orderReceivedDate))))&&((this.resultsReceiverParty == rhs.resultsReceiverParty)||((this.resultsReceiverParty!= null)&&this.resultsReceiverParty.equals(rhs.resultsReceiverParty))))&&((this.trackingInfo == rhs.trackingInfo)||((this.trackingInfo!= null)&&this.trackingInfo.equals(rhs.trackingInfo))))&&((this.statusEvent == rhs.statusEvent)||((this.statusEvent!= null)&&this.statusEvent.equals(rhs.statusEvent))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.followUpCount == rhs.followUpCount)||((this.followUpCount!= null)&&this.followUpCount.equals(rhs.followUpCount))))&&((this.fulfilledDate == rhs.fulfilledDate)||((this.fulfilledDate!= null)&&this.fulfilledDate.equals(rhs.fulfilledDate))))&&((this.referredDate == rhs.referredDate)||((this.referredDate!= null)&&this.referredDate.equals(rhs.referredDate))))&&((this.evaluationFaceAmt == rhs.evaluationFaceAmt)||((this.evaluationFaceAmt!= null)&&this.evaluationFaceAmt.equals(rhs.evaluationFaceAmt))))&&((this.physicianPartyID == rhs.physicianPartyID)||((this.physicianPartyID!= null)&&this.physicianPartyID.equals(rhs.physicianPartyID))))&&((this.requirementInfoSysKey == rhs.requirementInfoSysKey)||((this.requirementInfoSysKey!= null)&&this.requirementInfoSysKey.equals(rhs.requirementInfoSysKey))))&&((this.languageInterpreterNeeded == rhs.languageInterpreterNeeded)||((this.languageInterpreterNeeded!= null)&&this.languageInterpreterNeeded.equals(rhs.languageInterpreterNeeded))))&&((this.requesterPartyID == rhs.requesterPartyID)||((this.requesterPartyID!= null)&&this.requesterPartyID.equals(rhs.requesterPartyID))))&&((this.referredPartyID == rhs.referredPartyID)||((this.referredPartyID!= null)&&this.referredPartyID.equals(rhs.referredPartyID))))&&((this.scheduledDate == rhs.scheduledDate)||((this.scheduledDate!= null)&&this.scheduledDate.equals(rhs.scheduledDate))))&&((this.appliesToParticipantID == rhs.appliesToParticipantID)||((this.appliesToParticipantID!= null)&&this.appliesToParticipantID.equals(rhs.appliesToParticipantID))))&&((this.userCode == rhs.userCode)||((this.userCode!= null)&&this.userCode.equals(rhs.userCode))))&&((this.providerOrderNum == rhs.providerOrderNum)||((this.providerOrderNum!= null)&&this.providerOrderNum.equals(rhs.providerOrderNum))))&&((this.keyedValue == rhs.keyedValue)||((this.keyedValue!= null)&&this.keyedValue.equals(rhs.keyedValue))))&&((this.submissionType == rhs.submissionType)||((this.submissionType!= null)&&this.submissionType.equals(rhs.submissionType))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.requirementAcctNum == rhs.requirementAcctNum)||((this.requirementAcctNum!= null)&&this.requirementAcctNum.equals(rhs.requirementAcctNum))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))))&&((this.providerServiceCode == rhs.providerServiceCode)||((this.providerServiceCode!= null)&&this.providerServiceCode.equals(rhs.providerServiceCode))))&&((this.preferredReqFulfiller == rhs.preferredReqFulfiller)||((this.preferredReqFulfiller!= null)&&this.preferredReqFulfiller.equals(rhs.preferredReqFulfiller))))&&((this.requestedDate == rhs.requestedDate)||((this.requestedDate!= null)&&this.requestedDate.equals(rhs.requestedDate))))&&((this.fulfilledTime == rhs.fulfilledTime)||((this.fulfilledTime!= null)&&this.fulfilledTime.equals(rhs.fulfilledTime))))&&((this.reqCategory == rhs.reqCategory)||((this.reqCategory!= null)&&this.reqCategory.equals(rhs.reqCategory))))&&((this.reqSubStatus == rhs.reqSubStatus)||((this.reqSubStatus!= null)&&this.reqSubStatus.equals(rhs.reqSubStatus))))&&((this.receivedPartyID == rhs.receivedPartyID)||((this.receivedPartyID!= null)&&this.receivedPartyID.equals(rhs.receivedPartyID))))&&((this.requirementInfoUniqueID == rhs.requirementInfoUniqueID)||((this.requirementInfoUniqueID!= null)&&this.requirementInfoUniqueID.equals(rhs.requirementInfoUniqueID))))&&((this.appliesToPartyID == rhs.appliesToPartyID)||((this.appliesToPartyID!= null)&&this.appliesToPartyID.equals(rhs.appliesToPartyID))))&&((this.requestedScheduleTimeStart == rhs.requestedScheduleTimeStart)||((this.requestedScheduleTimeStart!= null)&&this.requestedScheduleTimeStart.equals(rhs.requestedScheduleTimeStart))))&&((this.carrierOrderNum == rhs.carrierOrderNum)||((this.carrierOrderNum!= null)&&this.carrierOrderNum.equals(rhs.carrierOrderNum))))&&((this.reRequestedDate == rhs.reRequestedDate)||((this.reRequestedDate!= null)&&this.reRequestedDate.equals(rhs.reRequestedDate))))&&((this.formNo == rhs.formNo)||((this.formNo!= null)&&this.formNo.equals(rhs.formNo))))&&((this.requestedScheduleDate == rhs.requestedScheduleDate)||((this.requestedScheduleDate!= null)&&this.requestedScheduleDate.equals(rhs.requestedScheduleDate))));
    }

}
