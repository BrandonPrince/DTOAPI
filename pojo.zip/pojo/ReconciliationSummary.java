
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ReconciliationSummaryKey",
    "ReconciliationSummarySysKey",
    "ReconciliationSummaryType",
    "ReconciliationDetailTypeCode",
    "ReconciliationTotalAmtSource",
    "ReconciliationTotalQtySource",
    "ReconciliationDetail",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class ReconciliationSummary {

    @JsonProperty("ReconciliationSummaryKey")
    private ReconciliationSummaryKey reconciliationSummaryKey;
    @JsonProperty("ReconciliationSummarySysKey")
    private List<Object> reconciliationSummarySysKey = new ArrayList<>();
    @JsonProperty("ReconciliationSummaryType")
    private ReconciliationSummaryType reconciliationSummaryType;
    @JsonProperty("ReconciliationDetailTypeCode")
    private ReconciliationDetailTypeCode reconciliationDetailTypeCode;
    @JsonProperty("ReconciliationTotalAmtSource")
    private String reconciliationTotalAmtSource;
    @JsonProperty("ReconciliationTotalQtySource")
    private String reconciliationTotalQtySource;
    @JsonProperty("ReconciliationDetail")
    private List<Object> reconciliationDetail = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("ReconciliationSummaryKey")
    public ReconciliationSummaryKey getReconciliationSummaryKey() {
        return reconciliationSummaryKey;
    }

    @JsonProperty("ReconciliationSummaryKey")
    public void setReconciliationSummaryKey(ReconciliationSummaryKey reconciliationSummaryKey) {
        this.reconciliationSummaryKey = reconciliationSummaryKey;
    }

    public ReconciliationSummary withReconciliationSummaryKey(ReconciliationSummaryKey reconciliationSummaryKey) {
        this.reconciliationSummaryKey = reconciliationSummaryKey;
        return this;
    }

    @JsonProperty("ReconciliationSummarySysKey")
    public List<Object> getReconciliationSummarySysKey() {
        return reconciliationSummarySysKey;
    }

    @JsonProperty("ReconciliationSummarySysKey")
    public void setReconciliationSummarySysKey(List<Object> reconciliationSummarySysKey) {
        this.reconciliationSummarySysKey = reconciliationSummarySysKey;
    }

    public ReconciliationSummary withReconciliationSummarySysKey(List<Object> reconciliationSummarySysKey) {
        this.reconciliationSummarySysKey = reconciliationSummarySysKey;
        return this;
    }

    @JsonProperty("ReconciliationSummaryType")
    public ReconciliationSummaryType getReconciliationSummaryType() {
        return reconciliationSummaryType;
    }

    @JsonProperty("ReconciliationSummaryType")
    public void setReconciliationSummaryType(ReconciliationSummaryType reconciliationSummaryType) {
        this.reconciliationSummaryType = reconciliationSummaryType;
    }

    public ReconciliationSummary withReconciliationSummaryType(ReconciliationSummaryType reconciliationSummaryType) {
        this.reconciliationSummaryType = reconciliationSummaryType;
        return this;
    }

    @JsonProperty("ReconciliationDetailTypeCode")
    public ReconciliationDetailTypeCode getReconciliationDetailTypeCode() {
        return reconciliationDetailTypeCode;
    }

    @JsonProperty("ReconciliationDetailTypeCode")
    public void setReconciliationDetailTypeCode(ReconciliationDetailTypeCode reconciliationDetailTypeCode) {
        this.reconciliationDetailTypeCode = reconciliationDetailTypeCode;
    }

    public ReconciliationSummary withReconciliationDetailTypeCode(ReconciliationDetailTypeCode reconciliationDetailTypeCode) {
        this.reconciliationDetailTypeCode = reconciliationDetailTypeCode;
        return this;
    }

    @JsonProperty("ReconciliationTotalAmtSource")
    public String getReconciliationTotalAmtSource() {
        return reconciliationTotalAmtSource;
    }

    @JsonProperty("ReconciliationTotalAmtSource")
    public void setReconciliationTotalAmtSource(String reconciliationTotalAmtSource) {
        this.reconciliationTotalAmtSource = reconciliationTotalAmtSource;
    }

    public ReconciliationSummary withReconciliationTotalAmtSource(String reconciliationTotalAmtSource) {
        this.reconciliationTotalAmtSource = reconciliationTotalAmtSource;
        return this;
    }

    @JsonProperty("ReconciliationTotalQtySource")
    public String getReconciliationTotalQtySource() {
        return reconciliationTotalQtySource;
    }

    @JsonProperty("ReconciliationTotalQtySource")
    public void setReconciliationTotalQtySource(String reconciliationTotalQtySource) {
        this.reconciliationTotalQtySource = reconciliationTotalQtySource;
    }

    public ReconciliationSummary withReconciliationTotalQtySource(String reconciliationTotalQtySource) {
        this.reconciliationTotalQtySource = reconciliationTotalQtySource;
        return this;
    }

    @JsonProperty("ReconciliationDetail")
    public List<Object> getReconciliationDetail() {
        return reconciliationDetail;
    }

    @JsonProperty("ReconciliationDetail")
    public void setReconciliationDetail(List<Object> reconciliationDetail) {
        this.reconciliationDetail = reconciliationDetail;
    }

    public ReconciliationSummary withReconciliationDetail(List<Object> reconciliationDetail) {
        this.reconciliationDetail = reconciliationDetail;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public ReconciliationSummary withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public ReconciliationSummary withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public ReconciliationSummary withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public ReconciliationSummary withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ReconciliationSummary.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("reconciliationSummaryKey");
        sb.append('=');
        sb.append(((this.reconciliationSummaryKey == null)?"<null>":this.reconciliationSummaryKey));
        sb.append(',');
        sb.append("reconciliationSummarySysKey");
        sb.append('=');
        sb.append(((this.reconciliationSummarySysKey == null)?"<null>":this.reconciliationSummarySysKey));
        sb.append(',');
        sb.append("reconciliationSummaryType");
        sb.append('=');
        sb.append(((this.reconciliationSummaryType == null)?"<null>":this.reconciliationSummaryType));
        sb.append(',');
        sb.append("reconciliationDetailTypeCode");
        sb.append('=');
        sb.append(((this.reconciliationDetailTypeCode == null)?"<null>":this.reconciliationDetailTypeCode));
        sb.append(',');
        sb.append("reconciliationTotalAmtSource");
        sb.append('=');
        sb.append(((this.reconciliationTotalAmtSource == null)?"<null>":this.reconciliationTotalAmtSource));
        sb.append(',');
        sb.append("reconciliationTotalQtySource");
        sb.append('=');
        sb.append(((this.reconciliationTotalQtySource == null)?"<null>":this.reconciliationTotalQtySource));
        sb.append(',');
        sb.append("reconciliationDetail");
        sb.append('=');
        sb.append(((this.reconciliationDetail == null)?"<null>":this.reconciliationDetail));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.reconciliationSummaryKey == null)? 0 :this.reconciliationSummaryKey.hashCode()));
        result = ((result* 31)+((this.reconciliationDetailTypeCode == null)? 0 :this.reconciliationDetailTypeCode.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.reconciliationTotalAmtSource == null)? 0 :this.reconciliationTotalAmtSource.hashCode()));
        result = ((result* 31)+((this.reconciliationTotalQtySource == null)? 0 :this.reconciliationTotalQtySource.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.reconciliationDetail == null)? 0 :this.reconciliationDetail.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.reconciliationSummarySysKey == null)? 0 :this.reconciliationSummarySysKey.hashCode()));
        result = ((result* 31)+((this.reconciliationSummaryType == null)? 0 :this.reconciliationSummaryType.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ReconciliationSummary) == false) {
            return false;
        }
        ReconciliationSummary rhs = ((ReconciliationSummary) other);
        return ((((((((((((this.reconciliationSummaryKey == rhs.reconciliationSummaryKey)||((this.reconciliationSummaryKey!= null)&&this.reconciliationSummaryKey.equals(rhs.reconciliationSummaryKey)))&&((this.reconciliationDetailTypeCode == rhs.reconciliationDetailTypeCode)||((this.reconciliationDetailTypeCode!= null)&&this.reconciliationDetailTypeCode.equals(rhs.reconciliationDetailTypeCode))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.reconciliationTotalAmtSource == rhs.reconciliationTotalAmtSource)||((this.reconciliationTotalAmtSource!= null)&&this.reconciliationTotalAmtSource.equals(rhs.reconciliationTotalAmtSource))))&&((this.reconciliationTotalQtySource == rhs.reconciliationTotalQtySource)||((this.reconciliationTotalQtySource!= null)&&this.reconciliationTotalQtySource.equals(rhs.reconciliationTotalQtySource))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.reconciliationDetail == rhs.reconciliationDetail)||((this.reconciliationDetail!= null)&&this.reconciliationDetail.equals(rhs.reconciliationDetail))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.reconciliationSummarySysKey == rhs.reconciliationSummarySysKey)||((this.reconciliationSummarySysKey!= null)&&this.reconciliationSummarySysKey.equals(rhs.reconciliationSummarySysKey))))&&((this.reconciliationSummaryType == rhs.reconciliationSummaryType)||((this.reconciliationSummaryType!= null)&&this.reconciliationSummaryType.equals(rhs.reconciliationSummaryType))));
    }

}
