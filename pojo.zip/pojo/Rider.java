
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "RiderKey",
    "RiderSysKey",
    "RiderTypeCode",
    "RiderSubTypeCode",
    "Description",
    "RiderCode",
    "ProductVersionCode",
    "WaiverSignal",
    "RiderStatus",
    "StatusReason",
    "EffDate",
    "IssueDate",
    "TermDate",
    "TotAmt",
    "TotAmtLastAnn",
    "DeductAmt",
    "PeriodicAmt",
    "PeriodicMode",
    "PaymentAmt",
    "BenefitPeriod",
    "BenefitMode",
    "NumberOfUnits",
    "FormNo",
    "FiledFormNumber",
    "NursingCareDailyBenefitPct",
    "HomeCommunityBasedCarePct",
    "NursingCareDailyBenefitAmt",
    "HomeCommunityBasedCareAmt",
    "InitialPremAmt",
    "BenefitPct",
    "EliminationPeriod",
    "RequiredHospitalPeriod",
    "AddlHospitalPeriod",
    "ProductCode",
    "RiderCategory",
    "CommissionLink",
    "CovNumber",
    "ValuationClassType",
    "ValuationBaseSeries",
    "ValuationSubSeries",
    "PaidUpDate",
    "ReserveFunction",
    "ReserveIntRate",
    "ReserveMethod",
    "MortalityOrMorbidityTable",
    "SalaryPct",
    "ShortName",
    "MarketingName",
    "ExpiryDate",
    "CarrierAdminSystem",
    "Purpose",
    "RenewableInd",
    "Duration",
    "LastPaidAmt",
    "LastPaidDate",
    "PreExistingConditionInd",
    "ChildMatureAge",
    "ChildAgeUse",
    "BenefitCoordinationInd",
    "PolicyExhibitStatus",
    "FeatureName",
    "ERContribAmt",
    "EEContribAmt",
    "ERContribPct",
    "EEContribPct",
    "EventType",
    "EventYear",
    "EstTargetAge",
    "RiderFreeAmt",
    "BenefitLimit",
    "ReinsuranceInfo",
    "Participant",
    "CovOption",
    "Fee",
    "AmountProduct",
    "DeductionOption",
    "RestrictionInfo",
    "AdditionalRiderClassification",
    "Attachment",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class Rider {

    @JsonProperty("RiderKey")
    private RiderKey riderKey;
    @JsonProperty("RiderSysKey")
    private List<Object> riderSysKey = new ArrayList<>();
    @JsonProperty("RiderTypeCode")
    private RiderTypeCode riderTypeCode;
    @JsonProperty("RiderSubTypeCode")
    private RiderSubTypeCode riderSubTypeCode;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("RiderCode")
    private String riderCode;
    @JsonProperty("ProductVersionCode")
    private String productVersionCode;
    @JsonProperty("WaiverSignal")
    private WaiverSignal waiverSignal;
    @JsonProperty("RiderStatus")
    private RiderStatus riderStatus;
    @JsonProperty("StatusReason")
    private StatusReason statusReason;
    @JsonProperty("EffDate")
    private String effDate;
    @JsonProperty("IssueDate")
    private String issueDate;
    @JsonProperty("TermDate")
    private String termDate;
    @JsonProperty("TotAmt")
    private Integer totAmt;
    @JsonProperty("TotAmtLastAnn")
    private Integer totAmtLastAnn;
    @JsonProperty("DeductAmt")
    private Integer deductAmt;
    @JsonProperty("PeriodicAmt")
    private Integer periodicAmt;
    @JsonProperty("PeriodicMode")
    private PeriodicMode periodicMode;
    @JsonProperty("PaymentAmt")
    private Integer paymentAmt;
    @JsonProperty("BenefitPeriod")
    private BenefitPeriod benefitPeriod;
    @JsonProperty("BenefitMode")
    private BenefitMode benefitMode;
    @JsonProperty("NumberOfUnits")
    private Integer numberOfUnits;
    @JsonProperty("FormNo")
    private String formNo;
    @JsonProperty("FiledFormNumber")
    private String filedFormNumber;
    @JsonProperty("NursingCareDailyBenefitPct")
    private Integer nursingCareDailyBenefitPct;
    @JsonProperty("HomeCommunityBasedCarePct")
    private Integer homeCommunityBasedCarePct;
    @JsonProperty("NursingCareDailyBenefitAmt")
    private Integer nursingCareDailyBenefitAmt;
    @JsonProperty("HomeCommunityBasedCareAmt")
    private Integer homeCommunityBasedCareAmt;
    @JsonProperty("InitialPremAmt")
    private Integer initialPremAmt;
    @JsonProperty("BenefitPct")
    private Integer benefitPct;
    @JsonProperty("EliminationPeriod")
    private EliminationPeriod eliminationPeriod;
    @JsonProperty("RequiredHospitalPeriod")
    private Integer requiredHospitalPeriod;
    @JsonProperty("AddlHospitalPeriod")
    private Integer addlHospitalPeriod;
    @JsonProperty("ProductCode")
    private String productCode;
    @JsonProperty("RiderCategory")
    private RiderCategory riderCategory;
    @JsonProperty("CommissionLink")
    private String commissionLink;
    @JsonProperty("CovNumber")
    private String covNumber;
    @JsonProperty("ValuationClassType")
    private ValuationClassType valuationClassType;
    @JsonProperty("ValuationBaseSeries")
    private String valuationBaseSeries;
    @JsonProperty("ValuationSubSeries")
    private String valuationSubSeries;
    @JsonProperty("PaidUpDate")
    private String paidUpDate;
    @JsonProperty("ReserveFunction")
    private ReserveFunction reserveFunction;
    @JsonProperty("ReserveIntRate")
    private Integer reserveIntRate;
    @JsonProperty("ReserveMethod")
    private ReserveMethod reserveMethod;
    @JsonProperty("MortalityOrMorbidityTable")
    private MortalityOrMorbidityTable mortalityOrMorbidityTable;
    @JsonProperty("SalaryPct")
    private Integer salaryPct;
    @JsonProperty("ShortName")
    private String shortName;
    @JsonProperty("MarketingName")
    private String marketingName;
    @JsonProperty("ExpiryDate")
    private String expiryDate;
    @JsonProperty("CarrierAdminSystem")
    private String carrierAdminSystem;
    @JsonProperty("Purpose")
    private Purpose purpose;
    @JsonProperty("RenewableInd")
    private RenewableInd renewableInd;
    @JsonProperty("Duration")
    private Integer duration;
    @JsonProperty("LastPaidAmt")
    private Integer lastPaidAmt;
    @JsonProperty("LastPaidDate")
    private String lastPaidDate;
    @JsonProperty("PreExistingConditionInd")
    private PreExistingConditionInd preExistingConditionInd;
    @JsonProperty("ChildMatureAge")
    private Integer childMatureAge;
    @JsonProperty("ChildAgeUse")
    private ChildAgeUse childAgeUse;
    @JsonProperty("BenefitCoordinationInd")
    private BenefitCoordinationInd benefitCoordinationInd;
    @JsonProperty("PolicyExhibitStatus")
    private PolicyExhibitStatus policyExhibitStatus;
    @JsonProperty("FeatureName")
    private String featureName;
    @JsonProperty("ERContribAmt")
    private Integer eRContribAmt;
    @JsonProperty("EEContribAmt")
    private Integer eEContribAmt;
    @JsonProperty("ERContribPct")
    private Integer eRContribPct;
    @JsonProperty("EEContribPct")
    private Integer eEContribPct;
    @JsonProperty("EventType")
    private EventType eventType;
    @JsonProperty("EventYear")
    private Integer eventYear;
    @JsonProperty("EstTargetAge")
    private Integer estTargetAge;
    @JsonProperty("RiderFreeAmt")
    private Integer riderFreeAmt;
    @JsonProperty("BenefitLimit")
    private List<Object> benefitLimit = new ArrayList<>();
    @JsonProperty("ReinsuranceInfo")
    private List<Object> reinsuranceInfo = new ArrayList<>();
    @JsonProperty("Participant")
    private List<Object> participant = new ArrayList<>();
    @JsonProperty("CovOption")
    private List<Object> covOption = new ArrayList<>();
    @JsonProperty("Fee")
    private List<Object> fee = new ArrayList<>();
    @JsonProperty("AmountProduct")
    private List<Object> amountProduct = new ArrayList<>();
    @JsonProperty("DeductionOption")
    private List<Object> deductionOption = new ArrayList<>();
    @JsonProperty("RestrictionInfo")
    private List<Object> restrictionInfo = new ArrayList<>();
    @JsonProperty("AdditionalRiderClassification")
    private List<Object> additionalRiderClassification = new ArrayList<>();
    @JsonProperty("Attachment")
    private List<Object> attachment = new ArrayList<>();
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("RiderKey")
    public RiderKey getRiderKey() {
        return riderKey;
    }

    @JsonProperty("RiderKey")
    public void setRiderKey(RiderKey riderKey) {
        this.riderKey = riderKey;
    }

    public Rider withRiderKey(RiderKey riderKey) {
        this.riderKey = riderKey;
        return this;
    }

    @JsonProperty("RiderSysKey")
    public List<Object> getRiderSysKey() {
        return riderSysKey;
    }

    @JsonProperty("RiderSysKey")
    public void setRiderSysKey(List<Object> riderSysKey) {
        this.riderSysKey = riderSysKey;
    }

    public Rider withRiderSysKey(List<Object> riderSysKey) {
        this.riderSysKey = riderSysKey;
        return this;
    }

    @JsonProperty("RiderTypeCode")
    public RiderTypeCode getRiderTypeCode() {
        return riderTypeCode;
    }

    @JsonProperty("RiderTypeCode")
    public void setRiderTypeCode(RiderTypeCode riderTypeCode) {
        this.riderTypeCode = riderTypeCode;
    }

    public Rider withRiderTypeCode(RiderTypeCode riderTypeCode) {
        this.riderTypeCode = riderTypeCode;
        return this;
    }

    @JsonProperty("RiderSubTypeCode")
    public RiderSubTypeCode getRiderSubTypeCode() {
        return riderSubTypeCode;
    }

    @JsonProperty("RiderSubTypeCode")
    public void setRiderSubTypeCode(RiderSubTypeCode riderSubTypeCode) {
        this.riderSubTypeCode = riderSubTypeCode;
    }

    public Rider withRiderSubTypeCode(RiderSubTypeCode riderSubTypeCode) {
        this.riderSubTypeCode = riderSubTypeCode;
        return this;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    public Rider withDescription(String description) {
        this.description = description;
        return this;
    }

    @JsonProperty("RiderCode")
    public String getRiderCode() {
        return riderCode;
    }

    @JsonProperty("RiderCode")
    public void setRiderCode(String riderCode) {
        this.riderCode = riderCode;
    }

    public Rider withRiderCode(String riderCode) {
        this.riderCode = riderCode;
        return this;
    }

    @JsonProperty("ProductVersionCode")
    public String getProductVersionCode() {
        return productVersionCode;
    }

    @JsonProperty("ProductVersionCode")
    public void setProductVersionCode(String productVersionCode) {
        this.productVersionCode = productVersionCode;
    }

    public Rider withProductVersionCode(String productVersionCode) {
        this.productVersionCode = productVersionCode;
        return this;
    }

    @JsonProperty("WaiverSignal")
    public WaiverSignal getWaiverSignal() {
        return waiverSignal;
    }

    @JsonProperty("WaiverSignal")
    public void setWaiverSignal(WaiverSignal waiverSignal) {
        this.waiverSignal = waiverSignal;
    }

    public Rider withWaiverSignal(WaiverSignal waiverSignal) {
        this.waiverSignal = waiverSignal;
        return this;
    }

    @JsonProperty("RiderStatus")
    public RiderStatus getRiderStatus() {
        return riderStatus;
    }

    @JsonProperty("RiderStatus")
    public void setRiderStatus(RiderStatus riderStatus) {
        this.riderStatus = riderStatus;
    }

    public Rider withRiderStatus(RiderStatus riderStatus) {
        this.riderStatus = riderStatus;
        return this;
    }

    @JsonProperty("StatusReason")
    public StatusReason getStatusReason() {
        return statusReason;
    }

    @JsonProperty("StatusReason")
    public void setStatusReason(StatusReason statusReason) {
        this.statusReason = statusReason;
    }

    public Rider withStatusReason(StatusReason statusReason) {
        this.statusReason = statusReason;
        return this;
    }

    @JsonProperty("EffDate")
    public String getEffDate() {
        return effDate;
    }

    @JsonProperty("EffDate")
    public void setEffDate(String effDate) {
        this.effDate = effDate;
    }

    public Rider withEffDate(String effDate) {
        this.effDate = effDate;
        return this;
    }

    @JsonProperty("IssueDate")
    public String getIssueDate() {
        return issueDate;
    }

    @JsonProperty("IssueDate")
    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public Rider withIssueDate(String issueDate) {
        this.issueDate = issueDate;
        return this;
    }

    @JsonProperty("TermDate")
    public String getTermDate() {
        return termDate;
    }

    @JsonProperty("TermDate")
    public void setTermDate(String termDate) {
        this.termDate = termDate;
    }

    public Rider withTermDate(String termDate) {
        this.termDate = termDate;
        return this;
    }

    @JsonProperty("TotAmt")
    public Integer getTotAmt() {
        return totAmt;
    }

    @JsonProperty("TotAmt")
    public void setTotAmt(Integer totAmt) {
        this.totAmt = totAmt;
    }

    public Rider withTotAmt(Integer totAmt) {
        this.totAmt = totAmt;
        return this;
    }

    @JsonProperty("TotAmtLastAnn")
    public Integer getTotAmtLastAnn() {
        return totAmtLastAnn;
    }

    @JsonProperty("TotAmtLastAnn")
    public void setTotAmtLastAnn(Integer totAmtLastAnn) {
        this.totAmtLastAnn = totAmtLastAnn;
    }

    public Rider withTotAmtLastAnn(Integer totAmtLastAnn) {
        this.totAmtLastAnn = totAmtLastAnn;
        return this;
    }

    @JsonProperty("DeductAmt")
    public Integer getDeductAmt() {
        return deductAmt;
    }

    @JsonProperty("DeductAmt")
    public void setDeductAmt(Integer deductAmt) {
        this.deductAmt = deductAmt;
    }

    public Rider withDeductAmt(Integer deductAmt) {
        this.deductAmt = deductAmt;
        return this;
    }

    @JsonProperty("PeriodicAmt")
    public Integer getPeriodicAmt() {
        return periodicAmt;
    }

    @JsonProperty("PeriodicAmt")
    public void setPeriodicAmt(Integer periodicAmt) {
        this.periodicAmt = periodicAmt;
    }

    public Rider withPeriodicAmt(Integer periodicAmt) {
        this.periodicAmt = periodicAmt;
        return this;
    }

    @JsonProperty("PeriodicMode")
    public PeriodicMode getPeriodicMode() {
        return periodicMode;
    }

    @JsonProperty("PeriodicMode")
    public void setPeriodicMode(PeriodicMode periodicMode) {
        this.periodicMode = periodicMode;
    }

    public Rider withPeriodicMode(PeriodicMode periodicMode) {
        this.periodicMode = periodicMode;
        return this;
    }

    @JsonProperty("PaymentAmt")
    public Integer getPaymentAmt() {
        return paymentAmt;
    }

    @JsonProperty("PaymentAmt")
    public void setPaymentAmt(Integer paymentAmt) {
        this.paymentAmt = paymentAmt;
    }

    public Rider withPaymentAmt(Integer paymentAmt) {
        this.paymentAmt = paymentAmt;
        return this;
    }

    @JsonProperty("BenefitPeriod")
    public BenefitPeriod getBenefitPeriod() {
        return benefitPeriod;
    }

    @JsonProperty("BenefitPeriod")
    public void setBenefitPeriod(BenefitPeriod benefitPeriod) {
        this.benefitPeriod = benefitPeriod;
    }

    public Rider withBenefitPeriod(BenefitPeriod benefitPeriod) {
        this.benefitPeriod = benefitPeriod;
        return this;
    }

    @JsonProperty("BenefitMode")
    public BenefitMode getBenefitMode() {
        return benefitMode;
    }

    @JsonProperty("BenefitMode")
    public void setBenefitMode(BenefitMode benefitMode) {
        this.benefitMode = benefitMode;
    }

    public Rider withBenefitMode(BenefitMode benefitMode) {
        this.benefitMode = benefitMode;
        return this;
    }

    @JsonProperty("NumberOfUnits")
    public Integer getNumberOfUnits() {
        return numberOfUnits;
    }

    @JsonProperty("NumberOfUnits")
    public void setNumberOfUnits(Integer numberOfUnits) {
        this.numberOfUnits = numberOfUnits;
    }

    public Rider withNumberOfUnits(Integer numberOfUnits) {
        this.numberOfUnits = numberOfUnits;
        return this;
    }

    @JsonProperty("FormNo")
    public String getFormNo() {
        return formNo;
    }

    @JsonProperty("FormNo")
    public void setFormNo(String formNo) {
        this.formNo = formNo;
    }

    public Rider withFormNo(String formNo) {
        this.formNo = formNo;
        return this;
    }

    @JsonProperty("FiledFormNumber")
    public String getFiledFormNumber() {
        return filedFormNumber;
    }

    @JsonProperty("FiledFormNumber")
    public void setFiledFormNumber(String filedFormNumber) {
        this.filedFormNumber = filedFormNumber;
    }

    public Rider withFiledFormNumber(String filedFormNumber) {
        this.filedFormNumber = filedFormNumber;
        return this;
    }

    @JsonProperty("NursingCareDailyBenefitPct")
    public Integer getNursingCareDailyBenefitPct() {
        return nursingCareDailyBenefitPct;
    }

    @JsonProperty("NursingCareDailyBenefitPct")
    public void setNursingCareDailyBenefitPct(Integer nursingCareDailyBenefitPct) {
        this.nursingCareDailyBenefitPct = nursingCareDailyBenefitPct;
    }

    public Rider withNursingCareDailyBenefitPct(Integer nursingCareDailyBenefitPct) {
        this.nursingCareDailyBenefitPct = nursingCareDailyBenefitPct;
        return this;
    }

    @JsonProperty("HomeCommunityBasedCarePct")
    public Integer getHomeCommunityBasedCarePct() {
        return homeCommunityBasedCarePct;
    }

    @JsonProperty("HomeCommunityBasedCarePct")
    public void setHomeCommunityBasedCarePct(Integer homeCommunityBasedCarePct) {
        this.homeCommunityBasedCarePct = homeCommunityBasedCarePct;
    }

    public Rider withHomeCommunityBasedCarePct(Integer homeCommunityBasedCarePct) {
        this.homeCommunityBasedCarePct = homeCommunityBasedCarePct;
        return this;
    }

    @JsonProperty("NursingCareDailyBenefitAmt")
    public Integer getNursingCareDailyBenefitAmt() {
        return nursingCareDailyBenefitAmt;
    }

    @JsonProperty("NursingCareDailyBenefitAmt")
    public void setNursingCareDailyBenefitAmt(Integer nursingCareDailyBenefitAmt) {
        this.nursingCareDailyBenefitAmt = nursingCareDailyBenefitAmt;
    }

    public Rider withNursingCareDailyBenefitAmt(Integer nursingCareDailyBenefitAmt) {
        this.nursingCareDailyBenefitAmt = nursingCareDailyBenefitAmt;
        return this;
    }

    @JsonProperty("HomeCommunityBasedCareAmt")
    public Integer getHomeCommunityBasedCareAmt() {
        return homeCommunityBasedCareAmt;
    }

    @JsonProperty("HomeCommunityBasedCareAmt")
    public void setHomeCommunityBasedCareAmt(Integer homeCommunityBasedCareAmt) {
        this.homeCommunityBasedCareAmt = homeCommunityBasedCareAmt;
    }

    public Rider withHomeCommunityBasedCareAmt(Integer homeCommunityBasedCareAmt) {
        this.homeCommunityBasedCareAmt = homeCommunityBasedCareAmt;
        return this;
    }

    @JsonProperty("InitialPremAmt")
    public Integer getInitialPremAmt() {
        return initialPremAmt;
    }

    @JsonProperty("InitialPremAmt")
    public void setInitialPremAmt(Integer initialPremAmt) {
        this.initialPremAmt = initialPremAmt;
    }

    public Rider withInitialPremAmt(Integer initialPremAmt) {
        this.initialPremAmt = initialPremAmt;
        return this;
    }

    @JsonProperty("BenefitPct")
    public Integer getBenefitPct() {
        return benefitPct;
    }

    @JsonProperty("BenefitPct")
    public void setBenefitPct(Integer benefitPct) {
        this.benefitPct = benefitPct;
    }

    public Rider withBenefitPct(Integer benefitPct) {
        this.benefitPct = benefitPct;
        return this;
    }

    @JsonProperty("EliminationPeriod")
    public EliminationPeriod getEliminationPeriod() {
        return eliminationPeriod;
    }

    @JsonProperty("EliminationPeriod")
    public void setEliminationPeriod(EliminationPeriod eliminationPeriod) {
        this.eliminationPeriod = eliminationPeriod;
    }

    public Rider withEliminationPeriod(EliminationPeriod eliminationPeriod) {
        this.eliminationPeriod = eliminationPeriod;
        return this;
    }

    @JsonProperty("RequiredHospitalPeriod")
    public Integer getRequiredHospitalPeriod() {
        return requiredHospitalPeriod;
    }

    @JsonProperty("RequiredHospitalPeriod")
    public void setRequiredHospitalPeriod(Integer requiredHospitalPeriod) {
        this.requiredHospitalPeriod = requiredHospitalPeriod;
    }

    public Rider withRequiredHospitalPeriod(Integer requiredHospitalPeriod) {
        this.requiredHospitalPeriod = requiredHospitalPeriod;
        return this;
    }

    @JsonProperty("AddlHospitalPeriod")
    public Integer getAddlHospitalPeriod() {
        return addlHospitalPeriod;
    }

    @JsonProperty("AddlHospitalPeriod")
    public void setAddlHospitalPeriod(Integer addlHospitalPeriod) {
        this.addlHospitalPeriod = addlHospitalPeriod;
    }

    public Rider withAddlHospitalPeriod(Integer addlHospitalPeriod) {
        this.addlHospitalPeriod = addlHospitalPeriod;
        return this;
    }

    @JsonProperty("ProductCode")
    public String getProductCode() {
        return productCode;
    }

    @JsonProperty("ProductCode")
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Rider withProductCode(String productCode) {
        this.productCode = productCode;
        return this;
    }

    @JsonProperty("RiderCategory")
    public RiderCategory getRiderCategory() {
        return riderCategory;
    }

    @JsonProperty("RiderCategory")
    public void setRiderCategory(RiderCategory riderCategory) {
        this.riderCategory = riderCategory;
    }

    public Rider withRiderCategory(RiderCategory riderCategory) {
        this.riderCategory = riderCategory;
        return this;
    }

    @JsonProperty("CommissionLink")
    public String getCommissionLink() {
        return commissionLink;
    }

    @JsonProperty("CommissionLink")
    public void setCommissionLink(String commissionLink) {
        this.commissionLink = commissionLink;
    }

    public Rider withCommissionLink(String commissionLink) {
        this.commissionLink = commissionLink;
        return this;
    }

    @JsonProperty("CovNumber")
    public String getCovNumber() {
        return covNumber;
    }

    @JsonProperty("CovNumber")
    public void setCovNumber(String covNumber) {
        this.covNumber = covNumber;
    }

    public Rider withCovNumber(String covNumber) {
        this.covNumber = covNumber;
        return this;
    }

    @JsonProperty("ValuationClassType")
    public ValuationClassType getValuationClassType() {
        return valuationClassType;
    }

    @JsonProperty("ValuationClassType")
    public void setValuationClassType(ValuationClassType valuationClassType) {
        this.valuationClassType = valuationClassType;
    }

    public Rider withValuationClassType(ValuationClassType valuationClassType) {
        this.valuationClassType = valuationClassType;
        return this;
    }

    @JsonProperty("ValuationBaseSeries")
    public String getValuationBaseSeries() {
        return valuationBaseSeries;
    }

    @JsonProperty("ValuationBaseSeries")
    public void setValuationBaseSeries(String valuationBaseSeries) {
        this.valuationBaseSeries = valuationBaseSeries;
    }

    public Rider withValuationBaseSeries(String valuationBaseSeries) {
        this.valuationBaseSeries = valuationBaseSeries;
        return this;
    }

    @JsonProperty("ValuationSubSeries")
    public String getValuationSubSeries() {
        return valuationSubSeries;
    }

    @JsonProperty("ValuationSubSeries")
    public void setValuationSubSeries(String valuationSubSeries) {
        this.valuationSubSeries = valuationSubSeries;
    }

    public Rider withValuationSubSeries(String valuationSubSeries) {
        this.valuationSubSeries = valuationSubSeries;
        return this;
    }

    @JsonProperty("PaidUpDate")
    public String getPaidUpDate() {
        return paidUpDate;
    }

    @JsonProperty("PaidUpDate")
    public void setPaidUpDate(String paidUpDate) {
        this.paidUpDate = paidUpDate;
    }

    public Rider withPaidUpDate(String paidUpDate) {
        this.paidUpDate = paidUpDate;
        return this;
    }

    @JsonProperty("ReserveFunction")
    public ReserveFunction getReserveFunction() {
        return reserveFunction;
    }

    @JsonProperty("ReserveFunction")
    public void setReserveFunction(ReserveFunction reserveFunction) {
        this.reserveFunction = reserveFunction;
    }

    public Rider withReserveFunction(ReserveFunction reserveFunction) {
        this.reserveFunction = reserveFunction;
        return this;
    }

    @JsonProperty("ReserveIntRate")
    public Integer getReserveIntRate() {
        return reserveIntRate;
    }

    @JsonProperty("ReserveIntRate")
    public void setReserveIntRate(Integer reserveIntRate) {
        this.reserveIntRate = reserveIntRate;
    }

    public Rider withReserveIntRate(Integer reserveIntRate) {
        this.reserveIntRate = reserveIntRate;
        return this;
    }

    @JsonProperty("ReserveMethod")
    public ReserveMethod getReserveMethod() {
        return reserveMethod;
    }

    @JsonProperty("ReserveMethod")
    public void setReserveMethod(ReserveMethod reserveMethod) {
        this.reserveMethod = reserveMethod;
    }

    public Rider withReserveMethod(ReserveMethod reserveMethod) {
        this.reserveMethod = reserveMethod;
        return this;
    }

    @JsonProperty("MortalityOrMorbidityTable")
    public MortalityOrMorbidityTable getMortalityOrMorbidityTable() {
        return mortalityOrMorbidityTable;
    }

    @JsonProperty("MortalityOrMorbidityTable")
    public void setMortalityOrMorbidityTable(MortalityOrMorbidityTable mortalityOrMorbidityTable) {
        this.mortalityOrMorbidityTable = mortalityOrMorbidityTable;
    }

    public Rider withMortalityOrMorbidityTable(MortalityOrMorbidityTable mortalityOrMorbidityTable) {
        this.mortalityOrMorbidityTable = mortalityOrMorbidityTable;
        return this;
    }

    @JsonProperty("SalaryPct")
    public Integer getSalaryPct() {
        return salaryPct;
    }

    @JsonProperty("SalaryPct")
    public void setSalaryPct(Integer salaryPct) {
        this.salaryPct = salaryPct;
    }

    public Rider withSalaryPct(Integer salaryPct) {
        this.salaryPct = salaryPct;
        return this;
    }

    @JsonProperty("ShortName")
    public String getShortName() {
        return shortName;
    }

    @JsonProperty("ShortName")
    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public Rider withShortName(String shortName) {
        this.shortName = shortName;
        return this;
    }

    @JsonProperty("MarketingName")
    public String getMarketingName() {
        return marketingName;
    }

    @JsonProperty("MarketingName")
    public void setMarketingName(String marketingName) {
        this.marketingName = marketingName;
    }

    public Rider withMarketingName(String marketingName) {
        this.marketingName = marketingName;
        return this;
    }

    @JsonProperty("ExpiryDate")
    public String getExpiryDate() {
        return expiryDate;
    }

    @JsonProperty("ExpiryDate")
    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Rider withExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
        return this;
    }

    @JsonProperty("CarrierAdminSystem")
    public String getCarrierAdminSystem() {
        return carrierAdminSystem;
    }

    @JsonProperty("CarrierAdminSystem")
    public void setCarrierAdminSystem(String carrierAdminSystem) {
        this.carrierAdminSystem = carrierAdminSystem;
    }

    public Rider withCarrierAdminSystem(String carrierAdminSystem) {
        this.carrierAdminSystem = carrierAdminSystem;
        return this;
    }

    @JsonProperty("Purpose")
    public Purpose getPurpose() {
        return purpose;
    }

    @JsonProperty("Purpose")
    public void setPurpose(Purpose purpose) {
        this.purpose = purpose;
    }

    public Rider withPurpose(Purpose purpose) {
        this.purpose = purpose;
        return this;
    }

    @JsonProperty("RenewableInd")
    public RenewableInd getRenewableInd() {
        return renewableInd;
    }

    @JsonProperty("RenewableInd")
    public void setRenewableInd(RenewableInd renewableInd) {
        this.renewableInd = renewableInd;
    }

    public Rider withRenewableInd(RenewableInd renewableInd) {
        this.renewableInd = renewableInd;
        return this;
    }

    @JsonProperty("Duration")
    public Integer getDuration() {
        return duration;
    }

    @JsonProperty("Duration")
    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Rider withDuration(Integer duration) {
        this.duration = duration;
        return this;
    }

    @JsonProperty("LastPaidAmt")
    public Integer getLastPaidAmt() {
        return lastPaidAmt;
    }

    @JsonProperty("LastPaidAmt")
    public void setLastPaidAmt(Integer lastPaidAmt) {
        this.lastPaidAmt = lastPaidAmt;
    }

    public Rider withLastPaidAmt(Integer lastPaidAmt) {
        this.lastPaidAmt = lastPaidAmt;
        return this;
    }

    @JsonProperty("LastPaidDate")
    public String getLastPaidDate() {
        return lastPaidDate;
    }

    @JsonProperty("LastPaidDate")
    public void setLastPaidDate(String lastPaidDate) {
        this.lastPaidDate = lastPaidDate;
    }

    public Rider withLastPaidDate(String lastPaidDate) {
        this.lastPaidDate = lastPaidDate;
        return this;
    }

    @JsonProperty("PreExistingConditionInd")
    public PreExistingConditionInd getPreExistingConditionInd() {
        return preExistingConditionInd;
    }

    @JsonProperty("PreExistingConditionInd")
    public void setPreExistingConditionInd(PreExistingConditionInd preExistingConditionInd) {
        this.preExistingConditionInd = preExistingConditionInd;
    }

    public Rider withPreExistingConditionInd(PreExistingConditionInd preExistingConditionInd) {
        this.preExistingConditionInd = preExistingConditionInd;
        return this;
    }

    @JsonProperty("ChildMatureAge")
    public Integer getChildMatureAge() {
        return childMatureAge;
    }

    @JsonProperty("ChildMatureAge")
    public void setChildMatureAge(Integer childMatureAge) {
        this.childMatureAge = childMatureAge;
    }

    public Rider withChildMatureAge(Integer childMatureAge) {
        this.childMatureAge = childMatureAge;
        return this;
    }

    @JsonProperty("ChildAgeUse")
    public ChildAgeUse getChildAgeUse() {
        return childAgeUse;
    }

    @JsonProperty("ChildAgeUse")
    public void setChildAgeUse(ChildAgeUse childAgeUse) {
        this.childAgeUse = childAgeUse;
    }

    public Rider withChildAgeUse(ChildAgeUse childAgeUse) {
        this.childAgeUse = childAgeUse;
        return this;
    }

    @JsonProperty("BenefitCoordinationInd")
    public BenefitCoordinationInd getBenefitCoordinationInd() {
        return benefitCoordinationInd;
    }

    @JsonProperty("BenefitCoordinationInd")
    public void setBenefitCoordinationInd(BenefitCoordinationInd benefitCoordinationInd) {
        this.benefitCoordinationInd = benefitCoordinationInd;
    }

    public Rider withBenefitCoordinationInd(BenefitCoordinationInd benefitCoordinationInd) {
        this.benefitCoordinationInd = benefitCoordinationInd;
        return this;
    }

    @JsonProperty("PolicyExhibitStatus")
    public PolicyExhibitStatus getPolicyExhibitStatus() {
        return policyExhibitStatus;
    }

    @JsonProperty("PolicyExhibitStatus")
    public void setPolicyExhibitStatus(PolicyExhibitStatus policyExhibitStatus) {
        this.policyExhibitStatus = policyExhibitStatus;
    }

    public Rider withPolicyExhibitStatus(PolicyExhibitStatus policyExhibitStatus) {
        this.policyExhibitStatus = policyExhibitStatus;
        return this;
    }

    @JsonProperty("FeatureName")
    public String getFeatureName() {
        return featureName;
    }

    @JsonProperty("FeatureName")
    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public Rider withFeatureName(String featureName) {
        this.featureName = featureName;
        return this;
    }

    @JsonProperty("ERContribAmt")
    public Integer getERContribAmt() {
        return eRContribAmt;
    }

    @JsonProperty("ERContribAmt")
    public void setERContribAmt(Integer eRContribAmt) {
        this.eRContribAmt = eRContribAmt;
    }

    public Rider withERContribAmt(Integer eRContribAmt) {
        this.eRContribAmt = eRContribAmt;
        return this;
    }

    @JsonProperty("EEContribAmt")
    public Integer getEEContribAmt() {
        return eEContribAmt;
    }

    @JsonProperty("EEContribAmt")
    public void setEEContribAmt(Integer eEContribAmt) {
        this.eEContribAmt = eEContribAmt;
    }

    public Rider withEEContribAmt(Integer eEContribAmt) {
        this.eEContribAmt = eEContribAmt;
        return this;
    }

    @JsonProperty("ERContribPct")
    public Integer getERContribPct() {
        return eRContribPct;
    }

    @JsonProperty("ERContribPct")
    public void setERContribPct(Integer eRContribPct) {
        this.eRContribPct = eRContribPct;
    }

    public Rider withERContribPct(Integer eRContribPct) {
        this.eRContribPct = eRContribPct;
        return this;
    }

    @JsonProperty("EEContribPct")
    public Integer getEEContribPct() {
        return eEContribPct;
    }

    @JsonProperty("EEContribPct")
    public void setEEContribPct(Integer eEContribPct) {
        this.eEContribPct = eEContribPct;
    }

    public Rider withEEContribPct(Integer eEContribPct) {
        this.eEContribPct = eEContribPct;
        return this;
    }

    @JsonProperty("EventType")
    public EventType getEventType() {
        return eventType;
    }

    @JsonProperty("EventType")
    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public Rider withEventType(EventType eventType) {
        this.eventType = eventType;
        return this;
    }

    @JsonProperty("EventYear")
    public Integer getEventYear() {
        return eventYear;
    }

    @JsonProperty("EventYear")
    public void setEventYear(Integer eventYear) {
        this.eventYear = eventYear;
    }

    public Rider withEventYear(Integer eventYear) {
        this.eventYear = eventYear;
        return this;
    }

    @JsonProperty("EstTargetAge")
    public Integer getEstTargetAge() {
        return estTargetAge;
    }

    @JsonProperty("EstTargetAge")
    public void setEstTargetAge(Integer estTargetAge) {
        this.estTargetAge = estTargetAge;
    }

    public Rider withEstTargetAge(Integer estTargetAge) {
        this.estTargetAge = estTargetAge;
        return this;
    }

    @JsonProperty("RiderFreeAmt")
    public Integer getRiderFreeAmt() {
        return riderFreeAmt;
    }

    @JsonProperty("RiderFreeAmt")
    public void setRiderFreeAmt(Integer riderFreeAmt) {
        this.riderFreeAmt = riderFreeAmt;
    }

    public Rider withRiderFreeAmt(Integer riderFreeAmt) {
        this.riderFreeAmt = riderFreeAmt;
        return this;
    }

    @JsonProperty("BenefitLimit")
    public List<Object> getBenefitLimit() {
        return benefitLimit;
    }

    @JsonProperty("BenefitLimit")
    public void setBenefitLimit(List<Object> benefitLimit) {
        this.benefitLimit = benefitLimit;
    }

    public Rider withBenefitLimit(List<Object> benefitLimit) {
        this.benefitLimit = benefitLimit;
        return this;
    }

    @JsonProperty("ReinsuranceInfo")
    public List<Object> getReinsuranceInfo() {
        return reinsuranceInfo;
    }

    @JsonProperty("ReinsuranceInfo")
    public void setReinsuranceInfo(List<Object> reinsuranceInfo) {
        this.reinsuranceInfo = reinsuranceInfo;
    }

    public Rider withReinsuranceInfo(List<Object> reinsuranceInfo) {
        this.reinsuranceInfo = reinsuranceInfo;
        return this;
    }

    @JsonProperty("Participant")
    public List<Object> getParticipant() {
        return participant;
    }

    @JsonProperty("Participant")
    public void setParticipant(List<Object> participant) {
        this.participant = participant;
    }

    public Rider withParticipant(List<Object> participant) {
        this.participant = participant;
        return this;
    }

    @JsonProperty("CovOption")
    public List<Object> getCovOption() {
        return covOption;
    }

    @JsonProperty("CovOption")
    public void setCovOption(List<Object> covOption) {
        this.covOption = covOption;
    }

    public Rider withCovOption(List<Object> covOption) {
        this.covOption = covOption;
        return this;
    }

    @JsonProperty("Fee")
    public List<Object> getFee() {
        return fee;
    }

    @JsonProperty("Fee")
    public void setFee(List<Object> fee) {
        this.fee = fee;
    }

    public Rider withFee(List<Object> fee) {
        this.fee = fee;
        return this;
    }

    @JsonProperty("AmountProduct")
    public List<Object> getAmountProduct() {
        return amountProduct;
    }

    @JsonProperty("AmountProduct")
    public void setAmountProduct(List<Object> amountProduct) {
        this.amountProduct = amountProduct;
    }

    public Rider withAmountProduct(List<Object> amountProduct) {
        this.amountProduct = amountProduct;
        return this;
    }

    @JsonProperty("DeductionOption")
    public List<Object> getDeductionOption() {
        return deductionOption;
    }

    @JsonProperty("DeductionOption")
    public void setDeductionOption(List<Object> deductionOption) {
        this.deductionOption = deductionOption;
    }

    public Rider withDeductionOption(List<Object> deductionOption) {
        this.deductionOption = deductionOption;
        return this;
    }

    @JsonProperty("RestrictionInfo")
    public List<Object> getRestrictionInfo() {
        return restrictionInfo;
    }

    @JsonProperty("RestrictionInfo")
    public void setRestrictionInfo(List<Object> restrictionInfo) {
        this.restrictionInfo = restrictionInfo;
    }

    public Rider withRestrictionInfo(List<Object> restrictionInfo) {
        this.restrictionInfo = restrictionInfo;
        return this;
    }

    @JsonProperty("AdditionalRiderClassification")
    public List<Object> getAdditionalRiderClassification() {
        return additionalRiderClassification;
    }

    @JsonProperty("AdditionalRiderClassification")
    public void setAdditionalRiderClassification(List<Object> additionalRiderClassification) {
        this.additionalRiderClassification = additionalRiderClassification;
    }

    public Rider withAdditionalRiderClassification(List<Object> additionalRiderClassification) {
        this.additionalRiderClassification = additionalRiderClassification;
        return this;
    }

    @JsonProperty("Attachment")
    public List<Object> getAttachment() {
        return attachment;
    }

    @JsonProperty("Attachment")
    public void setAttachment(List<Object> attachment) {
        this.attachment = attachment;
    }

    public Rider withAttachment(List<Object> attachment) {
        this.attachment = attachment;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public Rider withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public Rider withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public Rider withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Rider withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Rider.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("riderKey");
        sb.append('=');
        sb.append(((this.riderKey == null)?"<null>":this.riderKey));
        sb.append(',');
        sb.append("riderSysKey");
        sb.append('=');
        sb.append(((this.riderSysKey == null)?"<null>":this.riderSysKey));
        sb.append(',');
        sb.append("riderTypeCode");
        sb.append('=');
        sb.append(((this.riderTypeCode == null)?"<null>":this.riderTypeCode));
        sb.append(',');
        sb.append("riderSubTypeCode");
        sb.append('=');
        sb.append(((this.riderSubTypeCode == null)?"<null>":this.riderSubTypeCode));
        sb.append(',');
        sb.append("description");
        sb.append('=');
        sb.append(((this.description == null)?"<null>":this.description));
        sb.append(',');
        sb.append("riderCode");
        sb.append('=');
        sb.append(((this.riderCode == null)?"<null>":this.riderCode));
        sb.append(',');
        sb.append("productVersionCode");
        sb.append('=');
        sb.append(((this.productVersionCode == null)?"<null>":this.productVersionCode));
        sb.append(',');
        sb.append("waiverSignal");
        sb.append('=');
        sb.append(((this.waiverSignal == null)?"<null>":this.waiverSignal));
        sb.append(',');
        sb.append("riderStatus");
        sb.append('=');
        sb.append(((this.riderStatus == null)?"<null>":this.riderStatus));
        sb.append(',');
        sb.append("statusReason");
        sb.append('=');
        sb.append(((this.statusReason == null)?"<null>":this.statusReason));
        sb.append(',');
        sb.append("effDate");
        sb.append('=');
        sb.append(((this.effDate == null)?"<null>":this.effDate));
        sb.append(',');
        sb.append("issueDate");
        sb.append('=');
        sb.append(((this.issueDate == null)?"<null>":this.issueDate));
        sb.append(',');
        sb.append("termDate");
        sb.append('=');
        sb.append(((this.termDate == null)?"<null>":this.termDate));
        sb.append(',');
        sb.append("totAmt");
        sb.append('=');
        sb.append(((this.totAmt == null)?"<null>":this.totAmt));
        sb.append(',');
        sb.append("totAmtLastAnn");
        sb.append('=');
        sb.append(((this.totAmtLastAnn == null)?"<null>":this.totAmtLastAnn));
        sb.append(',');
        sb.append("deductAmt");
        sb.append('=');
        sb.append(((this.deductAmt == null)?"<null>":this.deductAmt));
        sb.append(',');
        sb.append("periodicAmt");
        sb.append('=');
        sb.append(((this.periodicAmt == null)?"<null>":this.periodicAmt));
        sb.append(',');
        sb.append("periodicMode");
        sb.append('=');
        sb.append(((this.periodicMode == null)?"<null>":this.periodicMode));
        sb.append(',');
        sb.append("paymentAmt");
        sb.append('=');
        sb.append(((this.paymentAmt == null)?"<null>":this.paymentAmt));
        sb.append(',');
        sb.append("benefitPeriod");
        sb.append('=');
        sb.append(((this.benefitPeriod == null)?"<null>":this.benefitPeriod));
        sb.append(',');
        sb.append("benefitMode");
        sb.append('=');
        sb.append(((this.benefitMode == null)?"<null>":this.benefitMode));
        sb.append(',');
        sb.append("numberOfUnits");
        sb.append('=');
        sb.append(((this.numberOfUnits == null)?"<null>":this.numberOfUnits));
        sb.append(',');
        sb.append("formNo");
        sb.append('=');
        sb.append(((this.formNo == null)?"<null>":this.formNo));
        sb.append(',');
        sb.append("filedFormNumber");
        sb.append('=');
        sb.append(((this.filedFormNumber == null)?"<null>":this.filedFormNumber));
        sb.append(',');
        sb.append("nursingCareDailyBenefitPct");
        sb.append('=');
        sb.append(((this.nursingCareDailyBenefitPct == null)?"<null>":this.nursingCareDailyBenefitPct));
        sb.append(',');
        sb.append("homeCommunityBasedCarePct");
        sb.append('=');
        sb.append(((this.homeCommunityBasedCarePct == null)?"<null>":this.homeCommunityBasedCarePct));
        sb.append(',');
        sb.append("nursingCareDailyBenefitAmt");
        sb.append('=');
        sb.append(((this.nursingCareDailyBenefitAmt == null)?"<null>":this.nursingCareDailyBenefitAmt));
        sb.append(',');
        sb.append("homeCommunityBasedCareAmt");
        sb.append('=');
        sb.append(((this.homeCommunityBasedCareAmt == null)?"<null>":this.homeCommunityBasedCareAmt));
        sb.append(',');
        sb.append("initialPremAmt");
        sb.append('=');
        sb.append(((this.initialPremAmt == null)?"<null>":this.initialPremAmt));
        sb.append(',');
        sb.append("benefitPct");
        sb.append('=');
        sb.append(((this.benefitPct == null)?"<null>":this.benefitPct));
        sb.append(',');
        sb.append("eliminationPeriod");
        sb.append('=');
        sb.append(((this.eliminationPeriod == null)?"<null>":this.eliminationPeriod));
        sb.append(',');
        sb.append("requiredHospitalPeriod");
        sb.append('=');
        sb.append(((this.requiredHospitalPeriod == null)?"<null>":this.requiredHospitalPeriod));
        sb.append(',');
        sb.append("addlHospitalPeriod");
        sb.append('=');
        sb.append(((this.addlHospitalPeriod == null)?"<null>":this.addlHospitalPeriod));
        sb.append(',');
        sb.append("productCode");
        sb.append('=');
        sb.append(((this.productCode == null)?"<null>":this.productCode));
        sb.append(',');
        sb.append("riderCategory");
        sb.append('=');
        sb.append(((this.riderCategory == null)?"<null>":this.riderCategory));
        sb.append(',');
        sb.append("commissionLink");
        sb.append('=');
        sb.append(((this.commissionLink == null)?"<null>":this.commissionLink));
        sb.append(',');
        sb.append("covNumber");
        sb.append('=');
        sb.append(((this.covNumber == null)?"<null>":this.covNumber));
        sb.append(',');
        sb.append("valuationClassType");
        sb.append('=');
        sb.append(((this.valuationClassType == null)?"<null>":this.valuationClassType));
        sb.append(',');
        sb.append("valuationBaseSeries");
        sb.append('=');
        sb.append(((this.valuationBaseSeries == null)?"<null>":this.valuationBaseSeries));
        sb.append(',');
        sb.append("valuationSubSeries");
        sb.append('=');
        sb.append(((this.valuationSubSeries == null)?"<null>":this.valuationSubSeries));
        sb.append(',');
        sb.append("paidUpDate");
        sb.append('=');
        sb.append(((this.paidUpDate == null)?"<null>":this.paidUpDate));
        sb.append(',');
        sb.append("reserveFunction");
        sb.append('=');
        sb.append(((this.reserveFunction == null)?"<null>":this.reserveFunction));
        sb.append(',');
        sb.append("reserveIntRate");
        sb.append('=');
        sb.append(((this.reserveIntRate == null)?"<null>":this.reserveIntRate));
        sb.append(',');
        sb.append("reserveMethod");
        sb.append('=');
        sb.append(((this.reserveMethod == null)?"<null>":this.reserveMethod));
        sb.append(',');
        sb.append("mortalityOrMorbidityTable");
        sb.append('=');
        sb.append(((this.mortalityOrMorbidityTable == null)?"<null>":this.mortalityOrMorbidityTable));
        sb.append(',');
        sb.append("salaryPct");
        sb.append('=');
        sb.append(((this.salaryPct == null)?"<null>":this.salaryPct));
        sb.append(',');
        sb.append("shortName");
        sb.append('=');
        sb.append(((this.shortName == null)?"<null>":this.shortName));
        sb.append(',');
        sb.append("marketingName");
        sb.append('=');
        sb.append(((this.marketingName == null)?"<null>":this.marketingName));
        sb.append(',');
        sb.append("expiryDate");
        sb.append('=');
        sb.append(((this.expiryDate == null)?"<null>":this.expiryDate));
        sb.append(',');
        sb.append("carrierAdminSystem");
        sb.append('=');
        sb.append(((this.carrierAdminSystem == null)?"<null>":this.carrierAdminSystem));
        sb.append(',');
        sb.append("purpose");
        sb.append('=');
        sb.append(((this.purpose == null)?"<null>":this.purpose));
        sb.append(',');
        sb.append("renewableInd");
        sb.append('=');
        sb.append(((this.renewableInd == null)?"<null>":this.renewableInd));
        sb.append(',');
        sb.append("duration");
        sb.append('=');
        sb.append(((this.duration == null)?"<null>":this.duration));
        sb.append(',');
        sb.append("lastPaidAmt");
        sb.append('=');
        sb.append(((this.lastPaidAmt == null)?"<null>":this.lastPaidAmt));
        sb.append(',');
        sb.append("lastPaidDate");
        sb.append('=');
        sb.append(((this.lastPaidDate == null)?"<null>":this.lastPaidDate));
        sb.append(',');
        sb.append("preExistingConditionInd");
        sb.append('=');
        sb.append(((this.preExistingConditionInd == null)?"<null>":this.preExistingConditionInd));
        sb.append(',');
        sb.append("childMatureAge");
        sb.append('=');
        sb.append(((this.childMatureAge == null)?"<null>":this.childMatureAge));
        sb.append(',');
        sb.append("childAgeUse");
        sb.append('=');
        sb.append(((this.childAgeUse == null)?"<null>":this.childAgeUse));
        sb.append(',');
        sb.append("benefitCoordinationInd");
        sb.append('=');
        sb.append(((this.benefitCoordinationInd == null)?"<null>":this.benefitCoordinationInd));
        sb.append(',');
        sb.append("policyExhibitStatus");
        sb.append('=');
        sb.append(((this.policyExhibitStatus == null)?"<null>":this.policyExhibitStatus));
        sb.append(',');
        sb.append("featureName");
        sb.append('=');
        sb.append(((this.featureName == null)?"<null>":this.featureName));
        sb.append(',');
        sb.append("eRContribAmt");
        sb.append('=');
        sb.append(((this.eRContribAmt == null)?"<null>":this.eRContribAmt));
        sb.append(',');
        sb.append("eEContribAmt");
        sb.append('=');
        sb.append(((this.eEContribAmt == null)?"<null>":this.eEContribAmt));
        sb.append(',');
        sb.append("eRContribPct");
        sb.append('=');
        sb.append(((this.eRContribPct == null)?"<null>":this.eRContribPct));
        sb.append(',');
        sb.append("eEContribPct");
        sb.append('=');
        sb.append(((this.eEContribPct == null)?"<null>":this.eEContribPct));
        sb.append(',');
        sb.append("eventType");
        sb.append('=');
        sb.append(((this.eventType == null)?"<null>":this.eventType));
        sb.append(',');
        sb.append("eventYear");
        sb.append('=');
        sb.append(((this.eventYear == null)?"<null>":this.eventYear));
        sb.append(',');
        sb.append("estTargetAge");
        sb.append('=');
        sb.append(((this.estTargetAge == null)?"<null>":this.estTargetAge));
        sb.append(',');
        sb.append("riderFreeAmt");
        sb.append('=');
        sb.append(((this.riderFreeAmt == null)?"<null>":this.riderFreeAmt));
        sb.append(',');
        sb.append("benefitLimit");
        sb.append('=');
        sb.append(((this.benefitLimit == null)?"<null>":this.benefitLimit));
        sb.append(',');
        sb.append("reinsuranceInfo");
        sb.append('=');
        sb.append(((this.reinsuranceInfo == null)?"<null>":this.reinsuranceInfo));
        sb.append(',');
        sb.append("participant");
        sb.append('=');
        sb.append(((this.participant == null)?"<null>":this.participant));
        sb.append(',');
        sb.append("covOption");
        sb.append('=');
        sb.append(((this.covOption == null)?"<null>":this.covOption));
        sb.append(',');
        sb.append("fee");
        sb.append('=');
        sb.append(((this.fee == null)?"<null>":this.fee));
        sb.append(',');
        sb.append("amountProduct");
        sb.append('=');
        sb.append(((this.amountProduct == null)?"<null>":this.amountProduct));
        sb.append(',');
        sb.append("deductionOption");
        sb.append('=');
        sb.append(((this.deductionOption == null)?"<null>":this.deductionOption));
        sb.append(',');
        sb.append("restrictionInfo");
        sb.append('=');
        sb.append(((this.restrictionInfo == null)?"<null>":this.restrictionInfo));
        sb.append(',');
        sb.append("additionalRiderClassification");
        sb.append('=');
        sb.append(((this.additionalRiderClassification == null)?"<null>":this.additionalRiderClassification));
        sb.append(',');
        sb.append("attachment");
        sb.append('=');
        sb.append(((this.attachment == null)?"<null>":this.attachment));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.benefitPeriod == null)? 0 :this.benefitPeriod.hashCode()));
        result = ((result* 31)+((this.riderSubTypeCode == null)? 0 :this.riderSubTypeCode.hashCode()));
        result = ((result* 31)+((this.salaryPct == null)? 0 :this.salaryPct.hashCode()));
        result = ((result* 31)+((this.riderCode == null)? 0 :this.riderCode.hashCode()));
        result = ((result* 31)+((this.covNumber == null)? 0 :this.covNumber.hashCode()));
        result = ((result* 31)+((this.nursingCareDailyBenefitAmt == null)? 0 :this.nursingCareDailyBenefitAmt.hashCode()));
        result = ((result* 31)+((this.fee == null)? 0 :this.fee.hashCode()));
        result = ((result* 31)+((this.restrictionInfo == null)? 0 :this.restrictionInfo.hashCode()));
        result = ((result* 31)+((this.participant == null)? 0 :this.participant.hashCode()));
        result = ((result* 31)+((this.effDate == null)? 0 :this.effDate.hashCode()));
        result = ((result* 31)+((this.eRContribAmt == null)? 0 :this.eRContribAmt.hashCode()));
        result = ((result* 31)+((this.statusReason == null)? 0 :this.statusReason.hashCode()));
        result = ((result* 31)+((this.eventYear == null)? 0 :this.eventYear.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.riderKey == null)? 0 :this.riderKey.hashCode()));
        result = ((result* 31)+((this.valuationClassType == null)? 0 :this.valuationClassType.hashCode()));
        result = ((result* 31)+((this.valuationBaseSeries == null)? 0 :this.valuationBaseSeries.hashCode()));
        result = ((result* 31)+((this.eEContribPct == null)? 0 :this.eEContribPct.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.productVersionCode == null)? 0 :this.productVersionCode.hashCode()));
        result = ((result* 31)+((this.nursingCareDailyBenefitPct == null)? 0 :this.nursingCareDailyBenefitPct.hashCode()));
        result = ((result* 31)+((this.commissionLink == null)? 0 :this.commissionLink.hashCode()));
        result = ((result* 31)+((this.carrierAdminSystem == null)? 0 :this.carrierAdminSystem.hashCode()));
        result = ((result* 31)+((this.deductionOption == null)? 0 :this.deductionOption.hashCode()));
        result = ((result* 31)+((this.featureName == null)? 0 :this.featureName.hashCode()));
        result = ((result* 31)+((this.reinsuranceInfo == null)? 0 :this.reinsuranceInfo.hashCode()));
        result = ((result* 31)+((this.estTargetAge == null)? 0 :this.estTargetAge.hashCode()));
        result = ((result* 31)+((this.benefitLimit == null)? 0 :this.benefitLimit.hashCode()));
        result = ((result* 31)+((this.eventType == null)? 0 :this.eventType.hashCode()));
        result = ((result* 31)+((this.homeCommunityBasedCarePct == null)? 0 :this.homeCommunityBasedCarePct.hashCode()));
        result = ((result* 31)+((this.reserveFunction == null)? 0 :this.reserveFunction.hashCode()));
        result = ((result* 31)+((this.eRContribPct == null)? 0 :this.eRContribPct.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.termDate == null)? 0 :this.termDate.hashCode()));
        result = ((result* 31)+((this.shortName == null)? 0 :this.shortName.hashCode()));
        result = ((result* 31)+((this.eEContribAmt == null)? 0 :this.eEContribAmt.hashCode()));
        result = ((result* 31)+((this.paymentAmt == null)? 0 :this.paymentAmt.hashCode()));
        result = ((result* 31)+((this.requiredHospitalPeriod == null)? 0 :this.requiredHospitalPeriod.hashCode()));
        result = ((result* 31)+((this.eliminationPeriod == null)? 0 :this.eliminationPeriod.hashCode()));
        result = ((result* 31)+((this.riderCategory == null)? 0 :this.riderCategory.hashCode()));
        result = ((result* 31)+((this.preExistingConditionInd == null)? 0 :this.preExistingConditionInd.hashCode()));
        result = ((result* 31)+((this.homeCommunityBasedCareAmt == null)? 0 :this.homeCommunityBasedCareAmt.hashCode()));
        result = ((result* 31)+((this.purpose == null)? 0 :this.purpose.hashCode()));
        result = ((result* 31)+((this.childMatureAge == null)? 0 :this.childMatureAge.hashCode()));
        result = ((result* 31)+((this.childAgeUse == null)? 0 :this.childAgeUse.hashCode()));
        result = ((result* 31)+((this.description == null)? 0 :this.description.hashCode()));
        result = ((result* 31)+((this.riderStatus == null)? 0 :this.riderStatus.hashCode()));
        result = ((result* 31)+((this.marketingName == null)? 0 :this.marketingName.hashCode()));
        result = ((result* 31)+((this.amountProduct == null)? 0 :this.amountProduct.hashCode()));
        result = ((result* 31)+((this.periodicMode == null)? 0 :this.periodicMode.hashCode()));
        result = ((result* 31)+((this.expiryDate == null)? 0 :this.expiryDate.hashCode()));
        result = ((result* 31)+((this.renewableInd == null)? 0 :this.renewableInd.hashCode()));
        result = ((result* 31)+((this.duration == null)? 0 :this.duration.hashCode()));
        result = ((result* 31)+((this.initialPremAmt == null)? 0 :this.initialPremAmt.hashCode()));
        result = ((result* 31)+((this.lastPaidDate == null)? 0 :this.lastPaidDate.hashCode()));
        result = ((result* 31)+((this.additionalRiderClassification == null)? 0 :this.additionalRiderClassification.hashCode()));
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.deductAmt == null)? 0 :this.deductAmt.hashCode()));
        result = ((result* 31)+((this.reserveMethod == null)? 0 :this.reserveMethod.hashCode()));
        result = ((result* 31)+((this.attachment == null)? 0 :this.attachment.hashCode()));
        result = ((result* 31)+((this.filedFormNumber == null)? 0 :this.filedFormNumber.hashCode()));
        result = ((result* 31)+((this.valuationSubSeries == null)? 0 :this.valuationSubSeries.hashCode()));
        result = ((result* 31)+((this.issueDate == null)? 0 :this.issueDate.hashCode()));
        result = ((result* 31)+((this.benefitCoordinationInd == null)? 0 :this.benefitCoordinationInd.hashCode()));
        result = ((result* 31)+((this.riderTypeCode == null)? 0 :this.riderTypeCode.hashCode()));
        result = ((result* 31)+((this.lastPaidAmt == null)? 0 :this.lastPaidAmt.hashCode()));
        result = ((result* 31)+((this.paidUpDate == null)? 0 :this.paidUpDate.hashCode()));
        result = ((result* 31)+((this.periodicAmt == null)? 0 :this.periodicAmt.hashCode()));
        result = ((result* 31)+((this.mortalityOrMorbidityTable == null)? 0 :this.mortalityOrMorbidityTable.hashCode()));
        result = ((result* 31)+((this.totAmt == null)? 0 :this.totAmt.hashCode()));
        result = ((result* 31)+((this.reserveIntRate == null)? 0 :this.reserveIntRate.hashCode()));
        result = ((result* 31)+((this.benefitMode == null)? 0 :this.benefitMode.hashCode()));
        result = ((result* 31)+((this.policyExhibitStatus == null)? 0 :this.policyExhibitStatus.hashCode()));
        result = ((result* 31)+((this.waiverSignal == null)? 0 :this.waiverSignal.hashCode()));
        result = ((result* 31)+((this.numberOfUnits == null)? 0 :this.numberOfUnits.hashCode()));
        result = ((result* 31)+((this.addlHospitalPeriod == null)? 0 :this.addlHospitalPeriod.hashCode()));
        result = ((result* 31)+((this.productCode == null)? 0 :this.productCode.hashCode()));
        result = ((result* 31)+((this.benefitPct == null)? 0 :this.benefitPct.hashCode()));
        result = ((result* 31)+((this.covOption == null)? 0 :this.covOption.hashCode()));
        result = ((result* 31)+((this.formNo == null)? 0 :this.formNo.hashCode()));
        result = ((result* 31)+((this.riderFreeAmt == null)? 0 :this.riderFreeAmt.hashCode()));
        result = ((result* 31)+((this.riderSysKey == null)? 0 :this.riderSysKey.hashCode()));
        result = ((result* 31)+((this.totAmtLastAnn == null)? 0 :this.totAmtLastAnn.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Rider) == false) {
            return false;
        }
        Rider rhs = ((Rider) other);
        return ((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((this.benefitPeriod == rhs.benefitPeriod)||((this.benefitPeriod!= null)&&this.benefitPeriod.equals(rhs.benefitPeriod)))&&((this.riderSubTypeCode == rhs.riderSubTypeCode)||((this.riderSubTypeCode!= null)&&this.riderSubTypeCode.equals(rhs.riderSubTypeCode))))&&((this.salaryPct == rhs.salaryPct)||((this.salaryPct!= null)&&this.salaryPct.equals(rhs.salaryPct))))&&((this.riderCode == rhs.riderCode)||((this.riderCode!= null)&&this.riderCode.equals(rhs.riderCode))))&&((this.covNumber == rhs.covNumber)||((this.covNumber!= null)&&this.covNumber.equals(rhs.covNumber))))&&((this.nursingCareDailyBenefitAmt == rhs.nursingCareDailyBenefitAmt)||((this.nursingCareDailyBenefitAmt!= null)&&this.nursingCareDailyBenefitAmt.equals(rhs.nursingCareDailyBenefitAmt))))&&((this.fee == rhs.fee)||((this.fee!= null)&&this.fee.equals(rhs.fee))))&&((this.restrictionInfo == rhs.restrictionInfo)||((this.restrictionInfo!= null)&&this.restrictionInfo.equals(rhs.restrictionInfo))))&&((this.participant == rhs.participant)||((this.participant!= null)&&this.participant.equals(rhs.participant))))&&((this.effDate == rhs.effDate)||((this.effDate!= null)&&this.effDate.equals(rhs.effDate))))&&((this.eRContribAmt == rhs.eRContribAmt)||((this.eRContribAmt!= null)&&this.eRContribAmt.equals(rhs.eRContribAmt))))&&((this.statusReason == rhs.statusReason)||((this.statusReason!= null)&&this.statusReason.equals(rhs.statusReason))))&&((this.eventYear == rhs.eventYear)||((this.eventYear!= null)&&this.eventYear.equals(rhs.eventYear))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.riderKey == rhs.riderKey)||((this.riderKey!= null)&&this.riderKey.equals(rhs.riderKey))))&&((this.valuationClassType == rhs.valuationClassType)||((this.valuationClassType!= null)&&this.valuationClassType.equals(rhs.valuationClassType))))&&((this.valuationBaseSeries == rhs.valuationBaseSeries)||((this.valuationBaseSeries!= null)&&this.valuationBaseSeries.equals(rhs.valuationBaseSeries))))&&((this.eEContribPct == rhs.eEContribPct)||((this.eEContribPct!= null)&&this.eEContribPct.equals(rhs.eEContribPct))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.productVersionCode == rhs.productVersionCode)||((this.productVersionCode!= null)&&this.productVersionCode.equals(rhs.productVersionCode))))&&((this.nursingCareDailyBenefitPct == rhs.nursingCareDailyBenefitPct)||((this.nursingCareDailyBenefitPct!= null)&&this.nursingCareDailyBenefitPct.equals(rhs.nursingCareDailyBenefitPct))))&&((this.commissionLink == rhs.commissionLink)||((this.commissionLink!= null)&&this.commissionLink.equals(rhs.commissionLink))))&&((this.carrierAdminSystem == rhs.carrierAdminSystem)||((this.carrierAdminSystem!= null)&&this.carrierAdminSystem.equals(rhs.carrierAdminSystem))))&&((this.deductionOption == rhs.deductionOption)||((this.deductionOption!= null)&&this.deductionOption.equals(rhs.deductionOption))))&&((this.featureName == rhs.featureName)||((this.featureName!= null)&&this.featureName.equals(rhs.featureName))))&&((this.reinsuranceInfo == rhs.reinsuranceInfo)||((this.reinsuranceInfo!= null)&&this.reinsuranceInfo.equals(rhs.reinsuranceInfo))))&&((this.estTargetAge == rhs.estTargetAge)||((this.estTargetAge!= null)&&this.estTargetAge.equals(rhs.estTargetAge))))&&((this.benefitLimit == rhs.benefitLimit)||((this.benefitLimit!= null)&&this.benefitLimit.equals(rhs.benefitLimit))))&&((this.eventType == rhs.eventType)||((this.eventType!= null)&&this.eventType.equals(rhs.eventType))))&&((this.homeCommunityBasedCarePct == rhs.homeCommunityBasedCarePct)||((this.homeCommunityBasedCarePct!= null)&&this.homeCommunityBasedCarePct.equals(rhs.homeCommunityBasedCarePct))))&&((this.reserveFunction == rhs.reserveFunction)||((this.reserveFunction!= null)&&this.reserveFunction.equals(rhs.reserveFunction))))&&((this.eRContribPct == rhs.eRContribPct)||((this.eRContribPct!= null)&&this.eRContribPct.equals(rhs.eRContribPct))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.termDate == rhs.termDate)||((this.termDate!= null)&&this.termDate.equals(rhs.termDate))))&&((this.shortName == rhs.shortName)||((this.shortName!= null)&&this.shortName.equals(rhs.shortName))))&&((this.eEContribAmt == rhs.eEContribAmt)||((this.eEContribAmt!= null)&&this.eEContribAmt.equals(rhs.eEContribAmt))))&&((this.paymentAmt == rhs.paymentAmt)||((this.paymentAmt!= null)&&this.paymentAmt.equals(rhs.paymentAmt))))&&((this.requiredHospitalPeriod == rhs.requiredHospitalPeriod)||((this.requiredHospitalPeriod!= null)&&this.requiredHospitalPeriod.equals(rhs.requiredHospitalPeriod))))&&((this.eliminationPeriod == rhs.eliminationPeriod)||((this.eliminationPeriod!= null)&&this.eliminationPeriod.equals(rhs.eliminationPeriod))))&&((this.riderCategory == rhs.riderCategory)||((this.riderCategory!= null)&&this.riderCategory.equals(rhs.riderCategory))))&&((this.preExistingConditionInd == rhs.preExistingConditionInd)||((this.preExistingConditionInd!= null)&&this.preExistingConditionInd.equals(rhs.preExistingConditionInd))))&&((this.homeCommunityBasedCareAmt == rhs.homeCommunityBasedCareAmt)||((this.homeCommunityBasedCareAmt!= null)&&this.homeCommunityBasedCareAmt.equals(rhs.homeCommunityBasedCareAmt))))&&((this.purpose == rhs.purpose)||((this.purpose!= null)&&this.purpose.equals(rhs.purpose))))&&((this.childMatureAge == rhs.childMatureAge)||((this.childMatureAge!= null)&&this.childMatureAge.equals(rhs.childMatureAge))))&&((this.childAgeUse == rhs.childAgeUse)||((this.childAgeUse!= null)&&this.childAgeUse.equals(rhs.childAgeUse))))&&((this.description == rhs.description)||((this.description!= null)&&this.description.equals(rhs.description))))&&((this.riderStatus == rhs.riderStatus)||((this.riderStatus!= null)&&this.riderStatus.equals(rhs.riderStatus))))&&((this.marketingName == rhs.marketingName)||((this.marketingName!= null)&&this.marketingName.equals(rhs.marketingName))))&&((this.amountProduct == rhs.amountProduct)||((this.amountProduct!= null)&&this.amountProduct.equals(rhs.amountProduct))))&&((this.periodicMode == rhs.periodicMode)||((this.periodicMode!= null)&&this.periodicMode.equals(rhs.periodicMode))))&&((this.expiryDate == rhs.expiryDate)||((this.expiryDate!= null)&&this.expiryDate.equals(rhs.expiryDate))))&&((this.renewableInd == rhs.renewableInd)||((this.renewableInd!= null)&&this.renewableInd.equals(rhs.renewableInd))))&&((this.duration == rhs.duration)||((this.duration!= null)&&this.duration.equals(rhs.duration))))&&((this.initialPremAmt == rhs.initialPremAmt)||((this.initialPremAmt!= null)&&this.initialPremAmt.equals(rhs.initialPremAmt))))&&((this.lastPaidDate == rhs.lastPaidDate)||((this.lastPaidDate!= null)&&this.lastPaidDate.equals(rhs.lastPaidDate))))&&((this.additionalRiderClassification == rhs.additionalRiderClassification)||((this.additionalRiderClassification!= null)&&this.additionalRiderClassification.equals(rhs.additionalRiderClassification))))&&((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension))))&&((this.deductAmt == rhs.deductAmt)||((this.deductAmt!= null)&&this.deductAmt.equals(rhs.deductAmt))))&&((this.reserveMethod == rhs.reserveMethod)||((this.reserveMethod!= null)&&this.reserveMethod.equals(rhs.reserveMethod))))&&((this.attachment == rhs.attachment)||((this.attachment!= null)&&this.attachment.equals(rhs.attachment))))&&((this.filedFormNumber == rhs.filedFormNumber)||((this.filedFormNumber!= null)&&this.filedFormNumber.equals(rhs.filedFormNumber))))&&((this.valuationSubSeries == rhs.valuationSubSeries)||((this.valuationSubSeries!= null)&&this.valuationSubSeries.equals(rhs.valuationSubSeries))))&&((this.issueDate == rhs.issueDate)||((this.issueDate!= null)&&this.issueDate.equals(rhs.issueDate))))&&((this.benefitCoordinationInd == rhs.benefitCoordinationInd)||((this.benefitCoordinationInd!= null)&&this.benefitCoordinationInd.equals(rhs.benefitCoordinationInd))))&&((this.riderTypeCode == rhs.riderTypeCode)||((this.riderTypeCode!= null)&&this.riderTypeCode.equals(rhs.riderTypeCode))))&&((this.lastPaidAmt == rhs.lastPaidAmt)||((this.lastPaidAmt!= null)&&this.lastPaidAmt.equals(rhs.lastPaidAmt))))&&((this.paidUpDate == rhs.paidUpDate)||((this.paidUpDate!= null)&&this.paidUpDate.equals(rhs.paidUpDate))))&&((this.periodicAmt == rhs.periodicAmt)||((this.periodicAmt!= null)&&this.periodicAmt.equals(rhs.periodicAmt))))&&((this.mortalityOrMorbidityTable == rhs.mortalityOrMorbidityTable)||((this.mortalityOrMorbidityTable!= null)&&this.mortalityOrMorbidityTable.equals(rhs.mortalityOrMorbidityTable))))&&((this.totAmt == rhs.totAmt)||((this.totAmt!= null)&&this.totAmt.equals(rhs.totAmt))))&&((this.reserveIntRate == rhs.reserveIntRate)||((this.reserveIntRate!= null)&&this.reserveIntRate.equals(rhs.reserveIntRate))))&&((this.benefitMode == rhs.benefitMode)||((this.benefitMode!= null)&&this.benefitMode.equals(rhs.benefitMode))))&&((this.policyExhibitStatus == rhs.policyExhibitStatus)||((this.policyExhibitStatus!= null)&&this.policyExhibitStatus.equals(rhs.policyExhibitStatus))))&&((this.waiverSignal == rhs.waiverSignal)||((this.waiverSignal!= null)&&this.waiverSignal.equals(rhs.waiverSignal))))&&((this.numberOfUnits == rhs.numberOfUnits)||((this.numberOfUnits!= null)&&this.numberOfUnits.equals(rhs.numberOfUnits))))&&((this.addlHospitalPeriod == rhs.addlHospitalPeriod)||((this.addlHospitalPeriod!= null)&&this.addlHospitalPeriod.equals(rhs.addlHospitalPeriod))))&&((this.productCode == rhs.productCode)||((this.productCode!= null)&&this.productCode.equals(rhs.productCode))))&&((this.benefitPct == rhs.benefitPct)||((this.benefitPct!= null)&&this.benefitPct.equals(rhs.benefitPct))))&&((this.covOption == rhs.covOption)||((this.covOption!= null)&&this.covOption.equals(rhs.covOption))))&&((this.formNo == rhs.formNo)||((this.formNo!= null)&&this.formNo.equals(rhs.formNo))))&&((this.riderFreeAmt == rhs.riderFreeAmt)||((this.riderFreeAmt!= null)&&this.riderFreeAmt.equals(rhs.riderFreeAmt))))&&((this.riderSysKey == rhs.riderSysKey)||((this.riderSysKey!= null)&&this.riderSysKey.equals(rhs.riderSysKey))))&&((this.totAmtLastAnn == rhs.totAmtLastAnn)||((this.totAmtLastAnn!= null)&&this.totAmtLastAnn.equals(rhs.totAmtLastAnn))));
    }

}
