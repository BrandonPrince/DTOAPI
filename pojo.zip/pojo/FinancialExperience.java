
package haj.com.astute.json.to.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "FinancialExperienceKey",
    "FinancialExperienceSysKey",
    "InvestmentType",
    "YearsOfInvestmentExperience",
    "Applicability",
    "OLifEExtension",
    "id",
    "DataRep"
})
@Generated("jsonschema2pojo")
public class FinancialExperience {

    @JsonProperty("FinancialExperienceKey")
    private FinancialExperienceKey financialExperienceKey;
    @JsonProperty("FinancialExperienceSysKey")
    private List<Object> financialExperienceSysKey = new ArrayList<>();
    @JsonProperty("InvestmentType")
    private InvestmentType investmentType;
    @JsonProperty("YearsOfInvestmentExperience")
    private Integer yearsOfInvestmentExperience;
    @JsonProperty("Applicability")
    private Applicability applicability;
    @JsonProperty("OLifEExtension")
    private List<Object> oLifEExtension = new ArrayList<>();
    @JsonProperty("id")
    private String id;
    @JsonProperty("DataRep")
    private String dataRep;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<>();

    @JsonProperty("FinancialExperienceKey")
    public FinancialExperienceKey getFinancialExperienceKey() {
        return financialExperienceKey;
    }

    @JsonProperty("FinancialExperienceKey")
    public void setFinancialExperienceKey(FinancialExperienceKey financialExperienceKey) {
        this.financialExperienceKey = financialExperienceKey;
    }

    public FinancialExperience withFinancialExperienceKey(FinancialExperienceKey financialExperienceKey) {
        this.financialExperienceKey = financialExperienceKey;
        return this;
    }

    @JsonProperty("FinancialExperienceSysKey")
    public List<Object> getFinancialExperienceSysKey() {
        return financialExperienceSysKey;
    }

    @JsonProperty("FinancialExperienceSysKey")
    public void setFinancialExperienceSysKey(List<Object> financialExperienceSysKey) {
        this.financialExperienceSysKey = financialExperienceSysKey;
    }

    public FinancialExperience withFinancialExperienceSysKey(List<Object> financialExperienceSysKey) {
        this.financialExperienceSysKey = financialExperienceSysKey;
        return this;
    }

    @JsonProperty("InvestmentType")
    public InvestmentType getInvestmentType() {
        return investmentType;
    }

    @JsonProperty("InvestmentType")
    public void setInvestmentType(InvestmentType investmentType) {
        this.investmentType = investmentType;
    }

    public FinancialExperience withInvestmentType(InvestmentType investmentType) {
        this.investmentType = investmentType;
        return this;
    }

    @JsonProperty("YearsOfInvestmentExperience")
    public Integer getYearsOfInvestmentExperience() {
        return yearsOfInvestmentExperience;
    }

    @JsonProperty("YearsOfInvestmentExperience")
    public void setYearsOfInvestmentExperience(Integer yearsOfInvestmentExperience) {
        this.yearsOfInvestmentExperience = yearsOfInvestmentExperience;
    }

    public FinancialExperience withYearsOfInvestmentExperience(Integer yearsOfInvestmentExperience) {
        this.yearsOfInvestmentExperience = yearsOfInvestmentExperience;
        return this;
    }

    @JsonProperty("Applicability")
    public Applicability getApplicability() {
        return applicability;
    }

    @JsonProperty("Applicability")
    public void setApplicability(Applicability applicability) {
        this.applicability = applicability;
    }

    public FinancialExperience withApplicability(Applicability applicability) {
        this.applicability = applicability;
        return this;
    }

    @JsonProperty("OLifEExtension")
    public List<Object> getOLifEExtension() {
        return oLifEExtension;
    }

    @JsonProperty("OLifEExtension")
    public void setOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
    }

    public FinancialExperience withOLifEExtension(List<Object> oLifEExtension) {
        this.oLifEExtension = oLifEExtension;
        return this;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    public FinancialExperience withId(String id) {
        this.id = id;
        return this;
    }

    @JsonProperty("DataRep")
    public String getDataRep() {
        return dataRep;
    }

    @JsonProperty("DataRep")
    public void setDataRep(String dataRep) {
        this.dataRep = dataRep;
    }

    public FinancialExperience withDataRep(String dataRep) {
        this.dataRep = dataRep;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public FinancialExperience withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(FinancialExperience.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("financialExperienceKey");
        sb.append('=');
        sb.append(((this.financialExperienceKey == null)?"<null>":this.financialExperienceKey));
        sb.append(',');
        sb.append("financialExperienceSysKey");
        sb.append('=');
        sb.append(((this.financialExperienceSysKey == null)?"<null>":this.financialExperienceSysKey));
        sb.append(',');
        sb.append("investmentType");
        sb.append('=');
        sb.append(((this.investmentType == null)?"<null>":this.investmentType));
        sb.append(',');
        sb.append("yearsOfInvestmentExperience");
        sb.append('=');
        sb.append(((this.yearsOfInvestmentExperience == null)?"<null>":this.yearsOfInvestmentExperience));
        sb.append(',');
        sb.append("applicability");
        sb.append('=');
        sb.append(((this.applicability == null)?"<null>":this.applicability));
        sb.append(',');
        sb.append("oLifEExtension");
        sb.append('=');
        sb.append(((this.oLifEExtension == null)?"<null>":this.oLifEExtension));
        sb.append(',');
        sb.append("id");
        sb.append('=');
        sb.append(((this.id == null)?"<null>":this.id));
        sb.append(',');
        sb.append("dataRep");
        sb.append('=');
        sb.append(((this.dataRep == null)?"<null>":this.dataRep));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.oLifEExtension == null)? 0 :this.oLifEExtension.hashCode()));
        result = ((result* 31)+((this.yearsOfInvestmentExperience == null)? 0 :this.yearsOfInvestmentExperience.hashCode()));
        result = ((result* 31)+((this.dataRep == null)? 0 :this.dataRep.hashCode()));
        result = ((result* 31)+((this.financialExperienceKey == null)? 0 :this.financialExperienceKey.hashCode()));
        result = ((result* 31)+((this.applicability == null)? 0 :this.applicability.hashCode()));
        result = ((result* 31)+((this.investmentType == null)? 0 :this.investmentType.hashCode()));
        result = ((result* 31)+((this.id == null)? 0 :this.id.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.financialExperienceSysKey == null)? 0 :this.financialExperienceSysKey.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof FinancialExperience) == false) {
            return false;
        }
        FinancialExperience rhs = ((FinancialExperience) other);
        return ((((((((((this.oLifEExtension == rhs.oLifEExtension)||((this.oLifEExtension!= null)&&this.oLifEExtension.equals(rhs.oLifEExtension)))&&((this.yearsOfInvestmentExperience == rhs.yearsOfInvestmentExperience)||((this.yearsOfInvestmentExperience!= null)&&this.yearsOfInvestmentExperience.equals(rhs.yearsOfInvestmentExperience))))&&((this.dataRep == rhs.dataRep)||((this.dataRep!= null)&&this.dataRep.equals(rhs.dataRep))))&&((this.financialExperienceKey == rhs.financialExperienceKey)||((this.financialExperienceKey!= null)&&this.financialExperienceKey.equals(rhs.financialExperienceKey))))&&((this.applicability == rhs.applicability)||((this.applicability!= null)&&this.applicability.equals(rhs.applicability))))&&((this.investmentType == rhs.investmentType)||((this.investmentType!= null)&&this.investmentType.equals(rhs.investmentType))))&&((this.id == rhs.id)||((this.id!= null)&&this.id.equals(rhs.id))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.financialExperienceSysKey == rhs.financialExperienceSysKey)||((this.financialExperienceSysKey!= null)&&this.financialExperienceSysKey.equals(rhs.financialExperienceSysKey))));
    }

}
